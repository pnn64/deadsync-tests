"""Run one explicit Python inspection/action through the existing Proxmox route."""
import argparse
import json
from pathlib import Path
import subprocess

HOST = 'root@192.168.1.79'

def run(code, *, guest=True, timeout=120, output=None):
    if guest:
        code = "\n".join([
            'import json,pathlib,subprocess',
            "row=next(r for r in json.loads(pathlib.Path('/root/deadsync-lua-20261119/fleet.json').read_bytes()) if r['vmid']==1503)",
            "assert row['ip']=='192.168.1.37'",
            "cmd=['ssh','-i','/root/deadsync-pass3-20261116/transfer-key','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=/root/deadsync-lua-20261119/fleet-known-hosts','-o','ConnectTimeout=10','parity@'+row['ip'],'python3','-']",
            'r=subprocess.run(cmd,input='+repr(code.encode())+',timeout='+repr(timeout)+')',
            'raise SystemExit(r.returncode)',
        ])
    return subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',HOST,'python3','-'],input=code.encode(),stdout=output,timeout=timeout+30)

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('script',type=Path)
    parser.add_argument('--host',action='store_true')
    parser.add_argument('--timeout',type=int,default=120)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.output:
        with args.output.open('xb') as out:
            result=run(args.script.read_text(encoding='utf-8'),guest=not args.host,timeout=args.timeout,output=out)
    else:
        result=run(args.script.read_text(encoding='utf-8'),guest=not args.host,timeout=args.timeout)
    raise SystemExit(result.returncode)
