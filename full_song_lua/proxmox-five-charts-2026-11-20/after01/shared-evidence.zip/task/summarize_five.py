"""Summarize retained five-chart evidence; never launch tests, captures or replays."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CIRCLES = "ccfbbe2824310517-c0001"
HASHES = {}


def digest(path):
    path = Path(path)
    stat = path.stat()
    key = (str(path.resolve()), stat.st_size, stat.st_mtime_ns)
    if key not in HASHES:
        with path.open("rb") as stream:
            HASHES[key] = hashlib.file_digest(stream, "sha256").hexdigest()
    return HASHES[key]


def ref(path):
    path = Path(path).resolve()
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def need(condition, message):
    if not condition:
        raise ValueError(message)


def check_file(path, expected):
    actual = ref(path)
    need(actual["sha256"] == expected["sha256"], f"SHA256 mismatch: {path}")
    if "bytes" in expected:
        need(actual["bytes"] == expected["bytes"], f"size mismatch: {path}")
    return actual


def validate_files(directory, execution):
    for name, expected in execution.get("files", {}).items():
        check_file(directory / name, expected)


def flags(data):
    return {key: value for key, value in data.items() if isinstance(value, bool)}


def field_counts(items):
    return dict(sorted(Counter(str(item.get("field", "<unspecified>")) for item in items).items()))


def query_summary(data):
    if data is None:
        return None
    result = {key: value for key, value in data.items() if not isinstance(value, (list, dict))}
    result.update({key + "_entries": len(value) for key, value in data.items() if isinstance(value, list)})
    return result


def read_replay(case_id, stage):
    directory = HERE / "replays" / case_id / stage
    execution = read(directory / "execution.json")
    need(execution.get("case_id") == case_id and execution.get("stage") == stage,
         f"replay receipt identity mismatch: {directory}")
    need(execution.get("finished_at") and isinstance(execution.get("exit_code"), int),
         f"incomplete replay: {directory}")
    validate_files(directory, execution)
    check_file(directory / "report.json", {"sha256": execution["report_sha256"]})
    command = execution["command"]
    archive = Path(command[command.index("--archive") + 1])
    check_file(archive, {"sha256": execution["archive_sha256"], "bytes": execution["archive_bytes"]})
    check_file(command[0], {"sha256": execution["binary_sha256"]})
    need(execution["build_binding"]["binaries"]["full_song_lua"]["sha256"] == execution["binary_sha256"],
         f"binary/build mismatch: {directory}")
    report = read(directory / "report.json")
    production = report.get("production_replay")
    need(isinstance(production, dict), f"missing production report: {directory}")
    need(report["fixture_sha256"] in {execution["archive_sha256"], execution.get("uncompressed_archive_sha256")},
         f"fixture/report mismatch: {directory}")
    diagnostic_mismatches = [item for item in report["mismatches"]
                             if item.get("execution_path") != "production-live-lua"]
    production_mismatches = production["mismatches"]
    need(len(report["mismatches"]) == len(diagnostic_mismatches) + len(production_mismatches),
         f"combined mismatch accounting changed: {directory}")
    diagnostic_stage = report["diagnostic_compared_stage_fields"]
    need(report["compared_stage_fields"] == diagnostic_stage + production["compared_stage_fields"],
         f"combined stage accounting changed: {directory}")
    diagnostic_errors = [item for item in report["errors"] if not item.startswith("production replay: ")]
    need(len(report["errors"]) == len(diagnostic_errors) + len(production["errors"]),
         f"combined error accounting changed: {directory}")
    diagnostic = {
        "native_frames": report["native_frames"], "replayed_frames": report["replayed_frames"],
        "checked_stage_samples": report["checked_stage_samples"], "compared_stage_fields": diagnostic_stage,
        "source_identity": report.get("source_identity"), "interactive": report["interactive"],
        "command_queries": query_summary(report.get("command_queries")),
        "retained_mismatch_entries": len(diagnostic_mismatches),
        "mismatch_fields": field_counts(diagnostic_mismatches), "mismatches": diagnostic_mismatches,
        "errors": diagnostic_errors,
        "pending_coverage": [item for item in report["pending_coverage"] if not item.startswith("production replay: ")],
    }
    production_summary = {key: production[key] for key in [
        "execution_path", "source_identity", "native_frames", "replayed_frames", "replayed_scenes",
        "checked_stage_samples", "compared_stage_fields", "interactive", "mismatches", "errors",
        "pending_coverage"] if key in production}
    production_summary.update({
        "flags": flags(production), "command_queries": query_summary(production.get("command_queries")),
        "retained_mismatch_entries": len(production_mismatches), "mismatch_fields": field_counts(production_mismatches),
    })
    return {
        "case_id": case_id, "stage": stage,
        "provenance": {"execution": ref(directory / "execution.json"),
                       "report": ref(directory / "report.json"), "receipt": execution},
        "execution_path": report["execution_path"], "acceptance_basis": report.get("acceptance_basis"),
        "root_flags": flags(report), "selected_description": report.get("selected_description"),
        "diagnostic": diagnostic, "production": production_summary,
        "combined": {"compared_stage_fields": report["compared_stage_fields"],
                     "retained_mismatch_entries": len(report["mismatches"]),
                     "mismatch_fields": field_counts(report["mismatches"]),
                     "errors": report["errors"], "pending_coverage": report["pending_coverage"]},
    }


def read_download(case, download_root, override=None):
    original_path = download_root / case["id"] / "download-receipt.json"
    path = override or original_path
    data = read(path)
    need(data.get("case_id") == case["id"], f"download identity mismatch: {path}")
    need(data["capture"].get("capture_validated") is True, f"native capture not validated: {path}")
    need(data["resource_receipt"]["service_result"] == "success" and data["resource_receipt"]["exit_status"] == "0",
         f"native capture unit did not succeed: {path}")
    for key in ("candidate", "evidence"):
        check_file(data[key]["path"], data[key])
    need(data["capture"]["candidate"]["sha256"] == data["candidate"]["sha256"],
         f"native candidate/download mismatch: {path}")
    phases = []
    original_provenance = None
    if "original_capture_resource_receipt" in data:
        original_provenance = check_file(original_path, {"sha256": data["original_download_receipt_sha256"]})
        original = read(original_path)
        need(original["resource_receipt"] == data["original_capture_resource_receipt"],
             f"original capture resource receipt differs: {path}")
        need(data["capture"].get("reused_native_trace") is True
             and data["capture"].get("native_capture_reexecuted") is False,
             f"recovery does not prove reuse of original native trace: {path}")
        phases.append({"phase": "native capture; wrapper validation failed",
                       "receipt": data["original_capture_resource_receipt"]})
        phases.append({"phase": "archive recovery; no native recapture", "receipt": data["resource_receipt"]})
    else:
        phases.append({"phase": "native capture and archive", "receipt": data["resource_receipt"]})
    resources = {
        "phases": phases,
        "memory_peak_max_bytes": max(int(phase["receipt"]["resource_usage"]["MemoryPeak"]) for phase in phases),
        "cpu_usage_sum_ns": sum(int(phase["receipt"]["resource_usage"]["CPUUsageNSec"]) for phase in phases),
        "original_download_receipt": original_provenance,
    }
    return {"provenance": ref(path), "receipt": data, "resources": resources}


def bind_runtime_commit(commit, source_files):
    if commit is None:
        return None
    need(re.fullmatch(r"[0-9a-fA-F]{7,40}", commit) is not None, "runtime commit must be a Git commit hash")
    resolved = subprocess.check_output(["git", "rev-parse", "--verify", commit + "^{commit}"],
                                       cwd=ROOT, text=True).strip()
    for name, expected in source_files.items():
        check_file(ROOT / name, {"sha256": expected})
    checked = subprocess.run(["git", "diff", "--quiet", resolved, "--", *source_files], cwd=ROOT)
    need(checked.returncode == 0, "current tested gameplay files differ from the supplied runtime commit")
    return {"commit": resolved, "source_files": source_files,
            "verification": "Working file SHA256 matches final build receipt; git diff versus commit is empty for those files."}


def read_regressions(final_dir, red_dir):
    green = read(final_dir / "execution.json")
    red = read(red_dir / "execution.json")
    need(green.get("finished_at") and green.get("source_unchanged") is True,
         "focused regression receipt is incomplete or source changed")
    check_file(final_dir / "output.log", {"sha256": green["output_sha256"]})
    check_file(Path(green["build"]) / "execution.json", {"sha256": green["build_execution_sha256"]})
    need(len(green["selected_tests"]) == len(green["results"]) == 46, "expected the 46-test focused receipt")
    need([item["name"] for item in green["results"]] == green["selected_tests"], "focused test identities changed")
    summaries = re.findall(r"test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;",
                           (final_dir / "output.log").read_text(encoding="utf-8"))
    need(len(summaries) == 46 and all(tuple(map(int, row)) == (1, 0, 0) for row in summaries),
         "focused output does not prove 46 individually executed passing tests")
    need(green["passed"] == 46 and green["failed"] == 0 and all(row["exit_code"] == 0 for row in green["results"]),
         "focused regressions failed")
    need(red["exit_code"] == 101 and red.get("source_unchanged_during_command") is True,
         "red regression receipt is not the retained expected test failure")
    validate_files(red_dir, red)
    red_output = (red_dir / "stdout.log").read_text(encoding="utf-8")
    red_error = (red_dir / "stderr.log").read_text(encoding="utf-8")
    need("0 passed; 1 failed; 0 ignored" in red_output and "Some(Held)" in red_error and "right: None" in red_error,
         "red regression failure has different cause")
    return {
        "red": {"provenance": ref(red_dir / "execution.json"), "receipt": red,
                "stdout": red_output, "stderr": red_error,
                "test": "runtime_regression_tests::autoplay_short_hold_feedback_waits_for_next_player_update",
                "scope": "Initial short-hold regression, before the later-crossed-tap strengthening."},
        "final": {"provenance": ref(final_dir / "execution.json"), "receipt": green,
                  "ignored": 0, "executed": 46, "output": ref(final_dir / "output.log")},
    }


def table(headers, rows):
    def cell(value):
        if value is None:
            return "not reported"
        if isinstance(value, bool):
            return str(value).lower()
        return str(value).replace("|", "\\|").replace("\n", " ")
    return ["| " + " | ".join(map(cell, headers)) + " |",
            "| " + " | ".join("---" for _ in headers) + " |"] + [
                "| " + " | ".join(map(cell, row)) + " |" for row in rows]


def read_formatting(path):
    receipt = read(path)
    need(receipt.get("checks_were_read_only") is True and receipt.get("source_modified") is False,
         "formatting receipt does not confirm unchanged sources")
    checks = {row["label"]: row for row in receipt["results"]}
    need(checks["package_format_check"]["exit_code"] == 1
         and checks["standalone_include_format_check"]["exit_code"] == 1,
         "recorded formatting outcomes changed")
    blob = "1f69fd696cce345682dc4c727cf3c94eb809f4bd"
    need(checks["standalone_include_format_check"]["output"].count(blob) == 2,
         "retained existing-file identity proof is missing")
    return {"provenance": ref(path), "receipt": receipt,
            "format_gate_passed": False,
            "package_check_existing_file": {"path": "crates/deadsync-gameplay/tests/held_lane_performance.rs",
                                            "before_git_blob": blob, "current_git_blob": blob,
                                            "reported_difference": "existing extra blank line"},
            "standalone_include_check": {"format_gate_passed": False,
                                          "scope": "five include! source fragments checked explicitly",
                                          "reported_difference": "compact formatting differences"},
            "scope_note": "Recorded read-only checks; not rerun for this report. Cargo fmt does not traverse include! fragments. Neither exit-1 result is a passing format gate; parity acceptance is recorded separately."}


def frames(run):
    return " / ".join(str(run[path][key]) for path, key in [
        ("diagnostic", "native_frames"), ("diagnostic", "replayed_frames"), ("production", "replayed_frames")])


def render(data):
    rows = data["cases"]
    lines = [
        "# Five-chart song-Lua coverage", "",
        f"Generated {data['created_at']}. Final replay stage: {data['final_stage']}.", "",
        "Exactly five previously failing song charts were selected. Each fresh native archive was replayed "
        "through diagnostic Lua and production gameplay paths. The original Circles before/after reference "
        "uses the same selected chart and is excluded from the five-chart totals.", "",
        "Original mismatch entries come from the failure ledger. Fresh native frame cadence can differ, "
        "so a zero fresh-baseline count does not establish reproduction of the old timing failure. "
        "Only the original Circles reference was replayed before and after this fix; the other four original "
        "failure counts are historical evidence. The sum of 136 historical entries is not a claim that all "
        "136 were replayed and removed. Mismatch counts are retained report entries; draw mismatch counters "
        "are reported separately.", "",
    ]
    lines += table(["Chart", "Case", "Original frames", "Original entries", "Fresh baseline entries",
                    "Final entries", "Final errors", "Final native / D / P frames"],
                   [[row["label"], row["id"], row["prior"]["native_frames"], row["prior"]["mismatch_count"],
                     row["baseline"]["combined"]["retained_mismatch_entries"],
                     row["final"]["combined"]["retained_mismatch_entries"],
                     len(row["final"]["combined"]["errors"]), frames(row["final"])] for row in rows])
    lines += ["", "All five select chart index 1, dance versus, Challenge. Exact identities:", ""]
    lines += table(["Chart", "Native title", "Source simfile", "Selected description"],
                   [[row["label"], row["native"]["receipt"]["capture"]["archive_entry"]["title"],
                     row["native"]["receipt"]["capture"]["archive_entry"]["source_simfile"],
                     row["final"]["selected_description"]] for row in rows])
    lines += ["", "D means diagnostic; P means production. Native frames count once per archive. "
              "Each path performs its own stage, draw, vertex and text comparisons. "
              "Production command/query instrumentation is pending, so its query count is unavailable.", ""]
    measured = []
    for row in rows:
        for key, tag in [("diagnostic", "D"), ("production", "P")]:
            run = row["final"][key]
            inter = run["interactive"]
            query = run["command_queries"]
            measured.append([
                row["label"], tag, run["compared_stage_fields"], run["checked_stage_samples"],
                inter.get("draw_samples_compared"), inter.get("submitted_vertices_compared"),
                inter.get("live_text_samples_compared"),
                f"{inter.get('render_random_inputs_replayed')} / {inter.get('render_random_inputs_captured')}",
                None if query is None else f"{query.get('actual_count')} / {query.get('native_count')}",
                inter.get("input_events_replayed"), inter.get("draw_mismatches"),
                run["retained_mismatch_entries"], len(run["errors"])])
    lines += table(["Chart", "Path", "Stage fields", "Stage samples", "Draws", "Vertices", "Text",
                    "Random replayed / captured", "Queries actual / native", "Inputs", "Draw mismatches",
                    "Retained entries", "Errors"], measured)
    lines += ["", "Five fresh archive totals:", ""]
    lines += table(["Measure", "Diagnostic", "Production"],
                   [[key, data["totals"]["diagnostic"][key], data["totals"]["production"][key]]
                    for key in data["totals"]["diagnostic"]])
    lines += ["", "Acceptance flags are copied literally. Root archive_accepted is the combined comparator "
              "decision; nested production archive_accepted is a separate, stricter flag. "
              "Neither replaces the production, whole-song or pixel parity proof flags. "
              "All root and nested booleans are retained in coverage.json.", ""]
    lines += table(["Chart", "Root accepted", "D checks", "P checks", "Root interactive checks",
                    "P accepted", "Production parity", "Whole-song parity", "Pixel parity"],
                   [[row["label"], row["final"]["root_flags"].get("archive_accepted"),
                     row["final"]["root_flags"].get("diagnostic_replay_checks_passed"),
                     row["final"]["root_flags"].get("production_gameplay_checks_passed"),
                     row["final"]["root_flags"].get("interactive_checks_passed"),
                     row["final"]["production"]["flags"].get("archive_accepted"),
                     row["final"]["root_flags"].get("production_parity_proven"),
                     row["final"]["root_flags"].get("whole_song_parity_proven"),
                     row["final"]["root_flags"].get("pixel_parity_proven")] for row in rows])
    history = data["historical_circles"]
    lines += ["", "## Original Circles reference", "",
              "Both runs use compressed archive SHA256 "
              + history["baseline"]["provenance"]["receipt"]["archive_sha256"]
              + ". This preserves the original frame sequence.", ""]
    lines += table(["Run", "Native / D / P frames", "D entries", "P entries", "Errors", "Root accepted"],
                   [[name, frames(run), run["diagnostic"]["retained_mismatch_entries"],
                     run["production"]["retained_mismatch_entries"], len(run["combined"]["errors"]),
                     run["root_flags"].get("archive_accepted")]
                    for name, run in [("Baseline", history["baseline"]), ("Final", history["final"])]])
    lines += [
        "", "Native Player.cpp refills autoplay rolls, processes active holds, then crosses autoplay rows. "
        "The fix puts live dance autoplay hold processing before new row judgments and removes the global "
        "row-triggered settlement path. Physical input and recorded input replay retain their existing "
        "event-time integration; Pump retains its checkpoint path. "
        "Same-column active-hold replacement retains immediate replacement settlement; these five charts do "
        "not establish general parity for that separate edge.",
        "", "## Regression evidence", "",
        "The initial full-frame short-hold regression failed before the fix: Some(Held) was observed where "
        "None was required at the end of the update that crossed the hold's head and tail "
        "(1 failed, 0 passed; cargo exit 101). "
        "The final test adds a later crossed tap and covers Single and Versus. "
        "The focused selection executed 46 individual tests: 46 passed, 0 failed, 0 ignored. "
        "The roll regression runs full gameplay frames for dance and Pump at four rates. "
        "The final replay build is bound to the same five gameplay source hashes as the focused test receipt.",
        "", "## Recorded formatting checks", "",
        "The package check (cargo fmt -p deadsync-gameplay -- --check) exited 1 for an existing extra blank "
        "line in crates/deadsync-gameplay/tests/held_lane_performance.rs. Its before/current Git blob is "
        "1f69fd696cce345682dc4c727cf3c94eb809f4bd, and the recorded working tree was clean. "
        "The standalone rustfmt check of the five include! fragments also exited 1 with compact formatting "
        "differences. Cargo fmt does not traverse these include! fragments. Both checks were read only, "
        "and neither is a passing formatting gate. These formatting results are separate from the parity "
        "comparison outcomes above. Retained standalone output may be truncated; the receipt records that "
        "limitation. No formatting command was rerun to create this report.",
        "", "## Resource use and cleanup", "",
    ]
    resource_rows = []
    for row in rows:
        for phase in row["native"]["resources"]["phases"]:
            resource = phase["receipt"]
            use = resource["resource_usage"]
            resource_rows.append([row["label"], phase["phase"], use.get("MemoryPeak"), use.get("CPUUsageNSec"),
                                  use.get("MemoryMax"), use.get("MemorySwapMax"),
                                  use.get("CPUQuotaPerSecUSec"), resource.get("service_result")])
    lines += table(["Chart", "Phase", "Unit memory peak (bytes)", "CPU (ns)", "Memory limit (bytes)",
                    "Swap limit (bytes)", "CPU quota / second", "Unit result"], resource_rows)
    lines += ["", "Maximum memory peak across each chart's capture and any recovery stages:", ""]
    lines += table(["Chart", "Maximum unit peak (bytes)", "Sum of phase CPU (ns)"],
                   [[row["label"], row["native"]["resources"]["memory_peak_max_bytes"],
                     row["native"]["resources"]["cpu_usage_sum_ns"]] for row in rows])
    for row in rows:
        if row["native"]["resources"]["original_download_receipt"] is not None:
            lines += ["", f"{row['label']}: native capture completed, but the local wrapper rejected the "
                      "legitimate empty drawable sample list. The corrected validator allows zero submitted "
                      "draw samples while requiring captured drawable frames, native drawable vertices support, "
                      "and zero capture drops. The existing native trace was validated and archived; native "
                      "capture was not rerun. The original failed receipt remains preserved. The capture "
                      "and recovery phase resource receipts above are separate, and the maximum includes both.", ""]
    cleanup = data["cleanup"]["receipt"]
    lines += [
        "", "Unit peaks include capture and archive work. Captures are serialized under the retained plan's "
        "200% CPU and 6 GiB memory limit with swap disabled.", "",
        f"Confirmed obsolete guest intermediates: {cleanup['deleted_files']:,} files deleted, "
        f"{cleanup['deleted_logical_bytes']:,} logical bytes and {cleanup['deleted_allocated_bytes']:,} "
        f"allocated bytes; {cleanup['retained_files_unchanged']} retained files unchanged. "
        f"Guest free space rose from {cleanup['disk_before']['free']:,} to "
        f"{cleanup['disk_after']['free']:,} bytes (gain {data['cleanup']['free_space_gain_bytes']:,}). "
        "This is the guest filesystem delta, not a host-wide reclamation claim.", "",
        f"{len(data['capture_attempts'])} completed orchestration attempt receipts are preserved in coverage.json, "
        "including failed attempts before successful final downloads.", "",
        "## Exact remaining coverage", "",
        "The following strings are copied from final reports. Pending coverage is distinct from an implemented "
        "comparison failure. Combined lists and baseline/original-reference lists are retained verbatim in coverage.json.", "",
    ]
    for row in rows:
        lines += [f"### {row['label']}", "", "Diagnostic/report pending coverage:", ""]
        lines += [f"- {value}" for value in row["final"]["diagnostic"]["pending_coverage"]] or ["- None."]
        lines += ["", "Nested production pending coverage:", ""]
        lines += [f"- {value}" for value in row["final"]["production"]["pending_coverage"]] or ["- None."]
        if row["final"]["combined"]["errors"] or row["final"]["combined"]["retained_mismatch_entries"]:
            failures = {"mismatches": row["final"]["diagnostic"]["mismatches"],
                        "production_mismatches": row["final"]["production"]["mismatches"],
                        "errors": row["final"]["combined"]["errors"]}
            lines += ["", "Remaining implemented-comparison failures:", "", "~~~json",
                      json.dumps(failures, indent=2), "~~~"]
        lines.append("")
    lines += ["## Provenance", "",
              f"- Native oracle identity: {json.dumps(data['native_oracle'], sort_keys=True)}.",
              f"- Selection SHA256: {data['selection']['sha256']}.",
              f"- Failure ledger: {data['source_ledger']['path']}; SHA256 {data['source_ledger']['sha256']}.",
              f"- Final replay binary SHA256: {data['final_binary_sha256']}.",
              f"- Summarizer SHA256: {data['summarizer']['sha256']}.",
              "- Exact report, execution, archive, native evidence, build and source hashes are in coverage.json.", ""]
    if data["runtime_commit_binding"] is not None:
        lines += [f"Runtime fix commit: {data['runtime_commit_binding']['commit']}. Its five gameplay files "
                  "match the final replay and focused regression source hashes.", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", default="after01")
    parser.add_argument("--baseline", default="baseline")
    parser.add_argument("--historical-baseline", default="historical-baseline")
    parser.add_argument("--historical-final", help="Defaults to historical-<stage>.")
    parser.add_argument("--download-root", type=Path, default=HERE / "download")
    parser.add_argument("--download-override", action="append", default=[], metavar="CASE=PATH",
                        help="Use a recovery download receipt without replacing the preserved failed receipt.")
    parser.add_argument("--regression-dir", type=Path, default=HERE / "hold-order-regressions")
    parser.add_argument("--red-dir", type=Path,
                        default=ROOT / "target/song-lua-parity-20261120/hold-order-before-valid-20261120")
    parser.add_argument("--extra-evidence", type=Path, action="append", default=[])
    parser.add_argument("--runtime-commit", help="Optional committed runtime fix; verify its five tested files.")
    parser.add_argument("--out", type=Path, help="New output subdirectory inside this ignored task directory.")
    parser.add_argument("--check-only", action="store_true", help="Validate evidence without writing reports.")
    args = parser.parse_args()
    historical_final = args.historical_final or "historical-" + args.stage
    selection_path = HERE / "selection.json"
    selection = read(selection_path)
    cases = selection["cases"]
    need(len(cases) == 5 and len({row["id"] for row in cases}) == 5,
         "selection must contain exactly five distinct actual song charts")
    overrides = {}
    for override in args.download_override:
        need("=" in override, "download override must be CASE=PATH")
        case_id, path = override.split("=", 1)
        need(case_id in {row["id"] for row in cases} and case_id not in overrides,
             f"unknown or duplicate download override: {case_id}")
        overrides[case_id] = Path(path)
    required = [HERE / "cleanup-completed.json", HERE / "build-intermediates-inspected.json",
                HERE / "formatting-checks.json",
                args.regression_dir / "execution.json", args.regression_dir / "output.log",
                args.red_dir / "execution.json", args.red_dir / "stdout.log", args.red_dir / "stderr.log"]
    for case in cases:
        required.append(overrides.get(case["id"], args.download_root / case["id"] / "download-receipt.json"))
        for stage in (args.baseline, args.stage):
            required += [HERE / "replays" / case["id"] / stage / name
                         for name in ("execution.json", "report.json", "summary.json")]
    for stage in (args.historical_baseline, historical_final):
        required += [HERE / "replays" / CIRCLES / stage / name
                     for name in ("execution.json", "report.json", "summary.json")]
    required.extend(args.extra_evidence)
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        print(json.dumps({"ready": False, "missing": missing, "reports_written": False}, indent=2))
        return 2
    regressions = read_regressions(args.regression_dir, args.red_dir)
    formatting = read_formatting(HERE / "formatting-checks.json")
    result_cases = []
    for case in cases:
        native = read_download(case, args.download_root, overrides.get(case["id"]))
        baseline = read_replay(case["id"], args.baseline)
        final = read_replay(case["id"], args.stage)
        for run in (baseline, final):
            receipt = run["provenance"]["receipt"]
            need(receipt["archive_sha256"] == native["receipt"]["candidate"]["sha256"],
                 f"fresh baseline/final archive differs: {case['id']}")
            need(receipt.get("download_receipt_sha256") == native["provenance"]["sha256"],
                 f"download receipt binding differs: {case['id']}")
            need(run["diagnostic"]["native_frames"] == native["receipt"]["capture"]["counts"]["update_frames"]
                 == run["production"]["native_frames"], f"native frame counts disagree: {case['id']}")
        source_files = final["provenance"]["receipt"]["build_binding"]["source_identity"]["source_files"]
        for filename, expected in regressions["final"]["receipt"]["source_sha256"].items():
            need(source_files.get("crates/deadsync-gameplay/src/" + filename) == expected,
                 f"final replay/regression source differs: {case['id']}: {filename}")
        prior = dict(case["prior_replay"])
        prior["native_frames"] = case["prior_capture"]["native_frames"]
        result_cases.append({"id": case["id"], "label": case["label"], "slug": case["slug"],
                             "source_simfile_absolute": case["source_simfile_absolute"],
                             "prior": prior, "native": native, "baseline": baseline, "final": final})
        print(json.dumps({"read": case["id"], "final_mismatches": final["combined"]["retained_mismatch_entries"],
                          "final_errors": len(final["combined"]["errors"])}), flush=True)
    historical = {"baseline": read_replay(CIRCLES, args.historical_baseline),
                  "final": read_replay(CIRCLES, historical_final)}
    need(historical["baseline"]["provenance"]["receipt"]["archive_sha256"]
         == historical["final"]["provenance"]["receipt"]["archive_sha256"],
         "historical Circles before/after archive differs")
    final_binary = result_cases[0]["final"]["provenance"]["receipt"]["binary_sha256"]
    need(all(row["final"]["provenance"]["receipt"]["binary_sha256"] == final_binary for row in result_cases)
         and historical["final"]["provenance"]["receipt"]["binary_sha256"] == final_binary,
         "final replays do not use the same binary")
    cleanup_path = HERE / "cleanup-completed.json"
    cleanup = read(cleanup_path)
    check_file(HERE / "build-intermediates-inspected.json", {"sha256": cleanup["inspection_sha256"]})
    check_file(selection["source_ledger"]["path"], selection["source_ledger"])
    check_file(selection["source_snapshot"]["path"], selection["source_snapshot"])
    source_files = result_cases[0]["final"]["provenance"]["receipt"]["build_binding"]["source_identity"]["source_files"]
    runtime_binding = bind_runtime_commit(args.runtime_commit, source_files)
    attempts = []
    for path in sorted((HERE / "executions").rglob("execution.json")):
        receipt = read(path)
        if receipt.get("finished_at"):
            attempts.append({"provenance": ref(path), "receipt": receipt})
    aggregate_keys = ["native_frames", "replayed_frames", "checked_stage_samples", "compared_stage_fields"]
    interactive_keys = ["draw_samples_compared", "submitted_vertices_compared", "live_text_samples_compared",
                        "input_events_replayed", "render_random_inputs_replayed", "render_random_inputs_captured",
                        "unreplayed_render_random_inputs", "draw_mismatches",
                        "typed_equal_backing_aft_uv_samples_compared",
                        "uncompared_owned_immediate_draws", "uncompared_owned_normal_draws"]
    totals = {}
    for lane in ("diagnostic", "production"):
        total = {key: sum(row["final"][lane][key] for row in result_cases) for key in aggregate_keys}
        total.update({key: sum(row["final"][lane]["interactive"].get(key, 0) for row in result_cases)
                      for key in interactive_keys})
        for key in ("native_count", "actual_count"):
            queries = [row["final"][lane]["command_queries"] for row in result_cases]
            total["command_queries_" + key] = (
                sum(query[key] for query in queries)
                if all(query is not None and key in query for query in queries) else None)
        total["retained_mismatch_entries"] = sum(row["final"][lane]["retained_mismatch_entries"] for row in result_cases)
        total["errors"] = sum(len(row["final"][lane]["errors"]) for row in result_cases)
        totals[lane] = total
    data = {
        "schema_version": 1, "created_at": datetime.now(timezone.utc).isoformat(),
        "scope": "Five selected actual charts only; original Circles is the same selected chart.",
        "final_stage": args.stage, "baseline_stage": args.baseline,
        "selection": ref(selection_path), "source_ledger": selection["source_ledger"],
        "source_snapshot": selection["source_snapshot"], "capture_settings": selection["capture_settings"],
        "summarizer": ref(__file__), "final_binary_sha256": final_binary,
        "runtime_commit_binding": runtime_binding,
        "native_oracle": {
            key: sorted({row["native"]["receipt"]["capture"][key] for row in result_cases})
            for key in ("harness_commit", "harness_sha256", "native_revision")},
        "native_resource_maximum_peak_bytes": max(row["native"]["resources"]["memory_peak_max_bytes"]
                                                  for row in result_cases),
        "cases": result_cases, "historical_circles": historical, "regressions": regressions, "totals": totals,
        "formatting": formatting,
        "original_ledger_retained_mismatch_entries": sum(row["prior"]["mismatch_count"] for row in result_cases),
        "fresh_baseline_retained_mismatch_entries": sum(row["baseline"]["combined"]["retained_mismatch_entries"] for row in result_cases),
        "cleanup": {"provenance": ref(cleanup_path), "receipt": cleanup,
                    "free_space_gain_bytes": cleanup["disk_after"]["free"] - cleanup["disk_before"]["free"],
                    "scope_note": "Guest filesystem delta; not host-wide reclamation."},
        "capture_attempts": attempts,
        "extra_evidence": [{"provenance": ref(path), "receipt": read(path)} for path in args.extra_evidence],
        "limitations": [
            "Root archive acceptance and nested production acceptance are separate literal report flags.",
            "Production command/query counts are unavailable while that instrumentation is pending.",
            "Mismatch arrays contain retained entries; uncapped draw_mismatches counters are separate.",
            "Native cadence differs across captures; ledger failures are separate from fresh baseline results.",
            "Same-column hold replacement settlement is an existing edge outside general parity claims.",
            "Implemented-check acceptance does not imply full application, whole-song or pixel proof.",
        ],
    }
    data["all_five_implemented_checks_passed"] = all(
        row["final"]["root_flags"].get("diagnostic_replay_checks_passed") is True
        and row["final"]["root_flags"].get("production_gameplay_checks_passed") is True
        and row["final"]["root_flags"].get("archive_accepted") is True
        and row["final"]["combined"]["retained_mismatch_entries"] == 0
        and not row["final"]["combined"]["errors"]
        and all(row["final"][lane]["interactive"]["draw_mismatches"] == 0 for lane in ("diagnostic", "production"))
        for row in result_cases)
    if args.check_only:
        print(json.dumps({"ready": True, "reports_written": False,
                          "all_five_implemented_checks_passed": data["all_five_implemented_checks_passed"],
                          "totals": totals}, indent=2))
        return 0
    output = (args.out or HERE / ("coverage-" + args.stage)).resolve()
    need(output.is_relative_to(HERE.resolve()) and output != HERE.resolve(),
         "output must be a new subdirectory of the ignored task directory")
    need(not output.exists(), f"refusing to overwrite evidence directory: {output}")
    json_text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    markdown = render(data)
    output.mkdir()
    (output / "coverage.json").write_text(json_text, encoding="utf-8")
    (output / "coverage.md").write_text(markdown, encoding="utf-8")
    print(json.dumps({"ready": True, "reports_written": True,
                      "coverage_json": ref(output / "coverage.json"),
                      "coverage_md": ref(output / "coverage.md"),
                      "all_five_implemented_checks_passed": data["all_five_implemented_checks_passed"]}, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError) as error:
        print(json.dumps({"ready": False, "error": str(error), "reports_written": False}, indent=2), file=sys.stderr)
        raise SystemExit(2)

