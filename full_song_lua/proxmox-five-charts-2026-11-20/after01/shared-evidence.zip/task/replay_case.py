"""Replay only a selected chart and retain source/build/report provenance."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=ROOT/'target/song-lua-parity-20261120/retained-binaries-after07'
BASE_SHA='69fe4fb89667c2a41ac4b80f589b0722b37fb72c197f50ac09948337271ac691'

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def write(path,value):
    with Path(path).open('x',encoding='utf-8') as output:
        json.dump(value,output,indent=2,ensure_ascii=False)
        output.write('\n')

def summarize(report):
    prod=report.get('production_replay') or {}
    fields=['native_frames','replayed_frames','archive_accepted','diagnostic_replay_checks_passed',
        'production_gameplay_checks_passed','whole_song_parity_proven','production_parity_proven',
        'pixel_parity_proven','checked_stage_samples','compared_stage_fields','diagnostic_compared_stage_fields',
        'execution_path','production_preparation_exercised','capture_completed_gameplay']
    result={k:report.get(k) for k in fields}
    result.update(mismatch_count=len(report.get('mismatches',[])),errors=report.get('errors',[]),
        mismatch_fields={},first_mismatches=report.get('mismatches',[])[:3],
        pending_coverage=report.get('pending_coverage',[]),production_pending_coverage=prod.get('pending_coverage',[]))
    for row in report.get('mismatches',[]):
        name=row.get('field','unknown')
        result['mismatch_fields'][name]=result['mismatch_fields'].get(name,0)+1
    draw_fields=['draw_samples_compared','submitted_vertices_compared','draw_mismatches','live_text_samples_compared',
        'input_events_replayed','render_random_inputs_replayed','render_random_inputs_captured']
    result['diagnostic_draws']={k:report.get('interactive',{}).get(k) for k in draw_fields}
    result['production_draws']={k:prod.get('interactive',{}).get(k) for k in draw_fields}
    result['production_stage_fields']=prod.get('compared_stage_fields')
    result['production_errors']=prod.get('errors',[])
    result['production_mismatch_count']=len(prod.get('mismatches',[]))
    result['production_archive_accepted']=prod.get('archive_accepted')
    result['command_queries']={k:report.get('command_queries',{}).get(k) for k in ['compared','native_count','actual_count']}
    result['uncompared_queries']=len(report.get('command_queries',{}).get('uncompared_actual',[]))
    return result

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('case_id')
    parser.add_argument('--stage',required=True)
    parser.add_argument('--binary',type=Path)
    parser.add_argument('--binding',type=Path)
    parser.add_argument('--download-receipt',type=Path)
    args=parser.parse_args()
    selection=json.loads((HERE/'selection.json').read_bytes())
    case=next(c for c in selection['cases'] if c['id']==args.case_id)
    download_path=args.download_receipt or HERE/'download'/args.case_id/'download-receipt.json'
    receipt=json.loads(download_path.read_bytes())
    assert receipt['case_id']==args.case_id
    assert receipt['capture']['capture_validated'] and receipt['resource_receipt']['service_result']=='success'
    archive=Path(receipt['candidate']['path'])
    assert sha(archive)==receipt['candidate']['sha256'] and archive.stat().st_size==receipt['candidate']['bytes']
    binary=args.binary or BASE/'full_song_lua.exe'
    binding_path=args.binding or BASE/'identity.json'
    binding=json.loads(binding_path.read_bytes())
    binary_sha=sha(binary)
    assert binary_sha==binding['binaries']['full_song_lua']['sha256']
    if args.binary is None:assert binary_sha==BASE_SHA
    folder=HERE/'replays'/case['id']/args.stage
    folder.mkdir(parents=True,exist_ok=False)
    report_path=folder/'report.json'
    command=[str(binary),'--archive',str(archive),'--report',str(report_path),'--production']
    invocation={'case_id':case['id'],'label':case['label'],'stage':args.stage,'command':command,
        'started_at':dt.datetime.now(dt.timezone.utc).isoformat(),'cwd':str(ROOT),
        'binary_sha256':binary_sha,'build_binding':binding,'build_binding_sha256':sha(binding_path),
        'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
        'download_receipt_path':str(download_path.resolve()),
        'download_receipt_sha256':sha(download_path),
        'baseline_runtime_commit':'af6a6c9e045f5dfb13abe38bd4eb58d7326f2e26' if args.binary is None else None,
        'timeout_seconds':case['original_job']['replay_timeout']}
    write(folder/'invocation.json',invocation)
    started=time.monotonic()
    with (folder/'stdout.log').open('xb') as out,(folder/'stderr.log').open('xb') as err:
        try:
            run=subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,timeout=invocation['timeout_seconds'])
            invocation['exit_code']=run.returncode
        except subprocess.TimeoutExpired:
            invocation.update(exit_code=None,timed_out=True)
    invocation.update(finished_at=dt.datetime.now(dt.timezone.utc).isoformat(),runtime_seconds=time.monotonic()-started)
    if report_path.exists():
        report=json.loads(report_path.read_bytes())
        summary=summarize(report)
        write(folder/'summary.json',summary)
        invocation['report_sha256']=sha(report_path)
        invocation['summary_sha256']=sha(folder/'summary.json')
    else:summary={'report_missing':True}
    invocation['files']={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in folder.iterdir() if p.is_file()}
    write(folder/'execution.json',invocation)
    concise={k:v for k,v in summary.items() if k not in ['first_mismatches','pending_coverage','production_pending_coverage']}
    print(json.dumps({'case_id':case['id'],'label':case['label'],'stage':args.stage,'exit_code':invocation['exit_code'],
        'runtime_seconds':invocation['runtime_seconds'],'summary':concise}),flush=True)
    return invocation['exit_code'] if invocation['exit_code'] is not None else 124

if __name__=='__main__':raise SystemExit(main())
