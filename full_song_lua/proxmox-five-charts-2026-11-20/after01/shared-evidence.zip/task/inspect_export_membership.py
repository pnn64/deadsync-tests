"""Read the five selected archives and report exact omitted source inventory entries."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import publish_five as publisher

plan = publisher.load(publisher.TASK / 'capture-plan.json')
exporter = subprocess.check_output(['git', 'show', publisher.HARNESS_COMMIT + ':src/song_lua_archive.rs'], cwd='C:/GitHub/itgmania-harness')
print(json.dumps({'exporter_commit': publisher.HARNESS_COMMIT, 'exporter_source_sha256': hashlib.sha256(exporter).hexdigest()}), flush=True)
for case in plan['cases']:
    execution = publisher.load(publisher.TASK / 'replays' / case['id'] / 'after01/execution.json')
    receipt = publisher.load(execution.get('download_receipt_path', publisher.TASK / 'download' / case['id'] / 'download-receipt.json'))
    candidate = Path(receipt['candidate']['path'])
    manifest = publisher.archive_manifest(candidate)
    prefix = PurePosixPath(case['original_job']['source_simfile']).parent
    source = {'song/' + PurePosixPath(row['path']).relative_to(prefix).as_posix(): row for row in case['files']}
    authored = {row['path'] for row in manifest['files'] if row['path'].startswith('song/') and not row['path'].startswith('song/__')}
    excluded = [{**source[name], 'archive_member': name} for name in sorted(set(source) - authored)]
    omitted_names = {row['archive_member'][5:] for row in excluded}
    refs = {'omitted_asset_matches': [row for row in manifest['required_assets'] if row.get('local_path') in omitted_names],
        'omitted_lua_matches': [name for name in manifest['lua_closure']['files'] if name[5:] in omitted_names]}
    native_dependency_evidence = None
    if excluded:
        with tarfile.open(candidate, 'r|') as archive:
            for member in archive:
                if member.name == manifest['chart']['trace']:
                    native = json.load(archive.extractfile(member))
                    break
        reads = native.get('file_reads', [])
        queries = native.get('directory_queries', [])
        read_dependencies = {row['path'][6:] for row in reads if row.get('exists') is True and row.get('generated') is not True
            and isinstance(row.get('path'), str) and row['path'].startswith('song:/')}
        listed = {path[6:] for row in queries for path in row.get('files', []) if isinstance(path, str) and path.startswith('song:/')}
        native_dependency_evidence = {'file_reads_count': len(reads), 'directory_queries_count': len(queries),
            'omitted_read_matches': sorted(omitted_names & read_dependencies), 'omitted_listing_matches': sorted(omitted_names & listed)}
        del native
    print(json.dumps({'case_id': case['id'], 'selected_simfile': case['original_job']['source_simfile'],
        'source_files': len(source), 'exported_authored_files': len(authored), 'excluded': excluded,
        'extra': sorted(authored - set(source)), 'dependencies': refs if excluded else None,
        'native_dependency_evidence': native_dependency_evidence}), flush=True)
