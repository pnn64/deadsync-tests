"""Verify the exact previously failing Circles update window, within the selected five."""
import argparse
import datetime as dt
import json
from pathlib import Path
import subprocess
import time
from replay_case import HERE,ROOT,BASE,BASE_SHA,sha,write,summarize

parser=argparse.ArgumentParser()
parser.add_argument('--stage',required=True)
parser.add_argument('--binary',type=Path)
parser.add_argument('--binding',type=Path)
args=parser.parse_args()
case_id='ccfbbe2824310517-c0001'
archive=Path('C:/GitHub/deadsync-lua-fleet-20261119/target/proxmox-song-lua-20261119/circles-query-diagnosis-20261119T052915.449930Z/artifacts/1467b5bccb06fe84d622d5590f5ee732dfbd6ed0b4fcbf9af7036f37d9b2a38e.tar.zst')
expected='1467b5bccb06fe84d622d5590f5ee732dfbd6ed0b4fcbf9af7036f37d9b2a38e'
assert sha(archive)==expected and archive.stat().st_size==145986606
binary=args.binary or BASE/'full_song_lua.exe'
binding_path=args.binding or BASE/'identity.json'
binding=json.loads(binding_path.read_bytes())
assert sha(binary)==binding['binaries']['full_song_lua']['sha256']
if args.binary is None:assert sha(binary)==BASE_SHA
folder=HERE/'replays'/case_id/args.stage
folder.mkdir(parents=True,exist_ok=False)
report_path=folder/'report.json'
command=[str(binary),'--archive',str(archive),'--report',str(report_path),'--production']
receipt={'case_id':case_id,'label':'Circles / Episode 15','capture_kind':'historical failing reference',
    'stage':args.stage,'command':command,'cwd':str(ROOT),'started_at':dt.datetime.now(dt.timezone.utc).isoformat(),
    'archive_sha256':expected,'archive_bytes':archive.stat().st_size,'binary_sha256':sha(binary),
    'uncompressed_archive_sha256':'262c6f112e190ba9148ae832ef068a8738cd2836d120f86cf5cb8aeb211dc432',
    'build_binding':binding,'build_binding_sha256':sha(binding_path),'runner_sha256':sha(__file__),
    'baseline_runtime_commit':'af6a6c9e045f5dfb13abe38bd4eb58d7326f2e26' if args.binary is None else None,
    'timeout_seconds':1800}
write(folder/'invocation.json',receipt)
started=time.monotonic()
with (folder/'stdout.log').open('xb') as out,(folder/'stderr.log').open('xb') as err:
    try:
        result=subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,timeout=1800)
        receipt['exit_code']=result.returncode
    except subprocess.TimeoutExpired:receipt.update(exit_code=None,timed_out=True)
receipt.update(runtime_seconds=time.monotonic()-started,finished_at=dt.datetime.now(dt.timezone.utc).isoformat())
if report_path.exists():
    report=json.loads(report_path.read_bytes())
    assert report['native_frames']==2483
    summary=summarize(report)
    write(folder/'summary.json',summary)
    receipt['report_sha256']=sha(report_path)
    receipt['summary_sha256']=sha(folder/'summary.json')
else:summary={'report_missing':True}
receipt['files']={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in folder.iterdir() if p.is_file()}
write(folder/'execution.json',receipt)
print(json.dumps({'case_id':case_id,'stage':args.stage,'exit_code':receipt['exit_code'],
    'runtime_seconds':receipt['runtime_seconds'],'summary':{k:v for k,v in summary.items()
    if k not in ['first_mismatches','pending_coverage','production_pending_coverage']}}),flush=True)
raise SystemExit(receipt['exit_code'] if receipt['exit_code'] is not None else 124)
