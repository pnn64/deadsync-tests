"""One exact selected native chart per bounded, sequential guest invocation."""
from __future__ import annotations

import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
PROFILE = Path('/opt/song-lua-audit/pass4/capture-profiles/d5e531147bbe2b44ae64ea19efb9c8087f0de503b9de340ccd2a872c09920911')
HARNESS = PROFILE / 'bin/itgmania-harness-rs'
ENGINE_ROOT = Path('/opt/song-lua-audit/harness-pass4/vendor/itgmania')
ENGINE = ENGINE_ROOT / 'ITGmania-harness-trace'
THEME = ENGINE_ROOT / 'Themes/Harness Simply Love'
PIN = 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c'
NATIVE = '663525dcb86eb570d0ef6a2e209678436660ae26'
HARNESS_SHA = '1780c9e517994285775fa75c98c1975c601be0f94c4ad1a376cab16bd8684e8e'
ENGINE_SHA = 'c03763cac1270c14dbe790cbb055c96ebbced269448d64e0bb705385dc9537a3'
THEME_SHA = '0bb994f67d417ab9570fd5097131f265b68045f6cc8d078060abf83c7a2aa111'
NOTESKINS_SHA = '0204cb9ebe9f7877c67c738a3f910b7ad6e83051384e1ce4a35fcae3f2bcc74e'

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def write(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')

def plan_case(case_id):
    plan = json.loads((ROOT / 'capture-plan.json').read_bytes())
    rows = [row for row in plan['cases'] if row['id'] == case_id]
    assert len(rows) == 1, case_id
    return plan, rows[0]

def safe_relative(value):
    path = Path(value)
    assert not path.is_absolute() and '..' not in path.parts and '\\' not in value, value
    return path

def tree_digest(root):
    hasher = hashlib.sha256()
    for directory, names, filenames in os.walk(root):
        names[:] = sorted(name for name in names if name != '.git')
        for filename in sorted(filenames):
            if filename == '.git':
                continue
            path = Path(directory) / filename
            hasher.update(path.relative_to(root).as_posix().encode() + b'\0' + digest(path).encode('ascii') + b'\n')
    return hasher.hexdigest()

def verify_inputs(case, source):
    expected = set()
    for record in case['files']:
        relative = safe_relative(record['path'])
        path = source / relative
        assert path.is_file() and not path.is_symlink(), str(path)
        assert path.stat().st_size == record['bytes'] and digest(path) == record['sha256'], str(path)
        expected.add(relative.as_posix())
    song = source / safe_relative(case['original_job']['source_simfile']).parent
    assert song != source, 'a named song directory is required'
    actual = {path.relative_to(source).as_posix() for path in song.rglob('*') if path.is_file()}
    assert actual == expected, {'missing': sorted(expected - actual), 'extra': sorted(actual - expected)}

def finished(spec_path):
    spec = json.loads(spec_path.read_bytes())
    result = subprocess.run(['systemctl', 'show', spec['unit'], '--no-pager',
        '--property=MemoryPeak,CPUUsageNSec,MemoryMax,MemorySwapMax,CPUQuotaPerSecUSec'], capture_output=True, text=True)
    write(spec_path.parent / 'resource-receipt.json', {'finished_at': now(), 'unit': spec['unit'],
        'service_result': os.environ.get('SERVICE_RESULT'), 'exit_code': os.environ.get('EXIT_CODE'),
        'exit_status': os.environ.get('EXIT_STATUS'), 'spec_sha256': digest(spec_path),
        'resource_usage': dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)})

def command(directory, name, arguments, timeout):
    arguments = [str(value) for value in arguments]
    start = time.monotonic()
    receipt = {'command': arguments, 'started_at': now(), 'timeout_seconds': timeout}
    write(directory / (name + '-invocation.json'), receipt)
    with (directory / (name + '.log')).open('xb') as output:
        try:
            result = subprocess.run(arguments, cwd=directory, stdout=output, stderr=subprocess.STDOUT, timeout=timeout)
            receipt['exit_code'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt['exit_code'] = None
            receipt['timed_out'] = True
    receipt.update(finished_at=now(), runtime_seconds=time.monotonic() - start,
        output_sha256=digest(directory / (name + '.log')))
    write(directory / (name + '-execution.json'), receipt)
    assert receipt['exit_code'] == 0, receipt

def execute(case_id):
    plan, case = plan_case(case_id)
    directory = ROOT / 'cases' / case_id
    assert directory.is_dir() and not (directory / 'run-started.json').exists()
    job = case['original_job']
    source = Path(case['source_corpus_root'])
    assert source.resolve() == Path('/opt/song-lua-audit/pass4/Songs')
    disk = dict(zip(['total', 'used', 'free'], shutil.disk_usage(ROOT)))
    assert disk['free'] >= 8 * 1024**3, disk
    write(directory / 'run-started.json', {'started_at': now(), 'case_id': case_id,
        'capture_plan_sha256': digest(ROOT / 'capture-plan.json'), 'disk': disk})
    try:
        assert digest(HARNESS) == HARNESS_SHA and digest(ENGINE) == ENGINE_SHA
        proof = json.loads((PROFILE / 'proof/source-proof.json').read_bytes())
        assert proof['pins']['harness'] == PIN and proof['pins']['native'] == NATIVE
        assert tree_digest(THEME) == THEME_SHA
        assert tree_digest(ENGINE_ROOT / 'NoteSkins') == NOTESKINS_SHA
        verify_inputs(case, source)
        inputs = directory / 'input/Songs'
        inputs.mkdir(parents=True)
        for record in case['files']:
            relative = safe_relative(record['path'])
            destination = inputs / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source / relative, destination)
        verify_inputs(case, inputs)
        for name in ['tmp', 'traces', 'provenance']:
            (directory / name).mkdir()
        for name in ['source-proof.json', 'build-proof.json']:
            shutil.copyfile(PROFILE / 'proof' / name, directory / 'provenance' / name)
        write(directory / 'source-and-recipe.json', case)
        trace = directory / 'traces/native.json'
        args = [HARNESS, 'song-lua-trace', inputs / safe_relative(job['source_simfile']),
            '--itgmania-bin', ENGINE, '--fallback-theme', 'Harness Simply Love',
            '--game', job['game'], '--style', job['style'], '--capture-fps', str(job['capture_fps']),
            '--max-events', str(job['max_events']), '--timeout', str(job['capture_timeout']),
            '--random-seed', str(job['random_seed']), '--out', trace, '--until-gameplay-end',
            '--headless', '--drawable-samples', '--chart-index', str(job['chart_index']),
            '--difficulty', job['difficulty'].removeprefix('Difficulty_')]
        command(directory, 'capture', args, job['capture_timeout'] + 90)
        native = json.loads(trace.read_bytes())
        summary = {'trace_sha256': digest(trace), 'trace_bytes': trace.stat().st_size,
            'harness_version': native.get('harness_version'), 'harness_commit': PIN,
            'capture_binary_sha256': native.get('command_observer', {}).get('capture_binary_sha256'),
            'input': native.get('input'), 'completion': native.get('completion'), 'capabilities': native.get('capabilities'),
            'counts': {name: len(native.get(name, [])) for name in ['update_frames', 'events', 'drawable_samples', 'stage_samples', 'render_random_inputs']},
            'dropped': {key: value for key, value in native.items() if key.startswith('dropped_')},
            'script_errors': native.get('script_errors', []), 'transition_script_errors': native.get('transition_script_errors', [])}
        write(directory / 'native-summary.json', summary)
        assert native['harness_version'] == '0.1.110'
        assert native['command_observer']['capture_binary_sha256'] == HARNESS_SHA
        assert native['input']['native_source']['revision'] == NATIVE
        assert native['input']['native_source']['modified_src'] is False
        assert native['input']['headless_graphics'] is True and native['input']['window_visible'] is False
        assert native['input']['requested_chart_index'] == job['chart_index']
        assert native['input']['starting_chart'] == job['expected_chart']
        assert native['completion']['reason'] == 'gameplay-exit' and native['completion']['stage_committed'] is True
        assert not summary['script_errors'] and not summary['transition_script_errors']
        assert all(value == 0 for value in summary['dropped'].values())
        assert all(summary['counts'][name] for name in ['update_frames', 'stage_samples'])
        # Match the native harness: sampling enabled can yield zero authored draws.
        assert native['capabilities']['native_drawable_vertices'] is True
        assert isinstance(native['drawable_samples'], list)
        assert isinstance(native['drawable_frames'], list) and native['drawable_frames']
        write(directory / 'traces/_semantic_manifest.json', {'fixture_schema_version': 1,
            'oracle_schema_version': native['schema_version'], 'harness_version': native['harness_version'],
            'itgmania': {'git_revision': NATIVE, 'git_dirty': 'false'},
            'simfiles': [{'simfile': job['source_simfile'], 'fixture': 'native.json', 'title': native['title'],
                'status': 'ok', 'command_observer': native['command_observer']}]})
        del native
        verify_inputs(case, inputs)
        verify_inputs(case, source)
        command(directory, 'archive', [HARNESS, 'song-lua-archive', inputs, '--traces', directory / 'traces',
            '--out', directory / 'candidate', '--uncompressed', '--theme-assets', THEME], 900)
        entries = json.loads((directory / 'candidate/index.json').read_bytes())['archives']
        assert len(entries) == 1
        candidate = directory / 'candidate' / entries[0]['archive']
        value = digest(candidate)
        assert candidate.name == value + '.tar'
        result = {'capture_validated': True, 'finished_at': now(), 'case_id': case_id, 'label': case['label'],
            'candidate': {'path': str(candidate), 'sha256': value, 'bytes': candidate.stat().st_size},
            'archive_entry': entries[0], 'native_summary_sha256': digest(directory / 'native-summary.json'),
            'counts': summary['counts'], 'source_folder_sha256': job['folder_sha256'],
            'harness_commit': PIN, 'harness_sha256': HARNESS_SHA, 'native_revision': NATIVE,
            'parity_accepted': False, 'current_main_replay_required': True}
        write(directory / 'capture-result.json', result)
        print(json.dumps(result), flush=True)
    except BaseException as error:
        if not (directory / 'capture-result.json').exists():
            write(directory / 'capture-result.json', {'capture_validated': False, 'case_id': case_id,
                'finished_at': now(), 'error_type': type(error).__name__, 'error': str(error),
                'traceback': traceback.format_exc(), 'parity_accepted': False})
        raise

def launch(case_id):
    _, case = plan_case(case_id)
    with (ROOT / 'active.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        processes = subprocess.run(['ps', '-eo', 'pid,ppid,comm,args'], capture_output=True, text=True, check=True).stdout
        busy = [line for line in processes.splitlines() if any(value in line for value in
            ['ITGmania-harness-trace', 'itgmania-harness-rs', 'full_song_lua-', '/cargo ', '/rustc '])]
        assert not busy, busy
        directory = ROOT / 'cases' / case_id
        directory.mkdir(parents=True, exist_ok=False)
        env = {'DISPLAY': ':99', 'LIBGL_ALWAYS_SOFTWARE': '1', 'GALLIUM_DRIVER': 'llvmpipe',
            'LP_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'TMPDIR': str(directory / 'tmp'),
            'ITGMANIA_SONG_LUA_NOTESKIN_ROOT': str(ENGINE_ROOT / 'NoteSkins')}
        seconds = case['original_job']['capture_timeout'] + 1110
        spec = {'case_id': case_id, 'started_at': now(), 'working_directory': str(ROOT),
            'command': ['/usr/bin/python3', str(Path(__file__).resolve()), 'execute', case_id],
            'environment': env, 'memory_max_bytes': 6 * 1024**3, 'cpu_quota_percent': 200,
            'memory_swap_max_bytes': 0, 'timeout_seconds': seconds,
            'capture_plan_sha256': digest(ROOT / 'capture-plan.json'), 'runner_sha256': digest(__file__)}
        spec['unit'] = 'deadsync-five-' + hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:16]
        spec_path = directory / 'unit-spec.json'
        write(spec_path, spec)
        cmd = ['sudo', '-n', 'systemd-run', '--quiet', '--wait', '--collect', '--unit=' + spec['unit'],
            '--property=MemoryMax=6G', '--property=MemorySwapMax=0', '--property=CPUQuota=200%',
            '--property=OOMPolicy=kill', '--property=RuntimeMaxSec=' + str(seconds),
            '--property=TimeoutStopSec=15', '--property=KillMode=control-group',
            '--property=User=parity', '--property=Group=parity',
            '--property=StandardOutput=append:' + str(directory / 'unit.log'),
            '--property=StandardError=append:' + str(directory / 'unit.log'),
            '--property=ExecStopPost=/usr/bin/python3 ' + str(Path(__file__).resolve()) + ' finished ' + str(spec_path),
            '--working-directory=' + str(ROOT)]
        cmd += ['--setenv=' + key + '=' + value for key, value in env.items()]
        result = subprocess.run(cmd + spec['command'], capture_output=True, text=True)
        write(directory / 'launch-execution.json', {'command': cmd + spec['command'], 'exit_code': result.returncode,
            'finished_at': now(), 'stdout': result.stdout, 'stderr': result.stderr})
        receipt = json.loads((directory / 'resource-receipt.json').read_bytes())
        print(json.dumps({'case_id': case_id, 'exit_code': result.returncode, 'resource_receipt': receipt}), flush=True)
        if result.returncode or receipt['service_result'] != 'success':
            return result.returncode or 1
        return 0

if __name__ == '__main__':
    assert len(sys.argv) == 3 and sys.argv[1] in ['launch', 'execute', 'finished']
    if sys.argv[1] == 'finished':
        finished(Path(sys.argv[2]))
    elif sys.argv[1] == 'execute':
        execute(sys.argv[2])
    else:
        raise SystemExit(launch(sys.argv[2]))
