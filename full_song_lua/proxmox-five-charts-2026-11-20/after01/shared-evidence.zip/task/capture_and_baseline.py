"""Sequentially capture only the five selected charts and test the retained baseline."""
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
cases=json.loads((HERE/'selection.json').read_bytes())['cases']
assert len(cases)==5
for case in cases:
    case_id=case['id']
    invocation=HERE/'executions'/case_id/'invocation.json'
    execution=HERE/'executions'/case_id/'execution.json'
    if execution.exists():
        assert json.loads(execution.read_bytes())['exit_code']==0,case_id
        print(json.dumps({'case':case_id,'stage':'capture','retained_success':True}),flush=True)
    else:
        assert not invocation.exists(),'Existing capture is still active or lacks completion: '+case_id
        subprocess.run([sys.executable,str(HERE/'remote_five.py'),'run',case_id],cwd=ROOT,check=True)
    downloaded=HERE/'download'/case_id/'download-receipt.json'
    if not downloaded.exists():
        assert not downloaded.parent.exists(),'Inspect incomplete download before retrying: '+case_id
        subprocess.run([sys.executable,str(HERE/'remote_five.py'),'download',case_id],cwd=ROOT,check=True)
    receipt=json.loads(downloaded.read_bytes())
    assert receipt['capture']['capture_validated'] and receipt['resource_receipt']['service_result']=='success'
    replay=HERE/'replays'/case_id/'baseline'/'execution.json'
    if not replay.exists():
        result=subprocess.run([sys.executable,str(HERE/'replay_case.py'),case_id,'--stage','baseline'],cwd=ROOT)
        assert replay.exists(),'No completed baseline receipt: '+case_id
    summary=json.loads((replay.parent/'summary.json').read_bytes())
    print(json.dumps({'case':case_id,'stage':'baseline_complete','native_frames':summary['native_frames'],
        'mismatches':summary['mismatch_count'],'errors':summary['errors'],
        'accepted':summary['archive_accepted']}),flush=True)
print(json.dumps({'selected_cases_completed':len(cases),'full_chart_suite_run':False}),flush=True)
