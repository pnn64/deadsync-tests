import collections
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path('/opt/song-lua-audit')
targets=[root/'deadsync/target/debug/incremental',root/'deadsync/target/release/incremental',root/'harness/target/debug/incremental',root/'harness/target/release/incremental']
rows=[]
for target in targets:
    if not target.exists():continue
    assert not target.is_symlink() and target.resolve().is_relative_to(root.resolve())
    files=[]
    for p in target.rglob('*'):
        assert not p.is_symlink(),str(p)
        if p.is_file():
            s=p.stat()
            files.append({'path':str(p.relative_to(target)),'bytes':s.st_size,'allocated':s.st_blocks*512,'mtime_ns':s.st_mtime_ns})
    rows.append({'path':str(target),'file_count':len(files),'bytes':sum(f['bytes'] for f in files),'allocated_bytes':sum(f['allocated'] for f in files),'suffixes':dict(collections.Counter(Path(f['path']).suffix for f in files)),'files':files})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'disk_before':dict(zip(['total','used','free'],shutil.disk_usage(root))),
    'processes':subprocess.run(['ps','-eo','pid,comm,args'],capture_output=True,text=True,check=True).stdout,
    'candidates':rows,'target_sizes':subprocess.run(['du','-xhd2',str(root/'deadsync/target'),str(root/'harness/target')],capture_output=True,text=True).stdout}
print(json.dumps(result,indent=2))
