"""Run only the hold-order change's focused regression selection."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / 'target/song-lua-parity-20261120/hold-order-final-focused-20261120'
DEST = Path(__file__).resolve().parent / 'hold-order-regressions'
DEST.mkdir(exist_ok=False)
build = json.loads((BUILD / 'execution.json').read_bytes())
assert build['exit_code'] == 0 and build['source_unchanged_during_command']
artifacts = [json.loads(line) for line in (BUILD / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()]
binary = Path(next(row['executable'] for row in artifacts if row.get('reason') == 'compiler-artifact' and row.get('executable')))
names = [line.removesuffix(': test') for line in subprocess.check_output([binary, '--list'], text=True).splitlines() if line.endswith(': test')]
specific = {
    'gameplay_pause_skips_judgments_and_roll_decay_but_keeps_screen_time',
    'early_next_hold_start_settles_previous_same_column_hold',
    'hold_render_activation_follows_native_update_order',
    'hold_render_activation_restores_and_resets_with_practice',
    'roll_step_refreshes_before_event_time_decay',
    'pump_preheld_hold_head_is_fantastic_and_scores_checkpoints',
    'pump_checkpoints_apply_chart_combo_multiplier',
    'pump_checkpoint_schedule_uses_chart_tickcounts',
    'pump_missed_head_can_recover_before_first_checkpoint',
    'pump_release_before_last_checkpoint_breaks_combo_and_lets_go',
    'pump_hold_head_edges_use_max_precision',
    'pump_short_hold_waits_for_late_head_judgment',
    'dance_preheld_hold_head_keeps_existing_itg_behavior',
    'mine_hit_side_effects_wait_until_after_active_holds',
    'masked_active_hold_update_retains_future_tail',
    'masked_active_hold_update_visits_only_active_lanes_in_column_order',
    'settle_replaced_active_hold_column_resolves_previous_hold',
}
selected = sorted(name for name in names if 'autoplay_' in name or name.split('::')[-1] in specific
                  or name.startswith('runtime_regression_tests::routine_'))
assert len(selected) < len(names) // 4
assert specific <= {name.split('::')[-1] for name in selected}
sources = ['runtime_update.rs', 'runtime_methods.rs', 'holds.rs', 'runtime_regression_tests.rs', 'tests.rs']
def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()
source_hashes = {name: sha(ROOT / 'crates/deadsync-gameplay/src' / name) for name in sources}
result = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'binary': str(binary), 'binary_sha256': sha(binary), 'build': str(BUILD),
          'build_execution_sha256': sha(BUILD / 'execution.json'), 'source_sha256': source_hashes,
          'selected_tests': selected, 'results': []}
with (DEST / 'output.log').open('wb') as output:
    for name in selected:
        started = time.monotonic()
        run = subprocess.run([binary, '--exact', name, '--nocapture', '--test-threads=1'], cwd=ROOT,
                             stdout=output, stderr=subprocess.STDOUT, timeout=60)
        result['results'].append({'name': name, 'exit_code': run.returncode,
                                  'seconds': time.monotonic() - started})
result['source_unchanged'] = source_hashes == {name: sha(ROOT / 'crates/deadsync-gameplay/src' / name) for name in sources}
result['passed'] = sum(row['exit_code'] == 0 for row in result['results'])
result['failed'] = sum(row['exit_code'] != 0 for row in result['results'])
result['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
result['output_sha256'] = sha(DEST / 'output.log')
(DEST / 'execution.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: result[key] for key in ['passed', 'failed', 'source_unchanged', 'binary_sha256']}))
raise SystemExit(0 if result['failed'] == 0 and result['source_unchanged'] else 1)
