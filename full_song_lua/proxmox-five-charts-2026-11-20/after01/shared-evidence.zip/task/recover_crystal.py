"""Archive Crystal's already completed native trace; never invoke native capture."""
from __future__ import annotations
import fcntl
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import traceback
import capture_five as original

ROOT = Path(__file__).resolve().parent
CASE = '1275a659b0dc21d2-c0001'
RECOVERY = 'recovery-zero-draw-01'
TRACE_SHA = '73015e53cfa329a8bdf6d80b5e45493bc4b61ecdfedaf694778d35719afe65c9'

def execute():
    _, case = original.plan_case(CASE)
    job = case['original_job']
    base = ROOT / 'cases' / CASE
    work = base / RECOVERY
    trace = base / 'traces/native.json'
    assert not (work / 'run-started.json').exists()
    preserved = {p.relative_to(base).as_posix(): original.digest(p)
        for p in base.rglob('*') if p.is_file() and RECOVERY not in p.relative_to(base).parts}
    original.write(work / 'run-started.json', {'started_at': original.now(), 'preserved_original_files': preserved,
        'native_capture_reexecuted': False, 'trace_sha256': original.digest(trace)})
    try:
        assert original.digest(trace) == TRACE_SHA and trace.stat().st_size == 182044251
        failed = json.loads((base / 'capture-result.json').read_bytes())
        assert failed['capture_validated'] is False and failed['error_type'] == 'AssertionError'
        assert "['update_frames', 'drawable_samples', 'stage_samples']" in failed['traceback']
        capture = json.loads((base / 'capture-execution.json').read_bytes())
        assert capture['exit_code'] == 0 and not capture.get('timed_out')
        assert 'song-lua-trace' in capture['command']
        assert original.digest(original.HARNESS) == original.HARNESS_SHA
        assert original.digest(original.ENGINE) == original.ENGINE_SHA
        proof = json.loads((original.PROFILE / 'proof/source-proof.json').read_bytes())
        assert proof['pins']['harness'] == original.PIN and proof['pins']['native'] == original.NATIVE
        assert original.tree_digest(original.THEME) == original.THEME_SHA
        assert original.tree_digest(original.ENGINE_ROOT / 'NoteSkins') == original.NOTESKINS_SHA
        inputs = base / 'input/Songs'
        source = Path(case['source_corpus_root'])
        original.verify_inputs(case, inputs)
        original.verify_inputs(case, source)
        native = json.loads(trace.read_bytes())
        summary = json.loads((base / 'native-summary.json').read_bytes())
        assert summary['trace_sha256'] == TRACE_SHA and summary['trace_bytes'] == trace.stat().st_size
        assert summary['counts'] == {name: len(native.get(name, [])) for name in summary['counts']}
        assert native['harness_version'] == '0.1.110'
        assert native['command_observer']['capture_binary_sha256'] == original.HARNESS_SHA
        assert native['input']['native_source']['revision'] == original.NATIVE
        assert native['input']['native_source']['modified_src'] is False
        assert native['input']['headless_graphics'] is True and native['input']['window_visible'] is False
        assert native['input']['requested_chart_index'] == job['chart_index']
        assert native['input']['starting_chart'] == job['expected_chart']
        assert native['completion']['reason'] == 'gameplay-exit' and native['completion']['stage_committed'] is True
        assert not native.get('script_errors') and not native.get('transition_script_errors')
        assert all(value == 0 for key, value in native.items() if key.startswith('dropped_'))
        assert all(summary['counts'][name] for name in ['update_frames', 'stage_samples'])
        assert native['capabilities']['native_drawable_vertices'] is True
        assert isinstance(native['drawable_samples'], list) and len(native['drawable_samples']) == 0
        assert isinstance(native['drawable_frames'], list) and native['drawable_frames']
        song = inputs / original.safe_relative(job['source_simfile']).parent
        actors = []
        lua_files = []
        for path in sorted((song / 'lua').glob('*.lua')):
            text = path.read_text(encoding='utf-8-sig')
            actors += re.findall(r'Def\.(\w+)\s*\{', text)
            lua_files.append({'path': path.relative_to(inputs).as_posix(), 'sha256': original.digest(path)})
        assert sorted(actors) == ['Actor', 'Actor', 'ActorFrame'], actors
        validation = {'validated_at': original.now(), 'reason': 'Native drawable sampling permits zero authored drawable submissions.',
            'native_validator_source': 'itgmania-harness/src/song_lua_runtime.rs:1455-1458',
            'harness_commit': original.PIN, 'native_drawable_vertices': True,
            'drawable_samples': 0, 'drawable_frames': len(native['drawable_frames']),
            'authored_actor_definitions': actors, 'authored_lua_files': lua_files,
            'all_original_capture_guards_rechecked': True, 'native_capture_reexecuted': False,
            'original_capture_result_sha256': original.digest(base / 'capture-result.json'),
            'original_resource_receipt_sha256': original.digest(base / 'resource-receipt.json'),
            'trace_sha256': TRACE_SHA, 'runner_sha256': original.digest(__file__)}
        original.write(work / 'validation.json', validation)
        traces = work / 'traces'
        traces.mkdir()
        os.link(trace, traces / 'native.json')
        original.write(traces / '_semantic_manifest.json', {'fixture_schema_version': 1,
            'oracle_schema_version': native['schema_version'], 'harness_version': native['harness_version'],
            'itgmania': {'git_revision': original.NATIVE, 'git_dirty': 'false'},
            'simfiles': [{'simfile': job['source_simfile'], 'fixture': 'native.json', 'title': native['title'],
                'status': 'ok', 'command_observer': native['command_observer']}]})
        del native
        assert not (base / 'candidate').exists()
        original.command(work, 'archive', [original.HARNESS, 'song-lua-archive', inputs, '--traces', traces,
            '--out', base / 'candidate', '--uncompressed', '--theme-assets', original.THEME], 900)
        entries = json.loads((base / 'candidate/index.json').read_bytes())['archives']
        assert len(entries) == 1
        candidate = base / 'candidate' / entries[0]['archive']
        value = original.digest(candidate)
        assert candidate.name == value + '.tar'
        original.verify_inputs(case, inputs)
        original.verify_inputs(case, source)
        assert all(original.digest(base / path) == value for path, value in preserved.items())
        result = {'capture_validated': True, 'finished_at': original.now(), 'case_id': CASE, 'label': case['label'],
            'candidate': {'path': str(candidate), 'sha256': value, 'bytes': candidate.stat().st_size},
            'archive_entry': entries[0], 'native_summary_sha256': original.digest(base / 'native-summary.json'),
            'counts': summary['counts'], 'source_folder_sha256': job['folder_sha256'],
            'harness_commit': original.PIN, 'harness_sha256': original.HARNESS_SHA, 'native_revision': original.NATIVE,
            'parity_accepted': False, 'current_main_replay_required': True,
            'reused_native_trace': True, 'native_capture_reexecuted': False, 'recovery': RECOVERY,
            'validation_sha256': original.digest(work / 'validation.json'),
            'original_capture_result_sha256': original.digest(base / 'capture-result.json'),
            'original_resource_receipt_sha256': original.digest(base / 'resource-receipt.json'),
            'original_native_trace_sha256': TRACE_SHA}
        original.write(work / 'capture-result.json', result)
        print(json.dumps(result), flush=True)
    except BaseException as error:
        if not (work / 'capture-result.json').exists():
            original.write(work / 'capture-result.json', {'capture_validated': False, 'case_id': CASE,
                'finished_at': original.now(), 'error_type': type(error).__name__, 'error': str(error),
                'traceback': traceback.format_exc(), 'native_capture_reexecuted': False})
        raise

def launch():
    with (ROOT / 'active.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        processes = subprocess.run(['ps', '-eo', 'pid,ppid,comm,args'], capture_output=True, text=True, check=True).stdout
        busy = [line for line in processes.splitlines() if any(value in line for value in
            ['ITGmania-harness-trace', 'itgmania-harness-rs', 'full_song_lua-', '/cargo ', '/rustc '])]
        assert not busy, busy
        work = ROOT / 'cases' / CASE / RECOVERY
        work.mkdir(exist_ok=False)
        (work / 'tmp').mkdir()
        spec = {'case_id': CASE, 'started_at': original.now(), 'working_directory': str(ROOT),
            'command': ['/usr/bin/python3', str(Path(__file__).resolve()), 'execute', CASE],
            'memory_max_bytes': 6 * 1024**3, 'cpu_quota_percent': 200, 'memory_swap_max_bytes': 0,
            'timeout_seconds': 1200, 'runner_sha256': original.digest(__file__), 'native_capture_reexecuted': False}
        spec['unit'] = 'deadsync-five-recover-' + original.digest(__file__)[:12]
        spec_path = work / 'unit-spec.json'
        original.write(spec_path, spec)
        cmd = ['sudo', '-n', 'systemd-run', '--quiet', '--wait', '--collect', '--unit=' + spec['unit'],
            '--property=MemoryMax=6G', '--property=MemorySwapMax=0', '--property=CPUQuota=200%',
            '--property=OOMPolicy=kill', '--property=RuntimeMaxSec=1200', '--property=TimeoutStopSec=15',
            '--property=KillMode=control-group', '--property=User=parity', '--property=Group=parity',
            '--property=StandardOutput=append:' + str(work / 'unit.log'),
            '--property=StandardError=append:' + str(work / 'unit.log'),
            '--property=ExecStopPost=/usr/bin/python3 ' + str(Path(__file__).resolve()) + ' finished ' + str(spec_path),
            '--setenv=TMPDIR=' + str(work / 'tmp'), '--working-directory=' + str(ROOT)]
        result = subprocess.run(cmd + spec['command'], capture_output=True, text=True)
        original.write(work / 'launch-execution.json', {'command': cmd + spec['command'], 'exit_code': result.returncode,
            'finished_at': original.now(), 'stdout': result.stdout, 'stderr': result.stderr})
        receipt = json.loads((work / 'resource-receipt.json').read_bytes())
        print(json.dumps({'case_id': CASE, 'recovery': RECOVERY, 'exit_code': result.returncode, 'resource_receipt': receipt}), flush=True)
        return result.returncode or (0 if receipt['service_result'] == 'success' else 1)

if __name__ == '__main__':
    assert len(sys.argv) == 3
    if sys.argv[1] == 'finished':
        original.finished(Path(sys.argv[2]))
    else:
        assert sys.argv[2] == CASE and sys.argv[1] in ['launch', 'execute']
        if sys.argv[1] == 'execute':
            execute()
        else:
            raise SystemExit(launch())
