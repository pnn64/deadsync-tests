"""Validate only the five existing candidates and retain an exclusive audit receipt."""
import json
from pathlib import Path
import publish_five as publisher

results = []
for row in publisher.load(publisher.TASK / 'selection.json')['cases']:
    execution = publisher.load(publisher.TASK / 'replays' / row['id'] / 'after01/execution.json')
    receipt_path = Path(execution.get('download_receipt_path', publisher.TASK / 'download' / row['id'] / 'download-receipt.json'))
    receipt = publisher.load(receipt_path)
    candidate = publisher.verify(receipt['candidate'])
    proof = publisher.candidate_source_proof(candidate, publisher.archive_manifest(candidate), row)
    results.append({'case_id': row['id'], 'candidate': publisher.identity(candidate),
        'download_receipt': publisher.identity(receipt_path), 'source_proof': proof})
    print(json.dumps({'validated': True, 'case_id': row['id'], 'source_inventory_files': proof['source_inventory_files'],
        'exported_source_files_checked': proof['source_files_checked'],
        'excluded_files': [item['archive_member'] for item in proof['excluded_source_files']]}), flush=True)
report = {'validated_at': publisher.now(), 'scope': 'Five existing candidate source memberships and bytes; no charts executed.',
    'publisher_sha256': publisher.sha(publisher.TASK / 'publish_five.py'),
    'previous_publisher_sha256': publisher.sha(publisher.TASK / 'publish_five-before-source-filter.py'), 'cases': results}
publisher.write(publisher.TASK / 'source-membership-validation.json', report)
print(json.dumps({'all_five_source_memberships_validated': True,
    'receipt': publisher.identity(publisher.TASK / 'source-membership-validation.json')}), flush=True)
