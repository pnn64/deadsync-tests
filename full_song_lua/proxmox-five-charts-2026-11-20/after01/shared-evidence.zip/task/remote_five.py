"""Install or invoke one selected capture, then stream its candidate and evidence."""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
GUEST_ROOT = '/opt/song-lua-audit/five-charts-20261120-attempt01'
CORPUS = Path('C:/GitHub/deadsync-lua-fleet-20261119/target/proxmox-song-lua-20261119/corpus-manifest.json')
EXPECTED_IDS = {'ecb7f9f9a8fb340b-c0001', 'ccfbbe2824310517-c0001', '1275a659b0dc21d2-c0001',
    'abe694267a1522a8-c0001', 'cdadde08ea8260ec-c0001'}

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')

def remote(guest, timeout=60, output=None):
    host = """
import json,pathlib,subprocess,sys
row=next(row for row in json.loads(pathlib.Path('/root/deadsync-lua-20261119/fleet.json').read_bytes()) if row['vmid']==1503)
assert row['ip']=='192.168.1.37',row['ip']
cmd=['ssh','-i','/root/deadsync-pass3-20261116/transfer-key','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',
 '-o','UserKnownHostsFile=/root/deadsync-lua-20261119/fleet-known-hosts','-o','ConnectTimeout=10',
 'parity@'+row['ip'],'python3','-']
result=subprocess.run(cmd,input=GUEST.encode(),timeout=TIMEOUT)
raise SystemExit(result.returncode)
""".replace('GUEST', repr(guest)).replace('TIMEOUT', str(timeout))
    return subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
        'root@192.168.1.79', 'python3', '-'], input=host.encode(),
        stdout=output if output is not None else subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout + 30)

def selected(case_id):
    selection = json.loads((ROOT / 'selection.json').read_bytes())
    assert {case['id'] for case in selection['cases']} == EXPECTED_IDS
    matches = [case for case in selection['cases'] if case['id'] == case_id]
    assert len(matches) == 1, case_id
    return matches[0]

def prepare_plan():
    selection = json.loads((ROOT / 'selection.json').read_bytes())
    assert len(selection['cases']) == 5
    assert {case['id'] for case in selection['cases']} == EXPECTED_IDS
    corpus = json.loads(CORPUS.read_bytes())
    cases = []
    for row in selection['cases']:
        job = row['original_job']
        relative = PurePosixPath(job['source_simfile'])
        assert not relative.is_absolute() and '..' not in relative.parts and relative.parent != PurePosixPath('.')
        prefix = relative.parent.as_posix() + '/'
        records = [entry for entry in corpus['files']
            if entry['folder_sha256'] == job['folder_sha256'] and entry['path'].startswith(prefix)]
        assert records, row['id']
        folder_sha = hashlib.sha256(json.dumps([(entry['path'][len(prefix):], entry['bytes'], entry['sha256'])
            for entry in records], ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
        assert folder_sha == job['folder_sha256'], row['id']
        simfiles = [entry for entry in records if entry['path'] == job['source_simfile']]
        assert len(simfiles) == 1 and simfiles[0]['sha256'] == job['simfile_sha256']
        assert row['source_corpus_root'] == '/opt/song-lua-audit/pass4/Songs'
        cases.append({'id': row['id'], 'label': row['label'], 'original_job': job,
            'source_corpus_root': row['source_corpus_root'],
            'prior_failure': row['prior_replay'],
            'files': [{key: entry[key] for key in ['path', 'bytes', 'sha256']} for entry in records]})
    return {'schema_version': 1, 'created_at': now(), 'guest_vmid': 1503, 'guest_ip': '192.168.1.37',
        'guest_root': GUEST_ROOT, 'harness_commit': 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c',
        'selection_sha256': digest(ROOT / 'selection.json'), 'corpus_manifest_sha256': digest(CORPUS),
        'cases': cases}

def install():
    assert not (ROOT / 'install-execution.json').exists(), 'installation was already invoked'
    plan_path = ROOT / 'capture-plan.json'
    if plan_path.exists():
        plan = json.loads(plan_path.read_bytes())
        assert plan['selection_sha256'] == digest(ROOT / 'selection.json')
        assert plan['corpus_manifest_sha256'] == digest(CORPUS)
        assert plan['guest_root'] == GUEST_ROOT
    else:
        plan = prepare_plan()
        write(plan_path, plan)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name in ['capture_five.py', 'capture-plan.json', 'selection.json']:
            archive.write(ROOT / name, name)
    raw = buffer.getvalue()
    expected = hashlib.sha256(raw).hexdigest()
    guest = """
import base64,hashlib,io,json,pathlib,shutil,zipfile
root=pathlib.Path(ROOT)
assert root.parent==pathlib.Path('/opt/song-lua-audit') and root.name.startswith('five-charts-20261120-')
assert not root.exists(),'exclusive attempt directory already exists'
disk=dict(zip(['total','used','free'],shutil.disk_usage(root.parent)))
assert disk['free']>=8*1024**3,disk
raw=base64.b64decode(PAYLOAD)
assert hashlib.sha256(raw).hexdigest()==EXPECTED
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
 assert archive.testzip() is None
 assert set(archive.namelist())=={'capture_five.py','capture-plan.json','selection.json'}
 root.mkdir()
 for name in archive.namelist():
  with (root/name).open('xb') as stream:stream.write(archive.read(name))
receipt={'vmid':1503,'guest_root':str(root),'package_sha256':EXPECTED,'package_bytes':len(raw),'disk':disk}
with (root/'install-receipt.json').open('x') as stream:json.dump(receipt,stream,indent=2)
print(json.dumps(receipt),flush=True)
""".replace('ROOT', repr(GUEST_ROOT)).replace('PAYLOAD', repr(base64.b64encode(raw).decode())).replace('EXPECTED', repr(expected))
    result = remote(guest, 90)
    receipt = {'action': 'install', 'finished_at': now(), 'guest_root': GUEST_ROOT,
        'exit_code': result.returncode, 'stdout': result.stdout.decode(errors='replace'),
        'stderr': result.stderr.decode(errors='replace'), 'package_sha256': expected,
        'runner_sha256': digest(ROOT / 'capture_five.py'), 'capture_plan_sha256': digest(plan_path)}
    write(ROOT / 'install-execution.json', receipt)
    print(json.dumps(receipt), flush=True)
    return result.returncode

def run(case_id):
    case = selected(case_id)
    installation = json.loads((ROOT / 'install-execution.json').read_bytes())
    assert installation['exit_code'] == 0
    assert installation['runner_sha256'] == digest(ROOT / 'capture_five.py'), 'installed runner changed locally'
    directory = ROOT / 'executions' / case_id
    directory.mkdir(parents=True, exist_ok=False)
    invocation = {'action': 'capture-and-archive', 'case_id': case_id, 'started_at': now(),
        'guest_root': GUEST_ROOT, 'runner_sha256': installation['runner_sha256'],
        'capture_plan_sha256': digest(ROOT / 'capture-plan.json')}
    write(directory / 'invocation.json', invocation)
    guest = """
import pathlib,subprocess
root=pathlib.Path(ROOT)
raise SystemExit(subprocess.run(['python3',str(root/'capture_five.py'),'launch',CASE],cwd=root).returncode)
""".replace('ROOT', repr(GUEST_ROOT)).replace('CASE', repr(case_id))
    result = remote(guest, case['original_job']['capture_timeout'] + 1230)
    invocation.update(finished_at=now(), exit_code=result.returncode,
        stdout=result.stdout.decode(errors='replace'), stderr=result.stderr.decode(errors='replace'))
    write(directory / 'execution.json', invocation)
    print(json.dumps(invocation), flush=True)
    return result.returncode

def download(case_id):
    selected(case_id)
    directory = ROOT / 'download' / case_id
    directory.mkdir(parents=True, exist_ok=False)
    case_root = GUEST_ROOT + '/cases/' + case_id
    guest = """
import pathlib,sys,zipfile
root=pathlib.Path(ROOT)
case=root/'cases'/CASE
assert case.is_dir()
with zipfile.ZipFile(sys.stdout.buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for path in sorted(case.iterdir()):
  if path.is_file():archive.write(path,'case/'+path.name)
 for folder in ['provenance']:
  for path in sorted((case/folder).rglob('*')):
   if path.is_file():archive.write(path,'case/'+path.relative_to(case).as_posix())
 for name in ['traces/_semantic_manifest.json','candidate/index.json']:
  path=case/name
  if path.is_file():archive.write(path,'case/'+name)
 for name in ['capture_five.py','capture-plan.json','selection.json','install-receipt.json']:
  archive.write(root/name,'setup/'+name)
""".replace('ROOT', repr(GUEST_ROOT)).replace('CASE', repr(case_id))
    evidence = directory / 'native-evidence.zip'
    with evidence.open('xb') as output:
        result = remote(guest, 120, output)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    with zipfile.ZipFile(evidence) as archive:
        assert archive.testzip() is None
        members = {name: {'bytes': archive.getinfo(name).file_size,
            'sha256': hashlib.sha256(archive.read(name)).hexdigest()} for name in archive.namelist()}
        result_name = 'case/capture-result.json'
        capture = json.loads(archive.read(result_name)) if result_name in members else {'capture_validated': False}
        receipt_name = 'case/resource-receipt.json'
        resource = json.loads(archive.read(receipt_name)) if receipt_name in members else None
    write(directory / 'evidence-members.json', members)
    receipt = {'case_id': case_id, 'downloaded_at': now(), 'capture': capture, 'resource_receipt': resource,
        'evidence': {'path': str(evidence), 'bytes': evidence.stat().st_size, 'sha256': digest(evidence)}}
    if capture.get('capture_validated'):
        assert resource and resource['service_result'] == 'success'
        usage = resource['resource_usage']
        assert usage['MemoryMax'] == str(6 * 1024**3) and usage['MemorySwapMax'] == '0' and usage['CPUQuotaPerSecUSec'] == '2s'
        candidate = capture['candidate']
        assert candidate['path'] == case_root + '/candidate/' + candidate['sha256'] + '.tar'
        destination = directory / (candidate['sha256'] + '.tar')
        guest = "import pathlib,shutil,sys\nwith pathlib.Path(" + repr(candidate['path']) + ").open('rb') as source:shutil.copyfileobj(source,sys.stdout.buffer,1<<20)\n"
        with destination.open('xb') as output:
            result = remote(guest, 300, output)
        assert result.returncode == 0, result.stderr.decode(errors='replace')
        assert destination.stat().st_size == candidate['bytes'] and digest(destination) == candidate['sha256']
        receipt['candidate'] = {'path': str(destination), 'bytes': candidate['bytes'], 'sha256': candidate['sha256']}
        receipt['current_main_replay_required'] = True
    write(directory / 'download-receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if capture.get('capture_validated') else 1

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'install', 'run', 'download'])
    parser.add_argument('case_id', nargs='?')
    args = parser.parse_args()
    if args.action in ['run', 'download'] and args.case_id not in EXPECTED_IDS:
        parser.error('run/download requires one of the five selected job IDs')
    if args.action in ['prepare', 'install'] and args.case_id is not None:
        parser.error('prepare/install does not take a job ID')
    if args.action == 'prepare':
        plan = prepare_plan()
        write(ROOT / 'capture-plan.json', plan)
        print(json.dumps({'prepared': True, 'cases': [{'id': row['id'], 'source_files': len(row['files']),
            'source_bytes': sum(entry['bytes'] for entry in row['files'])} for row in plan['cases']]}))
        raise SystemExit(0)
    raise SystemExit({'install': install, 'run': lambda: run(args.case_id), 'download': lambda: download(args.case_id)}[args.action]())
