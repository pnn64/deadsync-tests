"""Pack one accepted five-chart candidate under the capture resource budget."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CAPTURE_ROOT = Path('/opt/song-lua-audit/five-charts-20261120-attempt01')
sys.path.insert(0, str(CAPTURE_ROOT))
import capture_five as native

def execute():
    proof = json.loads((ROOT / 'acceptance-proof.json').read_bytes())
    candidate = Path(proof['guest_candidate'])
    assert candidate.parent.parent == CAPTURE_ROOT / 'cases' / proof['case_id']
    assert native.digest(candidate) == proof['candidate_sha256']
    assert candidate.stat().st_size == proof['candidate_bytes']
    assert native.digest(ROOT / 'report.json') == proof['report_sha256']
    assert native.digest(native.HARNESS) == native.HARNESS_SHA
    source = json.loads((native.PROFILE / 'proof/source-proof.json').read_bytes())
    assert source['pins']['harness'] == native.PIN and source['pins']['native'] == native.NATIVE
    report = json.loads((ROOT / 'report.json').read_bytes())
    assert report['archive_accepted'] and report['diagnostic_replay_checks_passed'] and report['production_gameplay_checks_passed']
    assert report['execution_path'] == 'production-and-diagnostic-live-lua'
    assert report['fixture_sha256'] == proof['candidate_sha256']
    assert not report['errors'] and not report['mismatches']
    del report
    args = [native.HARNESS, 'song-lua-pack', candidate, '--report', ROOT / 'report.json', '--out', ROOT / 'packed']
    native.command(ROOT, 'pack', args, 850)
    outputs = list((ROOT / 'packed').glob('*.tar.zst'))
    assert len(outputs) == 1
    path = outputs[0]
    sha = native.digest(path)
    assert path.name == sha + '.tar.zst'
    assert native.digest(candidate) == proof['candidate_sha256']
    result = {'packed': True, 'case_id': proof['case_id'], 'path': str(path), 'sha256': sha,
        'bytes': path.stat().st_size, 'candidate_sha256': proof['candidate_sha256'],
        'candidate_bytes': proof['candidate_bytes'], 'report_sha256': proof['report_sha256'],
        'source_commit': proof['source_commit'], 'runner_sha256': proof['runner_sha256'],
        'harness_commit': native.PIN, 'harness_sha256': native.HARNESS_SHA,
        'compression_level': 12, 'candidate_unchanged': True, 'finished_at': native.now()}
    native.write(ROOT / 'pack-result.json', result)
    print(json.dumps(result), flush=True)

def launch():
    with (CAPTURE_ROOT / 'active.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        processes = subprocess.run(['ps', '-eo', 'pid,ppid,comm,args'], capture_output=True, text=True, check=True).stdout
        busy = [line for line in processes.splitlines() if any(value in line for value in
            ['ITGmania-harness-trace', 'itgmania-harness-rs', 'full_song_lua-', '/cargo ', '/rustc '])]
        assert not busy, busy
        proof = json.loads((ROOT / 'acceptance-proof.json').read_bytes())
        spec = {'started_at': native.now(), 'case_id': proof['case_id'], 'timeout_seconds': 900,
            'memory_max_bytes': 6 * 1024**3, 'memory_swap_max_bytes': 0, 'cpu_quota_percent': 200,
            'command': ['/usr/bin/python3', str(Path(__file__).resolve()), 'execute'],
            'runner_sha256': native.digest(__file__), 'acceptance_proof_sha256': native.digest(ROOT / 'acceptance-proof.json')}
        spec['unit'] = 'deadsync-five-pack-' + hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:16]
        spec_path = ROOT / 'unit-spec.json'
        native.write(spec_path, spec)
        args = ['sudo', '-n', 'systemd-run', '--quiet', '--wait', '--collect', '--unit=' + spec['unit'],
            '--property=MemoryMax=6G', '--property=MemorySwapMax=0', '--property=CPUQuota=200%',
            '--property=OOMPolicy=kill', '--property=RuntimeMaxSec=900', '--property=TimeoutStopSec=15',
            '--property=KillMode=control-group', '--property=User=parity', '--property=Group=parity',
            '--property=StandardOutput=append:' + str(ROOT / 'unit.log'),
            '--property=StandardError=append:' + str(ROOT / 'unit.log'),
            '--property=ExecStopPost=/usr/bin/python3 ' + str(CAPTURE_ROOT / 'capture_five.py') + ' finished ' + str(spec_path),
            '--working-directory=' + str(ROOT)]
        result = subprocess.run(args + spec['command'], capture_output=True, text=True)
        native.write(ROOT / 'launch-execution.json', {'command': args + spec['command'], 'exit_code': result.returncode,
            'finished_at': native.now(), 'stdout': result.stdout, 'stderr': result.stderr})
        receipt = json.loads((ROOT / 'resource-receipt.json').read_bytes())
        print(json.dumps({'case_id': proof['case_id'], 'exit_code': result.returncode, 'resource_receipt': receipt}), flush=True)
        return result.returncode or (0 if receipt['service_result'] == 'success' else 1)

if __name__ == '__main__':
    assert len(sys.argv) == 2 and sys.argv[1] in ['launch', 'execute']
    if sys.argv[1] == 'execute':
        execute()
    else:
        raise SystemExit(launch())
