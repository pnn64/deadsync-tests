# Five real song chart selection

All five selected charts had complete native captures and final parity failures in the retained fleet ledger. There are no selected capture/replay resource obligations. This selection contains no synthetic controls and does not run the full suite.

| Chart | Job | Prior frames | Prior mismatches |
|---|---|---:|---:|
| Nishi-Shinjuku seisou kyoku | `ecb7f9f9a8fb340b-c0001` | 1648 | 10 |
| Circles (native title Episode 15) | `ccfbbe2824310517-c0001` | 2483 | 12 |
| [CRYSTAL_ACCESS] | `1275a659b0dc21d2-c0001` | 1683 | 20 |
| And Drugs | `abe694267a1522a8-c0001` | 1493 | 46 |
| Flying Castle | `cdadde08ea8260ec-c0001` | 1488 | 48 |

The failures are recorded command/query observations: native Player recursive tween time is 0.8 seconds while owned time is the older child maximum. The Circles retained diagnosis independently ties its exact failure window to native hold-before-autoplay ordering: an update crosses both head and tail; native judges the head this update and starts Held feedback on the next. Owned autoplay currently starts the hold and the subsequent active-hold phase resolves it immediately.

Current main retains that ordering. The three core gameplay files (`runtime_update.rs`, `runtime_methods.rs`, `holds.rs`) are unchanged Git blobs from the frozen fleet baseline `81c18c105`. Recent wrapper timer fixes did not address this cause. The related metadata includes exact current/base blob and worktree hashes. The matching cause for the other four charts is a source-supported hypothesis that fresh replay must confirm.

Native anchors: `Player.cpp` hold pass 1206-1267 precedes `CrossedRows` 1291/1295; head judgment prerequisite 1427-1430; `ActorFrame.cpp` 500-509 computes the recursive maximum; `HoldJudgment.cpp` 53-64 restarts feedback. Owned autoplay runs at `runtime_update.rs` 288, followed by post-input active holds at `runtime_methods.rs` 2369. Tail resolution at `holds.rs` 1191-1193 accepts the newly started hold in that same update.

Fresh captures must verify simfile/folder hashes and use the latest harness, with the recorded native chart identity (index 1, dance versus, Challenge), 60 fps, seed 1, two million maximum events, until gameplay exit, headless drawable capture, two CPUs, 6 GiB and zero swap. Source corpus paths in the selection are observed historical paths and require fresh live verification.

A useful focused regression must cross one short autoplay hold's head and tail in one update and inspect both that update and the next, including both players, score/hold result, and recursive feedback tween. Preserve physical-input ordering, pause, routine, rolls and replaced holds. Do not adjust comparator tolerance or native expected data.
