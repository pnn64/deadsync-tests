import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root=Path('/opt/song-lua-audit')
profile=root/'pass4/capture-profiles/d5e531147bbe2b44ae64ea19efb9c8087f0de503b9de340ccd2a872c09920911'
def cmd(argv):
    r=subprocess.run(argv,capture_output=True,text=True)
    return {'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
result={
    'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'disk':dict(zip(['total','used','free'],shutil.disk_usage(root))),
    'active':cmd(['pgrep','-af','ITGmania-harness-trace|itgmania-harness-rs|full_song_lua-|cargo|rustc']),
    'display':cmd(['systemctl','status','deadsync-lua-pass4-xvfb.service','--no-pager']),
    'sizes':cmd(['du','-xhd2',str(root)]),
    'root_entries':[{'name':p.name,'directory':p.is_dir()} for p in root.iterdir()],
    'harness_sha256':digest(profile/'bin/itgmania-harness-rs'),
    'engine_sha256':digest(root/'harness-pass4/vendor/itgmania/ITGmania-harness-trace'),
    'source_proof':json.loads((profile/'proof/source-proof.json').read_bytes()),
}
print(json.dumps(result,indent=2))
