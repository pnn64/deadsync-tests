"""Build only the five-chart replay runner and bind its exact source inputs."""
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'target/song-lua-parity-20261120'))
from source_identity import identity,sha

name=sys.argv[1]
assert name.startswith('build-after') and '/' not in name and '\\' not in name
folder=HERE/name
folder.mkdir(exist_ok=False)
env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='2')
command=['cargo','test','--locked','-p','deadsync','--features','deadsync-song-lua/test-support',
    '--test','full_song_lua','--no-run','--message-format=json-render-diagnostics']
receipt={'command':command,'cwd':str(ROOT),'started_at':dt.datetime.now(dt.timezone.utc).isoformat(),
    'source_identity':identity(folder),'environment':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS']}}
(folder/'invocation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
start=time.monotonic()
with (folder/'cargo.jsonl').open('xb') as stdout,(folder/'stderr.log').open('xb') as stderr:
    result=subprocess.run(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
receipt.update(exit_code=result.returncode,runtime_seconds=time.monotonic()-start,finished_at=dt.datetime.now(dt.timezone.utc).isoformat())
after=folder/'after'
after.mkdir()
receipt['source_unchanged_during_build']=identity(after)==receipt['source_identity']
receipt['cargo_build_jsonl_sha256']=sha(folder/'cargo.jsonl')
(folder/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
assert result.returncode==0 and receipt['source_unchanged_during_build'],receipt
artifacts={}
finished=False
for line in (folder/'cargo.jsonl').read_text(encoding='utf-8-sig').splitlines():
    row=json.loads(line)
    if row.get('reason')=='build-finished':finished=row['success']
    if row.get('reason')=='compiler-artifact' and row.get('executable'):
        artifacts[row['target']['name']]=Path(row['executable'])
assert finished and 'full_song_lua' in artifacts
binary=folder/'full_song_lua.exe'
shutil.copy2(artifacts['full_song_lua'],binary)
binding={'source_identity':receipt['source_identity'],'build_directory':str(folder),
    'build_execution_receipt_sha256':sha(folder/'execution.json'),
    'cargo_build_jsonl_sha256':sha(folder/'cargo.jsonl'),
    'binaries':{'full_song_lua':{'path':str(binary),'bytes':binary.stat().st_size,'sha256':sha(binary)}}}
(folder/'binding.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8')
print(json.dumps(binding),flush=True)
