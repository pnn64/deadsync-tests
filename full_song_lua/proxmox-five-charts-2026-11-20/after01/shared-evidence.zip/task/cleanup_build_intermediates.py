import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root=Path('/opt/song-lua-audit')
audit=root/'five-charts-cleanup-20261120'
source=audit/'inspected.json'
manifest=json.loads(source.read_bytes())
base=root/'deadsync/target/release/deps'
assert manifest['scope']==str(base) and base.resolve()==base
assert not (audit/'completed.json').exists()
busy=subprocess.run(['pgrep','-af','ITGmania-harness-trace|itgmania-harness-rs|full_song_lua-|cargo|rustc'],capture_output=True,text=True)
assert busy.returncode==1,busy.stdout
selected={Path(row['path']) for row in manifest['files']}
def retained():
    return {str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in base.iterdir() if p not in selected}
before=retained()
for row in manifest['files']:
    p=Path(row['path'])
    assert p.parent==base and p.resolve().parent==base and not p.is_symlink()
    assert p.suffix in {'.rlib','.rmeta','.d'} and p.is_file()
    s=p.stat()
    assert [s.st_size,s.st_mtime_ns]==[row['bytes'],row['mtime_ns']],str(p)
for row in manifest['files']:
    Path(row['path']).unlink()
assert retained()==before
assert not any(p.exists() for p in selected)
trim=subprocess.run(['sudo','-n','fstrim','-v','/'],capture_output=True,text=True)
result={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'inspection_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':str(base),
    'deleted_files':len(selected),'deleted_logical_bytes':manifest['bytes'],
    'deleted_allocated_bytes':manifest['allocated_bytes'],'retained_files_unchanged':len(before),
    'busy_processes':busy.stdout,'disk_before':manifest['disk_before'],
    'disk_after':dict(zip(['total','used','free'],shutil.disk_usage(root))),
    'fstrim':{'exit':trim.returncode,'stdout':trim.stdout,'stderr':trim.stderr}}
(audit/'completed.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
