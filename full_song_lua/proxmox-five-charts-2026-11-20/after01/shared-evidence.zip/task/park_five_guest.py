"""Inspect, then gracefully restore only guest 1503 to its initial stopped state.

Preparation is local. The inspect action performs remote reads and temporarily
holds the existing task lock. The park action requires the inspected receipt's
hash, repeats all guards, holds that same lock through graceful shutdown, and
never force-stops a guest, removes a disk, or deletes any retained evidence.
"""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess

import run_remote
from remote_five import EXPECTED_IDS, GUEST_ROOT

ROOT = Path(__file__).resolve().parent
VMID = 1503


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def verified(record):
    path = Path(record['path']).resolve()
    need(path.is_relative_to(ROOT), 'Task evidence must be inside this task directory')
    need(path.is_file() and path.stat().st_size == record['bytes'] and sha(path) == record['sha256'],
         'Retained evidence changed: ' + str(path))
    return path


def publication_gate(prepared):
    prepared = prepared.resolve()
    need(prepared.parent.parent == ROOT and prepared.name == 'prepared.json', 'Unexpected publication path')
    plan = read(prepared)
    need(Path(plan['directory']).resolve() == prepared.parent, 'Publication directory mismatch')
    need(len(plan['cases']) == 5 and {row['case_id'] for row in plan['cases']} == EXPECTED_IDS,
         'Require exactly the five selected charts')
    cases = []
    for row in plan['cases']:
        folder = prepared.parent / 'packing' / row['case_id']
        execution_path = folder / 'pack-execution.json'
        download_path = folder / 'packed-download-receipt.json'
        execution, download = read(execution_path), read(download_path)
        need(execution['case_id'] == row['case_id'] and execution['exit_code'] == 0
             and execution['prepared_sha256'] == sha(prepared), 'Pack not complete: ' + row['case_id'])
        need(download['case_id'] == row['case_id'] and download['download_verified'] is True
             and download.get('finished_at'), 'Download not complete: ' + row['case_id'])
        need(download['decoded_sha256'] == row['candidate_sha256']
             and download['decoded_bytes'] == row['candidate_bytes'], 'Decoded candidate mismatch')
        need(download['resource_receipt']['service_result'] == 'success'
             and download['pack_result']['packed'] is True, 'Packing did not complete successfully')
        packed, evidence = verified(download['packed']), verified(download['pack_evidence'])
        report, replay = read(verified(row['report'])), read(verified(row['execution']))
        need(replay['exit_code'] == 0 and not replay.get('timed_out'), 'Final replay incomplete')
        need(report['archive_accepted'] and report['diagnostic_replay_checks_passed']
             and report['production_gameplay_checks_passed'] and not report['errors'] and not report['mismatches'],
             'Final replay did not pass: ' + row['case_id'])
        cases.append({'case_id': row['case_id'], 'pack_execution_sha256': sha(execution_path),
                      'packed_download_receipt_sha256': sha(download_path),
                      'packed': {'path': str(packed), 'bytes': packed.stat().st_size, 'sha256': sha(packed)},
                      'pack_evidence': {'path': str(evidence), 'bytes': evidence.stat().st_size, 'sha256': sha(evidence)},
                      'report_sha256': row['report']['sha256'], 'execution_sha256': row['execution']['sha256']})
    return {'prepared_path': str(prepared), 'prepared_sha256': sha(prepared),
            'source_commit': plan['source_commit'], 'stage': plan['stage'], 'cases': cases,
            'capture_plan_sha256': sha(ROOT / 'capture-plan.json')}


GUEST = r'''
import datetime,fcntl,hashlib,json,os,pathlib,shutil,subprocess,sys
root=pathlib.Path(GUEST_ROOT)
lock_path=root/'active.lock'
assert root.resolve()==root and lock_path.is_file() and not lock_path.is_symlink()
assert hashlib.sha256((root/'capture-plan.json').read_bytes()).hexdigest()==PLAN_SHA
lock=lock_path.open('rb')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
ancestors=set()
pid=os.getpid()
while pid>0 and pid not in ancestors:
 ancestors.add(pid)
 try:
  rows=(pathlib.Path('/proc')/str(pid)/'status').read_text().splitlines()
  pid=int(next(row.split()[1] for row in rows if row.startswith('PPid:')))
 except (OSError,StopIteration,ValueError): break
busy=[]
processes=[]
tool_names={'cargo','rustc','rustdoc','cmake','ninja','make','gmake','cc','c++','gcc','g++','clang','clang++',
 'ld','ld.lld','cc1','cc1plus','zstd','tar','gzip','bzip2','xz','zip','unzip','scp','rsync','sftp-server',
 'apt','apt-get','dpkg'}
for path in pathlib.Path('/proc').iterdir():
 if not path.name.isdigit() or int(path.name) in ancestors: continue
 try:
  name=(path/'comm').read_text().strip()
  args=(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace').strip()
  status=(path/'status').read_text().splitlines()
  uid=int(next(row.split()[1] for row in status if row.startswith('Uid:')))
 except (OSError,StopIteration,ValueError): continue
 lower=name.lower()
 row={'pid':int(path.name),'name':name,'uid':uid,'args':args[:1200]}
 task_tool=(lower in tool_names or lower.startswith(('python','itgmania','full_song_lua'))
            or any(token in args for token in ('capture_five','pack_five','song-lua-trace','song-lua-pack',
                                               'song-lua-archive','replay_case','capture_and_baseline')))
 session=(lower in {'bash','zsh','fish','sh','ssh','sftp'}
          or (lower.startswith('sshd') and ('@' in args or '[priv]' in args)))
 harmless_user=(lower in {'systemd','(sd-pam)','dbus-daemon','dbus-broker','dbus-broker-lau'}
                or (lower=='xvfb' and ':99' in args))
 unexpected_user=(uid==os.getuid() and bool(args) and not harmless_user)
 if task_tool or session or unexpected_user: busy.append(row)
 if args and (uid==os.getuid() or '/opt/song-lua-audit/' in args): processes.append(row)
units=subprocess.check_output(['systemctl','list-units','--type=service',
 '--state=running,activating,deactivating','--no-legend','--plain'],text=True)
task_units=[line.strip() for line in units.splitlines() if any(word in line.lower() for word in
 ('deadsync','itgmania','song-lua','capture','replay'))]
allowed_units={'deadsync-lua-pass4-xvfb.service'}
blocking_units=[line for line in task_units if line.split()[0] not in allowed_units]
users=subprocess.check_output(['who'],text=True).strip()
result={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'guest_root':str(root),'capture_plan_sha256':PLAN_SHA,'active_lock_held':True,
 'busy_processes':busy,'task_services':task_units,'blocking_task_services':blocking_units,
 'logged_in_users':users,'task_user_processes':processes,
 'disk':dict(zip(['total','used','free'],shutil.disk_usage(root))),
 'meminfo':pathlib.Path('/proc/meminfo').read_text(),
 'disk_table':subprocess.check_output(['df','-B1','-T',str(root)],text=True),
 'idle':not busy and not blocking_units and not users}
print(json.dumps(result),flush=True)
if not result['idle']: raise SystemExit(3)
# Keep the lock until the host releases inspection or graceful shutdown ends SSH.
assert sys.stdin.readline().strip()=='release'
'''


HOST = r'''
import datetime,hashlib,json,pathlib,shlex,shutil,subprocess,sys,time
VMID=1503
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def command(args,timeout=30):
 result=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
 assert result.returncode==0,{'command':args,'exit':result.returncode,'stderr':result.stderr}
 return result.stdout
def config():
 raw=command(['qm','config',str(VMID)])
 data=dict(line.split(': ',1) for line in raw.splitlines() if ': ' in line)
 assert data['name']=='deadsync-lua-20261119-03' and data['memory']=='8192' and data['cores']=='2'
 assert data['scsi0'].startswith('deadsync-lua-audit:1500/base-1500-disk-0.qcow2/1503/')
 return {'sha256':hashlib.sha256(raw.encode()).hexdigest(),'name':data['name'],
  'memory_mib':int(data['memory']),'cores':int(data['cores']),
  'disks':{key:value for key,value in data.items() if key.startswith(('scsi','ide','sata','virtio')) and key!='scsihw'}}
def resources():
 rows=json.loads(command(['pvesh','get','/cluster/resources','--type','vm','--output-format','json']))
 return {'checked_at':now(),'disk':dict(zip(['total','used','free'],shutil.disk_usage('/'))),
  'disk_table':command(['df','-B1','-T']), 'meminfo':pathlib.Path('/proc/meminfo').read_text(),
  'vms':[{key:row.get(key) for key in ('vmid','type','name','status','maxmem','maxcpu','mem','cpu')}
         for row in sorted(rows,key=lambda item:item['vmid'])]}
receipt={'action':ACTION,'vmid':VMID,'initial_task_state_to_restore':'stopped','started_at':now(),
 'configuration_before':config(),'host_before':resources(),'gate_sha256':GATE_SHA,
 'other_guests_modified':False,'retained_disks_removed':False,'artifacts_deleted':False}
guard=None
try:
 state=command(['qm','status',str(VMID)]).strip()
 receipt['status_before']=state
 assert state in {'status: running','status: stopped'},state
 if EXPECTED_CONFIG is not None: assert receipt['configuration_before']['sha256']==EXPECTED_CONFIG
 if state=='status: running':
  fleet=json.loads(pathlib.Path('/root/deadsync-lua-20261119/fleet.json').read_bytes())
  row=next(row for row in fleet if row['vmid']==VMID)
  assert row['ip']=='192.168.1.37'
  argv=['ssh','-i','/root/deadsync-pass3-20261116/transfer-key','-o','BatchMode=yes',
   '-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=/root/deadsync-lua-20261119/fleet-known-hosts',
   '-o','ConnectTimeout=10','parity@'+row['ip'],'python3','-u','-c',shlex.quote(GUEST_CODE)]
  guard=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  first=guard.stdout.readline()
  assert first,{'guest_guard_exit':guard.poll(),'stderr':guard.stderr.read()}
  receipt['guest']=json.loads(first)
  assert receipt['guest']['idle'] and receipt['guest']['active_lock_held'],receipt['guest']
  assert guard.poll() is None,'Idle lock holder exited unexpectedly'
 else:
  receipt['guest']={'idle':True,'reason':'guest already stopped'}
 print(json.dumps({'kind':'inspection','receipt':receipt}),flush=True)
 if ACTION=='park' and state=='status: running':
  # Lock holder is still connected. No new task capture/pack can acquire active.lock.
  assert guard.poll() is None
  result=subprocess.run(['qm','shutdown',str(VMID),'--timeout','45'],capture_output=True,text=True,timeout=50)
  receipt['shutdown']={'command':['qm','shutdown','1503','--timeout','45'],
   'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
   'forced_stop_requested':False}
  receipt['status_after']=command(['qm','status',str(VMID)]).strip()
  assert result.returncode==0 and receipt['status_after']=='status: stopped',receipt['shutdown']
 elif ACTION=='park':
  receipt['status_after']=state
 else:
  receipt['status_after']=state
 receipt['configuration_after']=config()
 assert receipt['configuration_after']==receipt['configuration_before'],'Guest configuration changed'
 receipt['host_after']=resources()
 receipt['finished_at']=now()
 receipt['completed']=True
 print(json.dumps({'kind':'completed','receipt':receipt}),flush=True)
except BaseException as error:
 receipt['completed']=False
 receipt['error']=repr(error)
 try: receipt['status_after']=command(['qm','status',str(VMID)]).strip()
 except BaseException as status_error: receipt['status_error']=repr(status_error)
 print(json.dumps({'kind':'failed','receipt':receipt}),flush=True)
 raise
finally:
 if guard is not None:
  if guard.poll() is None:
   try: guard.communicate('release\n',timeout=5)
   except (BrokenPipeError,subprocess.TimeoutExpired): pass
  # No process is terminated here. If shutdown failed, the guest stays running.
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['inspect', 'park'])
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--out', type=Path, default=ROOT / 'final-resource-parking')
    parser.add_argument('--inspection-sha256')
    args = parser.parse_args()
    output = args.out.resolve()
    need(output.parent == ROOT, 'Parking evidence must be a direct task subdirectory')
    gate = publication_gate(args.prepared)
    gate_sha = hashlib.sha256(json.dumps(gate, sort_keys=True).encode()).hexdigest()
    expected_config = None
    inspection = output / 'inspection.json'
    if args.action == 'park':
        need(args.inspection_sha256 and inspection.is_file() and sha(inspection) == args.inspection_sha256,
             'Park requires the exact reviewed inspection hash')
        previous = read(inspection)
        need(previous['gate'] == gate and previous['remote']['completed']
             and previous['remote']['guest']['idle'], 'Inspected publication or idle state differs')
        expected_config = previous['remote']['configuration_after']['sha256']
        need(not (output / 'completed.json').exists(), 'A completed parking receipt already exists')
    else:
        need(args.inspection_sha256 is None, 'Inspection does not take an inspection hash')
        output.mkdir(exist_ok=False)
    guest = 'GUEST_ROOT=' + repr(GUEST_ROOT) + '\nPLAN_SHA=' + repr(gate['capture_plan_sha256']) + '\n' + GUEST
    host = '\n'.join(['ACTION=' + repr(args.action), 'GATE_SHA=' + repr(gate_sha),
                      'EXPECTED_CONFIG=' + repr(expected_config), 'GUEST_CODE=' + repr(guest), HOST])
    transport = output / (args.action + '-transport.jsonl')
    invocation = {'action': args.action, 'vmid': VMID, 'started_at': dt.datetime.now(dt.timezone.utc).isoformat(),
                  'script_sha256': sha(__file__), 'gate': gate, 'gate_sha256': gate_sha,
                  'inspection_sha256': args.inspection_sha256,
                  'remote_source_sha256': hashlib.sha256(host.encode()).hexdigest()}
    write(output / (args.action + '-invocation.json'), invocation)
    with transport.open('xb') as stream:
        result = run_remote.run(host, guest=False, timeout=110, output=stream)
    events = [json.loads(line) for line in transport.read_text(encoding='utf-8').splitlines() if line.strip()]
    final = events[-1] if events else {'kind': 'failed', 'receipt': {'completed': False, 'error': 'No remote receipt'}}
    receipt = {**invocation, 'finished_at': dt.datetime.now(dt.timezone.utc).isoformat(),
               'remote_exit_code': result.returncode, 'remote': final['receipt'],
               'transport_sha256': sha(transport)}
    success = result.returncode == 0 and final['kind'] == 'completed' and final['receipt'].get('completed')
    destination = inspection if args.action == 'inspect' and success else output / (
        'completed.json' if success else args.action + '-failed.json')
    write(destination, receipt)
    print(json.dumps({'action': args.action, 'success': bool(success), 'receipt': str(destination),
                      'sha256': sha(destination), 'vmid': VMID,
                      'status_after': final['receipt'].get('status_after')}), flush=True)
    return 0 if success else 1


if __name__ == '__main__':
    raise SystemExit(main())
