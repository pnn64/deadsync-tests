import datetime
import json
from pathlib import Path
import shutil
import subprocess

root=Path('/opt/song-lua-audit')
base=root/'deadsync/target/release/deps'
assert base.resolve()==base and base.is_dir()
active=subprocess.run(['pgrep','-af','ITGmania-harness-trace|itgmania-harness-rs|full_song_lua-|cargo|rustc'],capture_output=True,text=True)
assert active.returncode==1,active.stdout
files=[]
for p in sorted(base.iterdir()):
    if p.suffix not in {'.rlib','.rmeta','.d'}:continue
    assert p.is_file() and not p.is_symlink() and p.resolve().parent==base
    s=p.stat()
    files.append({'path':str(p),'bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'mtime_ns':s.st_mtime_ns})
value={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':str(base),'suffixes':['.rlib','.rmeta','.d'],
       'reason':'Obsolete Rust compiler intermediates in inactive pass3 test build; executables, native captures, source and evidence excluded.',
       'busy_processes':active.stdout,'disk_before':dict(zip(['total','used','free'],shutil.disk_usage(root))),
       'files':files,'file_count':len(files),'bytes':sum(f['bytes'] for f in files),'allocated_bytes':sum(f['allocated_bytes'] for f in files)}
path=root/'five-charts-cleanup-20261120'
path.mkdir(exist_ok=False)
(path/'inspected.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value,indent=2))
