"""Versioned wrapper correction and explicit recovery downloads; old evidence is immutable."""
from __future__ import annotations
import argparse
import base64
import hashlib
import io
import json
from pathlib import Path
import zipfile
import remote_five as original

ROOT = Path(__file__).resolve().parent
GUEST_ROOT = original.GUEST_ROOT
CRYSTAL = '1275a659b0dc21d2-c0001'
RECOVERY = 'recovery-zero-draw-01'
FILES = ['capture_five_v2.py', 'recover_crystal.py', 'capture-correction.json']
OLD = "        assert all(summary['counts'][name] for name in ['update_frames', 'drawable_samples', 'stage_samples'])"
NEW = "\n".join([
    "        assert all(summary['counts'][name] for name in ['update_frames', 'stage_samples'])",
    "        # Match the native harness: sampling enabled can yield zero authored draws.",
    "        assert native['capabilities']['native_drawable_vertices'] is True",
    "        assert isinstance(native['drawable_samples'], list)",
    "        assert isinstance(native['drawable_frames'], list) and native['drawable_frames']"])

def install():
    installation = json.loads((ROOT / 'install-execution.json').read_bytes())
    assert installation['exit_code'] == 0
    old_path = ROOT / 'capture_five.py'
    assert original.digest(old_path) == installation['runner_sha256']
    old = old_path.read_text(encoding='utf-8')
    assert old.count(OLD) == 1
    corrected = old.replace(OLD, NEW)
    compile(corrected, 'capture_five_v2.py', 'exec')
    compile((ROOT / 'recover_crystal.py').read_text(encoding='utf-8'), 'recover_crystal.py', 'exec')
    with (ROOT / 'capture_five_v2.py').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(corrected)
    correction = {'created_at': original.now(), 'original_runner_sha256': original.digest(old_path),
        'original_installation_sha256': original.digest(ROOT / 'install-execution.json'),
        'corrected_runner_sha256': original.digest(ROOT / 'capture_five_v2.py'),
        'recovery_runner_sha256': original.digest(ROOT / 'recover_crystal.py'),
        'old_guard': OLD.strip(), 'new_guard': NEW.strip(),
        'native_validator_source': 'itgmania-harness/src/song_lua_runtime.rs:1455-1458',
        'harness_commit': 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c',
        'reason': 'Native drawable sample arrays may be empty when authored Lua only updates modifiers.',
        'native_binary_changed': False, 'comparator_changed': False}
    original.write(ROOT / 'capture-correction.json', correction)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            archive.write(ROOT / name, name)
    data = buffer.getvalue()
    guest = '''
import base64,hashlib,io,json,pathlib,zipfile
root=pathlib.Path(ROOT)
assert hashlib.sha256((root/'capture_five.py').read_bytes()).hexdigest()==OLD_SHA
names=NAMES
assert all(not (root/name).exists() for name in names)
assert not (root/'correction-install-receipt.json').exists()
data=base64.b64decode(PAYLOAD)
assert hashlib.sha256(data).hexdigest()==PACKAGE_SHA
with zipfile.ZipFile(io.BytesIO(data)) as archive:
 assert set(archive.namelist())==set(names) and archive.testzip() is None
 for name in names:
  with (root/name).open('xb') as out:out.write(archive.read(name))
receipt={'guest_root':str(root),'files':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names},'package_sha256':PACKAGE_SHA,'original_runner_sha256':OLD_SHA}
with (root/'correction-install-receipt.json').open('x') as out:json.dump(receipt,out,indent=2)
print(json.dumps(receipt),flush=True)
'''.replace('ROOT', repr(GUEST_ROOT)).replace('OLD_SHA', repr(correction['original_runner_sha256'])).replace('NAMES', repr(FILES)).replace('PAYLOAD', repr(base64.b64encode(data).decode())).replace('PACKAGE_SHA', repr(hashlib.sha256(data).hexdigest()))
    result = original.remote(guest, 90)
    receipt = {'action': 'install-versioned-correction', 'finished_at': original.now(), 'exit_code': result.returncode,
        'stdout': result.stdout.decode(errors='replace'), 'stderr': result.stderr.decode(errors='replace'),
        'files': {name: original.digest(ROOT / name) for name in FILES}, 'original_runner_sha256': correction['original_runner_sha256']}
    original.write(ROOT / 'correction-install-execution.json', receipt)
    print(json.dumps(receipt), flush=True)
    return result.returncode

def run(case_id, recovery=False):
    case = original.selected(case_id)
    assert case_id == CRYSTAL if recovery else case_id in ['abe694267a1522a8-c0001', 'cdadde08ea8260ec-c0001']
    installation = json.loads((ROOT / 'correction-install-execution.json').read_bytes())
    assert installation['exit_code'] == 0
    runner = 'recover_crystal.py' if recovery else 'capture_five_v2.py'
    assert original.digest(ROOT / runner) == installation['files'][runner]
    directory = ROOT / 'executions' / case_id
    if recovery:
        directory /= RECOVERY
    directory.mkdir(parents=True, exist_ok=False)
    invocation = {'action': 'recover-existing-native-trace' if recovery else 'capture-and-archive-corrected-wrapper',
        'case_id': case_id, 'started_at': original.now(), 'runner': runner, 'runner_sha256': original.digest(ROOT / runner)}
    original.write(directory / 'invocation.json', invocation)
    guest = '''
import hashlib,pathlib,subprocess
root=pathlib.Path(ROOT)
assert hashlib.sha256((root/RUNNER).read_bytes()).hexdigest()==RUNNER_SHA
raise SystemExit(subprocess.run(['python3',str(root/RUNNER),'launch',CASE],cwd=root).returncode)
'''.replace('ROOT', repr(GUEST_ROOT)).replace('RUNNER_SHA', repr(invocation['runner_sha256'])).replace('RUNNER', repr(runner)).replace('CASE', repr(case_id))
    result = original.remote(guest, 1320 if recovery else case['original_job']['capture_timeout'] + 1230)
    invocation.update(finished_at=original.now(), exit_code=result.returncode,
        stdout=result.stdout.decode(errors='replace'), stderr=result.stderr.decode(errors='replace'))
    original.write(directory / 'execution.json', invocation)
    print(json.dumps(invocation), flush=True)
    return result.returncode

def download(case_id, recovery=False):
    original.selected(case_id)
    assert not recovery or case_id == CRYSTAL
    directory = ROOT / 'download' / case_id
    old_receipt = None
    if recovery:
        old_path = directory / 'download-receipt.json'
        old_receipt = json.loads(old_path.read_bytes())
        assert old_receipt['capture']['capture_validated'] is False
        directory /= RECOVERY
    directory.mkdir(parents=True, exist_ok=False)
    guest = '''
import pathlib,sys,zipfile
root=pathlib.Path(ROOT)
case=root/'cases'/CASE
work=case/RECOVERY if RECOVER else case
with zipfile.ZipFile(sys.stdout.buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for path in sorted(case.iterdir()):
  if path.is_file():archive.write(path,('original-case/' if RECOVER else 'case/')+path.name)
 if RECOVER:
  for path in sorted(work.iterdir()):
   if path.is_file():archive.write(path,'case/'+path.name)
  for name in ['native-summary.json','source-and-recipe.json','capture-invocation.json','capture-execution.json','capture.log']:
   archive.write(case/name,'case/'+name)
 for path in sorted((case/'provenance').rglob('*')):
  if path.is_file():archive.write(path,'case/'+path.relative_to(case).as_posix())
 archive.write(work/'traces/_semantic_manifest.json','case/traces/_semantic_manifest.json')
 archive.write(case/'candidate/index.json','case/candidate/index.json')
 for name in ['capture_five.py','capture_five_v2.py','recover_crystal.py','capture-plan.json','selection.json','install-receipt.json','capture-correction.json','correction-install-receipt.json']:
  archive.write(root/name,'setup/'+name)
'''.replace('ROOT', repr(GUEST_ROOT)).replace('CASE', repr(case_id)).replace('RECOVERY', repr(RECOVERY)).replace('RECOVER', repr(recovery))
    evidence = directory / 'native-evidence.zip'
    with evidence.open('xb') as out:
        result = original.remote(guest, 120, out)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    with zipfile.ZipFile(evidence) as archive:
        assert archive.testzip() is None
        members = {name: {'bytes': archive.getinfo(name).file_size, 'sha256': hashlib.sha256(archive.read(name)).hexdigest()} for name in archive.namelist()}
        capture = json.loads(archive.read('case/capture-result.json'))
        resource = json.loads(archive.read('case/resource-receipt.json'))
        prior_resource = json.loads(archive.read('original-case/resource-receipt.json')) if recovery else None
    original.write(directory / 'evidence-members.json', members)
    assert capture['capture_validated'] and resource['service_result'] == 'success', capture
    for item in [resource] + ([prior_resource] if prior_resource else []):
        usage = item['resource_usage']
        assert usage['MemoryMax'] == str(6 * 1024**3) and usage['MemorySwapMax'] == '0' and usage['CPUQuotaPerSecUSec'] == '2s'
    candidate = capture['candidate']
    assert candidate['path'] == GUEST_ROOT + '/cases/' + case_id + '/candidate/' + candidate['sha256'] + '.tar'
    destination = directory / (candidate['sha256'] + '.tar')
    guest = "import pathlib,shutil,sys\nwith pathlib.Path(" + repr(candidate['path']) + ").open('rb') as source:shutil.copyfileobj(source,sys.stdout.buffer,1<<20)\n"
    with destination.open('xb') as out:
        result = original.remote(guest, 300, out)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    assert destination.stat().st_size == candidate['bytes'] and original.digest(destination) == candidate['sha256']
    receipt = {'case_id': case_id, 'downloaded_at': original.now(), 'capture': capture, 'resource_receipt': resource,
        'evidence': {'path': str(evidence), 'bytes': evidence.stat().st_size, 'sha256': original.digest(evidence)},
        'candidate': {'path': str(destination), 'bytes': candidate['bytes'], 'sha256': candidate['sha256']},
        'current_main_replay_required': True, 'correction_installation_sha256': original.digest(ROOT / 'correction-install-execution.json')}
    if recovery:
        receipt.update(recovery=RECOVERY, original_capture_resource_receipt=prior_resource,
            original_download_receipt_path=str(old_path), original_download_receipt_sha256=original.digest(old_path),
            original_evidence=old_receipt['evidence'])
    original.write(directory / 'download-receipt.json', receipt)
    print(json.dumps(receipt), flush=True)
    return 0

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['install', 'run', 'recover', 'download'])
    parser.add_argument('case_id', nargs='?')
    parser.add_argument('--recovery', action='store_true')
    args = parser.parse_args()
    if args.action == 'install':
        assert args.case_id is None and not args.recovery
        raise SystemExit(install())
    assert args.case_id in original.EXPECTED_IDS
    if args.action == 'download':
        raise SystemExit(download(args.case_id, args.recovery))
    assert not args.recovery
    raise SystemExit(run(args.case_id, args.action == 'recover'))
