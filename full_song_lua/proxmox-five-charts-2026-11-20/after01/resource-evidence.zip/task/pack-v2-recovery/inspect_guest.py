"""Read-only check that the failed first upload created no guest pack attempt."""
import datetime
import json
from pathlib import Path
import subprocess

root = Path('/opt/song-lua-audit/five-charts-20261120-attempt01')
target = root / 'accepted-after01-ecb7f9f9a8fb340b-c0001'
processes = subprocess.run(['ps', '-eo', 'pid,ppid,comm,args'], capture_output=True, text=True, check=True).stdout
busy = [line for line in processes.splitlines() if any(value in line for value in
    ['ITGmania-harness-trace', 'itgmania-harness-rs', 'full_song_lua-', '/cargo ', '/rustc ', 'pack_five_guest.py'])]
result = {'inspected_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'guest_vmid': 1503, 'guest_ip': '192.168.1.37', 'target': str(target),
    'target_exists': target.exists(), 'other_accepted_roots': sorted(path.name for path in root.glob('accepted-*')),
    'native_pack_capture_build_or_replay_processes': busy, 'read_only': True}
print(json.dumps(result), flush=True)
assert not target.exists() and not busy, result
