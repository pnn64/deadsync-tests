"""Prepare, pack, preview, and explicitly apply only five accepted native fixtures.

No action stages or commits Git files. prepare/preview write only in this ignored
task directory. pack launches one bounded native-harness pack at a time. apply
is the sole action that writes the fixture checkout, from a verified preview.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile
import zipfile
import zstandard
import remote_five as transport

TASK = Path(__file__).resolve().parent
PROJECT = TASK.parents[1]
FIXTURES = Path('C:/GitHub/deadsync-tests')
MAX_BYTES = 50_000_000
PART_BYTES = 48_000_000
HARNESS_SHA = '1780c9e517994285775fa75c98c1975c601be0f94c4ad1a376cab16bd8684e8e'
HARNESS_COMMIT = 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c'
NATIVE = '663525dcb86eb570d0ef6a2e209678436660ae26'
META = ['.gitignore', 'full_song_lua/index.json', 'full_song_lua/split-archives.json',
    'full_song_lua/committed-archives.txt', 'full_song_lua/committed-songs.json',
    'full_song_lua/references.json', 'full_song_lua/committed-reference-files.txt']
SHARED = ['selection.json', 'capture-plan.json', 'source-analysis.json', 'source-analysis.md',
    'cleanup-completed.json', 'cleanup-inspection.json', 'build-intermediates-inspected.json',
    'guest-inspection-summary.json', 'install-execution.json', 'capture_five.py',
    'remote_five.py', 'replay_case.py', 'pack_five_guest.py', 'publish_five.py',
    'capture_five_v2.py', 'recover_crystal.py', 'capture_correction.py',
    'capture-correction.json', 'correction-install-execution.json',
    'run_remote.py', 'build_replay.py', 'run_hold_regressions.py',
    'replay_retained_circles.py', 'capture_and_baseline.py', 'summarize_five.py',
    'inspect_cleanup.py', 'cleanup_build_intermediates.py', 'inspect_build_intermediates.py',
    'publish_five-before-source-filter.py', 'inspect_export_membership.py',
    'validate_source_membership.py', 'source-membership-validation.json']

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def identity(path):
    path = Path(path)
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def verify(value):
    path = Path(value['path'])
    assert path.is_file() and path.stat().st_size == value['bytes'] and sha(path) == value['sha256'], str(path)
    return path

def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

def text(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(value)

def git(*args, root=FIXTURES):
    return subprocess.check_output(['git', *args], cwd=root).decode('utf-8').strip()

def git_files(*args, root=FIXTURES):
    return [value for value in subprocess.check_output(['git', 'ls-files', '-z', *args], cwd=root).decode('utf-8').split('\0') if value]

def load(path):
    return json.loads(Path(path).read_bytes())

def python_program(bindings, body):
    assert all(name.isidentifier() for name in bindings)
    program = '\n'.join(name + ' = ' + repr(value) for name, value in bindings.items()) + '\n' + body
    compile(program, '<five-chart-generated-python>', 'exec')
    return program

def safe_remote(guest, timeout=60, output=None):
    compile(guest, '<five-chart-guest-python>', 'exec')
    host = python_program({'guest_source': guest, 'guest_timeout': timeout}, """
import json,pathlib,subprocess
row=next(row for row in json.loads(pathlib.Path('/root/deadsync-lua-20261119/fleet.json').read_bytes()) if row['vmid']==1503)
assert row['ip']=='192.168.1.37',row['ip']
cmd=['ssh','-i','/root/deadsync-pass3-20261116/transfer-key','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',
 '-o','UserKnownHostsFile=/root/deadsync-lua-20261119/fleet-known-hosts','-o','ConnectTimeout=10',
 'parity@'+row['ip'],'python3','-']
result=subprocess.run(cmd,input=guest_source.encode(),timeout=guest_timeout)
raise SystemExit(result.returncode)
""")
    return subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
        'root@192.168.1.79', 'python3', '-'], input=host.encode(),
        stdout=output if output is not None else subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout + 30)

def archive_manifest(candidate):
    with tarfile.open(candidate, 'r|') as archive:
        member = next(iter(archive))
        assert member.name == 'manifest.json'
        return json.load(archive.extractfile(member))

def candidate_source_proof(candidate, manifest, row):
    plan = load(TASK / 'capture-plan.json')
    selected = [item for item in plan['cases'] if item['id'] == row['id']]
    assert len(selected) == 1 and selected[0]['original_job'] == row['original_job']
    source = selected[0]
    job = row['original_job']
    assert manifest['chart']['source_path'] == job['source_simfile']
    prefix = PurePosixPath(job['source_simfile']).parent
    inventory = {'song/' + PurePosixPath(item['path']).relative_to(prefix).as_posix(): item for item in source['files']}
    # This is an exact five-candidate audit, not a general dependency resolver.
    # Native export includes the selected simfile, all physical Lua and media,
    # plus referenced assets and captured runtime reads/listings. These specific
    # backups, alternative simfiles, metadata and legacy XML were not selected.
    known_exclusions = {
        'ccfbbe2824310517-c0001': {
            'song/Circles.sm.old': 'backup', 'song/Circles.ssc': 'unselected-simfile',
            'song/Circles.ssc.old': 'backup', 'song/desktop.ini': 'unreferenced-desktop-metadata',
            'song/lua/desktop.ini': 'unreferenced-desktop-metadata'},
        'abe694267a1522a8-c0001': {
            'song/lua/default.xml': 'legacy-xml', 'song/lua/easing.xml': 'legacy-xml',
            'song/lua/modhelpers.xml': 'legacy-xml'},
        'cdadde08ea8260ec-c0001': {
            'song/flying castle.sm.old': 'backup', 'song/flying castle.ssc': 'unselected-simfile',
            'song/flying castle.ssc.old': 'backup', 'song/lua/default.xml': 'legacy-xml',
            'song/lua/easing.xml': 'legacy-xml', 'song/lua/modhelpers.xml': 'legacy-xml'},
    }
    exclusions = known_exclusions.get(row['id'], {})
    assert set(exclusions).issubset(inventory)
    exporter_bytes = subprocess.check_output(['git', 'show', HARNESS_COMMIT + ':src/song_lua_archive.rs'],
        cwd='C:/GitHub/itgmania-harness')
    exporter_sha = hashlib.sha256(exporter_bytes).hexdigest()
    assert exporter_sha == '1232d427b1aa46c53453eebee1d5f4d86eed095da7920edc775f8bd34c73affc'
    exporter = {'harness_commit': HARNESS_COMMIT, 'file': 'src/song_lua_archive.rs', 'sha256': exporter_sha,
        'anchors': {'selected_simfile': '311-335', 'automatic_media': '553-591', 'physical_lua': '617-672',
            'referenced_assets': '351-371,819-969', 'runtime_reads_and_listings': '372-418'}}
    media_extensions = {'ogg', 'wav', 'mp3', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp',
        'avi', 'f4v', 'flv', 'mkv', 'mp4', 'mpeg', 'mpg', 'mov', 'ogv', 'webm', 'wmv'}
    assert manifest['chart']['simfile'] == 'song/' + PurePosixPath(job['source_simfile']).name
    required_assets = {'song/' + asset['local_path'] for asset in manifest['required_assets'] if asset.get('local_path')}
    lua_dependencies = set(manifest['lua_closure']['files'])
    reasons = {
        'backup': ('The .old extension is outside automatic media and physical Lua collection; this is not the selected simfile.', ['311-335', '553-591', '656-672']),
        'unselected-simfile': ('Only the selected simfile is inserted; this alternative .ssc is outside automatic media and Lua collection.', ['311-335', '553-591', '656-672']),
        'legacy-xml': ('The .xml extension is outside automatic media and physical .lua collection; this legacy XML is not a resolved Lua or asset dependency.', ['553-591', '617-672', '1034-1055']),
        'unreferenced-desktop-metadata': ('The desktop.ini file is outside automatic media and Lua collection and is not a referenced asset or captured runtime dependency.', ['553-591', '656-672', '351-418']),
    }
    excluded_proof = []
    for name, reason in sorted(exclusions.items()):
        extension = PurePosixPath(name).suffix[1:].lower()
        assert name != manifest['chart']['simfile'] and extension not in media_extensions | {'lua'}
        assert name not in required_assets and name not in lua_dependencies
        assert {'backup': extension == 'old', 'unselected-simfile': extension in {'sm', 'ssc'},
            'legacy-xml': extension == 'xml', 'unreferenced-desktop-metadata': PurePosixPath(name).name == 'desktop.ini'}[reason]
        explanation, anchors = reasons[reason]
        excluded_proof.append({**inventory[name], 'archive_member': name, 'reason': reason,
            'explanation': explanation, 'exporter_source_anchors': anchors,
            'exporter_source_sha256': exporter_sha, 'not_in_resolved_asset_or_lua_dependencies': True})
    expected = {name: item for name, item in inventory.items() if name not in exclusions}
    declared = {item['path']: item for item in manifest['files']}
    assert len(declared) == len(manifest['files'])
    song_files = {name for name in declared if name.startswith('song/') and not name.startswith('song/__')}
    assert song_files == set(expected), {'missing': sorted(set(expected) - song_files), 'extra': sorted(song_files - set(expected))}
    for name, item in expected.items():
        assert declared[name]['sha256'] == item['sha256'] and declared[name]['bytes'] == item['bytes'], name
    checked = {}
    runtime_dependency_proof = None
    targets = expected | {manifest['chart']['trace']: declared[manifest['chart']['trace']]}
    with tarfile.open(candidate, 'r|') as archive:
        for member in archive:
            if member.name not in targets:
                continue
            assert member.isfile() and member.name not in checked
            expected_file = targets[member.name]
            assert member.size == expected_file['bytes']
            stream = archive.extractfile(member)
            hasher = hashlib.sha256()
            count = 0
            if exclusions and member.name == manifest['chart']['trace']:
                raw = stream.read()
                hasher.update(raw)
                count = len(raw)
                native = json.loads(raw)
                del raw
                # All affected captures have no file-read or listing records.
                # Fail on a different trace instead of inventing closure rules.
                reads = native.get('file_reads', [])
                queries = native.get('directory_queries', [])
                assert isinstance(reads, list) and reads == [], 'source exclusions need a runtime-read review'
                assert isinstance(queries, list) and queries == [], 'source exclusions need a directory-listing review'
                runtime_dependency_proof = {'native_trace_sha256': hasher.hexdigest(),
                    'file_reads_present': 'file_reads' in native, 'file_reads_count': 0,
                    'directory_queries_present': 'directory_queries' in native, 'directory_queries_count': 0,
                    'exporter_source_anchor': '372-418'}
                del native
            else:
                for block in iter(lambda: stream.read(1 << 20), b''):
                    hasher.update(block)
                    count += len(block)
            assert hasher.hexdigest() == expected_file['sha256'] and count == expected_file['bytes'], member.name
            checked[member.name] = {'sha256': hasher.hexdigest(), 'bytes': count}
    assert set(checked) == set(targets)
    assert not exclusions or runtime_dependency_proof is not None
    return {'source_folder_sha256': job['folder_sha256'], 'source_simfile_sha256': job['simfile_sha256'],
        'source_inventory_files': len(inventory), 'source_files_checked': len(expected),
        'source_and_native_archive_members': checked, 'excluded_source_files': excluded_proof,
        'exporter_source': exporter, 'runtime_dependency_proof': runtime_dependency_proof,
        'capture_plan_sha256': sha(TASK / 'capture-plan.json')}

def source_proof(binding, commit):
    source = binding['source_identity']
    result = {'source_commit': commit, 'compiled_source_identity': source, 'files': {}}
    files = source.get('source_files', {})
    if files:
        for name, expected in files.items():
            raw = subprocess.check_output(['git', 'show', commit + ':' + name], cwd=PROJECT)
            matches = [label for label, value in [('as_committed', raw), ('crlf', raw.replace(b'\n', b'\r\n'))]
                if hashlib.sha256(value).hexdigest() == expected]
            assert matches, 'compiled source is not in runtime commit: ' + name
            result['files'][name] = {'compiled_sha256': expected, 'committed_sha256': hashlib.sha256(raw).hexdigest(), 'matching_line_endings': matches}
    else:
        assert source['git_head'] == commit, 'build without per-file hashes must bind the final commit'
        assert source['tracked_patch_sha256'] == hashlib.sha256(b'').hexdigest(), 'build has unbound source edits'
    return result

def fixture_state():
    assert git('branch', '--show-current') == 'main'
    assert not git('diff', 'HEAD', '--name-only', '--', *META), 'fixture metadata already has unrelated edits'
    store = FIXTURES / 'full_song_lua'
    split = load(store / 'split-archives.json')
    assert split['version'] == 1
    tracked = set(git_files('--cached', '--', 'full_song_lua'))
    names = {PurePosixPath(name).name for name in tracked
        if PurePosixPath(name).parent == PurePosixPath('full_song_lua') and name.endswith('.tar.zst')}
    for row in split['archives']:
        assert all('full_song_lua/' + part['file'] in tracked for part in row['parts']), row['archive']
        names.add(row['archive'])
    archived = (store / 'committed-archives.txt').read_text(encoding='utf-8').splitlines()
    songs = load(store / 'committed-songs.json')
    assert set(archived) == names and len(archived) == len(names)
    assert {song['archive'] for song in songs} == names and len(songs) == len(names)
    protected = {name: identity(FIXTURES / name) for name in git_files('--others', '--exclude-standard')}
    return {'head': git('rev-parse', 'HEAD'), 'branch': 'main',
        'metadata': {name: identity(FIXTURES / name) for name in META},
        'protected_untracked': protected, 'committed_archives_before': sorted(names),
        'status_before': git('status', '--porcelain=v1', '--untracked-files=all')}

def case_proof(row, stage, binding, binding_path, commit):
    case_id = row['id']
    replay = TASK / 'replays' / case_id / stage
    execution_path = replay / 'execution.json'
    execution = load(execution_path)
    download_path = Path(execution.get('download_receipt_path', TASK / 'download' / case_id / 'download-receipt.json')).resolve()
    assert download_path.is_relative_to((TASK / 'download' / case_id).resolve())
    assert download_path.name == 'download-receipt.json'
    download = load(download_path)
    assert download['case_id'] == case_id
    candidate = verify(download['candidate'])
    assert candidate.name == download['candidate']['sha256'] + '.tar'
    assert download['capture']['capture_validated'] and download['capture']['harness_sha256'] == HARNESS_SHA
    assert download['capture']['candidate']['sha256'] == download['candidate']['sha256']
    assert download['capture']['candidate']['bytes'] == download['candidate']['bytes']
    assert download['capture']['source_folder_sha256'] == row['original_job']['folder_sha256']
    native_zip = verify(download['evidence'])
    with zipfile.ZipFile(native_zip) as archive:
        assert archive.testzip() is None
        members = load(download_path.parent / 'evidence-members.json')
        assert set(members) == set(archive.namelist())
        for name, expected in members.items():
            raw = archive.read(name)
            assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256']
        native = json.loads(archive.read('case/native-summary.json'))
        resources = json.loads(archive.read('case/resource-receipt.json'))
        assert json.loads(archive.read('case/capture-result.json')) == download['capture']
        assert hashlib.sha256(archive.read('case/native-summary.json')).hexdigest() == download['capture']['native_summary_sha256']
        original_evidence = []
        phases = [{'phase': 'native-capture-and-archive', 'receipt': resources}]
        recovery = None
        if download.get('recovery'):
            assert case_id == '1275a659b0dc21d2-c0001' and download['recovery'] == 'recovery-zero-draw-01'
            assert download['capture']['reused_native_trace'] is True and download['capture']['native_capture_reexecuted'] is False
            old_path = Path(download['original_download_receipt_path']).resolve()
            assert old_path == (TASK / 'download' / case_id / 'download-receipt.json').resolve()
            assert sha(old_path) == download['original_download_receipt_sha256']
            old = load(old_path)
            assert old['capture']['capture_validated'] is False and old['evidence'] == download['original_evidence']
            old_zip = verify(old['evidence'])
            old_members_path = old_path.parent / 'evidence-members.json'
            old_members = load(old_members_path)
            with zipfile.ZipFile(old_zip) as previous:
                assert previous.testzip() is None and set(old_members) == set(previous.namelist())
                for name, expected in old_members.items():
                    raw = previous.read(name)
                    assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256']
                    recovered_name = 'original-case/' + name[5:] if name.startswith('case/') else name
                    if recovered_name not in members:
                        recovered_name = name
                    assert archive.read(recovered_name) == raw, (case_id, 'original evidence changed', name)
            prior_resources = json.loads(archive.read('original-case/resource-receipt.json'))
            assert prior_resources == old['resource_receipt'] == download['original_capture_resource_receipt']
            assert prior_resources['service_result'] == 'exit-code'
            assert hashlib.sha256(archive.read('original-case/resource-receipt.json')).hexdigest() == download['capture']['original_resource_receipt_sha256']
            assert hashlib.sha256(archive.read('original-case/capture-result.json')).hexdigest() == download['capture']['original_capture_result_sha256']
            native_execution = json.loads(archive.read('case/capture-execution.json'))
            assert native_execution['exit_code'] == 0 and 'song-lua-trace' in native_execution['command']
            recovery = json.loads(archive.read('case/validation.json'))
            assert hashlib.sha256(archive.read('case/validation.json')).hexdigest() == download['capture']['validation_sha256']
            assert recovery['native_capture_reexecuted'] is False and recovery['all_original_capture_guards_rechecked'] is True
            assert recovery['drawable_samples'] == native['counts']['drawable_samples'] == 0
            assert recovery['drawable_frames'] > 0 and recovery['native_drawable_vertices'] is True
            assert recovery['trace_sha256'] == download['capture']['original_native_trace_sha256'] == native['trace_sha256']
            original_evidence = [identity(old_path), identity(old_zip), identity(old_members_path)]
            phases = [{'phase': 'native-capture-wrapper-guard-failure', 'receipt': prior_resources},
                {'phase': 'archive-recovery-without-native-recapture', 'receipt': resources}]
    assert native['harness_version'] == '0.1.110' and native['harness_commit'] == HARNESS_COMMIT
    assert native['capture_binary_sha256'] == HARNESS_SHA
    assert native['completion']['reason'] == 'gameplay-exit' and native['completion']['stage_committed'] is True
    assert native['input']['native_source']['revision'] == NATIVE and native['input']['native_source']['modified_src'] is False
    assert native['input']['starting_chart'] == row['original_job']['expected_chart']
    assert native['input']['headless_graphics'] is True and native['input']['window_visible'] is False
    assert not native['script_errors'] and not native['transition_script_errors'] and all(value == 0 for value in native['dropped'].values())
    assert resources == download['resource_receipt'] and resources['service_result'] == 'success'
    for phase in phases:
        usage = phase['receipt']['resource_usage']
        assert usage['MemoryMax'] == str(6 * 1024**3) and usage['MemorySwapMax'] == '0' and usage['CPUQuotaPerSecUSec'] == '2s'
    manifest = archive_manifest(candidate)
    assert manifest['harness_version'] == '0.1.110' and manifest['itgmania']['execution'] == 'native_gameplay'
    assert manifest['itgmania']['source_revision'] == NATIVE and manifest['itgmania']['source_dirty'] == 'false'
    assert manifest['runtime']['command_observer']['capture_binary_sha256'] == HARNESS_SHA
    trace = next(value for value in manifest['files'] if value['path'] == manifest['chart']['trace'])
    assert trace['sha256'] == native['trace_sha256'] and trace['bytes'] == native['trace_bytes']
    source_bytes = candidate_source_proof(candidate, manifest, row)
    report_path = replay / 'report.json'
    report = load(report_path)
    assert execution['exit_code'] == 0 and not execution.get('timed_out')
    assert execution['archive_sha256'] == report['fixture_sha256'] == download['candidate']['sha256']
    assert execution['archive_bytes'] == download['candidate']['bytes']
    assert execution['build_binding'] == binding and execution['build_binding_sha256'] == sha(binding_path)
    assert execution['download_receipt_sha256'] == sha(download_path)
    assert execution['binary_sha256'] == binding['binaries']['full_song_lua']['sha256']
    assert sha(Path(execution['command'][0])) == execution['binary_sha256']
    assert '--production' in execution['command']
    for name, expected in execution['files'].items():
        assert (replay / name).stat().st_size == expected['bytes'] and sha(replay / name) == expected['sha256']
    assert sha(report_path) == execution['report_sha256']
    for name in ['archive_accepted', 'diagnostic_replay_checks_passed', 'production_gameplay_checks_passed',
        'production_preparation_exercised', 'capture_completed_gameplay']:
        assert report[name] is True, (case_id, name)
    assert report['execution_path'] == 'production-and-diagnostic-live-lua'
    assert report['errors'] == [] and report['mismatches'] == []
    assert report['native_frames'] == report['replayed_frames'] == native['counts']['update_frames']
    production = report['production_replay']
    assert production['production_gameplay_checks_passed'] is True
    assert not production['errors'] and not production['mismatches']
    evidence = [identity(path) for path in sorted(replay.iterdir()) if path.is_file()]
    baseline_files = []
    replay_runs = []
    for other in sorted((TASK / 'replays' / case_id).iterdir()):
        if not other.is_dir() or not (other / 'execution.json').is_file():
            continue
        observed = load(other / 'execution.json')
        for name, expected in observed['files'].items():
            assert (other / name).stat().st_size == expected['bytes'] and sha(other / name) == expected['sha256']
        run_summary = load(other / 'summary.json') if (other / 'summary.json').is_file() else {}
        replay_runs.append({'stage': other.name, 'archive_sha256': observed['archive_sha256'],
            'binary_sha256': observed['binary_sha256'], 'exit_code': observed['exit_code'],
            'fresh_candidate': observed['archive_sha256'] == download['candidate']['sha256'],
            'summary': run_summary})
        if other == replay:
            continue
        baseline_files += [{**identity(path), 'replay_stage': other.name}
            for path in sorted(other.iterdir()) if path.is_file()]
    return {'case_id': case_id, 'label': row['label'], 'candidate': identity(candidate),
        'candidate_sha256': download['candidate']['sha256'], 'candidate_bytes': download['candidate']['bytes'],
        'guest_candidate': download['capture']['candidate']['path'], 'download_receipt': identity(download_path),
        'native_evidence': identity(native_zip), 'native_evidence_members': identity(download_path.parent / 'evidence-members.json'),
        'original_capture_evidence': original_evidence, 'resource_phases': phases, 'recovery_validation': recovery,
        'maximum_stage_memory_peak_bytes': max(int(item['receipt']['resource_usage']['MemoryPeak']) for item in phases),
        'candidate_source_proof': source_bytes,
        'report': identity(report_path), 'report_sha256': sha(report_path), 'execution': identity(execution_path),
        'source_commit': commit, 'runner_sha256': execution['binary_sha256'],
        'native_counts': native['counts'], 'archive_manifest': manifest,
        'final_replay_files': evidence, 'baseline_replay_files': baseline_files,
        'prior_recorded_failure': row['prior_replay'], 'replay_runs': replay_runs,
        'pending_coverage': report['pending_coverage'], 'production_pending_coverage': production.get('pending_coverage', []),
        'claim_flags': {key: value for key, value in report.items() if key.endswith('_parity_proven')}}

def prepare(args):
    assert args.stage and '/' not in args.stage and '\\' not in args.stage and '..' not in args.stage
    selection = load(TASK / 'selection.json')
    assert len(selection['cases']) == 5 and {row['id'] for row in selection['cases']} == transport.EXPECTED_IDS
    commit = git('rev-parse', args.source_commit, root=PROJECT)
    assert git('branch', '--show-current', root=PROJECT) == 'main'
    subprocess.run(['git', 'merge-base', '--is-ancestor', commit, 'HEAD'], cwd=PROJECT, check=True)
    binding_path = args.build_binding.resolve()
    binding = load(binding_path)
    proof = source_proof(binding, commit)
    state = fixture_state()
    cases = [case_proof(row, args.stage, binding, binding_path, commit) for row in selection['cases']]
    directory = TASK / ('publication-' + args.stage)
    assert not directory.exists(), 'publication stage already exists'
    shared_paths = [TASK / name for name in SHARED if (TASK / name).is_file()]
    skipped = []
    for supplied in args.evidence:
        supplied = supplied.resolve()
        assert supplied.exists(), str(supplied)
        for path in sorted(supplied.rglob('*')) if supplied.is_dir() else [supplied]:
            if not path.is_file():
                continue
            if path.suffix.lower() in ['.exe', '.pdb', '.dll', '.so', '.a', '.rlib', '.rmeta', '.o', '.obj']:
                skipped.append({'path': str(path), 'bytes': path.stat().st_size, 'reason': 'binary payload retained separately; evidence records its hash'})
                continue
            shared_paths.append(path)
    shared = []
    for path in dict.fromkeys(path.resolve() for path in shared_paths):
        if path.is_relative_to(TASK):
            name = 'task/' + path.relative_to(TASK).as_posix()
        elif path.is_relative_to(PROJECT):
            name = 'project/' + path.relative_to(PROJECT).as_posix()
        else:
            name = 'external/' + path.name + '-' + sha(path)[:12]
        shared.append({**identity(path), 'archive_name': name})
    coverage_root = (TASK / ('coverage-' + args.stage)).resolve()
    coverage = [record for record in shared if Path(record['path']).parent == coverage_root
        and Path(record['path']).name in ['coverage.json', 'coverage.md']]
    assert len(coverage) == 2 and {Path(record['path']).name for record in coverage} == {'coverage.json', 'coverage.md'}, \
        'supply exactly the completed coverage JSON/Markdown pair with --evidence'
    result = {'schema_version': 1, 'prepared_at': now(), 'stage': args.stage, 'source_commit': commit,
        'directory': str(directory), 'fixture_root': str(FIXTURES), 'fixture_state': state,
        'build_binding': identity(binding_path), 'compiled_source_proof': proof,
        'shared_evidence': shared, 'coverage_evidence': coverage,
        'binary_payloads_retained_separately': skipped, 'cases': cases, 'packing_executed': False,
        'fixture_mutation_executed': False, 'compression_level': 12}
    directory.mkdir(exist_ok=False)
    write(directory / 'prepared.json', result)
    print(json.dumps({'prepared': True, 'path': str(directory / 'prepared.json'),
        'cases': [row['case_id'] for row in cases], 'source_commit': commit}), flush=True)

def prepared(args):
    path = args.prepared.resolve()
    assert path.parent.parent == TASK and path.name == 'prepared.json'
    value = load(path)
    assert Path(value['directory']).resolve() == path.parent
    assert Path(value['fixture_root']).resolve() == FIXTURES.resolve()
    for record in value['shared_evidence'] + value['coverage_evidence'] + [value['build_binding']]:
        verify(record)
    for row in value['cases']:
        for key in ['candidate', 'download_receipt', 'native_evidence', 'native_evidence_members', 'report', 'execution']:
            verify(row[key])
        for record in row['final_replay_files'] + row['baseline_replay_files']:
            verify(record)
        for record in row.get('original_capture_evidence', []):
            verify(record)
    return path.parent, value

def pack(args):
    directory, value = prepared(args)
    cases = [row for row in value['cases'] if args.case_id is None or row['case_id'] == args.case_id]
    assert cases
    for row in cases:
        folder = directory / 'packing' / row['case_id']
        folder.mkdir(parents=True, exist_ok=False)
        guest_root = transport.GUEST_ROOT + '/accepted-' + value['stage'] + '-' + row['case_id']
        acceptance = {key: row[key] for key in ['case_id', 'guest_candidate', 'candidate_sha256',
            'candidate_bytes', 'report_sha256', 'source_commit', 'runner_sha256']}
        write(folder / 'acceptance-proof.json', acceptance)
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            archive.write(TASK / 'pack_five_guest.py', 'pack_five_guest.py')
            archive.write(folder / 'acceptance-proof.json', 'acceptance-proof.json')
            archive.write(row['report']['path'], 'report.json')
        raw = buffer.getvalue()
        guest = python_program({'upload_root': guest_root, 'upload_parent': transport.GUEST_ROOT,
            'upload_payload': base64.b64encode(raw).decode(), 'upload_sha256': hashlib.sha256(raw).hexdigest()}, """
import base64,hashlib,io,json,pathlib,subprocess,zipfile
root=pathlib.Path(upload_root)
assert root.parent==pathlib.Path(upload_parent) and root.name.startswith('accepted-')
assert not root.exists(),'pack invocation already exists'
raw=base64.b64decode(upload_payload);assert hashlib.sha256(raw).hexdigest()==upload_sha256
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
 assert archive.testzip() is None and set(archive.namelist())=={'pack_five_guest.py','acceptance-proof.json','report.json'}
 root.mkdir()
 for name in archive.namelist():
  with (root/name).open('xb') as stream:stream.write(archive.read(name))
raise SystemExit(subprocess.run(['python3',str(root/'pack_five_guest.py'),'launch'],cwd=root).returncode)
""")
        result = safe_remote(guest, 960)
        receipt = {'case_id': row['case_id'], 'guest_root': guest_root, 'finished_at': now(),
            'exit_code': result.returncode, 'stdout': result.stdout.decode(errors='replace'),
            'stderr': result.stderr.decode(errors='replace'), 'acceptance_proof_sha256': sha(folder / 'acceptance-proof.json'),
            'prepared_sha256': sha(args.prepared), 'guest_program_sha256': hashlib.sha256(guest.encode()).hexdigest(),
            'guest_program_bytes': len(guest.encode()), 'publisher_source_sha256': sha(__file__)}
        write(folder / 'pack-execution.json', receipt)
        print(json.dumps(receipt), flush=True)
        assert result.returncode == 0, 'pack failed; retain evidence and inspect before another attempt'

def download(args):
    directory, value = prepared(args)
    cases = [row for row in value['cases'] if args.case_id is None or row['case_id'] == args.case_id]
    assert cases
    for row in cases:
        folder = directory / 'packing' / row['case_id']
        execution = load(folder / 'pack-execution.json')
        assert execution['exit_code'] == 0
        guest_root = execution['guest_root']
        evidence = folder / 'pack-evidence.zip'
        guest = python_program({'download_root': guest_root}, """
import pathlib,sys,zipfile
root=pathlib.Path(download_root)
with zipfile.ZipFile(sys.stdout.buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for path in sorted(root.iterdir()):
  if path.is_file() and path.name!='report.json':archive.write(path,path.name)
""")
        with evidence.open('xb') as output:
            result = safe_remote(guest, 120, output)
        assert result.returncode == 0, result.stderr.decode(errors='replace')
        with zipfile.ZipFile(evidence) as archive:
            assert archive.testzip() is None
            packed = json.loads(archive.read('pack-result.json'))
            resources = json.loads(archive.read('resource-receipt.json'))
            assert json.loads(archive.read('acceptance-proof.json')) == load(folder / 'acceptance-proof.json')
        assert resources['service_result'] == 'success'
        usage = resources['resource_usage']
        assert usage['MemoryMax'] == str(6 * 1024**3) and usage['MemorySwapMax'] == '0' and usage['CPUQuotaPerSecUSec'] == '2s'
        assert packed['candidate_sha256'] == row['candidate_sha256'] and packed['report_sha256'] == row['report_sha256']
        assert packed['path'] == guest_root + '/packed/' + packed['sha256'] + '.tar.zst'
        destination = folder / (packed['sha256'] + '.tar.zst')
        guest = "import pathlib,shutil,sys\nwith pathlib.Path(" + repr(packed['path']) + ").open('rb') as source:shutil.copyfileobj(source,sys.stdout.buffer,1<<20)\n"
        with destination.open('xb') as output:
            result = safe_remote(guest, 300, output)
        assert result.returncode == 0, result.stderr.decode(errors='replace')
        assert sha(destination) == packed['sha256'] and destination.stat().st_size == packed['bytes']
        whole = hashlib.sha256()
        count = 0
        with destination.open('rb') as stream, zstandard.ZstdDecompressor().stream_reader(stream) as decoded:
            for block in iter(lambda: decoded.read(1 << 20), b''):
                whole.update(block)
                count += len(block)
        assert whole.hexdigest() == row['candidate_sha256'] and count == row['candidate_bytes']
        receipt = {'case_id': row['case_id'], 'download_verified': True, 'packed': identity(destination),
            'decoded_sha256': whole.hexdigest(), 'decoded_bytes': count, 'pack_evidence': identity(evidence),
            'pack_result': packed, 'resource_receipt': resources, 'finished_at': now()}
        write(folder / 'packed-download-receipt.json', receipt)
        print(json.dumps(receipt), flush=True)

def unchanged_fixture(value):
    state = value['fixture_state']
    assert git('branch', '--show-current') == 'main' and git('rev-parse', 'HEAD') == state['head']
    for record in list(state['metadata'].values()) + list(state['protected_untracked'].values()):
        verify(record)

def copy_new(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists(), str(destination)
    with Path(source).open('rb') as input_file, destination.open('xb') as output:
        shutil.copyfileobj(input_file, output, 1 << 20)
    assert sha(source) == sha(destination)

def zip_evidence(destination, records):
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert len({name for name, _ in records}) == len(records), 'duplicate evidence name'
    with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, source in records:
            archive.write(source, name)
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        members = {name: {'bytes': archive.getinfo(name).file_size,
            'sha256': hashlib.sha256(archive.read(name)).hexdigest()} for name in archive.namelist()}
    assert destination.stat().st_size < MAX_BYTES, 'evidence zip requires splitting before publication'
    write(destination.with_suffix('.members.json'), members)

def post_pack_evidence(paths):
    records = {}
    skipped = {}
    root = TASK.resolve()
    for supplied in paths:
        supplied = supplied.resolve(strict=True)
        assert supplied != root and supplied.is_relative_to(root), 'post-pack evidence must be under this task directory'
        assert supplied.is_file() or supplied.is_dir(), str(supplied)
        for path in sorted(supplied.rglob('*')) if supplied.is_dir() else [supplied]:
            if not path.is_file():
                continue
            path = path.resolve(strict=True)
            assert path.is_relative_to(root), 'post-pack evidence resolves outside this task directory: ' + str(path)
            if path.suffix.lower() in ['.exe', '.pdb', '.dll', '.so', '.a', '.rlib', '.rmeta', '.o', '.obj', '.bin', '.pyc']:
                skipped[str(path)] = {'path': str(path), 'bytes': path.stat().st_size,
                    'reason': 'binary payload excluded from post-pack resource evidence'}
                continue
            record = identity(path)
            assert record['bytes'] < MAX_BYTES, 'post-pack evidence member is too large: ' + str(path)
            record['archive_name'] = 'task/' + path.relative_to(root).as_posix()
            records[str(path)] = record
    assert not paths or records, 'supplied post-pack evidence contains no nonbinary files'
    return [records[name] for name in sorted(records)], [skipped[name] for name in sorted(skipped)]

def preserve_historical_aliases(refs, old, committed):
    evidence = []
    for alias in old.get('aliases', []):
        existing = {key: target for key, target in refs.items() if PurePosixPath(key).name == alias}
        item = {'alias': alias, 'superseded_primary_archive': old['archive'],
            'existing_mappings': existing, 'added_mappings': {}}
        if existing:
            # A historical reference may name an earlier retained archive.
            # Its recorded target is authoritative and must remain unchanged.
            item['action'] = 'preserved-existing-mappings'
            item['existing_target_differs_from_primary'] = any(target != old['archive'] for target in existing.values())
        elif alias in committed:
            item['action'] = 'preserved-direct-committed-archive'
        else:
            key = 'tests/fixtures/itgmania-song-archives/' + alias
            assert key not in refs
            refs[key] = old['archive']
            item['action'] = 'added-previously-unrecorded-alias'
            item['added_mappings'] = {key: old['archive']}
        evidence.append(item)
    return evidence

def preview(args):
    directory, value = prepared(args)
    unchanged_fixture(value)
    resource_records, resource_skipped = post_pack_evidence(args.post_pack_evidence)
    store = FIXTURES / 'full_song_lua'
    preview_root = directory / 'preview'
    preview_root.mkdir(exist_ok=False)
    output = preview_root / 'full_song_lua'
    output.mkdir()
    evidence_root = output / 'proxmox-five-charts-2026-11-20' / value['stage']
    evidence_root.mkdir(parents=True)
    split = load(store / 'split-archives.json')
    index = load(store / 'index.json')
    original_primary_rows = list(index['archives'])
    refs = load(store / 'references.json')
    original_refs = dict(refs)
    alias_evidence = []
    committed = set(value['fixture_state']['committed_archives_before'])
    songs = {row['archive']: row for row in load(store / 'committed-songs.json')}
    old_rows = {}
    results = []
    ignore = (FIXTURES / '.gitignore').read_text(encoding='utf-8')
    for row in value['cases']:
        case_id = row['case_id']
        folder = directory / 'packing' / case_id
        receipt = load(folder / 'packed-download-receipt.json')
        assert receipt['download_verified'] and receipt['decoded_sha256'] == row['candidate_sha256']
        packed = verify(receipt['packed'])
        verify(receipt['pack_evidence'])
        name = packed.name
        assert name not in committed and not (store / name).exists(), 'new archive collides with existing work'
        manifest = row['archive_manifest']
        entry = {'title': manifest['chart']['title'], 'source_simfile': manifest['chart']['source_path'],
            'harness_version': manifest['harness_version'], 'archive': name,
            'sha256': receipt['packed']['sha256'], 'compressed_bytes': receipt['packed']['bytes'],
            'uncompressed_sha256': row['candidate_sha256'], 'compression_level': 12, 'aliases': []}
        previous = [(i, item) for i, item in enumerate(index['archives']) if item['source_simfile'] == entry['source_simfile']]
        assert len(previous) == 1, (case_id, 'expected exactly one primary index row')
        ordinal, old = previous[0]
        assert old['archive'] in committed
        old_rows[case_id] = old
        alias_evidence.append({'case_id': case_id, 'source_simfile': old['source_simfile'],
            'aliases': preserve_historical_aliases(refs, old, committed)})
        index['archives'][ordinal] = entry
        committed.add(name)
        songs[name] = {key: entry[key] for key in ['title', 'source_simfile', 'harness_version', 'archive']}
        if packed.stat().st_size < MAX_BYTES:
            copy_new(packed, output / name)
        else:
            parts = []
            hasher = hashlib.sha256()
            count = 0
            with packed.open('rb') as stream:
                while block := stream.read(PART_BYTES):
                    relative = 'archive-parts/' + receipt['packed']['sha256'] + '/' + f'{len(parts):03}.part'
                    destination = output / relative
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with destination.open('xb') as part:
                        part.write(block)
                    parts.append({'file': relative, 'bytes': len(block), 'sha256': hashlib.sha256(block).hexdigest()})
                    hasher.update(block)
                    count += len(block)
            assert hasher.hexdigest() == receipt['packed']['sha256'] and count == receipt['packed']['bytes']
            split['archives'].append({'archive': name, 'bytes': count, 'sha256': hasher.hexdigest(), 'parts': parts})
            rule = '/full_song_lua/' + name
            assert rule not in ignore.splitlines()
            ignore = ignore.rstrip() + '\n' + rule + '\n'
        final = [('final/' + Path(record['path']).name, verify(record)) for record in row['final_replay_files']]
        baseline = [('replays/' + record['replay_stage'] + '/' + Path(record['path']).name, verify(record)) for record in row['baseline_replay_files']]
        records = final + baseline + [('native/' + Path(row[key]['path']).name, verify(row[key]))
            for key in ['native_evidence', 'native_evidence_members', 'download_receipt']]
        records += [('original-capture/' + Path(record['path']).name, verify(record))
            for record in row.get('original_capture_evidence', [])]
        records += [('packing/' + path.name, path) for path in sorted(folder.iterdir()) if path.is_file() and not path.name.endswith('.tar.zst')]
        zip_evidence(evidence_root / case_id / 'evidence.zip', records)
        results.append({'case_id': case_id, 'label': row['label'], 'archive': entry,
            'candidate_sha256': row['candidate_sha256'], 'source_commit': value['source_commit'],
            'runner_sha256': row['runner_sha256'], 'report_sha256': row['report_sha256'],
            'native_counts': row['native_counts'], 'pending_coverage': row['pending_coverage'],
            'resource_phases': row['resource_phases'], 'maximum_stage_memory_peak_bytes': row['maximum_stage_memory_peak_bytes'],
            'recovery_validation': row['recovery_validation'], 'candidate_source_proof': row['candidate_source_proof'],
            'production_pending_coverage': row['production_pending_coverage'], 'claim_flags': row['claim_flags'],
            'prior_recorded_failure': row['prior_recorded_failure'], 'replay_runs': row['replay_runs']})
    split['archives'].sort(key=lambda row: row['archive'])
    assert len({row['archive'] for row in split['archives']}) == len(split['archives'])
    assert all(refs.get(key) == target for key, target in original_refs.items()), 'historical reference was retargeted or removed'
    added_refs = {key: target for key, target in refs.items() if key not in original_refs}
    recorded_additions = {key: target for case in alias_evidence for alias in case['aliases']
        for key, target in alias['added_mappings'].items()}
    assert added_refs == recorded_additions
    assert len(index['archives']) == len(original_primary_rows)
    changed_primary_rows = [after['source_simfile'] for before, after in zip(original_primary_rows, index['archives']) if before != after]
    assert len(changed_primary_rows) == 5 and set(changed_primary_rows) == {row['archive_manifest']['chart']['source_path'] for row in value['cases']}
    assert set(refs.values()).issubset(committed | {PurePosixPath(name).name for name in git_files('--cached', '--', 'full_song_lua')})
    write(output / 'index.json', index)
    write(output / 'split-archives.json', split)
    write(output / 'committed-songs.json', [songs[name] for name in sorted(songs)])
    text(output / 'committed-archives.txt', '\n'.join(sorted(committed)) + '\n')
    if refs == original_refs:
        copy_new(store / 'references.json', output / 'references.json')
        copy_new(store / 'committed-reference-files.txt', output / 'committed-reference-files.txt')
    else:
        write(output / 'references.json', refs)
        text(output / 'committed-reference-files.txt', '\n'.join(sorted(set(refs.values()))) + '\n')
    text(preview_root / '.gitignore', ignore)
    write(evidence_root / 'superseded-primary-entries.json', old_rows)
    write(evidence_root / 'historical-alias-preservation.json', {
        'original_references': identity(store / 'references.json'), 'original_mapping_count': len(original_refs),
        'existing_mappings_preserved': True, 'added_mappings': added_refs, 'cases': alias_evidence,
        'changed_primary_rows': changed_primary_rows, 'unselected_primary_rows_unchanged': True})
    write(evidence_root / 'source-build-proof.json', value['compiled_source_proof'])
    zip_evidence(evidence_root / 'shared-evidence.zip',
        [(record['archive_name'], verify(record)) for record in value['shared_evidence']]
        + [('compiled-build-binding.json', verify(value['build_binding']))])
    for record in value['coverage_evidence']:
        copy_new(verify(record), evidence_root / Path(record['path']).name)
    if resource_records:
        zip_evidence(evidence_root / 'resource-evidence.zip',
            [(record['archive_name'], verify(record)) for record in resource_records])
        expected_members = {record['archive_name']: {key: record[key] for key in ['bytes', 'sha256']}
            for record in resource_records}
        assert load(evidence_root / 'resource-evidence.members.json') == expected_members
    summary = {'created_at': now(), 'scope': 'Five previously failing authored song charts; complete captured production and diagnostic replay.',
        'source_commit': value['source_commit'], 'stage': value['stage'],
        'harness_commit': 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c', 'native_revision': NATIVE,
        'harness_sha256': HARNESS_SHA, 'compression_level': 12, 'cases': results,
        'old_archives_and_alias_bytes_preserved': True, 'fixture_base_head': value['fixture_state']['head'],
        'binary_payloads_retained_separately': value['binary_payloads_retained_separately']}
    if resource_records:
        summary['post_pack_resource_evidence'] = {'files': resource_records, 'excluded_binary_payloads': resource_skipped}
    write(evidence_root / 'summary.json', summary)
    lines = ['# Five authored song chart parity checks', '',
        'All five fresh native captures pass their implemented production and diagnostic comparisons with no mismatches or errors.', '',
        'The exact tested uncompressed archives were packed by harness `b2af4f355d827fb0e89aead84b4c75a9b8cccf6c` using its actual zstd level 12. Decompressed hashes and byte counts match the tested candidates.', '',
        '| Chart | Native frames | Native draw samples |', '|---|---:|---:|']
    for row in results:
        lines.append('| ' + row['label'].replace('|', '\\|') + ' | ' + str(row['native_counts']['update_frames']) + ' | ' + str(row['native_counts']['drawable_samples']) + ' |')
    lines += ['', 'Each case evidence ZIP preserves every completed replay stage, including historical-reference comparisons where present, their source/binary bindings, native capture and source proofs, resource receipts, and official pack provenance. Shared evidence retains chart selection, cleanup, focused regression results and source analysis.', '',
        'Original recorded failures, fresh-capture baseline results and historical-reference replays remain distinct in summary.json. A newly captured native cadence can change whether the old runtime exhibits the recorded fault; a passing fresh baseline is not reported as a newly repaired failure.', '',
        'Acceptance covers the checks implemented by the replay. Full pending coverage and original parity claim flags remain in summary.json and the unmodified reports; this does not establish framebuffer pixel parity or all unobserved behavior.', '']
    text(evidence_root / 'README.md', '\n'.join(lines))
    members = {path.relative_to(evidence_root).as_posix(): {'bytes': path.stat().st_size, 'sha256': sha(path)}
        for path in sorted(evidence_root.rglob('*')) if path.is_file()}
    write(evidence_root / 'manifest.json', {'members': members, 'prepared_sha256': sha(args.prepared)})
    files = {}
    for path in sorted(preview_root.rglob('*')):
        if not path.is_file():
            continue
        assert path.stat().st_size < MAX_BYTES, str(path)
        name = path.relative_to(preview_root).as_posix()
        before = value['fixture_state']['metadata'].get(name)
        if before and before['sha256'] == sha(path):
            continue
        assert before or not (FIXTURES / name).exists(), name
        files[name] = {'bytes': path.stat().st_size, 'sha256': sha(path), 'before_sha256': before['sha256'] if before else None}
    preview_receipt = {'created_at': now(), 'prepared_sha256': sha(args.prepared), 'preview': str(preview_root),
        'fixture_root': str(FIXTURES), 'files': files, 'new_archives': [row['archive']['archive'] for row in results],
        'changed_primary_rows': changed_primary_rows, 'existing_alias_mappings_preserved': True,
        'old_archive_count': len(value['fixture_state']['committed_archives_before']), 'new_archive_count': len(committed)}
    write(directory / 'preview.json', preview_receipt)
    text(directory / 'git-add-paths.txt', '\n'.join(sorted(files)) + '\n')
    with (directory / 'git-add-paths.nul').open('xb') as output_file:
        output_file.write(b'\0'.join(name.encode() for name in sorted(files)) + b'\0')
    print(json.dumps({'preview': str(directory / 'preview.json'), 'files': len(files), 'new_archives': preview_receipt['new_archives'],
        'git_add_paths': str(directory / 'git-add-paths.txt'), 'fixture_mutation_executed': False}), flush=True)

def apply(args):
    directory, value = prepared(args)
    unchanged_fixture(value)
    view = load(directory / 'preview.json')
    assert view['prepared_sha256'] == sha(args.prepared)
    preview_root = Path(view['preview'])
    assert preview_root == directory / 'preview'
    for name, expected in view['files'].items():
        path = preview_root / name
        assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256']
        destination = FIXTURES / name
        assert expected['before_sha256'] is not None or not destination.exists(), name
    for name, expected in view['files'].items():
        if expected['before_sha256'] is None:
            copy_new(preview_root / name, FIXTURES / name)
    for name, expected in view['files'].items():
        if expected['before_sha256'] is not None:
            destination = FIXTURES / name
            assert sha(destination) == expected['before_sha256']
            destination.write_bytes((preview_root / name).read_bytes())
    for record in value['fixture_state']['protected_untracked'].values():
        verify(record)
    write(directory / 'applied.json', {'applied_at': now(), 'preview_sha256': sha(directory / 'preview.json'),
        'files': view['files'], 'unrelated_untracked_preserved': True, 'git_staging_performed': False})
    print(json.dumps({'applied': True, 'files': len(view['files']), 'fixture_root': str(FIXTURES),
        'git_add_paths': str(directory / 'git-add-paths.txt')}), flush=True)

def check(args):
    directory, value = prepared(args)
    view = load(directory / 'preview.json')
    assert git('branch', '--show-current') == 'main'
    for name, expected in view['files'].items():
        path = FIXTURES / name
        assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256']
        assert path.stat().st_size < MAX_BYTES
    for record in value['fixture_state']['protected_untracked'].values():
        verify(record)
    store = FIXTURES / 'full_song_lua'
    split = load(store / 'split-archives.json')
    split_by_name = {row['archive']: row for row in split['archives']}
    for name in view['new_archives']:
        if name in split_by_name:
            row = split_by_name[name]
            hasher = hashlib.sha256()
            count = 0
            for part in row['parts']:
                path = store / part['file']
                assert path.stat().st_size == part['bytes'] and sha(path) == part['sha256']
                assert 0 < part['bytes'] <= PART_BYTES
                with path.open('rb') as stream:
                    for block in iter(lambda: stream.read(1 << 20), b''):
                        hasher.update(block)
                        count += len(block)
            assert hasher.hexdigest() == row['sha256'] and count == row['bytes']
        else:
            assert sha(store / name) == name.removesuffix('.tar.zst')
    names = (store / 'committed-archives.txt').read_text(encoding='utf-8').splitlines()
    expected_names = sorted(set(value['fixture_state']['committed_archives_before']) | set(view['new_archives']))
    assert names == expected_names
    assert [row['archive'] for row in load(store / 'committed-songs.json')] == names
    assert len(load(store / 'index.json')['archives']) == len(load(directory / 'preview/full_song_lua/index.json')['archives'])
    refs = load(store / 'references.json')
    assert (store / 'committed-reference-files.txt').read_text(encoding='utf-8').splitlines() == sorted(set(refs.values()))
    if args.require_staged:
        tracked = set(git_files('--cached', '--', 'full_song_lua'))
        actual = {PurePosixPath(name).name for name in tracked
            if PurePosixPath(name).parent == PurePosixPath('full_song_lua') and name.endswith('.tar.zst')}
        for row in split['archives']:
            assert all('full_song_lua/' + part['file'] in tracked for part in row['parts'])
            actual.add(row['archive'])
        assert actual == set(names)
    print(json.dumps({'targeted_index_check_passed': True, 'new_archives': len(view['new_archives']),
        'catalog_archive_count': len(names), 'unrelated_untracked_preserved': True,
        'staged_catalog_checked': args.require_staged, 'chart_replays_run': 0}), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    p = sub.add_parser('prepare')
    p.add_argument('--stage', required=True)
    p.add_argument('--build-binding', type=Path, required=True)
    p.add_argument('--source-commit', required=True)
    p.add_argument('--evidence', type=Path, action='append', default=[])
    for action in ['pack', 'download', 'preview', 'apply', 'check']:
        p = sub.add_parser(action)
        p.add_argument('--prepared', type=Path, required=True)
        if action in ['pack', 'download']:
            p.add_argument('--case-id', choices=sorted(transport.EXPECTED_IDS))
        if action == 'preview':
            p.add_argument('--post-pack-evidence', type=Path, action='append', default=[])
        if action == 'check':
            p.add_argument('--require-staged', action='store_true')
    args = parser.parse_args()
    {'prepare': prepare, 'pack': pack, 'download': download, 'preview': preview, 'apply': apply, 'check': check}[args.action](args)
