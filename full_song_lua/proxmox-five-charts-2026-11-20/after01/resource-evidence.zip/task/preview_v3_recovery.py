"""Audit five metadata replacements and archive a failed local preview only."""
import argparse
import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
import publish_five_v3 as publisher

TASK = publisher.TASK
PREPARED = TASK / 'publication-after01/prepared.json'
PREPARED_SHA = '0a29a3628b378e7a38a53b9e28c29ceed7b7390274defc1daee0160b091f6e31'
EVIDENCE = TASK / 'preview-v3-recovery'
PARTIAL = PREPARED.parent / 'preview'
PRIOR = PREPARED.parent / 'preview-failed-attempt01'
CONFLICT = '8d3d240cb4c779869a2c4295590038e7e8aad2989c69f99ddeaf9ae923a58af0.tar.zst'

def initial_state():
    assert publisher.sha(PREPARED) == PREPARED_SHA
    assert publisher.sha(TASK / 'publish_five_v2.py') == 'a4a1e465f15ff08a628e60cc217e40ccc403fc4b8d2cf4adb04418bcc4a951be'
    value = publisher.load(PREPARED)
    publisher.unchanged_fixture(value)
    tracked_changes = set(publisher.git('diff', 'HEAD', '--name-only').splitlines())
    assert tracked_changes.issubset({'.gitattributes'}), tracked_changes
    assert not (PREPARED.parent / 'preview.json').exists() and not (PREPARED.parent / 'applied.json').exists()
    assert not (PREPARED.parent / 'git-add-paths.txt').exists()
    assert PARTIAL.is_dir() and not PRIOR.exists()
    return value

def inventory(root):
    assert root.resolve().parent == PREPARED.parent.resolve()
    directories = []
    files = {}
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink() and path.resolve().is_relative_to(root.resolve())
        name = path.relative_to(root).as_posix()
        if path.is_dir():
            directories.append(name)
        elif path.is_file():
            files[name] = {'bytes': path.stat().st_size, 'sha256': publisher.sha(path)}
        else:
            raise AssertionError(str(path))
    return {'directories': directories, 'files': files}

def retained_archive(name, catalog, split):
    store = publisher.FIXTURES / 'full_song_lua'
    assert name in catalog
    path = store / name
    if path.is_file():
        result = publisher.identity(path)
        assert result['sha256'] == name.removesuffix('.tar.zst')
    else:
        row = split[name]
        hasher = hashlib.sha256()
        count = 0
        for part in row['parts']:
            member = store / part['file']
            assert member.stat().st_size == part['bytes'] and publisher.sha(member) == part['sha256']
            with member.open('rb') as stream:
                for block in iter(lambda: stream.read(1 << 20), b''):
                    hasher.update(block)
                    count += len(block)
        assert hasher.hexdigest() == row['sha256'] == name.removesuffix('.tar.zst') and count == row['bytes']
        result = {'archive': name, 'bytes': count, 'sha256': hasher.hexdigest(), 'parts': row['parts']}
    return {'catalog_entry': catalog[name], 'retained_bytes': result}

def validate():
    value = initial_state()
    store = publisher.FIXTURES / 'full_song_lua'
    index = publisher.load(store / 'index.json')
    proposed = copy.deepcopy(index)
    refs = publisher.load(store / 'references.json')
    original_refs = dict(refs)
    committed = set(value['fixture_state']['committed_archives_before'])
    catalog = {row['archive']: row for row in publisher.load(store / 'committed-songs.json')}
    split = {row['archive']: row for row in publisher.load(store / 'split-archives.json')['archives']}
    cases = []
    archive_names = set()
    for case in value['cases']:
        folder = PREPARED.parent / 'packing' / case['case_id']
        packed = publisher.load(folder / 'packed-download-receipt.json')
        assert packed['download_verified'] is True and packed['decoded_sha256'] == case['candidate_sha256']
        source = case['archive_manifest']['chart']['source_path']
        previous = [(i, row) for i, row in enumerate(index['archives']) if row['source_simfile'] == source]
        assert len(previous) == 1
        ordinal, old = previous[0]
        assert old['archive'] in committed
        alias_proof = publisher.preserve_historical_aliases(refs, old, committed)
        archive_names.add(old['archive'])
        for alias in alias_proof:
            archive_names.update(alias['existing_mappings'].values())
            archive_names.update(alias['added_mappings'].values())
            if alias['action'] == 'preserved-direct-committed-archive':
                archive_names.add(alias['alias'])
        manifest = case['archive_manifest']
        new = {'title': manifest['chart']['title'], 'source_simfile': source,
            'harness_version': manifest['harness_version'], 'archive': Path(packed['packed']['path']).name,
            'sha256': packed['packed']['sha256'], 'compressed_bytes': packed['packed']['bytes'],
            'uncompressed_sha256': case['candidate_sha256'], 'compression_level': 12, 'aliases': []}
        proposed['archives'][ordinal] = new
        cases.append({'case_id': case['case_id'], 'ordinal': ordinal, 'old_primary': old,
            'proposed_primary': new, 'historical_aliases': alias_proof,
            'packed_download_receipt': publisher.identity(folder / 'packed-download-receipt.json')})
    changes = [i for i, (before, after) in enumerate(zip(index['archives'], proposed['archives'])) if before != after]
    assert len(index['archives']) == len(proposed['archives']) and len(changes) == 5
    assert set(changes) == {case['ordinal'] for case in cases}
    assert all(refs.get(key) == target for key, target in original_refs.items())
    additions = {key: target for key, target in refs.items() if key not in original_refs}
    assert additions == {key: target for case in cases for alias in case['historical_aliases'] for key, target in alias['added_mappings'].items()}
    identities = {name: retained_archive(name, catalog, split) for name in sorted(archive_names)}
    conflict = [case for case in cases if any(alias['alias'] == CONFLICT for alias in case['historical_aliases'])]
    assert len(conflict) == 1
    conflict_alias = next(alias for alias in conflict[0]['historical_aliases'] if alias['alias'] == CONFLICT)
    assert conflict_alias['existing_target_differs_from_primary'] is True
    partial = inventory(PARTIAL)
    assert initial_state()['fixture_state'] == value['fixture_state']
    report = {'validated_at': publisher.now(), 'scope': 'Five selected primary row replacements and preservation of all historical references; no charts executed.',
        'prepared': publisher.identity(PREPARED), 'frozen_v2_publisher': publisher.identity(TASK / 'publish_five_v2.py'),
        'versioned_v3_publisher': publisher.identity(TASK / 'publish_five_v3.py'),
        'recovery_helper': publisher.identity(Path(__file__)),
        'fixture_metadata': {name: publisher.identity(publisher.FIXTURES / name) for name in publisher.META},
        'fixture_attributes': publisher.identity(publisher.FIXTURES / '.gitattributes'),
        'original_reference_count': len(original_refs), 'all_existing_mappings_preserved': True,
        'added_mappings': additions, 'changed_primary_ordinals': changes, 'changed_primary_rows': 5,
        'unselected_primary_rows_unchanged': True, 'cases': cases, 'retained_archive_identities': identities,
        'original_conflict': conflict_alias,
        'failed_preview': {'path': str(PARTIAL), 'tool_session_id': 51626, 'exit_code': 1,
            'error': "AssertionError: ('historical alias conflict', '" + CONFLICT + "')",
            'publisher_line': 648, 'inventory': partial, 'fixture_files_written': False},
        'failed_preview_relocated': False, 'native_or_remote_operations': False}
    publisher.write(EVIDENCE / 'validation.json', report)
    print(json.dumps({'validated': True, 'changed_primary_rows': 5, 'original_reference_count': len(original_refs),
        'existing_mappings_preserved': True, 'added_mappings': additions, 'partial_preview_files': len(partial['files']),
        'versioned_v3_publisher_sha256': report['versioned_v3_publisher']['sha256'],
        'receipt': publisher.identity(EVIDENCE / 'validation.json')}), flush=True)

def archive_local():
    initial_state()
    validation = publisher.load(EVIDENCE / 'validation.json')
    for record in [validation['prepared'], validation['frozen_v2_publisher'], validation['versioned_v3_publisher'],
        validation['recovery_helper'], validation['fixture_attributes']] + list(validation['fixture_metadata'].values()):
        publisher.verify(record)
    before = inventory(PARTIAL)
    assert before == validation['failed_preview']['inventory']
    PARTIAL.rename(PRIOR)
    assert not PARTIAL.exists() and inventory(PRIOR) == before
    assert publisher.sha(PREPARED) == PREPARED_SHA
    for record in validation['fixture_metadata'].values():
        publisher.verify(record)
    receipt = {'relocated_at': publisher.now(), 'from': str(PARTIAL), 'to': str(PRIOR),
        'inventory': before, 'all_original_bytes_preserved': True, 'prepared_sha256': PREPARED_SHA,
        'validation': publisher.identity(EVIDENCE / 'validation.json'), 'fixture_mutation_executed': False,
        'native_or_remote_operations': False, 'partial_payloads_outside_small_resource_evidence': True}
    publisher.write(EVIDENCE / 'relocation-receipt.json', receipt)
    print(json.dumps({'archived_failed_preview': True, 'prior_attempt': str(PRIOR),
        'files_preserved': len(before['files']), 'receipt': publisher.identity(EVIDENCE / 'relocation-receipt.json')}), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['validate', 'archive-local'])
    args = parser.parse_args()
    {'validate': validate, 'archive-local': archive_local}[args.action]()
