"""Audit the failed upload; optionally archive only its failed local attempt."""
import argparse
import ast
import base64
import hashlib
import io
import json
from pathlib import Path
import zipfile
import publish_five_v2 as publisher

TASK = publisher.TASK
CASE = 'ecb7f9f9a8fb340b-c0001'
DIRECTORY = TASK / 'pack-v2-recovery'
PREPARED = TASK / 'publication-after01/prepared.json'
PREPARED_SHA = '0a29a3628b378e7a38a53b9e28c29ceed7b7390274defc1daee0160b091f6e31'
FAILED = PREPARED.parent / 'packing' / CASE
PRIOR = DIRECTORY / 'prior-attempts' / CASE

def inspect_failed():
    assert publisher.sha(PREPARED) == PREPARED_SHA
    prepared = publisher.load(PREPARED)
    assert prepared['stage'] == 'after01'
    row = next(row for row in prepared['cases'] if row['case_id'] == CASE)
    frozen = [record for record in prepared['shared_evidence']
        if Path(record['path']).name in ['publish_five.py', 'pack_five_guest.py', 'remote_five.py']]
    assert {Path(record['path']).name for record in frozen} == {'publish_five.py', 'pack_five_guest.py', 'remote_five.py'}
    for record in frozen:
        publisher.verify(record)
    assert FAILED.is_dir()
    assert {path.name for path in FAILED.iterdir()} == {'acceptance-proof.json', 'pack-execution.json'}
    failure = publisher.load(FAILED / 'pack-execution.json')
    assert failure['case_id'] == CASE and failure['prepared_sha256'] == PREPARED_SHA
    assert failure['exit_code'] == 1 and failure['stdout'] == ''
    assert 'SyntaxError: invalid syntax. Perhaps you forgot a comma?' in failure['stderr']
    assert 'raw=base64.b64decode(' in failure['stderr']
    assert publisher.sha(FAILED / 'acceptance-proof.json') == failure['acceptance_proof_sha256']
    expected = {key: row[key] for key in ['case_id', 'guest_candidate', 'candidate_sha256',
        'candidate_bytes', 'report_sha256', 'source_commit', 'runner_sha256']}
    assert publisher.load(FAILED / 'acceptance-proof.json') == expected
    guest_root = publisher.transport.GUEST_ROOT + '/accepted-after01-' + CASE
    assert failure['guest_root'] == guest_root
    return row, failure, frozen

def assignment(source, function_name, variable):
    function = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == function_name)
    return next(node.value for node in ast.walk(function) if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == variable for target in node.targets))

def constants(program, names):
    return {node.targets[0].id: ast.literal_eval(node.value) for node in ast.parse(program).body
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id in names}

def validate():
    row, failure, frozen = inspect_failed()
    inspection_path = DIRECTORY / 'guest-inspection.json'
    inspection = publisher.load(inspection_path)
    assert inspection['read_only'] is True and inspection['target'] == failure['guest_root']
    assert inspection['target_exists'] is False and inspection['native_pack_capture_build_or_replay_processes'] == []
    publisher.verify(row['report'])
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        archive.write(TASK / 'pack_five_guest.py', 'pack_five_guest.py')
        archive.write(FAILED / 'acceptance-proof.json', 'acceptance-proof.json')
        archive.write(row['report']['path'], 'report.json')
    raw = buffer.getvalue()
    encoded = base64.b64encode(raw).decode()
    scope = {'guest_root': failure['guest_root'], 'transport': publisher.transport,
        'base64': base64, 'hashlib': hashlib, 'raw': raw, 'python_program': publisher.python_program}
    old_source = (TASK / 'publish_five.py').read_text(encoding='utf-8')
    legacy = eval(compile(ast.Expression(assignment(old_source, 'pack', 'guest')), '<frozen-upload-expression>', 'eval'), scope)
    assert encoded.count('SHA') > 0
    try:
        compile(legacy, '<frozen-upload-program>', 'exec')
    except SyntaxError as error:
        old_error = {'message': error.msg, 'line': error.lineno, 'offset': error.offset}
    else:
        raise AssertionError('real payload did not reproduce the frozen interpolation failure')
    new_source = (TASK / 'publish_five_v2.py').read_text(encoding='utf-8')
    corrected = eval(compile(ast.Expression(assignment(new_source, 'pack', 'guest')), '<corrected-upload-expression>', 'eval'), scope)
    upload = constants(corrected, {'upload_root', 'upload_parent', 'upload_payload', 'upload_sha256'})
    assert upload['upload_root'] == failure['guest_root'] and upload['upload_parent'] == publisher.transport.GUEST_ROOT
    assert base64.b64decode(upload['upload_payload']) == raw and upload['upload_sha256'] == hashlib.sha256(raw).hexdigest()
    host_scope = {'guest': corrected, 'timeout': 960, 'python_program': publisher.python_program}
    host = eval(compile(ast.Expression(assignment(new_source, 'safe_remote', 'host')), '<corrected-host-expression>', 'eval'), host_scope)
    host_values = constants(host, {'guest_source', 'guest_timeout'})
    assert host_values == {'guest_source': corrected, 'guest_timeout': 960}
    assert '.replace(' not in ast.unparse(assignment(new_source, 'pack', 'guest'))
    assert '.replace(' not in ast.unparse(assignment(new_source, 'download', 'guest'))
    assert '.replace(' not in ast.unparse(assignment(new_source, 'safe_remote', 'host'))
    for record in frozen:
        publisher.verify(record)
    assert publisher.sha(PREPARED) == PREPARED_SHA
    receipt = {'validated_at': publisher.now(), 'case_id': CASE, 'prepared': publisher.identity(PREPARED),
        'frozen_files_verified': frozen, 'versioned_publisher': publisher.identity(TASK / 'publish_five_v2.py'),
        'recovery_helper': publisher.identity(Path(__file__)), 'guest_inspection': publisher.identity(inspection_path),
        'failed_files': [publisher.identity(path) for path in sorted(FAILED.iterdir())],
        'payload_zip_sha256': hashlib.sha256(raw).hexdigest(), 'payload_zip_bytes': len(raw),
        'payload_SHA_token_count': encoded.count('SHA'), 'legacy_error_reproduced': old_error,
        'corrected_guest_compiles': True, 'corrected_payload_round_trip_exact': True,
        'corrected_host_compiles': True, 'corrected_host_guest_round_trip_exact': True,
        'frozen_inputs_unchanged': True, 'guest_pack_launched': False, 'local_failed_attempt_moved': False}
    publisher.write(DIRECTORY / 'validation.json', receipt)
    print(json.dumps({'validated': True, 'payload_SHA_token_count': encoded.count('SHA'),
        'legacy_error_reproduced': old_error, 'versioned_publisher_sha256': receipt['versioned_publisher']['sha256'],
        'receipt': publisher.identity(DIRECTORY / 'validation.json'), 'guest_pack_launched': False}), flush=True)

def archive_local():
    _, failure, frozen = inspect_failed()
    validation = publisher.load(DIRECTORY / 'validation.json')
    for record in validation['failed_files'] + [validation['versioned_publisher'], validation['recovery_helper'], validation['prepared']]:
        publisher.verify(record)
    assert not PRIOR.exists(), 'prior failed attempt was already archived'
    result = publisher.safe_remote((DIRECTORY / 'inspect_guest.py').read_text(encoding='utf-8'), 60)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    inspection = json.loads(result.stdout)
    assert inspection['target'] == failure['guest_root'] and inspection['target_exists'] is False
    assert inspection['native_pack_capture_build_or_replay_processes'] == []
    publisher.write(DIRECTORY / 'guest-inspection-before-local-archive.json', inspection)
    before = {path.name: publisher.identity(path) for path in sorted(FAILED.iterdir())}
    assert set(before) == {'acceptance-proof.json', 'pack-execution.json'}
    PRIOR.parent.mkdir(parents=True, exist_ok=True)
    FAILED.rename(PRIOR)
    after = {}
    for name, record in before.items():
        relocated = {**record, 'path': str(PRIOR / name)}
        publisher.verify(relocated)
        after[name] = relocated
    for record in frozen:
        publisher.verify(record)
    assert publisher.sha(PREPARED) == PREPARED_SHA and not FAILED.exists()
    receipt = {'archived_at': publisher.now(), 'case_id': CASE, 'from': str(FAILED), 'to': str(PRIOR),
        'before': before, 'after': after, 'original_bytes_preserved': True,
        'prepared_sha256': PREPARED_SHA, 'guest_target_absent': True, 'guest_pack_launched': False,
        'guest_inspection': publisher.identity(DIRECTORY / 'guest-inspection-before-local-archive.json')}
    publisher.write(DIRECTORY / 'local-archive-receipt.json', receipt)
    print(json.dumps({'archived_failed_local_attempt': True, 'prior_attempt': str(PRIOR),
        'guest_pack_launched': False, 'receipt': publisher.identity(DIRECTORY / 'local-archive-receipt.json')}), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['validate', 'archive-local'])
    args = parser.parse_args()
    {'validate': validate, 'archive-local': archive_local}[args.action]()
