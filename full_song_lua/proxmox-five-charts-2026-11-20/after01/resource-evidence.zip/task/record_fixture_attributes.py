"""Record the one scoped Git attribute rule needed for exact evidence bytes."""
import hashlib
import json
from pathlib import Path
import subprocess

task = Path(__file__).resolve().parent
repo = Path('C:/GitHub/deadsync-tests')
base = subprocess.check_output(['git', 'show', 'HEAD:.gitattributes'], cwd=repo)
current = (repo / '.gitattributes').read_bytes()
addition = ('# Five-chart evidence is bound by exact file and archive checksums.\n'
            '/full_song_lua/proxmox-five-charts-2026-11-20/**/* -text -whitespace\n').encode()
assert current.replace(b'\r\n', b'\n') == base.replace(b'\r\n', b'\n').rstrip(b'\n') + b'\n' + addition
paths = ['full_song_lua/proxmox-five-charts-2026-11-20/after01/' + name
         for name in ['coverage.md', 'coverage.json', 'manifest.json']]
attributes = subprocess.check_output(['git', 'check-attr', 'text', 'whitespace', '--', *paths], cwd=repo).decode()
assert all(line.endswith(': unset') for line in attributes.splitlines())
record = {'fixture_base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'path': str(repo / '.gitattributes'), 'base_sha256': hashlib.sha256(base).hexdigest(),
          'current_sha256': hashlib.sha256(current).hexdigest(), 'current_bytes': len(current),
          'only_scoped_rule_appended': True, 'added_text': addition.decode(),
          'resolved_attributes': attributes,
          'diff': subprocess.check_output(['git', 'diff', '--', '.gitattributes'], cwd=repo).decode()}
with (task / 'fixture-attribute-proof.json').open('x', encoding='utf-8') as output:
    json.dump(record, output, indent=2)
    output.write('\n')
print(json.dumps(record), flush=True)
