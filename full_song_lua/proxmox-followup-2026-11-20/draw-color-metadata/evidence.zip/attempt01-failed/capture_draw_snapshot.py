"""Capture new Draw metadata against exact completed-build rlibs; never edit fixtures."""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[3]
TASK = Path(__file__).resolve().parent
SNAPSHOT = ROOT / 'tests/fixtures/regression-expectations/deadsync-song-lua/696f42b0abead8eb.snap'
TEST = ROOT / 'crates/deadsync-song-lua/tests/draw.rs'
FIELDS = re.compile(rb', inherited_diffuse: \[[^\]\r\n]*\], inherited_glow: \[[^\]\r\n]*\]')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def artifact(jsonl: Path, name: str) -> Path:
    found = []
    for line in jsonl.read_text(encoding='utf-8-sig').splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('reason') == 'compiler-artifact' and event.get('target', {}).get('name') == name:
            found.extend(Path(value) for value in event.get('filenames', []) if value.endswith('.rlib'))
    unique = list(dict.fromkeys(found))
    if len(unique) != 1:
        raise RuntimeError(f'expected one exact {name} rlib in {jsonl}, found {unique}')
    if not unique[0].is_file():
        raise RuntimeError(f'missing built rlib: {unique[0]}')
    return unique[0]


def source_identity() -> dict:
    paths = [TEST, ROOT / 'crates/deadsync-song-lua/src/actors/draw.rs',
             ROOT / 'crates/deadsync-song-lua/src/draw_commands.rs',
             ROOT / 'crates/deadsync-song-lua/src/playback.rs']
    return {str(path.relative_to(ROOT)): sha(path.read_bytes()) for path in paths}


def prepare_capture() -> Path:
    source = TEST.read_text(encoding='utf-8')
    old = '#[allow(dead_code)]\n#[path = "../../deadlib-lua/src/reference_test.rs"]\nmod reference_test;'
    assert source.count(old) == 1
    original = (ROOT / 'crates/deadlib-lua/src/reference_test.rs').as_posix()
    helper = r'''
#[allow(dead_code)]
#[path = "__ORIGINAL__"]
mod original_reference;
mod reference_test {
    use std::{cell::Cell, fmt::Debug, fs::OpenOptions, io::Write};
    thread_local! { static NEXT: Cell<usize> = const { Cell::new(0) }; }
    pub(crate) fn assert_debug(id: &str, actual: &impl Debug) {
        if id != "song/tests/rust_draw.rs::frames" {
            return super::original_reference::assert_debug(id, actual);
        }
        let index = NEXT.with(|next| { let index = next.get(); next.set(index + 1); index });
        let thread = std::thread::current();
        let name = thread.name().expect("named test");
        let text = format!("{actual:?}");
        let hex: String = text.bytes().map(|byte| format!("{byte:02x}")).collect();
        let path = std::env::var_os("DEADSYNC_DRAW_METADATA_CAPTURE").expect("capture output");
        let mut file = OpenOptions::new().create(true).append(true).open(path).unwrap();
        writeln!(file, "{name}\t{index}\t{hex}").unwrap();
    }
}
'''.replace('__ORIGINAL__', original)
    path = TASK / 'draw_capture.rs'
    path.write_text(source.replace(old, helper), encoding='utf-8', newline='\n')
    return path


def migrate(capture: Path, before: bytes) -> dict:
    actual = {}
    for line in capture.read_text(encoding='utf-8').splitlines():
        name, index, encoded = line.split('\t')
        key = (name, int(index))
        assert key not in actual, key
        actual[key] = bytes.fromhex(encoded)
    lines = before.splitlines(keepends=True)
    assert lines[0].rstrip(b'\r\n') == b'song/tests/rust_draw.rs::frames'
    output = []
    rows = []
    seen = set()
    name = None
    index = 0
    for lineno, raw in enumerate(lines, 1):
        content = raw.rstrip(b'\r\n')
        ending = raw[len(content):]
        if lineno == 1:
            output.append(raw)
            continue
        if content.startswith(b'test: '):
            name = content[len(b'test: '):].decode()
            index = 0
            output.append(raw)
            continue
        key = (name, index)
        index += 1
        seen.add(key)
        if key not in actual:
            raise RuntimeError(f'missing captured row {key}')
        value = actual[key]
        stripped, additions = FIELDS.subn(b'', value)
        if stripped != content:
            offset = next((i for i, (a, b) in enumerate(zip(stripped, content)) if a != b),
                          min(len(stripped), len(content)))
            raise RuntimeError(f'old fields changed: line {lineno} {key} byte {offset}; '
                               f'old={content[max(0,offset-80):offset+180]!r}; '
                               f'new={stripped[max(0,offset-80):offset+180]!r}')
        assert additions == content.count(b'Draw {'), (key, additions)
        if additions:
            rows.append({'line': lineno, 'test': name, 'case': key[1], 'metadata_pairs': additions})
        output.append(value + ending)
    if set(actual) != seen:
        raise RuntimeError(f'capture row mismatch: extra={set(actual)-seen}, missing={seen-set(actual)}')
    after = b''.join(output)
    assert FIELDS.sub(b'', after) == before
    proposed = TASK / 'draw-metadata-proposed.snap'
    proposed.write_bytes(after)
    patch = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),
                                       after.decode().splitlines(keepends=True),
                                       fromfile=str(SNAPSHOT), tofile=str(SNAPSHOT)))
    (TASK / 'draw-metadata-proposed.patch').write_text(patch, encoding='utf-8', newline='')
    return {'status': 'proposal only; fixture was not modified', 'old_fields_byte_identical': True,
            'before_sha256': sha(before), 'after_sha256': sha(after),
            'before_bytes': len(before), 'after_bytes': len(after),
            'crlf_before': before.count(b'\r\n'), 'crlf_after': after.count(b'\r\n'),
            'observation_rows': len(seen), 'changed_rows': rows,
            'metadata_pairs': sum(row['metadata_pairs'] for row in rows),
            'proposed_snapshot': str(proposed), 'capture_sha256': sha(capture.read_bytes())}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-jsonl', type=Path, required=True)
    parser.add_argument('--rustc', default='rustc')
    args = parser.parse_args()
    before_source = source_identity()
    before = SNAPSHOT.read_bytes()
    rlibs = {name: artifact(args.build_jsonl, name) for name in ['deadsync_song_lua', 'deadlib_lua']}
    source = prepare_capture()
    capture = TASK / 'draw-metadata-observations.tsv'
    capture.write_bytes(b'')
    binary = TASK / 'draw_capture.exe'
    command = [args.rustc, '--edition=2024', '--test', str(source), '--crate-name', 'draw_capture',
               '-C', 'target-feature=+crt-static',
               '-L', 'dependency=' + str(rlibs['deadsync_song_lua'].parent), '-o', str(binary)]
    for name, rlib in rlibs.items():
        command.extend(['--extern', f'{name}={rlib}'])
    native = set()
    for line in args.build_jsonl.read_text(encoding='utf-8-sig').splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('reason') == 'build-script-executed':
            native.update(event.get('linked_paths', []))
    for directory in sorted(native):
        command.extend(['-L', directory])
    env = dict(os.environ, CARGO_MANIFEST_DIR=str(ROOT / 'crates/deadsync-song-lua'),
               CARGO_PKG_NAME='deadsync-song-lua', DEADSYNC_DRAW_METADATA_CAPTURE=str(capture))
    with (TASK / 'draw-capture-build.stdout.log').open('w', encoding='utf-8') as out, \
         (TASK / 'draw-capture-build.stderr.log').open('w', encoding='utf-8') as err:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=out, stderr=err)
    if result.returncode:
        raise RuntimeError(f'capture-driver rustc failed: {result.returncode}; see target build logs')
    test_command = [str(binary), '--test-threads=1']
    with (TASK / 'draw-capture.stdout.log').open('w', encoding='utf-8') as out, \
         (TASK / 'draw-capture.stderr.log').open('w', encoding='utf-8') as err:
        result = subprocess.run(test_command, cwd=ROOT, env=env, stdout=out, stderr=err)
    if result.returncode:
        raise RuntimeError(f'capture-driver tests failed: {result.returncode}; see target test logs')
    assert source_identity() == before_source, 'source changed during capture'
    assert SNAPSHOT.read_bytes() == before, 'fixture changed during capture'
    receipt = migrate(capture, before)
    receipt.update({'build_jsonl': str(args.build_jsonl.resolve()),
                    'build_jsonl_sha256': sha(args.build_jsonl.read_bytes()),
                    'rlibs': {name: {'path': str(path), 'sha256': sha(path.read_bytes())}
                              for name, path in rlibs.items()},
                    'source_identity': before_source, 'capture_driver_sha256': sha(source.read_bytes()),
                    'capture_binary_sha256': sha(binary.read_bytes()),
                    'build_command': command, 'test_command': test_command,
                    'test_exit_code': result.returncode})
    (TASK / 'draw-metadata-migration-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n',
                                                            encoding='utf-8')
    print(json.dumps({key: receipt[key] for key in ['status', 'old_fields_byte_identical',
                                                  'observation_rows', 'metadata_pairs',
                                                  'before_sha256', 'after_sha256', 'proposed_snapshot']}))


if __name__ == '__main__':
    main()
