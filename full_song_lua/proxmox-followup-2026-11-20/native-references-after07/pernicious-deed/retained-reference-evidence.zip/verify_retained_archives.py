"""Stream-verify complete retained archives without loading their native JSON."""
import hashlib
import json
from pathlib import Path
import tarfile
import zstandard

ROOT = Path(__file__).resolve().parent

def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

class DigestReader:
    def __init__(self, stream):
        self.stream = stream
        self.sha = hashlib.sha256()
        self.bytes = 0
    def read(self, count=-1):
        raw = self.stream.read(count)
        self.sha.update(raw)
        self.bytes += len(raw)
        return raw

def main():
    references = json.loads((ROOT / 'retained-accepted-references.json').read_bytes())
    results = {}
    for slug in ['sharkmode', 'pernicious-deed']:
        reference = references[slug]
        path = Path(reference['archive'])
        before = path.stat()
        assert digest(path) == reference['sha256']
        with path.open('rb') as source:
            decoded = zstandard.ZstdDecompressor().stream_reader(source) if path.suffix == '.zst' else source
            reader = DigestReader(decoded)
            observed = {}
            with tarfile.open(fileobj=reader, mode='r|') as archive:
                for index, member in enumerate(archive):
                    assert member.isfile() and member.name not in observed
                    stream = archive.extractfile(member)
                    if index == 0:
                        assert member.name == 'manifest.json'
                        raw = stream.read()
                        assert hashlib.sha256(raw).hexdigest() == reference['manifest_sha256']
                        manifest = json.loads(raw)
                        expected = {row['path']: row for row in manifest['files']}
                        assert len(expected) == len(manifest['files'])
                        continue
                    assert member.name in expected, member.name
                    sha = hashlib.sha256()
                    size = 0
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        sha.update(chunk)
                        size += len(chunk)
                    row = {'bytes': size, 'sha256': sha.hexdigest()}
                    assert row['bytes'] == expected[member.name]['bytes'] == member.size, member.name
                    assert row['sha256'] == expected[member.name]['sha256'], member.name
                    observed[member.name] = row
            while reader.read(1 << 20):
                pass
            assert observed.keys() == expected.keys()
            raw_sha = reader.sha.hexdigest()
            if slug == 'pernicious-deed':
                assert raw_sha == '6edb175e95df37bc926956e9593aa8f95450a74e413e6e43f7fcaad96da0974a'
            else:
                assert raw_sha == reference['sha256']
            after = path.stat()
            assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
            assert digest(path) == reference['sha256']
            results[slug] = {'path': str(path), 'compressed' : path.suffix == '.zst',
                'sha256': reference['sha256'], 'bytes': before.st_size,
                'decoded_sha256': raw_sha, 'decoded_bytes': reader.bytes,
                'verified_manifest_files': len(observed), 'manifest_sha256': reference['manifest_sha256'],
                'trace': observed[manifest['chart']['trace']], 'source_unchanged': True,
                'source_mtime_ns': before.st_mtime_ns}
        print(json.dumps({'verified': slug, **results[slug]}), flush=True)
    with (ROOT / 'retained-archive-verification.json').open('x', encoding='utf-8') as output:
        json.dump(results, output, indent=2)
        output.write('\n')

if __name__ == '__main__':
    main()
