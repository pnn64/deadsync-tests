"""Verify retained references and freeze the original Shark source/settings once."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile
import zstandard

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
FLEET = Path('C:/GitHub/deadsync-lua-fleet-20261119/target/proxmox-song-lua-20261119')
OLD = FLEET / 'followup-native-controls-input-20261119T100328.353787Z/sharkmode'
SHA = 'c3a143c50fd1efb56e4f590560d157459417a1583f9b2e7db8fb35231fea4ab2'
DEED = 'e909208ae5d1a021e5cea40158a7cb31a25dfccea3e62bdb9c4106ebc16e58e9'
COMMIT = 'c715e619dd5acba3ecacfaafc99fbc1981b8ec02'

def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def write(path, value):
    with path.open('x', encoding='utf-8') as output:
        json.dump(value, output, indent=2, ensure_ascii=False)
        output.write('\n')

def main():
    selected = json.loads(gzip.decompress((OLD / 'selected-capture.json.gz').read_bytes()))
    original = selected['guests'][0]['payload']['files'][0]['data']
    job = original['job']
    manifest_path = FLEET / 'corpus-manifest.json'
    assert digest(manifest_path) == original['binding']['corpus_sha256']
    corpus = json.loads(manifest_path.read_bytes())
    records = [r for r in corpus['files'] if r['folder_sha256'] == job['folder_sha256']]
    assert len(records) == 23
    prefix = str(Path(job['source_simfile']).parent).replace('\\', '/') + '/'
    source_records = []
    for record in records:
        path = Path(record['source_path'])
        before = path.stat()
        assert before.st_size == record['bytes'] and digest(path) == record['sha256'], str(path)
        after = path.stat()
        assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
        assert record['path'].startswith(prefix)
        source_records.append({k: record[k] for k in ['path', 'bytes', 'sha256', 'source_path']})
    folder_digest = hashlib.sha256(json.dumps([(r['path'][len(prefix):], r['bytes'], r['sha256'])
        for r in source_records], ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
    assert folder_digest == job['folder_sha256']
    source_root = Path(records[0]['source_path']).parents[len(Path(records[0]['path']).parts) - 2]
    actual = {p.relative_to(source_root).as_posix() for p in source_root.rglob('*') if p.is_file()}
    assert actual == {r['path'][len(prefix):] for r in source_records}
    input_manifest = {'original_job': job, 'original_binding': original['binding'],
        'original_selected_capture': str(OLD / 'selected-capture.json.gz'),
        'original_selected_capture_sha256': digest(OLD / 'selected-capture.json.gz'),
        'corpus_manifest': str(manifest_path), 'corpus_manifest_sha256': digest(manifest_path),
        'folder_sha256': folder_digest, 'files': source_records,
        'original_capture_command': original['stages']['capture']['command'],
        'original_capture_timeout_seconds': original['stages']['capture']['timeout_seconds']}
    write(ROOT / 'source-and-recipe.json', input_manifest)
    accepted = {}
    for slug, path, expected_sha, expected_report in [
        ('sharkmode', OLD / 'input' / (SHA + '.tar'), SHA,
         '84a9906f70df0830eda5b42ee0d0ba2a7cd1da1737230bfc89bbcc4dea1e3d94'),
        ('pernicious-deed', ROOT.parent / 'native' / (DEED + '.tar.zst'), DEED,
         '949075a69b72fd6756b6955186786eb0e55d3898b3accb5466fed8b555e9bf95')]:
        assert digest(path) == expected_sha
        replay = ROOT.parent / (slug + '-after04')
        report_path = replay / 'report.json'
        assert digest(report_path) == expected_report
        report = json.loads(report_path.read_bytes())
        execution = json.loads((replay / 'execution.json').read_bytes())
        assert report['fixture_sha256'] == expected_sha and execution['archive_sha256'] == expected_sha
        assert report['archive_accepted'] and execution['exit_code'] == 0
        assert report['diagnostic_replay_checks_passed'] and report['production_gameplay_checks_passed']
        assert report['execution_path'] == 'production-and-diagnostic-live-lua'
        assert report['errors'] == [] and report['mismatches'] == []
        assert execution['binary_sha256'] == 'b466c6211c834f371bca599a2e34bf514e53ab8a2c3b96a8f33bb338def79e41'
        for name, expected in execution['reports'].items():
            member = replay / name
            assert member.stat().st_size == expected['bytes'] and digest(member) == expected['sha256']
        source = subprocess.run(['git', 'show', COMMIT + ':tests/song_lua_itgmania_semantic_parity/interactive.rs'],
                                cwd=PROJECT, capture_output=True, check=True).stdout
        variants = [source, source.replace(b'\n', b'\r\n')]
        assert any(hashlib.sha256(v).hexdigest() == execution['interactive_source_sha256'] for v in variants)
        with path.open('rb') as stream:
            decoded = zstandard.ZstdDecompressor().stream_reader(stream) if path.suffix == '.zst' else stream
            with tarfile.open(fileobj=decoded, mode='r|') as archive:
                member = next(iter(archive))
                assert member.name == 'manifest.json'
                raw_manifest = archive.extractfile(member).read()
                manifest = json.loads(raw_manifest)
        assert manifest['harness_version'] == '0.1.110'
        assert manifest['itgmania']['source_revision'] == '663525dcb86eb570d0ef6a2e209678436660ae26'
        assert manifest['itgmania']['source_dirty'] == 'false'
        accepted[slug] = {'archive': str(path), 'sha256': expected_sha, 'bytes': path.stat().st_size,
            'manifest_sha256': hashlib.sha256(raw_manifest).hexdigest(),
            'harness_version': manifest['harness_version'], 'native_source': manifest['itgmania'],
            'capture_binary_sha256': manifest['runtime']['command_observer']['capture_binary_sha256'],
            'chart': manifest['chart'], 'trace': next(r for r in manifest['files'] if r['role'] == 'semantic-render-trace'),
            'replay_report': str(report_path), 'replay_report_sha256': expected_report,
            'replay_execution': str(replay / 'execution.json'), 'replay_execution_sha256': digest(replay / 'execution.json'),
            'runner_sha256': execution['binary_sha256'], 'source_commit': COMMIT,
            'compiled_interactive_source_sha256': execution['interactive_source_sha256'],
            'compiled_build_binding_sha256': execution['compiled_build_binding_sha256'],
            'archive_accepted': True, 'diagnostic_replay_checks_passed': True, 'production_gameplay_checks_passed': True,
            'whole_song_parity_proven': report.get('whole_song_parity_proven'),
            'pixel_parity_proven': report.get('pixel_parity_proven'), 'pending_coverage_count': len(report['pending_coverage'])}
    assert accepted['pernicious-deed']['capture_binary_sha256'] == '1780c9e517994285775fa75c98c1975c601be0f94c4ad1a376cab16bd8684e8e'
    accepted['sharkmode']['disposition'] = 'retained accepted baseline; recapture with current binary before new fixture'
    accepted['pernicious-deed']['disposition'] = 'retain exact accepted compressed bytes; already captured with current binary'
    catalog_path = PROJECT / 'tests/fixtures/full_song_lua/index.json'
    rows = json.loads(catalog_path.read_bytes())['archives']
    accepted['catalog_before'] = {'path': str(catalog_path), 'sha256': digest(catalog_path),
        'matching_titles': [r for r in rows if any(s in r.get('title', '').lower() for s in ['sharkmode', 'pernicious'])],
        'exact_candidate_hash_present': any(r.get('sha256') in [SHA, DEED] or r.get('uncompressed_sha256') in [SHA, DEED] for r in rows)}
    assert not accepted['catalog_before']['exact_candidate_hash_present']
    write(ROOT / 'retained-accepted-references.json', accepted)
    helper_source = Path('C:/GitHub/itgmania-harness/target/typed-aft-uv-20261120/guest_capture.py')
    raw = helper_source.read_text(encoding='utf-8')
    prefix_source = raw.split('\ndef main():', 1)[0]
    helper = prefix_source.replace("unit = 'deadsync-typed-aft-'", "unit = 'deadsync-shark-fresh-'")
    helper += "\nif __name__ == '__main__':\n    assert len(sys.argv) == 3 and sys.argv[1] == 'finished'\n    finished(Path(sys.argv[2]))\n"
    with (ROOT / 'bounded_stage.py').open('x', encoding='utf-8', newline='\n') as output:
        output.write(helper)
    write(ROOT / 'bounded-stage-source.json', {'source': str(helper_source), 'source_sha256': digest(helper_source),
        'derived_sha256': digest(ROOT / 'bounded_stage.py'), 'changes': ['retain exact helper functions before main',
        'change only systemd unit prefix', 'allow only finished callback at script entry']})
    package = ROOT / 'input-package.zip'
    with zipfile.ZipFile(package, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for record in source_records:
            archive.write(record['source_path'], 'input/Songs/' + record['path'])
        for name in ['source-and-recipe.json', 'retained-accepted-references.json', 'bounded_stage.py', 'bounded-stage-source.json', 'run_native.py']:
            archive.write(ROOT / name, name)
    with zipfile.ZipFile(package) as archive:
        assert archive.testzip() is None
    write(ROOT / 'input-package.json', {'path': str(package), 'sha256': digest(package), 'bytes': package.stat().st_size,
        'source_files': len(source_records), 'source_bytes': sum(r['bytes'] for r in source_records),
        'folder_sha256': folder_digest})
    print(json.dumps({'prepared': True, 'input_package_sha256': digest(package), 'input_package_bytes': package.stat().st_size,
        'source_files': len(source_records), 'retained_accepted_references': str(ROOT / 'retained-accepted-references.json')}), flush=True)

if __name__ == '__main__':
    main()
