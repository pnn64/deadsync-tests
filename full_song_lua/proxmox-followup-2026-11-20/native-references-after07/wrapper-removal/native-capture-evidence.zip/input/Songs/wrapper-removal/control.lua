-- Native wrapper lifetime, late effect timers, theme metrics and affine order.
local ONE, TWO, THREE, INNER
local two_updates, inner_updates = 0, 0
local stopped_two, stopped_inner
local function stale(actor)
    return not pcall(function() return actor:x(0) end)
end
local function check_rejected(owner, value)
    assert(not pcall(function() owner:RemoveWrapperState(value) end))
    assert(owner:GetNumWrapperStates() == 3)
end

return Def.ActorFrame {
    Name = "WrapperRemovalControl",
    OnCommand = function(self) self:sleep(6) end,
    Def.Quad {
        Name = "Owner",
        InitCommand = function(self) self:xy(100, 100):setsize(20, 20):diffuse(1, 1, 1, 1) end,
        OnCommand = function(self)
            self.started = GAMESTATE:GetSongPosition():GetMusicSeconds()
            self.phase = 0
            self:queuecommand("Update")
        end,
        UpdateCommand = function(self)
            local elapsed = GAMESTATE:GetSongPosition():GetMusicSeconds() - self.started
            if self.phase == 0 and elapsed >= 0.25 then
                ONE = self:AddWrapperState():x(10)
                TWO = self:AddWrapperState():y(20)
                THREE = self:AddWrapperState():z(0)
                INNER = TWO:AddWrapperState():x(2)
                TWO.raw_saved = "retained outer field"
                INNER.raw_saved = "retained nested field"
                local late_timer = ONE:GetSecsIntoEffect()
                local nested_timer = INNER:GetSecsIntoEffect()
                assert(late_timer == 0 and nested_timer == 0)
                self:GetParent():GetChild("ImmediateTimerProbe"):xy(40 + late_timer, 40 + nested_timer)
                TWO:SetUpdateFunction(function(wrapper, delta)
                    two_updates = two_updates + 1
                    wrapper.last_delta = delta
                    wrapper.last_seconds = wrapper:GetSecsIntoEffect()
                end)
                INNER:SetUpdateFunction(function(wrapper, delta)
                    inner_updates = inner_updates + 1
                    wrapper.last_delta = delta
                    wrapper.last_seconds = wrapper:GetSecsIntoEffect()
                end)
                assert(self:GetNumWrapperStates() == 3)
                check_rejected(self, 0)
                check_rejected(self, -1)
                check_rejected(self, 4)
                check_rejected(self, false)
                check_rejected(self, {})
                check_rejected(self, "bad")
                assert(not pcall(function() self:RemoveWrapperState() end))
                assert(self:GetNumWrapperStates() == 3)
                self.phase = 1
            elseif self.phase == 1 and elapsed >= 0.65 then
                assert(two_updates > 0 and inner_updates > 0)
                assert(TWO.last_delta > 0 and INNER.last_delta > 0)
                assert(TWO.last_seconds > 0 and INNER.last_seconds > 0)
                stopped_two, stopped_inner = two_updates, inner_updates
                assert(self:RemoveWrapperState("2") == self)
                assert(self:GetNumWrapperStates() == 2)
                assert(self:GetWrapperState(1) == ONE and self:GetWrapperState(2) == THREE)
                assert(TWO.raw_saved == "retained outer field" and stale(TWO))
                assert(INNER.raw_saved == "retained nested field" and stale(INNER))
                THREE:vibrate():effectmagnitude(2, 3, 0)
                self.phase = 2
            elseif self.phase == 2 and elapsed >= 0.95 then
                assert(two_updates == stopped_two and inner_updates == stopped_inner)
                THREE:stopeffect()
                self.phase = 3
            elseif self.phase == 3 and elapsed >= 1.20 then
                assert(self:RemoveWrapperState(1.9) == self)
                assert(self:GetNumWrapperStates() == 1 and self:GetWrapperState(1) == THREE)
                assert(stale(ONE))
                self.phase = 4
            elseif self.phase == 4 and elapsed >= 1.55 then
                assert(self:RemoveWrapperState("1.9") == self)
                assert(self:GetNumWrapperStates() == 0 and stale(THREE))
                self.phase = 5
            elseif self.phase == 5 and elapsed >= 1.90 then
                local magnitude = THEME:GetMetric("ArrowEffects", "WaveModMagnitude")
                local height = THEME:GetMetric("ArrowEffects", "WaveModHeight")
                assert(magnitude == 20 and height == 38)
                self:GetParent():GetChild("WaveMetricProbe"):xy(magnitude, height)
                assert(two_updates == stopped_two and inner_updates == stopped_inner)
                self.phase = 6
            end
            if self.phase < 6 then self:sleep(0.025):queuecommand("Update") end
        end,
    },
    Def.Quad {
        Name = "ImmediateTimerProbe",
        InitCommand = function(self) self:xy(60, 60):setsize(4, 4) end,
    },
    Def.Quad {
        Name = "WaveMetricProbe",
        InitCommand = function(self) self:xy(60, 80):setsize(4, 4) end,
    },
    Def.ActorFrame {
        Name = "AffineParent",
        InitCommand = function(self) self:xy(420, 240):zoomx(3):zoomy(0.2) end,
        Def.ActorFrame {
            Name = "AffineRotated",
            InitCommand = function(self) self:rotationz(30) end,
            Def.Quad {
                Name = "AffineQuad",
                InitCommand = function(self) self:x(-12):setsize(16, 12):zoom(1) end,
            },
            Def.Sprite {
                Name = "AffineSprite",
                Texture = "white.png",
                InitCommand = function(self) self:x(12):zoom(1) end,
            },
        },
    },
}
