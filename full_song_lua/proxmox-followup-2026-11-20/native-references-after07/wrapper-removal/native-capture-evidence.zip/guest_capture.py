"""Bounded native capture in a new task directory; old queues remain untouched."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PROFILE = Path('/opt/song-lua-audit/pass4/capture-profiles/d5e531147bbe2b44ae64ea19efb9c8087f0de503b9de340ccd2a872c09920911')
HARNESS = PROFILE / 'bin/itgmania-harness-rs'
ENGINE_ROOT = Path('/opt/song-lua-audit/harness-pass4/vendor/itgmania')
ENGINE = ENGINE_ROOT / 'ITGmania-harness-trace'
THEME = ENGINE_ROOT / 'Themes/Harness Simply Love'
EXPECTED = {
    str(HARNESS): '1780c9e517994285775fa75c98c1975c601be0f94c4ad1a376cab16bd8684e8e',
    str(ENGINE): 'c03763cac1270c14dbe790cbb055c96ebbced269448d64e0bb705385dc9537a3',
}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def finished(spec_path):
    spec = json.loads(spec_path.read_text())
    info = subprocess.run(['systemctl', 'show', spec['unit'], '--no-pager',
                           '--property=MemoryPeak,CPUUsageNSec,MemoryMax,MemorySwapMax,CPUQuotaPerSecUSec'],
                          capture_output=True, text=True)
    write(spec_path.parent / 'receipt.json', {
        'finished_at': now(), 'unit': spec['unit'],
        'service_result': os.environ.get('SERVICE_RESULT'),
        'exit_code': os.environ.get('EXIT_CODE'), 'exit_status': os.environ.get('EXIT_STATUS'),
        'resource_usage': dict(line.split('=', 1) for line in info.stdout.splitlines() if '=' in line),
        'spec_sha256': digest(spec_path),
    })

def stage(name, command, seconds):
    directory = ROOT / 'stages' / name
    directory.mkdir(parents=True)
    environment = {'DISPLAY': ':99', 'LIBGL_ALWAYS_SOFTWARE': '1', 'GALLIUM_DRIVER': 'llvmpipe',
                   'LP_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'TMPDIR': str(ROOT / 'tmp'),
                   'ITGMANIA_SONG_LUA_NOTESKIN_ROOT': str(ENGINE_ROOT / 'NoteSkins')}
    command = [str(value) for value in command]
    spec = {'started_at': now(), 'command': command, 'environment': environment,
            'working_directory': str(ROOT), 'memory_max_bytes': 6 * 1024**3,
            'cpu_quota_percent': 200, 'timeout_seconds': seconds}
    token = hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:16]
    unit = 'deadsync-wrapper-removal-' + name + '-' + token
    spec['unit'] = unit
    spec_path = directory / 'spec.json'
    write(spec_path, spec)
    log = directory / 'output.log'
    launch = ['sudo', '-n', 'systemd-run', '--quiet', '--wait', '--collect', '--unit=' + unit,
              '--property=MemoryMax=6G', '--property=MemorySwapMax=0', '--property=CPUQuota=200%',
              '--property=OOMPolicy=kill', '--property=RuntimeMaxSec=' + str(seconds),
              '--property=TimeoutStopSec=15', '--property=KillMode=control-group',
              '--property=User=parity', '--property=Group=parity',
              '--property=StandardOutput=append:' + str(log),
              '--property=StandardError=append:' + str(log),
              '--property=ExecStopPost=/usr/bin/python3 ' + str(Path(__file__).resolve()) + ' finished ' + str(spec_path),
              '--working-directory=' + str(ROOT)]
    launch += ['--setenv=' + key + '=' + value for key, value in environment.items()]
    result = subprocess.run(launch + command, capture_output=True, text=True)
    write(directory / 'launch.json', {'command': launch + command, 'exit': result.returncode,
                                     'stdout': result.stdout, 'stderr': result.stderr})
    receipt = json.loads((directory / 'receipt.json').read_text())
    print(json.dumps({'stage': name, 'exit': result.returncode, 'receipt': receipt}), flush=True)
    if result.returncode != 0 or receipt['service_result'] != 'success':
        raise RuntimeError(name + ' failed; see retained output and receipt')

def main():
    (ROOT / 'tmp').mkdir()
    (ROOT / 'traces').mkdir()
    (ROOT / 'provenance').mkdir()
    source_proof = json.loads((PROFILE / 'proof/source-proof.json').read_text())
    assert source_proof['pins']['harness'] == 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c'
    observed = {}
    for name, expected in EXPECTED.items():
        actual = digest(name)
        assert actual == expected, (name, actual, expected)
        observed[name] = {'sha256': actual, 'bytes': Path(name).stat().st_size}
    for name in ['source-proof.json', 'build-proof.json']:
        shutil.copyfile(PROFILE / 'proof' / name, ROOT / 'provenance' / name)
    write(ROOT / 'provenance/binaries.json', {'verified_at': now(), 'binaries': observed,
                                            'source_pins': source_proof['pins']})
    source = ROOT / 'input/Songs/wrapper-removal/control.ssc'
    trace_path = ROOT / 'traces/native.json'
    stage('capture', [HARNESS, 'song-lua-trace', source, '--itgmania-bin', ENGINE,
          '--fallback-theme', 'Harness Simply Love', '--game', 'dance', '--style', 'versus',
          '--capture-fps', '60', '--max-events', '200000', '--timeout', '120', '--random-seed', '1',
          '--autoplay', '1', '--out', trace_path, '--until-gameplay-end', '--headless',
          '--drawable-samples', '--chart-index', '1', '--difficulty', 'Challenge'], 150)
    native = json.loads(trace_path.read_text())
    assert native['input']['native_source']['revision'] == '663525dcb86eb570d0ef6a2e209678436660ae26'
    assert native['input']['native_source']['modified_src'] is False
    assert native['input']['headless_graphics'] is True and native['input']['window_visible'] is False
    assert native['completion']['reason'] == 'gameplay-exit' and native['completion']['stage_committed'] is True
    assert not native.get('script_errors') and not native.get('transition_script_errors')
    assert all(value == 0 for key, value in native.items() if key.startswith('dropped_'))
    assert len(native['drawable_samples']) > 0, 'control did not observe draw submissions'
    observed = [event for event in native['events'] if event.get('operation') in
                ['Actor.AddWrapperState', 'Actor.RemoveWrapperState', 'Actor.GetSecsIntoEffect',
                 'Actor.GetWrapperState', 'Actor.GetNumWrapperStates', 'ThemeManager.GetMetric']]
    assert sum(event.get('operation') == 'Actor.AddWrapperState' for event in observed) == 4
    assert sum(event.get('operation') == 'Actor.RemoveWrapperState' for event in observed) >= 3
    write(ROOT / 'native-probe-events.json', observed)
    summary = {'trace_sha256': digest(trace_path), 'trace_bytes': trace_path.stat().st_size,
               'harness_revision': source_proof['pins']['harness'],
               'harness_version': native['harness_version'], 'native_source': native['input']['native_source'],
               'completion': native['completion'], 'capabilities': native['capabilities'],
               'counts': {key: len(native.get(key, [])) for key in ['update_frames', 'events', 'drawable_samples', 'stage_samples']},
               'dropped': {key: value for key, value in native.items() if key.startswith('dropped_')}}
    write(ROOT / 'native-summary.json', summary)
    write(ROOT / 'traces/_semantic_manifest.json', {
        'fixture_schema_version': 1, 'oracle_schema_version': native['schema_version'],
        'harness_version': native['harness_version'],
        'itgmania': {'git_revision': source_proof['pins']['native'], 'git_dirty': 'false'},
        'simfiles': [{'simfile': 'wrapper-removal/control.ssc', 'fixture': 'native.json',
                     'title': 'Wrapper removal native semantics', 'status': 'ok',
                     'command_observer': native['command_observer']}]})
    stage('archive', [HARNESS, 'song-lua-archive', ROOT / 'input/Songs', '--traces', ROOT / 'traces',
                     '--out', ROOT / 'candidate', '--uncompressed', '--theme-assets', THEME], 150)
    entry = json.loads((ROOT / 'candidate/index.json').read_text())['archives']
    assert len(entry) == 1
    candidate = ROOT / 'candidate' / entry[0]['archive']
    assert candidate.name == digest(candidate) + '.tar'
    write(ROOT / 'capture-result.json', {'passed': True, 'finished_at': now(), 'native': summary,
          'candidate': {'path': str(candidate), 'sha256': digest(candidate), 'bytes': candidate.stat().st_size},
          'archive_entry': entry[0], 'parity_accepted': False})
    print(json.dumps({'passed': True, 'root': str(ROOT), 'candidate': str(candidate), 'counts': summary['counts']}), flush=True)

if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == 'finished':
        finished(Path(sys.argv[2]))
    else:
        main()
