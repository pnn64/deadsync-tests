import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

root = Path(__file__).resolve().parent
out = root / 'baseline-before-fix'
out.mkdir(exist_ok=False)
retained = Path('C:/GitHub/deadsync/target/song-lua-parity-20261120/baseline-before-amv-and-wrapper-fixes')
binary = retained / 'full_song_lua.exe'
identity = json.loads((retained / 'identity.json').read_text())
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''): h.update(block)
    return h.hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
assert sha(binary) == identity['binary_sha256'] == 'db462d6906c1c904b7a786483e0719d09cc7fb120d73a9bf0df12ed3da7a1e25'
assert binary.stat().st_size == identity['bytes']
assert sha(Path(identity['source_execution_receipt'])) == identity['source_execution_receipt_sha256']
shutil.copyfile(retained / 'identity.json', out / 'retained-binary-identity.json')
receipt = json.loads((root / 'download-receipt.json').read_text())
candidate = Path(receipt['candidate']['local_path'])
assert sha(candidate) == receipt['candidate']['sha256']
command = [str(binary), '--archive', str(candidate), '--report', str(out / 'report.json'), '--production']
invocation = {'command': command, 'cwd': 'C:/GitHub/deadsync', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'timeout_seconds': 180, 'retained_historical_build': True, 'binary_sha256': sha(binary),
              'binary_identity_sha256': sha(retained / 'identity.json'), 'candidate_sha256': sha(candidate)}
write(out / 'invocation.json', invocation)
start = time.monotonic()
with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
    try:
        result = subprocess.run(command, cwd='C:/GitHub/deadsync', stdout=stdout, stderr=stderr,
            env={**os.environ, 'RAYON_NUM_THREADS': '2', 'OMP_NUM_THREADS': '2'}, timeout=180)
        code = result.returncode
        timeout = False
    except subprocess.TimeoutExpired:
        code, timeout = None, True
execution = {**invocation, 'exit_code': code, 'timed_out': timeout, 'runtime_seconds': time.monotonic() - start,
             'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'outputs': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in out.iterdir() if p.is_file()}}
write(out / 'execution.json', execution)
summary = {'exit_code': code, 'timed_out': timeout, 'directory': str(out)}
if (out / 'report.json').exists():
    report = json.loads((out / 'report.json').read_text())
    summary.update({'report_sha256': sha(out / 'report.json'),
        'archive_accepted': report['archive_accepted'],
        'diagnostic_replay_checks_passed': report['diagnostic_replay_checks_passed'],
        'production_gameplay_checks_passed': report['production_gameplay_checks_passed'],
        'diagnostic': report['interactive'], 'production': report['production_replay']['interactive'],
        'errors': report['errors'], 'mismatches_count': len(report['mismatches'])})
write(out / 'summary.json', summary)
print(json.dumps(summary, indent=2))
