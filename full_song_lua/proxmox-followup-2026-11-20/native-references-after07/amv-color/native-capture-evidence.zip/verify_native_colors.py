"""Verify actual native color-byte observations for the authored control."""
import collections
import math


def color_bytes(sample):
    observed = []
    for vertex in sample['vertices']:
        assert len(vertex) == 13
        rgba = vertex[9:13]
        assert len(rgba) == 4 and all(math.isfinite(value) for value in rgba)
        packed = tuple(round(value * 255) for value in rgba)
        assert all(0 <= value <= 255 for value in packed)
        assert all(abs(value - byte / 255) <= 5e-7 for value, byte in zip(rgba, packed))
        observed.append(packed)
    return observed


def verify(trace, expected):
    definitions = trace['actor_definitions']
    frames = {(frame['scene'], frame['sequence']): frame for frame in trace['update_frames']}
    results = {}
    sample_count = None
    for name, case in expected['expected_cases'].items():
        parents = [definition for definition in definitions if definition.get('name') == name]
        assert len(parents) == 1, ('named parent', name, parents)
        children = [definition for definition in definitions if definition.get('parent_id') == parents[0]['id']
                    and definition['class'] == 'ActorMultiVertex' and definition.get('name') == 'Mesh']
        assert len(children) == 1 and len(children[0]['runtime_actors']) == 1, ('mesh identity', name, children)
        actor = children[0]['runtime_actors'][0]
        samples = [sample for sample in trace['drawable_samples'] if sample['actor'] == actor]
        calls = [event for event in trace['events'] if event.get('actor') == actor
                 and event.get('operation') == 'Actor.Draw' and event.get('callback') == 'SetDrawFunction']
        assert samples, ('empty native coverage', name)
        by_frame = collections.defaultdict(list)
        for sample in samples:
            assert len(sample['vertices']) == 4
            state = sample['state']
            if case.get('textured', True):
                assert [state[key] for key in ['image_width', 'image_height', 'texture_width', 'texture_height']] == [8, 8, 8, 8]
                assert state['texture'] == 'AmvColorWhiteTarget'
            else:
                assert state['texture'] == ''
                assert [state[key] for key in ['image_width', 'image_height', 'texture_width', 'texture_height']] == [1, 1, 1, 1]
            by_frame[(sample['scene'], sample['update_sequence'])].append(sample)
        if case.get('manual_draw', True):
            assert len(calls) == len(by_frame), ('manual call/sample frame count', name)
        else:
            assert not calls, ('parent diffuse cases use normal child drawing', name)
        if sample_count is None:
            sample_count = len(by_frame)
        assert len(by_frame) == sample_count, ('unequal case coverage', name)
        ordered = sorted(by_frame)
        observed_classes = collections.Counter()
        for call, key in zip(calls, ordered):
            assert call['scene'] == key[0] and call['seconds'] == frames[key]['seconds']
        for key in ordered:
            frame_samples = by_frame[key]
            if 'glow_submitted_rgba_bytes' in case:
                assert len(frame_samples) == 2, ('both diffuse and glow submissions required', key)
                required = {frozenset(map(tuple, case['diffuse_submitted_rgba_bytes'])),
                            frozenset(map(tuple, case['glow_submitted_rgba_bytes']))}
                actual = {frozenset(color_bytes(sample)) for sample in frame_samples}
                assert actual == required, ('diffuse/glow color bytes', name, key, actual, required)
            else:
                assert len(frame_samples) == 1
                required = set(map(tuple, case['submitted_rgba_bytes']))
                actual = set(color_bytes(frame_samples[0]))
                assert actual == required, ('color bytes', name, key, actual, required)
            for sample in frame_samples:
                observed_classes[str(sorted(set(color_bytes(sample))))] += 1
        results[name] = {'definition_id': children[0]['id'], 'runtime_actor': actor,
                         'draw_calls': len(calls), 'drawable_samples': len(samples),
                         'sample_update_sequences': [ordered[0][1], ordered[-1][1]],
                         'observed_rgba_byte_classes': dict(observed_classes),
                         'first_sample': samples[0]}
    return {'native_observations_verified': True, 'case_count': len(results),
            'sample_frames_per_case': sample_count, 'cases': results,
            'replay_acceptance': 'pending', 'pixel_parity_proven': False}
