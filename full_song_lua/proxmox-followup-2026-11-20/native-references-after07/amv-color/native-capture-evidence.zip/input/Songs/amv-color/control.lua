-- Native AMV colors: FTOC on authored vertices, then byte/float modulation.
local white = {1, 1, 1, 1}
local authored = {0.1234, 0.501, 0.8761, 0.1234}
local clamped = {-0.125, 1.25, 0.501, 0.499}
local function quad(first, second)
    return {
        {{0, 0, 0}, first, {0, 0}},
        {{64, 0, 0}, second, {1, 0}},
        {{64, 64, 0}, first, {1, 1}},
        {{0, 64, 0}, second, {0, 1}},
    }
end

return Def.ActorFrame {
    Name = "AmvByteColorControl",
    OnCommand = function(self)
        self:sleep(6)
        local target = self:GetChild("Target")
        target:SetSize(8, 8):SetTextureName("AmvColorWhiteTarget")
            :EnableAlphaBuffer(true):Create()
        local texture = target:GetTexture()
        assert(texture:GetImageWidth() == 8 and texture:GetImageHeight() == 8)
        assert(texture:GetTextureWidth() == 8 and texture:GetTextureHeight() == 8)
        local groups = {
            self:GetChild("FractionalParent"), self:GetChild("AlphaLow"),
            self:GetChild("AlphaMid"), self:GetChild("AlphaHigh"), self:GetChild("GlowCase"),
            self:GetChild("UntexturedParent"), self:GetChild("UntexturedGlow"),
        }
        for index, group in ipairs(groups) do
            local mesh = group:GetChild("Mesh")
            local vertices = (index == 2 or index == 3 or index == 4) and quad(white, white) or quad(authored, clamped)
            if index <= 5 then mesh:SetTexture(texture) end
            mesh:SetVertices(vertices):SetDrawState{Mode="DrawMode_Quads", First=1, Num=-1}
            -- Native ActorFrame normal drawing propagates parent diffuse;
            -- a custom DrawFunction deliberately handles only the other cases.
            if index ~= 1 and index ~= 6 then
                group:SetDrawFunction(function() mesh:Draw() end)
            end
        end
        self:SetDrawFunction(function()
            target:Draw()
            for _, group in ipairs(groups) do group:Draw() end
        end)
    end,
    Def.ActorFrameTexture {
        Name = "Target",
        Def.Quad {
            Name = "WhiteFill",
            InitCommand = function(self) self:xy(4, 4):zoomto(8, 8):diffuse(1, 1, 1, 1) end,
        },
    },
    Def.ActorFrame {
        Name = "FractionalParent",
        InitCommand = function(self) self:xy(80, 120):diffuse(0.875, 0.875, 0.75, 0.875) end,
        Def.ActorMultiVertex {
            Name = "Mesh",
            InitCommand = function(self) self:diffuse(0.8, 0.6, 0.75, 0.8) end,
        },
    },
    Def.ActorFrame {
        Name = "AlphaLow",
        InitCommand = function(self) self:xy(240, 120) end,
        Def.ActorMultiVertex {
            Name = "Mesh",
            InitCommand = function(self) self:diffusealpha(0.10809415578842163) end,
        },
    },
    Def.ActorFrame {
        Name = "AlphaMid",
        InitCommand = function(self) self:xy(400, 120) end,
        Def.ActorMultiVertex {
            Name = "Mesh",
            InitCommand = function(self) self:diffusealpha(0.626785933971405) end,
        },
    },
    Def.ActorFrame {
        Name = "AlphaHigh",
        InitCommand = function(self) self:xy(560, 120) end,
        Def.ActorMultiVertex {
            Name = "Mesh",
            InitCommand = function(self) self:diffusealpha(0.7642954587936401) end,
        },
    },
    Def.ActorFrame {
        Name = "GlowCase",
        InitCommand = function(self) self:xy(80, 280):diffuse(1, 1, 1, 1) end,
        Def.ActorMultiVertex {
            Name = "Mesh",
            InitCommand = function(self)
                self:diffuse(1, 1, 1, 0.001):glow(0.4375, 0.25, 0.125, 0.3133929669857025)
            end,
        },
    },
    Def.ActorFrame {
        Name = "UntexturedParent",
        InitCommand = function(self) self:xy(240, 280):diffuse(0.875, 0.875, 0.75, 0.875) end,
        Def.ActorMultiVertex {
            Name = "Mesh",
            InitCommand = function(self) self:diffuse(0.8, 0.6, 0.75, 0.8) end,
        },
    },
    Def.ActorFrame {
        Name = "UntexturedGlow",
        InitCommand = function(self) self:xy(400, 280):diffuse(1, 1, 1, 1) end,
        Def.ActorMultiVertex {
            Name = "Mesh",
            InitCommand = function(self)
                self:diffuse(1, 1, 1, 0.001):glow(0.4375, 0.25, 0.125, 0.3133929669857025)
            end,
        },
    },
}
