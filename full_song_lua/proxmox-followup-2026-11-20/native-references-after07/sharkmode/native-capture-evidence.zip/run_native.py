"""One bounded Shark capture/archive using the exact prior source and settings."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import bounded_stage as stage

ROOT = Path(__file__).resolve().parent
EXPECTED_HARNESS = '1780c9e517994285775fa75c98c1975c601be0f94c4ad1a376cab16bd8684e8e'

def tree_digest(root):
    root = Path(root)
    hasher = hashlib.sha256()
    for directory, names, filenames in os.walk(root):
        names[:] = sorted(name for name in names if name != '.git')
        for filename in sorted(filenames):
            if filename == '.git':
                continue
            path = Path(directory) / filename
            hasher.update(path.relative_to(root).as_posix().encode('utf-8') + b'\0' + stage.digest(path).encode('ascii') + b'\n')
    return hasher.hexdigest()

def verify_song(recipe):
    for row in recipe['files']:
        path = ROOT / 'input/Songs' / row['path']
        assert path.stat().st_size == row['bytes'] and stage.digest(path) == row['sha256'], str(path)
    actual = {p.relative_to(ROOT / 'input/Songs').as_posix() for p in (ROOT / 'input/Songs').rglob('*') if p.is_file()}
    assert actual == {r['path'] for r in recipe['files']}

def main():
    recipe = json.loads((ROOT / 'source-and-recipe.json').read_bytes())
    job = recipe['original_job']
    assert not (ROOT / 'run-started.json').exists(), 'one attempt only'
    disk = dict(zip(['total', 'used', 'free'], shutil.disk_usage(ROOT)))
    assert disk['free'] >= 8 * 1024**3
    processes = subprocess.run(['ps', '-eo', 'pid,ppid,comm,args'], capture_output=True, text=True, check=True).stdout
    active = [line for line in processes.splitlines() if any(s in line for s in ['ITGmania-harness-trace', 'itgmania-harness-rs', 'full_song_lua-', '/cargo ', '/rustc '])]
    assert not active, active
    verify_song(recipe)
    assert stage.digest(stage.HARNESS) == EXPECTED_HARNESS
    assert stage.digest(stage.ENGINE) == recipe['original_binding']['engine_sha256']
    proof = json.loads((stage.PROFILE / 'proof/source-proof.json').read_bytes())
    assert proof['pins']['harness'] == 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c'
    assert proof['pins']['native'] == recipe['original_binding']['native_revision']
    observed_theme = tree_digest(stage.THEME)
    observed_noteskins = tree_digest(stage.ENGINE_ROOT / 'NoteSkins')
    assert observed_theme == recipe['original_binding']['theme_tree_sha256']
    assert observed_noteskins == recipe['original_binding']['noteskins_tree_sha256']
    for name in ['tmp', 'traces', 'provenance']:
        (ROOT / name).mkdir()
    for name in ['source-proof.json', 'build-proof.json']:
        shutil.copyfile(stage.PROFILE / 'proof' / name, ROOT / 'provenance' / name)
    stage.write(ROOT / 'run-started.json', {'started_at': stage.now(), 'vmid': 1503, 'disk': disk,
        'active_competing_jobs': active, 'folder_sha256': recipe['folder_sha256'],
        'harness_sha256': EXPECTED_HARNESS, 'engine_sha256': stage.digest(stage.ENGINE),
        'theme_tree_sha256': observed_theme, 'noteskins_tree_sha256': observed_noteskins})
    trace_path = ROOT / 'traces/native.json'
    command = [stage.HARNESS, 'song-lua-trace', ROOT / 'input/Songs' / job['source_simfile'],
        '--itgmania-bin', stage.ENGINE, '--fallback-theme', 'Harness Simply Love',
        '--game', job['game'], '--style', job['style'], '--capture-fps', str(job['capture_fps']),
        '--max-events', str(job['max_events']), '--timeout', str(job['capture_timeout']),
        '--random-seed', str(job['random_seed']), '--out', trace_path, '--until-gameplay-end',
        '--headless', '--drawable-samples', '--chart-index', str(job['chart_index']), '--difficulty', 'Challenge']
    stage.stage('capture', command, recipe['original_capture_timeout_seconds'])
    native = json.loads(trace_path.read_bytes())
    assert native['harness_version'] == '0.1.110'
    assert native['command_observer']['capture_binary_sha256'] == EXPECTED_HARNESS
    assert native['input']['native_source']['revision'] == recipe['original_binding']['native_revision']
    assert native['input']['native_source']['modified_src'] is False
    assert native['input']['headless_graphics'] is True and native['input']['window_visible'] is False
    assert native['input']['requested_chart_index'] == job['chart_index']
    assert native['input']['starting_chart'] == job['expected_chart']
    assert native['completion']['reason'] == 'gameplay-exit' and native['completion']['stage_committed'] is True
    assert not native.get('script_errors') and not native.get('transition_script_errors')
    assert all(value == 0 for key, value in native.items() if key.startswith('dropped_'))
    assert native['drawable_samples'] and native['update_frames'] and native['stage_samples']
    summary = {'trace_sha256': stage.digest(trace_path), 'trace_bytes': trace_path.stat().st_size,
        'harness_version': native['harness_version'], 'capture_binary_sha256': EXPECTED_HARNESS,
        'harness_commit': proof['pins']['harness'], 'native_source': native['input']['native_source'],
        'input': native['input'], 'completion': native['completion'], 'capabilities': native['capabilities'],
        'counts': {key: len(native.get(key, [])) for key in ['update_frames', 'events', 'drawable_samples', 'stage_samples', 'render_random_inputs']},
        'dropped': {key: value for key, value in native.items() if key.startswith('dropped_')},
        'script_error_count': len(native.get('script_errors', [])),
        'transition_script_error_count': len(native.get('transition_script_errors', []))}
    stage.write(ROOT / 'native-summary.json', summary)
    stage.write(ROOT / 'traces/_semantic_manifest.json', {'fixture_schema_version': 1,
        'oracle_schema_version': native['schema_version'], 'harness_version': native['harness_version'],
        'itgmania': {'git_revision': proof['pins']['native'], 'git_dirty': 'false'},
        'simfiles': [{'simfile': job['source_simfile'], 'fixture': 'native.json', 'title': native['title'],
            'status': 'ok', 'command_observer': native['command_observer']}]})
    del native
    verify_song(recipe)
    stage.stage('archive', [stage.HARNESS, 'song-lua-archive', ROOT / 'input/Songs', '--traces', ROOT / 'traces',
        '--out', ROOT / 'candidate', '--uncompressed', '--theme-assets', stage.THEME], 900)
    entries = json.loads((ROOT / 'candidate/index.json').read_bytes())['archives']
    assert len(entries) == 1
    candidate = ROOT / 'candidate' / entries[0]['archive']
    digest = stage.digest(candidate)
    assert candidate.name == digest + '.tar'
    result = {'capture_validated': True, 'finished_at': stage.now(), 'vmid': 1503,
        'candidate': {'path': str(candidate), 'sha256': digest, 'bytes': candidate.stat().st_size},
        'archive_entry': entries[0], 'native_summary_sha256': stage.digest(ROOT / 'native-summary.json'),
        'counts': summary['counts'], 'source_folder_sha256': recipe['folder_sha256'],
        'parity_accepted': False, 'current_main_replay_required': True}
    stage.write(ROOT / 'capture-result.json', result)
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    main()
