"""Bounded native capture in a new task directory; old queues remain untouched."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PROFILE = Path('/opt/song-lua-audit/pass4/capture-profiles/d5e531147bbe2b44ae64ea19efb9c8087f0de503b9de340ccd2a872c09920911')
HARNESS = PROFILE / 'bin/itgmania-harness-rs'
ENGINE_ROOT = Path('/opt/song-lua-audit/harness-pass4/vendor/itgmania')
ENGINE = ENGINE_ROOT / 'ITGmania-harness-trace'
THEME = ENGINE_ROOT / 'Themes/Harness Simply Love'
EXPECTED = {
    str(HARNESS): '1780c9e517994285775fa75c98c1975c601be0f94c4ad1a376cab16bd8684e8e',
    str(ENGINE): 'c03763cac1270c14dbe790cbb055c96ebbced269448d64e0bb705385dc9537a3',
}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def finished(spec_path):
    spec = json.loads(spec_path.read_text())
    info = subprocess.run(['systemctl', 'show', spec['unit'], '--no-pager',
                           '--property=MemoryPeak,CPUUsageNSec,MemoryMax,MemorySwapMax,CPUQuotaPerSecUSec'],
                          capture_output=True, text=True)
    write(spec_path.parent / 'receipt.json', {
        'finished_at': now(), 'unit': spec['unit'],
        'service_result': os.environ.get('SERVICE_RESULT'),
        'exit_code': os.environ.get('EXIT_CODE'), 'exit_status': os.environ.get('EXIT_STATUS'),
        'resource_usage': dict(line.split('=', 1) for line in info.stdout.splitlines() if '=' in line),
        'spec_sha256': digest(spec_path),
    })

def stage(name, command, seconds):
    directory = ROOT / 'stages' / name
    directory.mkdir(parents=True)
    environment = {'DISPLAY': ':99', 'LIBGL_ALWAYS_SOFTWARE': '1', 'GALLIUM_DRIVER': 'llvmpipe',
                   'LP_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'TMPDIR': str(ROOT / 'tmp'),
                   'ITGMANIA_SONG_LUA_NOTESKIN_ROOT': str(ENGINE_ROOT / 'NoteSkins')}
    command = [str(value) for value in command]
    spec = {'started_at': now(), 'command': command, 'environment': environment,
            'working_directory': str(ROOT), 'memory_max_bytes': 6 * 1024**3,
            'cpu_quota_percent': 200, 'timeout_seconds': seconds}
    token = hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:16]
    unit = 'deadsync-shark-fresh-' + name + '-' + token
    spec['unit'] = unit
    spec_path = directory / 'spec.json'
    write(spec_path, spec)
    log = directory / 'output.log'
    launch = ['sudo', '-n', 'systemd-run', '--quiet', '--wait', '--collect', '--unit=' + unit,
              '--property=MemoryMax=6G', '--property=MemorySwapMax=0', '--property=CPUQuota=200%',
              '--property=OOMPolicy=kill', '--property=RuntimeMaxSec=' + str(seconds),
              '--property=TimeoutStopSec=15', '--property=KillMode=control-group',
              '--property=User=parity', '--property=Group=parity',
              '--property=StandardOutput=append:' + str(log),
              '--property=StandardError=append:' + str(log),
              '--property=ExecStopPost=/usr/bin/python3 ' + str(Path(__file__).resolve()) + ' finished ' + str(spec_path),
              '--working-directory=' + str(ROOT)]
    launch += ['--setenv=' + key + '=' + value for key, value in environment.items()]
    result = subprocess.run(launch + command, capture_output=True, text=True)
    write(directory / 'launch.json', {'command': launch + command, 'exit': result.returncode,
                                     'stdout': result.stdout, 'stderr': result.stderr})
    receipt = json.loads((directory / 'receipt.json').read_text())
    print(json.dumps({'stage': name, 'exit': result.returncode, 'receipt': receipt}), flush=True)
    if result.returncode != 0 or receipt['service_result'] != 'success':
        raise RuntimeError(name + ' failed; see retained output and receipt')

if __name__ == '__main__':
    assert len(sys.argv) == 3 and sys.argv[1] == 'finished'
    finished(Path(sys.argv[2]))
