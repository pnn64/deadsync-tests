"""Retain a completed replay checkpoint without modifying any earlier evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def verify_files(directory, inventory):
    for name, expected in inventory.items():
        path = directory / name
        assert path.resolve().is_relative_to(directory.resolve())
        assert path.is_file(), 'missing retained evidence: ' + str(path)
        assert path.stat().st_size == expected['bytes'], 'retained evidence size changed: ' + str(path)
        assert sha(path) == expected['sha256'], 'retained evidence hash changed: ' + str(path)

def artifacts(log):
    binaries = {}
    finished = False
    for line in log.read_text(encoding='utf-8-sig').splitlines():
        event = json.loads(line)
        if event.get('reason') == 'build-finished':
            finished = event.get('success') is True
        if event.get('reason') == 'compiler-artifact' and event.get('executable'):
            binaries[event['target']['name']] = Path(event['executable'])
    assert finished, 'Cargo build has not finished successfully: ' + str(log)
    return binaries

def test_results(directory):
    results = []
    paths = set(directory.glob('*.stdout.log'))
    if (directory / 'stdout.log').is_file():
        paths.add(directory / 'stdout.log')
    for path in sorted(paths):
        matches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', path.read_text(encoding='utf-8', errors='replace'))
        results.append({'log': path.name, 'results': matches})
    return results

def comparison(report):
    keys = ['native_frames', 'replayed_frames', 'checked_stage_samples',
            'compared_stage_fields', 'diagnostic_compared_stage_fields',
            'archive_accepted', 'diagnostic_replay_checks_passed',
            'production_gameplay_checks_passed', 'whole_song_parity_proven',
            'production_parity_proven', 'pixel_parity_proven']
    result = {key: report[key] for key in keys if key in report}
    result['reported_mismatch_rows'] = len(report.get('mismatches', []))
    result['errors'] = report.get('errors', [])
    result['pending_coverage'] = report.get('pending_coverage', [])
    result['draws'] = {key: value for key, value in report.get('interactive', {}).items()
                       if key not in ('draw_mismatch_examples', 'last_draw_mismatch')}
    result['mismatch_examples'] = report.get('mismatches', [])[:8]
    if 'production_replay' in report:
        result['production'] = comparison(report['production_replay'])
    return result

parser = argparse.ArgumentParser()
parser.add_argument('--suffix', required=True)
parser.add_argument('--build', required=True)
parser.add_argument('--regressions', required=True)
parser.add_argument('--source-commit', required=True)
parser.add_argument('--extra', action='append', default=[], help='relative historical or supporting target evidence; never counted as current validation')
parser.add_argument('--validate-only', action='store_true', help='check all inputs and identities without creating a fixture directory or archive')
args = parser.parse_args()
build = HERE / args.build
destination = ROOT / 'tests/fixtures/full_song_lua/proxmox-followup-2026-11-20' / ('current-main-' + args.suffix)
assert not destination.exists()
args.source_commit = subprocess.check_output(['git', 'rev-parse', '--verify', args.source_commit + '^{commit}'], cwd=ROOT, text=True).strip()
receipt = json.loads((build / 'execution.json').read_bytes())
assert receipt['exit_code'] == 0 and receipt['source_unchanged_during_command']
verify_files(build, receipt['files'])
binding_path = build / 'replay-build-binding.json'
binding = json.loads(binding_path.read_bytes())
build_receipt_sha256 = sha(build / 'execution.json')
build_jsonl_sha256 = sha(build / 'stdout.log')
binding_sha256 = sha(binding_path)
assert binding['build_execution_receipt_sha256'] == build_receipt_sha256
assert binding['cargo_build_jsonl_sha256'] == build_jsonl_sha256
assert binding['source_identity'] == receipt['source_identity']
assert Path(binding['build_directory']).resolve() == build.resolve()
binaries = artifacts(build / 'stdout.log')
binary_hashes = {}
for name, expected in binding['binaries'].items():
    assert binaries[name].resolve() == Path(expected['path']).resolve()
    assert binaries[name].stat().st_size == expected['bytes']
    binary_hashes[name] = sha(binaries[name])
    assert binary_hashes[name] == expected['sha256'], 'compiled executable changed: ' + name
source_commit_binding = {}
for name, expected in receipt['source_identity']['source_files'].items():
    assert sha(ROOT / name) == expected, 'worktree source differs from compiled bytes: ' + name
    compiled_blob = subprocess.check_output(['git', 'hash-object', '--path=' + name, name], cwd=ROOT, text=True).strip()
    committed_blob = subprocess.check_output(['git', 'rev-parse', args.source_commit + ':' + name], cwd=ROOT, text=True).strip()
    assert compiled_blob == committed_blob, 'committed source differs after repository text filters: ' + name
    source_commit_binding[name] = {'compiled_worktree_sha256': expected, 'committed_git_blob': committed_blob}

members = {}
summary = {'source_commit': args.source_commit,
           'source_commit_binding': source_commit_binding,
           'compiled_build_binding': binding,
           'build_execution_receipt_sha256': build_receipt_sha256,
           'compiled_build_binding_sha256': binding_sha256,
           'validation_suffix': args.suffix,
           'same_build_required_for_all_current_results': True,
           'cross_build_result_reuse': False,
           'scope': 'Measured replay checkpoint; all pending coverage and any failures are retained.',
           'cases': {}, 'focused_regressions': {},
           'supplementary_evidence': {'scope': 'Historical runs and supporting proof only; excluded from current test totals and executable equivalence.', 'entries': []}}
for case in ['interactive', 'typed-aft-uv', 'amv-color', 'wrapper-removal', 'sharkmode', 'pernicious-deed']:
    directory = HERE / (case + '-' + args.suffix)
    execution = json.loads((directory / 'execution.json').read_bytes())
    verify_files(directory, execution['reports'])
    assert execution['case'] == case
    assert execution['compiled_build_binding'] == binding, 'case used another build: ' + case
    assert execution['compiled_build_binding_sha256'] == binding_sha256
    assert execution['cargo_build_jsonl_sha256'] == build_jsonl_sha256
    name = 'song_lua_itgmania_semantic_parity' if case == 'interactive' else 'full_song_lua'
    assert execution['binary_sha256'] == binary_hashes[name], 'case executable mismatch: ' + case
    assert Path(execution['command'][0]).resolve() == binaries[name].resolve()
    result = {key: execution.get(key) for key in
              ('exit_code', 'runtime_seconds', 'binary_sha256', 'archive_sha256', 'archive_bytes', 'timed_out')}
    result['observed_suffix'] = args.suffix
    result['execution_receipt_sha256'] = sha(directory / 'execution.json')
    result['build_binding'] = {'directory': str(build), 'execution_receipt_sha256': build_receipt_sha256,
                               'compiled_build_binding_sha256': binding_sha256,
                               'cargo_build_jsonl_sha256': build_jsonl_sha256,
                               'binary_name': name, 'binary_sha256': binary_hashes[name]}
    report = directory / 'report.json'
    assert case == 'interactive' or report.is_file(), 'native replay report missing: ' + case
    if report.exists():
        result['report_sha256'] = sha(report)
        result['comparison'] = comparison(json.loads(report.read_bytes()))
    else:
        result['report_written'] = False
    if case == 'interactive':
        assert 'interactive::' in execution['command'], 'unexpected comparator test selection'
        result['test_counts'] = test_results(directory)
    summary['cases'][case] = result
    for path in directory.iterdir():
        if path.is_file():
            members['replays/' + case + '/' + path.name] = path

checks = HERE / args.regressions
regressions = json.loads((checks / 'execution.json').read_bytes())
verify_files(checks, regressions['files'])
assert regressions['build_receipt_sha256'] == build_receipt_sha256, 'regressions used another build'
assert regressions['source_identity'] == receipt['source_identity']
regression_bindings = []
for result in regressions['results']:
    path = Path(result['command'][0]).resolve()
    names = [name for name, binary in binaries.items() if binary.resolve() == path]
    assert len(names) == 1, 'regression executable is not an exact build artifact: ' + str(path)
    name = names[0]
    if name not in binary_hashes:
        binary_hashes[name] = sha(path)
    assert result['binary_sha256'] == binary_hashes[name], 'regression executable changed: ' + result['name']
    regression_bindings.append({'test': result['name'], 'artifact': name, 'binary_sha256': binary_hashes[name]})
summary['focused_regressions']['execution'] = regressions
summary['focused_regressions']['execution_receipt_sha256'] = sha(checks / 'execution.json')
summary['focused_regressions']['build_execution_receipt_sha256'] = build_receipt_sha256
summary['focused_regressions']['artifact_bindings'] = regression_bindings
summary['focused_regressions']['counts'] = test_results(checks)
for path in checks.iterdir():
    if path.is_file():
        members['focused-regressions/' + path.name] = path
for name in ('invocation.json', 'execution.json', 'source.patch', 'stdout.log', 'stderr.log', 'replay-build-binding.json'):
    members['build/' + name] = build / name
for requested in args.extra:
    path = HERE / requested
    assert path.exists() and path.resolve().is_relative_to(HERE.resolve())
    entry = {'requested': requested, 'classification': 'historical or supporting; not current validation', 'members': []}
    files = sorted(path.rglob('*')) if path.is_dir() else [path]
    for file in files:
        if file.is_file():
            assert file.suffix.lower() not in {'.exe', '.dll', '.rlib', '.rmeta', '.pdb'}, 'compiled artifact is not checkpoint evidence: ' + str(file)
            assert file.stat().st_size < 50_000_000, 'unexpected large extra evidence: ' + str(file)
            member = 'extra/' + file.relative_to(HERE).as_posix()
            members[member] = file
            entry['members'].append(member)
    prior_receipt = path / 'execution.json' if path.is_dir() else None
    if prior_receipt and prior_receipt.is_file():
        prior = json.loads(prior_receipt.read_bytes())
        verify_files(path, prior.get('files', {}))
        verify_files(path, prior.get('reports', {}))
        entry['execution_receipt_sha256'] = sha(prior_receipt)
        entry['recorded_build_receipt_sha256'] = prior.get('build_receipt_sha256', prior.get('compiled_build_binding', {}).get('build_execution_receipt_sha256'))
        entry['recorded_binary_sha256'] = prior.get('binary_sha256')
        entry['recorded_exit_code'] = prior.get('exit_code')
        entry['recorded_test_results'] = [{key: value.get(key) for key in ('name', 'exit_code', 'binary_sha256')} for value in prior.get('results', [])]
        entry['recorded_test_counts'] = test_results(path)
    summary['supplementary_evidence']['entries'].append(entry)
members['helpers/bundle_validation_checkpoint.py'] = Path(__file__)

if args.validate_only:
    print(json.dumps({'status': 'validated only; no fixture directory or archive created',
                      'source_commit': args.source_commit, 'build': args.build,
                      'suffix': args.suffix, 'current_cases': list(summary['cases']),
                      'regression_invocations': len(regression_bindings),
                      'binaries': binary_hashes, 'members': len(members)}), flush=True)
    raise SystemExit(0)

destination.mkdir()
summary_path = destination / 'summary.json'
summary_path.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
manifest = {'source_commit': args.source_commit,
            'members': {name: {'bytes': path.stat().st_size, 'sha256': sha(path)}
                        for name, path in sorted(members.items())}}
archive = destination / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as packed:
    for name, path in sorted(members.items()):
        packed.write(path, name)
with zipfile.ZipFile(archive) as packed:
    assert packed.testzip() is None
    assert set(packed.namelist()) == set(manifest['members'])
    for name, expected in manifest['members'].items():
        data = packed.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
assert archive.stat().st_size < 50_000_000
manifest['archive'] = {'bytes': archive.stat().st_size, 'sha256': sha(archive)}
manifest['summary'] = {'bytes': summary_path.stat().st_size, 'sha256': sha(summary_path)}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
(destination / 'README.md').write_text(
    '# Native replay checkpoint ' + args.suffix + '\n\n'
    'This checkpoint binds the tested source to DeadSync commit ' + args.source_commit + '.\n'
    'Every changed source file was checked against the completed build identity.\n'
    'Every current replay and regression receipt was checked against that same\n'
    'build and its exact executable. No result is carried across builds.\n'
    'The exact source patch, executable identities, reports, execution receipts,\n'
    'logs and focused regression results are preserved in evidence.zip.\n\n'
    'summary.json separates diagnostic and production results, retains all pending\n'
    'coverage, and records total draw mismatch counters even when example lists\n'
    'are capped. An accepted recorded replay is not a claim of whole-song,\n'
    'production-build or framebuffer-pixel parity. Supplementary earlier runs\n'
    'and correction proofs are historical evidence, excluded from current\n'
    'validation totals and any claim of executable equivalence. Earlier checkpoints remain\n'
    'unchanged.\n', encoding='utf-8')
print(json.dumps({'directory': str(destination), 'members': len(members),
                  'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive)}), flush=True)
