"""Inventory completed same-build evidence under target; never read an unfinished report."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
TASK = OUT.parent
CASES = ('typed-aft-uv', 'amv-color', 'wrapper-removal', 'sharkmode', 'pernicious-deed')
DRAW_COUNTERS = (
    'input_events_replayed', 'draw_samples_compared', 'submitted_vertices_compared',
    'live_text_samples_compared', 'typed_equal_backing_aft_uv_samples_compared',
    'draw_mismatches', 'equivalent_offscreen_culls', 'batched_native_draw_samples',
    'equivalent_degenerate_culls', 'uncompared_owned_immediate_draws',
    'uncompared_owned_normal_draws', 'render_random_inputs_replayed',
    'render_random_inputs_captured', 'unreplayed_render_random_inputs',
    'draw_vibration_scopes_without_native_inputs',
)
PROOF_FLAGS = ('whole_song_parity_proven', 'production_parity_proven', 'pixel_parity_proven')
TEST_RESULT = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out')
SOURCES = {}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identify(path):
    path = Path(path)
    name = path.relative_to(ROOT).as_posix()
    item = {'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)}
    SOURCES[name] = item
    return item


def read(path):
    identity = identify(path)
    with Path(path).open(encoding='utf-8-sig') as stream:
        return json.load(stream), identity


def verify_files(directory, inventory):
    for name, expected in inventory.items():
        path = directory / name
        assert path.resolve().is_relative_to(directory.resolve())
        assert path.stat().st_size == expected['bytes'], str(path)
        assert sha(path) == expected['sha256'], str(path)


def pending_parts(entries):
    buckets = {'operations': [], 'resources': [], 'subscribers': [], 'production': [], 'other': []}
    for entry in entries:
        if entry.startswith('uncompared song operations: '):
            buckets['operations'].append(entry.removeprefix('uncompared song operations: ').split(', '))
        elif entry.startswith('native drawable state/resources: '):
            buckets['resources'].append(entry.removeprefix('native drawable state/resources: ').split(', '))
        elif entry.startswith('missing captured subscriber identity for '):
            buckets['subscribers'].append(entry.removeprefix('missing captured subscriber identity for '))
        elif entry.startswith('production replay: '):
            buckets['production'].append(entry.removeprefix('production replay: '))
        else:
            buckets['other'].append(entry)
    return {'combined_entries': len(entries),
            'diagnostic_entries': len(entries) - len(buckets['production']),
            'production_entries': len(buckets['production']),
            'operation_bucket_entries': len(buckets['operations']),
            'uncompared_operations': [value for values in buckets['operations'] for value in values],
            'uncompared_operation_count': sum(map(len, buckets['operations'])),
            'resource_bucket_entries': len(buckets['resources']),
            'drawable_resource_classes': [value for values in buckets['resources'] for value in values],
            'missing_subscriber_count': len(buckets['subscribers']),
            'missing_subscriber_paths': buckets['subscribers'],
            'production_pending': buckets['production'], 'other_entries': buckets['other'],
            'original_entries': entries}


def query_counts(report):
    queries = report.get('command_queries')
    if queries is None:
        return {'instrumented': False, 'compared': None, 'native_count': None,
                'actual_count': None, 'uncompared_actual_count': None,
                'scope': 'No production command/query instrumentation is present.'}
    uncompared = queries.get('uncompared_actual', [])
    return {'instrumented': True, 'compared': queries['compared'],
            'native_count': queries['native_count'], 'actual_count': queries['actual_count'],
            'uncompared_actual_count': len(uncompared),
            'uncompared_actual_operations': sorted({str(item.get('operation')) for item in uncompared}),
            'scope': 'Selected diagnostic observations; uncompared operations remain explicit.'}


def path_counts(report, stage_fields):
    draws = report['interactive']
    return {'native_frames': report['native_frames'], 'replayed_frames': report['replayed_frames'],
            'checked_stage_samples': report['checked_stage_samples'], 'compared_stage_fields': stage_fields,
            'draws': {name: draws[name] for name in DRAW_COUNTERS},
            'draw_mismatch_counts': draws.get('draw_mismatch_counts', {}),
            'live_text_scope': draws['live_text_comparison'], 'queries': query_counts(report),
            'reported_mismatch_rows': len(report['mismatches']), 'reported_errors': len(report['errors']),
            'proof_flags': {name: report[name] for name in PROOF_FLAGS}}


def compact_case(name, report, report_id, execution, execution_id, invocation_id):
    production = report['production_replay']
    pending = pending_parts(report['pending_coverage'])
    assert production['pending_coverage'] == pending['production_pending']
    diagnostic_fields = report['diagnostic_compared_stage_fields']
    assert report['compared_stage_fields'] == diagnostic_fields + production['compared_stage_fields']
    return {'case': name, 'report': report_id, 'execution_receipt': execution_id,
            'invocation_receipt': invocation_id, 'runner_sha256': execution['binary_sha256'],
            'archive_sha256': execution['archive_sha256'], 'archive_bytes': execution['archive_bytes'],
            'exit_code': execution['exit_code'], 'runtime_seconds': execution['runtime_seconds'],
            'archive_accepted': report['archive_accepted'],
            'diagnostic_replay_checks_passed': report['diagnostic_replay_checks_passed'],
            'production_gameplay_checks_passed': report['production_gameplay_checks_passed'],
            'production_report_archive_accepted': production['archive_accepted'],
            'capture_completed_gameplay': report['capture_completed_gameplay'],
            'interactive_checks_passed': report['interactive_checks_passed'],
            'combined_stage_fields': report['compared_stage_fields'],
            'combined_stage_observation_rows': len(report.get('stage_observations', [])),
            'diagnostic': path_counts(report, diagnostic_fields),
            'production': path_counts(production, production['compared_stage_fields']),
            'pending': pending, 'global_pending_separate': report['coverage']['global_pending'],
            'coverage_scope': report['coverage']['scope'],
            'observed_song_operation_count': len(report['coverage']['observed_song_operations']),
            'production_flags': {key: production[key] for key in (
                'application_build_exercised', 'test_support_enabled', 'retained_lua_vm',
                'production_preparation_exercised', 'drawable_coverage_exercised', 'native_capture_bounded')}}


def log_counts(path):
    identity = identify(path)
    text = path.read_text(encoding='utf-8', errors='replace')
    matches = TEST_RESULT.findall(text)
    assert len(matches) == 1, 'expected one completed Rust test result: ' + str(path)
    status, *numbers = matches[0]
    result = dict(zip(('passed', 'failed', 'ignored', 'measured', 'filtered_out'), map(int, numbers)))
    result.update(status=status, log=identity,
                  ignored_tests=[{'name': name, 'reason': reason} for name, reason in
                                 re.findall(r'^test (\S+) \.\.\. ignored(?:, (.*))?$', text, re.MULTILINE)])
    return result


def source_anchors(commit):
    requests = {
        'tests/song_lua_itgmania_semantic_parity/native_gameplay.rs': [
            'let mut pending_coverage = vec!["application build without test-support"',
            '"application_build_exercised":false,"test_support_enabled":true',
            'report["interactive_checks_passed"] = json!(scope == Scope::Full',
            '&& input_cursor > 0 && input_cursor == input_events.len()'],
        'tests/song_lua_itgmania_semantic_parity/whole_song_archives.rs': [
            'fn append_production_report(', 'report["diagnostic_compared_stage_fields"]',
            'report["production_parity_proven"] = Value::Bool(false);'],
        'tests/song_lua_itgmania_semantic_parity/interactive.rs': [
            'self.vertices += rows.len();',
            '"live_text_comparison":"content only; submitted glyph geometry, textures and RGBA are not compared"'],
    }
    result = []
    for path, needles in requests.items():
        raw = subprocess.check_output(['git', 'show', commit + ':' + path], cwd=ROOT)
        lines = raw.decode().splitlines()
        result.append({'commit': commit, 'path': path,
                       'sha256_of_git_blob_content': hashlib.sha256(raw).hexdigest(),
                       'anchors': [{'line': next(i for i, line in enumerate(lines, 1) if needle in line),
                                    'contains': needle} for needle in needles]})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suffix', required=True)
    parser.add_argument('--build', required=True)
    parser.add_argument('--regressions', required=True)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--expect-passed', type=int)
    parser.add_argument('--expect-ignored', type=int)
    args = parser.parse_args()
    assert re.fullmatch(r'[a-zA-Z0-9_-]+', args.suffix)
    destination = OUT / args.suffix
    assert not destination.exists(), 'refusing to overwrite a previous inventory: ' + str(destination)
    build = TASK / args.build
    checks = TASK / args.regressions
    assert build.resolve().is_relative_to(TASK.resolve()) and checks.resolve().is_relative_to(TASK.resolve())

    # Read completion receipts first, before opening any report. In particular,
    # a report being streamed by an active Deed replay cannot become evidence.
    executions = {}
    for name in (*CASES, 'interactive'):
        path = TASK / (name + '-' + args.suffix) / 'execution.json'
        if not path.is_file():
            raise SystemExit('Not ready: completed execution receipt is missing: ' + str(path))
        execution, identity = read(path)
        if execution.get('exit_code') != 0 or execution.get('timed_out') or not execution.get('finished_at'):
            raise SystemExit('Not ready: replay did not complete successfully: ' + str(path))
        executions[name] = (execution, identity)

    build_receipt, build_id = read(build / 'execution.json')
    binding, binding_id = read(build / 'replay-build-binding.json')
    assert build_receipt['exit_code'] == 0 and build_receipt['source_unchanged_during_command']
    verify_files(build, build_receipt['files'])
    assert binding['build_execution_receipt_sha256'] == build_id['sha256']
    assert binding['cargo_build_jsonl_sha256'] == sha(build / 'stdout.log')
    assert binding['source_identity'] == build_receipt['source_identity']
    for name in ('full_song_lua', 'song_lua_itgmania_semantic_parity'):
        assert sha(binding['binaries'][name]['path']) == binding['binaries'][name]['sha256']
    commit = subprocess.check_output(['git', 'rev-parse', '--verify', args.source_commit + '^{commit}'], cwd=ROOT, text=True).strip()
    committed_files = {}
    for name, expected in binding['source_identity']['source_files'].items():
        assert sha(ROOT / name) == expected
        actual = subprocess.check_output(['git', 'hash-object', '--path=' + name, name], cwd=ROOT, text=True).strip()
        committed = subprocess.check_output(['git', 'rev-parse', commit + ':' + name], cwd=ROOT, text=True).strip()
        assert actual == committed, 'committed source differs from built bytes: ' + name
        committed_files[name] = {'compiled_sha256': expected, 'committed_git_blob': committed}

    cases = []
    for name in (*CASES, 'interactive'):
        directory = TASK / (name + '-' + args.suffix)
        execution, execution_id = executions[name]
        binary = 'song_lua_itgmania_semantic_parity' if name == 'interactive' else 'full_song_lua'
        assert execution['case'] == name
        assert execution['compiled_build_binding'] == binding
        assert execution['compiled_build_binding_sha256'] == binding_id['sha256']
        assert execution['cargo_build_jsonl_sha256'] == binding['cargo_build_jsonl_sha256']
        assert execution['binary_sha256'] == binding['binaries'][binary]['sha256']
        verify_files(directory, execution['reports'])
        _, invocation_id = read(directory / 'invocation.json')
        if name == 'interactive':
            interactive = log_counts(directory / 'stdout.log')
            interactive['execution_receipt'] = execution_id
            interactive['binary_sha256'] = execution['binary_sha256']
            continue
        report, report_id = read(directory / 'report.json')
        assert execution['reports']['report.json']['sha256'] == report_id['sha256']
        assert report['fixture_sha256'] == execution['archive_sha256']
        cases.append(compact_case(name, report, report_id, execution, execution_id, invocation_id))
        del report

    regressions, regression_id = read(checks / 'execution.json')
    assert regressions['build_receipt_sha256'] == build_id['sha256']
    assert regressions['source_identity'] == binding['source_identity']
    verify_files(checks, regressions['files'])
    groups = []
    for result in regressions['results']:
        assert result['exit_code'] == 0
        group = log_counts(checks / (result['name'] + '.stdout.log'))
        assert group['status'] == 'ok' and group['failed'] == 0
        group.update(name=result['name'], binary_sha256=result['binary_sha256'])
        groups.append(group)
    totals = {key: sum(group[key] for group in groups) for key in ('passed', 'failed', 'ignored', 'measured')}
    combined_tests = {key: totals[key] + interactive[key] for key in totals}
    if args.expect_passed is not None:
        assert combined_tests['passed'] == args.expect_passed
    if args.expect_ignored is not None:
        assert combined_tests['ignored'] == args.expect_ignored
    assert interactive['status'] == 'ok' and combined_tests['failed'] == 0

    path_totals = {}
    for path in ('diagnostic', 'production'):
        path_totals[path] = {key: sum(item[path][key] for item in cases)
                             for key in ('native_frames', 'replayed_frames', 'checked_stage_samples', 'compared_stage_fields')}
        path_totals[path]['draws'] = {key: sum(item[path]['draws'][key] for item in cases) for key in DRAW_COUNTERS}
        queries = [item[path]['queries'] for item in cases]
        path_totals[path]['queries'] = {'instrumented_cases': sum(item['instrumented'] for item in queries),
                                       'native_count': sum(item['native_count'] for item in queries) if all(item['instrumented'] for item in queries) else None,
                                       'actual_count': sum(item['actual_count'] for item in queries) if all(item['instrumented'] for item in queries) else None}
    inventory = {
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'Completed ' + args.suffix + ' native replays and regressions from one exact build; historical checkpoints and fleet accounting excluded.',
        'source_commit': commit, 'source_commit_binding': committed_files,
        'build_receipt': build_id, 'compiled_build_binding': binding, 'compiled_build_binding_identity': binding_id,
        'cases': cases, 'totals_per_path': path_totals,
        'native_reference_frames_counted_once': sum(item['diagnostic']['native_frames'] for item in cases),
        'combined_stage_fields': sum(item['combined_stage_fields'] for item in cases),
        'regressions': {'receipt': regression_id, 'focused': totals, 'focused_groups': groups,
                        'interactive_comparator': interactive, 'combined': combined_tests,
                        'note': 'Regression tests are not captured gameplay input events. Filtered-out counts are retained per invocation and are not added as coverage.'},
        'coverage_interpretation': {
            'counter_conventions': [
                'Each native reference frame is counted once; diagnostic and production independently replay the same captured run.',
                'Top-level interactive draw/text/random/input counters belong to diagnostic replay; production counters come only from production_replay.interactive.',
                'Draw samples count native submissions, not unique Actor.Draw calls. Submitted vertex counts are compared owned expanded rows, not unique/raw native quad vertices; batched samples are retained separately.',
                'Top-level compared_stage_fields is combined; diagnostic_compared_stage_fields and production_replay.compared_stage_fields are per-path.',
                'Stored mismatch rows may be capped; draw_mismatches and draw_mismatch_counts retain the actual draw comparison totals.',
                'Coverage entries are obligations, not failed tests. Global pending obligations remain separate from the displayed combined/production entry counts.',
                'Nested production archive_accepted is recorded separately from production_gameplay_checks_passed and combined archive_accepted.'],
            'unproven_scopes': [
                'The application build without test-support is unproven; the retained production replay is executed by the test-support runner.',
                'Input-event coverage is limited to input_events_replayed. The interactive_checks_passed predicate requires at least one input event.',
                'Observed native gameplay completion and replay of all recorded frames do not discharge the explicit production full-song-completion obligation.',
                'Live text comparison covers content only; submitted glyph geometry, texture bindings and RGBA remain unproven.',
                'Submitted vertex comparisons do not establish framebuffer-pixel parity.',
                'Diagnostic selected query observations do not establish production query instrumentation or complete API coverage.',
                'Missing subscriber identities, stage-finalization/aggregate/history semantics and broader contexts remain exactly as listed in each report.'],
            'historical_fleet_accounting': 'Excluded; older captures, binaries, fleet counts and resource obligations cannot be merged into this checkpoint.'},
        'immutable_source_anchors': source_anchors(commit), 'sources': list(SOURCES.values()),
    }
    rows = []
    detail_rows = []
    for item in cases:
        d, p = item['diagnostic'], item['production']
        rows.append(f"| {item['case']} | {d['native_frames']:,} | {d['compared_stage_fields']:,} / {p['compared_stage_fields']:,} | {d['draws']['draw_samples_compared']:,} / {p['draws']['draw_samples_compared']:,} | {d['draws']['submitted_vertices_compared']:,} / {p['draws']['submitted_vertices_compared']:,} | {d['draws']['draw_mismatches']:,} / {p['draws']['draw_mismatches']:,} | {item['pending']['combined_entries']} / {item['pending']['production_entries']} |")
        detail_rows.append(f"| {item['case']} | {d['queries']['native_count']:,} / {d['queries']['actual_count']:,} | {d['queries']['uncompared_actual_count']} | {d['draws']['render_random_inputs_replayed']} / {d['draws']['render_random_inputs_captured']} | {p['draws']['render_random_inputs_replayed']} / {p['draws']['render_random_inputs_captured']} | {d['draws']['live_text_samples_compared']:,} / {p['draws']['live_text_samples_compared']:,} | {d['draws']['input_events_replayed']} / {p['draws']['input_events_replayed']} |")
    flags = {name: {path: sorted({item[path]['proof_flags'][name] for item in cases})
                    for path in ('diagnostic', 'production')} for name in PROOF_FLAGS}
    acceptance = {name: sum(bool(item[name]) for item in cases) for name in (
        'archive_accepted', 'diagnostic_replay_checks_passed', 'production_gameplay_checks_passed',
        'production_report_archive_accepted')}
    pending_shapes = sorted({(item['pending']['combined_entries'], item['pending']['diagnostic_entries'],
                              item['pending']['production_entries'], item['pending']['operation_bucket_entries'],
                              item['pending']['resource_bucket_entries'], item['pending']['missing_subscriber_count'])
                             for item in cases})
    inventory['acceptance_case_counts'] = acceptance
    inventory['coverage_entry_shapes'] = [dict(zip(
        ('combined', 'diagnostic', 'production', 'operation_buckets', 'resource_buckets', 'missing_subscribers'), shape))
        for shape in pending_shapes]
    notes = '\n'.join([
        f"Completed {args.suffix} coverage inventory, source commit `{commit}`.", '',
        f"Runner SHA-256: `{binding['binaries']['full_song_lua']['sha256']}`. All five execution receipts completed with exit 0 and bind to this exact build. No earlier replay is substituted.", '',
        '| Case | Reference frames | Stage fields D / P | Draws D / P | Vertices D / P | Draw mismatches D / P | Pending combined / production |',
        '|---|---:|---:|---:|---:|---:|---:|', *rows, '',
        '| Case | Diagnostic native / owned queries | Uncompared owned queries | Random D replayed / captured | Random P replayed / captured | Text content D / P | Gameplay inputs D / P |',
        '|---|---:|---:|---:|---:|---:|---:|', *detail_rows, '',
        f"Focused regressions: **{totals['passed']} passed, {totals['failed']} failed, {totals['ignored']} ignored**. Interactive comparator regressions: **{interactive['passed']} passed, {interactive['failed']} failed, {interactive['ignored']} ignored**. Combined: **{combined_tests['passed']} passed, {combined_tests['failed']} failed, {combined_tests['ignored']} ignored**.", '',
        f"Combined archives accepted: {acceptance['archive_accepted']}/{len(cases)}; diagnostic checks passed: {acceptance['diagnostic_replay_checks_passed']}/{len(cases)}; production gameplay checks passed: {acceptance['production_gameplay_checks_passed']}/{len(cases)}. Nested standalone production archive-acceptance flags are true in {acceptance['production_report_archive_accepted']}/{len(cases)} cases; this is a separate acceptance scope.", '',
        'D and P mean separate diagnostic and production replay paths. They replay the same reference frames; stage-field totals at the report root include both paths. Production command/query instrumentation is absent, so production query counts are null rather than a claimed zero.', '',
        'Draw samples count native submissions, not unique Actor.Draw calls. Vertices count the comparator\'s owned expanded rows, not raw native quad vertices. Batched submissions and offscreen/degenerate equivalences remain separate counters in the JSON.', '',
        'Production gameplay checks and combined archive acceptance are separate from the nested standalone production archive-acceptance flag. All three flags are retained individually in the JSON.', '',
        'Actual parity-proof flag values across the cases (D/P separately): `' + json.dumps(flags, sort_keys=True) + '`.', '',
        'Coverage obligations are not failed comparisons. Each case retains the exact operation/resource buckets, missing subscriber identities, and production obligations; global pending remains separate. Production obligations:', '',
        *[f"- Entry counts: {combined} combined = {diagnostic} diagnostic + {production} production; diagnostic groups contain {operations} operation bucket(s), {resources} resource bucket(s), and {subscribers} missing subscriber identities." for combined, diagnostic, production, operations, resources, subscribers in pending_shapes], '',
        *['- ' + value for value in dict.fromkeys(value for item in cases for value in item['pending']['production_pending'])], '',
        'Native natural gameplay exit and complete recorded-frame replay do not establish the application build, complete input coverage, glyph geometry or framebuffer pixels. Text counters cover content only. Comparator regression counts are not captured input events.', '',
        'Historical after04/after05/after06 results and fleet accounting are excluded. Exact report, execution, invocation, regression-log, build and source hashes are in the companion JSON.', '',
    ])
    preserved_path = OUT / 'after04-artifacts-preserved.json'
    preserved = json.loads(preserved_path.read_text())
    for name, expected in preserved['files'].items():
        assert sha(OUT / name) == expected['sha256'], 'historical artifact changed: ' + name
    destination.mkdir()
    output = destination / 'coverage-inventory.json'
    output.write_text(json.dumps(inventory, indent=2) + '\n', encoding='utf-8')
    (destination / 'coverage-notes.md').write_text(notes, encoding='utf-8')
    manifest = {'scope': inventory['scope'], 'helper_sha256': sha(Path(__file__)),
                'files': {path.name: {'bytes': path.stat().st_size, 'sha256': sha(path)} for path in destination.iterdir() if path.is_file()},
                'historical_after04_preserved': preserved}
    (destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'inventory': str(output), 'sha256': sha(output), 'case_count': len(cases),
                      'regressions': combined_tests,
                      'pending_per_case': {item['case']: [item['pending']['combined_entries'], item['pending']['production_entries']] for item in cases}}))


if __name__ == '__main__':
    main()
