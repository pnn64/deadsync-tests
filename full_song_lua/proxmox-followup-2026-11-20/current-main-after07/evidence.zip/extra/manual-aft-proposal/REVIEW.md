# Manual AFT viewport and camera change

The live source activation was authorized by the parent after after04 retained 1,666 AMV draw mismatches per replay path, including the 8x8 WhiteFill capture. The source patch was applied once after `git apply --check` succeeded. The parent owns compilation, replay, acceptance and commits.

The viewport-only patch is `source.patch` (SHA-256 `0ff8f6c445ecd72a707896c647d4c9ce092852208cbe98fd12806f0d2f144398`). `base/`, `proposed/` and `manifest.json` retain the exact base bytes and proposed normalized bytes. Subsequent inherited-color edits to the live playback file belong to the underlay worker; these copies are evidence of the isolated viewport change and must not replace the combined live file.

Native source anchors are RageTextureRenderTarget.cpp 44-69 (image-sized default camera, identity world and nested restoration), ActorFrameTexture.cpp 80-89 (ordinary child traversal), ActorFrame.cpp 208-214 (explicit child FOV resolves against original SCREEN_WIDTH/HEIGHT), and RageDisplay.cpp 498-530 (ortho depth -1000..1000 and perspective camera). Their source hashes are retained in the parent `manual-aft-space-proposal.json` one directory above.

The implementation stores the active image viewport per recorded draw. Builders run within temporary logical metrics restored exactly on return or unwind; physical pixel dimensions remain independent. An explicit ActorFrame camera is resolved before entering target metrics. Target composition retains the depth -1..1 outer projection because each projected mesh already cancels that projection and applies native depth once.

Manual Player and ScreenLayer sources retain a separate original source projection and canvas. A preallocated source-layout scope preserves their original world origin and Fill extent when composing in a smaller target. The destination projection remains target-sized. Layout storage is allocated at song entry only for operation positions that can draw these sources, and is reused with the existing frame banks.

The diagnostic adapter consumes the production draw slot viewport and the same originally resolved explicit camera. This avoids rebuilding target observations in the outer screen dimensions.

Five tests in `tests/playback/manual_target_space.rs` independently check numeric native clip coordinates for 8x8 and 13x7 Quad fills; nested 13x7/5x3 targets and screen restoration; nonzero mesh depth with and without depth bias; explicit FOV 0/45 using original screen dimensions; and Player/ScreenLayer original layout, nested camera, Fill extent and warmed scratch reuse. The new space test checks exact asymmetric metric restoration through nested return and panic, while preserving pixel dimensions.

Local checks completed: new test file parsed/formatted with rustfmt edition 2024; scoped `git diff --check` passed. No compilation or runtime test was run by this worker.

Requested parent checks:

```text
cargo test -p deadlib-present --lib scoped_metrics_restore_exact_bounds_after_nested_return_and_unwind
cargo test -p deadsync-song-lua --features test-support --test playback manual_target_space -- --nocapture
```

After coordinated inherited-color changes compile, replay the retained fresh color control through both diagnostic and production paths. The existing typed-AFT fixture and native manual Player regression should remain passing. Source acceptance requires measured current-main replay results; the tests above are not a substitute for that replay.
