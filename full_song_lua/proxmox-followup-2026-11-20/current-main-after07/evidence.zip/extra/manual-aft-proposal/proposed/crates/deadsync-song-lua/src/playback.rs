// Chart actor playback and capture semantics, independent of theme and asset loaders.
use crate::gameplay::{
    SongLuaRuntimeOverlayStateDelta, song_lua_runtime_column_offset_windows,
    song_lua_runtime_ease_windows, song_lua_runtime_mod_windows,
};
use crate::{
    SongLuaCapturedActor, SongLuaCapturedChildActor, SongLuaDrawFrame, SongLuaDrawOp,
    SongLuaDrawSource, SongLuaOverlayBlendMode, SongLuaOverlayCommandBlock,
    SongLuaOverlayMeshVertex, SongLuaOverlayMessageCommand, SongLuaOverlayModelDraw,
    SongLuaOverlayState, SongLuaProxyTarget, SongLuaTextGlowMode,
};
use crate::{apply_overlay_delta, overlay_state_lerp};
use deadlib_assets::AssetManager;
use deadlib_present::actors::{
    Actor, FlatDraw, SharedActorFrameScratch, SizeSpec, SpriteSource, TextAttribute,
    TextAttributes, TextContent,
};
use deadlib_present::anim::EffectState;
use deadlib_present::compose::{ActorSegment, FlatProxyStyle, TextLayoutCache};
use deadlib_present::font;
use deadlib_present::space::{screen_center_x, screen_center_y, screen_height, screen_width};
use deadlib_render_core::{
    BlendMode, INVALID_TMESH_CACHE_KEY, MeshVertex, TMeshCacheKey, TextureHandle,
    TexturedMeshVertex, render_target_sample_handle, render_target_texture_handle,
};
use deadsync_chart::SongData;
use deadsync_core::input::{MAX_COLS, MAX_PLAYERS};
use deadsync_gameplay::{
    SongLuaEase, SongLuaOverlayMessageRuntime, SongLuaRuntimeVisuals, song_lua_ease_factor,
};
use deadsync_notefield::ViewOverride as NotefieldViewOverride;
use deadsync_notefield::{
    CapturedActorSource, FieldPlacement, ModelMeshCache, NotefieldCameraCache,
    ProxyCaptureRequests, SongLuaPlayerTransformRequest, ViewOverride, actor_from_flat_draw,
    noteskin_model_actor_from_draw_depth_sorted_affine_cached_geometry,
    song_lua_player_skew_x_matrix, song_lua_player_skew_y_matrix, song_lua_player_transform_matrix,
};
use deadsync_noteskin::ModelDrawState;
use deadsync_noteskin::NoteskinSlot;
use deadsync_rules::judgment::JudgeGrade;
use glam::{Mat2 as Matrix2, Mat4 as Matrix4, Vec2 as Vector2, Vec3 as Vector3, Vec4 as Vector4};
use std::collections::HashSet;
use std::hash::Hasher;
use std::num::NonZeroUsize;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering as AtomicOrdering};
use std::sync::{Arc, OnceLock};
use std::time::Instant;
type SongLuaOverlayModelLayer = crate::SongLuaOverlayModelLayer<TexturedMeshVertex>;
type SongLuaOverlayKind<S> = crate::SongLuaOverlayKind<S, TexturedMeshVertex, TextAttribute>;
type SongLuaOverlayActor<S> = crate::SongLuaOverlayActor<SongLuaOverlayKind<S>>;
type CompiledSongLua<S> = crate::CompiledSongLua<SongLuaOverlayActor<S>>;
pub type GameplayCoreState<P, S> = deadsync_gameplay::GameplayRuntimeState<
    P,
    SongLuaOverlayActor<S>,
    SongLuaCapturedActor,
    SongLuaRuntimeOverlayStateDelta,
>;
#[path = "playback/native.rs"]
mod native;
#[path = "playback/prepare.rs"]
mod prepare;
#[path = "playback/live_topology.rs"]
mod live_topology;
#[path = "playback/movie.rs"]
mod movie;
use deadlib_assets::present_dsl::cover_sprite;
pub use prepare::{
    PreparedGameplaySongLua, prepare_song_lua, prepare_song_lua_with_runtime_fallback,
    reload_song_lua, song_lua_sound_paths,
};
use prepare::{SongLuaOverlayEaseWindowRuntime, SongLuaSoundEvent};
use smallvec::SmallVec;
static NEXT_SONG_LUA_AFT_ID: AtomicU64 = AtomicU64::new(1);
const SONG_LUA_CHILD_ORDER_STATIC: u8 = 0;
const SONG_LUA_CHILD_ORDER_DRAW: u8 = 1;
const SONG_LUA_CHILD_ORDER_Z: u8 = 2;

/// Song-lifetime state/order execution plan for one compiled overlay tree.
///
/// The gameplay frame thread owns it without synchronization. Screen entry
/// sizes every child list, records the only actors whose state can change,
/// propagates that set through descendants, and flattens immutable root order.
/// Prepared timelines perform no insertion or growth during gameplay. Live
/// wrapper insertion refreshes only the affected tree; ordinary frames reuse
/// the resulting plan and only re-sort a sibling list after a key change. All
/// storage is released at the gameplay transition.
#[derive(Default)]
struct SongLuaOverlayOrderCache {
    child_lists: Vec<Vec<usize>>,
    dynamic_draw_order: Vec<bool>,
    // Built once at song load; at most one entry per captured grade command.
    // The frame loop updates only effect epochs and reads judgment slots.
    tap_commands: Vec<SongLuaTapCommand>,
    // Song-lifetime execution plan: only these actors can change local state,
    // and only these composed states depend on changing local/ancestor state.
    dynamic_local_indices: Box<[usize]>,
    dynamic_composed_indices: Box<[usize]>,
    // Transform effects require bounded recomposition of their actors and descendants.
    effect_composed_indices: Box<[usize]>,
    // Most Song Lua trees never mutate ordering fields. Flatten those trees at
    // screen entry so the frame loop can copy one contiguous index slice.
    static_root_order: Option<Box<[usize]>>,
    // Update tracks are immutable and sorted by overlay. Store their ranges
    // once, then retain one sample cursor per track across gameplay frames.
    // Nearby frames advance from the prior boundary; seeks retain logarithmic
    // fallback through `partition_point_from_hint`.
    update_actor_index: SongLuaOverlayIndex,
    update_ranges: Box<[std::ops::Range<usize>]>,
    visible_update_indices: SmallVec<[usize; 8]>,
    update_cursors: Vec<usize>,
    sort_modes: Vec<u8>,
    // Dynamic-capable lists usually keep the same keys for many frames. Remember
    // those keys so we only pay O(n log n) when their effective order changes.
    last_draw_orders: Vec<i32>,
    last_z_keys: Vec<u32>,
}

struct SongLuaTapCommand {
    overlay: usize,
    command: usize,
    player: usize,
    column: usize,
    grade: JudgeGrade,
    glow_started_at: Option<f32>,
}

// Built once per song or visual layer so frame rendering does not repeatedly
// walk actor parents or resolve ActorFrameTexture names.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
#[repr(transparent)]
struct SongLuaOverlayIndex(Option<NonZeroUsize>);

impl SongLuaOverlayIndex {
    fn new(index: Option<usize>) -> Self {
        Self(
            index
                .and_then(|index| index.checked_add(1))
                .and_then(NonZeroUsize::new),
        )
    }

    fn get(self) -> Option<usize> {
        self.0.map(|index| index.get() - 1)
    }
}

/// Song-lifetime topology lookup for Song Lua overlay rendering.
///
/// The gameplay screen owns one index for the root overlays and one
/// per visual layer. Construction runs during screen entry, groups AFT sprites
/// by capture name and allocates a stable render-target handle for each AFT.
/// Static camera scopes are resolved at screen entry; trees whose camera FOV can
/// change retain the indexed ancestor fallback. Live wrapper insertion rebuilds
/// the affected index while preserving its capture handles. Live allocation or
/// sampling-name changes refresh only the target map. Unchanged frames reuse
/// the index without synchronization, allocation, eviction or pruning.
/// Storage follows the owned overlay count and is released with the screen.
#[derive(Default)]
struct SongLuaOverlayTopologyIndex {
    aft_ancestors: Vec<SongLuaOverlayIndex>,
    aft_sprite_targets: Vec<SongLuaOverlayIndex>,
    aft_sprite_indices: Box<[usize]>,
    aft_texture_handles: Vec<TextureHandle>,
    aft_texture_dependencies: Vec<(Option<String>, Option<String>)>,
    camera_ancestors: Vec<SongLuaOverlayIndex>,
    camera_states: Vec<SongLuaOverlayIndex>,
    dynamic_camera_scope: bool,
}

impl SongLuaOverlayTopologyIndex {
    // Only allocated names can be targets; requested names/flags/sizes do not
    // change the binding map. The second component is the current sampler name.
    fn texture_dependency<S: NoteskinSlot + Clone>(
        overlay: &SongLuaOverlayActor<S>,
    ) -> (Option<&str>, Option<&str>) {
        match &overlay.kind {
            SongLuaOverlayKind::ActorFrameTexture {
                capture_name,
                capture_size: Some(_),
                ..
            } => (Some(capture_name), None),
            SongLuaOverlayKind::AftSprite { capture_name } => (None, Some(capture_name)),
            SongLuaOverlayKind::ActorMultiVertex { capture_name, .. } => {
                (None, capture_name.as_deref())
            }
            _ => (None, None),
        }
    }

    fn new<S: NoteskinSlot + Clone>(overlays: &[SongLuaOverlayActor<S>]) -> Self {
        let aft_ancestors = (0..overlays.len())
            .map(|index| SongLuaOverlayIndex::new(song_lua_overlay_aft_ancestor(overlays, index)))
            .collect::<Vec<_>>();
        let aft_sprite_indices = overlays
            .iter()
            .enumerate()
            .filter_map(|(index, overlay)| {
                matches!(
                    overlay.kind,
                    SongLuaOverlayKind::AftSprite { .. }
                        | SongLuaOverlayKind::ActorMultiVertex {
                            capture_name: Some(_),
                            ..
                        }
                )
                .then_some(index)
            })
            .collect::<Box<[_]>>();
        let mut aft_sprite_targets = vec![SongLuaOverlayIndex::default(); overlays.len()];
        for &index in &aft_sprite_indices {
            let capture_name = match &overlays[index].kind {
                SongLuaOverlayKind::AftSprite { capture_name }
                | SongLuaOverlayKind::ActorMultiVertex {
                    capture_name: Some(capture_name),
                    ..
                } => capture_name,
                _ => {
                    unreachable!("AFT sampling index was built from the same immutable actor list")
                }
            };
            aft_sprite_targets[index] = SongLuaOverlayIndex::new(
                song_lua_overlay_capture_index_by_name(overlays, capture_name),
            );
        }
        let aft_texture_handles = overlays
            .iter()
            .map(|overlay| {
                matches!(overlay.kind, SongLuaOverlayKind::ActorFrameTexture { .. })
                    .then(|| {
                        render_target_texture_handle(
                            NEXT_SONG_LUA_AFT_ID.fetch_add(1, AtomicOrdering::Relaxed),
                        )
                    })
                    .unwrap_or_default()
            })
            .collect::<Vec<_>>();
        let aft_texture_dependencies = overlays.iter().map(|overlay| {
            let (allocated, sampled) = Self::texture_dependency(overlay);
            (allocated.map(str::to_owned), sampled.map(str::to_owned))
        }).collect();
        let camera_ancestors = overlays
            .iter()
            .map(|overlay| {
                SongLuaOverlayIndex::new(song_lua_overlay_camera_ancestor(
                    overlays,
                    overlay.parent_index,
                ))
            })
            .collect();
        let mut camera_states = vec![SongLuaOverlayIndex::default(); overlays.len()];
        Self::fill_camera_states(
            overlays,
            |index| overlays.get(index).map(|overlay| overlay.initial_state),
            &mut camera_states,
        );
        let dynamic_camera_scope = overlays.iter().any(|overlay| {
            matches!(
                overlay.kind,
                SongLuaOverlayKind::ActorFrame
                    | SongLuaOverlayKind::WrapperState
                    | SongLuaOverlayKind::ActorFrameTexture { .. }
            ) && overlay
                .message_commands
                .iter()
                .any(|command| command.blocks.iter().any(|block| block.delta.fov.is_some()))
        });
        Self {
            aft_ancestors,
            aft_sprite_targets,
            aft_sprite_indices,
            aft_texture_handles,
            aft_texture_dependencies,
            camera_ancestors,
            camera_states,
            dynamic_camera_scope,
        }
    }

    fn texture_handle(&self, index: usize) -> Option<TextureHandle> {
        self.aft_sprite_targets
            .get(index)?
            .get()
            .and_then(|target| self.aft_texture_handles.get(target).copied())
    }

    fn fill_camera_states<S: NoteskinSlot + Clone>(
        overlays: &[SongLuaOverlayActor<S>],
        mut state_at: impl FnMut(usize) -> Option<SongLuaOverlayState>,
        camera_states: &mut [SongLuaOverlayIndex],
    ) {
        camera_states.fill(SongLuaOverlayIndex::default());
        let order = song_lua_parent_order(overlays);
        for ordinal in 0..overlays.len() {
            let index = order.as_ref().map_or(ordinal, |order| order[ordinal]);
            let overlay = &overlays[index];
            let camera_index = overlay.parent_index.and_then(|parent_index| {
                let parent = overlays.get(parent_index)?;
                let parent_state = state_at(parent_index)?;
                if matches!(parent.kind, SongLuaOverlayKind::ActorFrameTexture { .. }) {
                    return None;
                }
                if matches!(
                    parent.kind,
                    SongLuaOverlayKind::ActorFrame
                        | SongLuaOverlayKind::WrapperState
                        | SongLuaOverlayKind::ActorFrameTexture { .. }
                ) && parent_state.fov.is_some()
                {
                    Some(parent_index)
                } else {
                    camera_states[parent_index].get()
                }
            });
            camera_states[index] = SongLuaOverlayIndex::new(camera_index);
        }
    }

    fn include_camera_eases<S: NoteskinSlot + Clone>(
        &mut self,
        overlays: &[SongLuaOverlayActor<S>],
        overlay_eases: &[SongLuaOverlayEaseWindowRuntime],
    ) {
        self.dynamic_camera_scope |= overlay_eases.iter().any(|ease| {
            overlays.get(ease.overlay_index).is_some_and(|overlay| {
                matches!(
                    overlay.kind,
                    SongLuaOverlayKind::ActorFrame
                        | SongLuaOverlayKind::WrapperState
                        | SongLuaOverlayKind::ActorFrameTexture { .. }
                ) && (ease.from.delta.fov.is_some() || ease.to.delta.fov.is_some())
            })
        });
    }

    #[inline(always)]
    fn camera_state(
        &self,
        overlay_states: &[SongLuaOverlayState],
        index: usize,
    ) -> Option<SongLuaOverlayState> {
        if self.dynamic_camera_scope {
            let mut candidate = self
                .camera_ancestors
                .get(index)
                .copied()
                .and_then(SongLuaOverlayIndex::get);
            while let Some(current) = candidate {
                let state = overlay_states.get(current).copied()?;
                if state.fov.is_some() {
                    return Some(state);
                }
                candidate = self
                    .camera_ancestors
                    .get(current)
                    .copied()
                    .and_then(SongLuaOverlayIndex::get);
            }
            return None;
        }
        self.camera_states
            .get(index)
            .copied()
            .and_then(SongLuaOverlayIndex::get)
            .and_then(|camera_index| overlay_states.get(camera_index))
            .copied()
    }
}

const PROJECTED_MESH_VERTEX_CAPACITY: usize = 54;
const SONG_LUA_RAINBOW_TEXT_PREWARM_MAX_CHARS: usize = 64;

/// Screen-owned reusable storage for one dynamic Song Lua mesh.
///
/// One scratch slot is prewarmed for every compiled projected Sprite/Quad and
/// `ActorMultiVertex` during gameplay entry. The game/render thread is the sole
/// writer and clones the base/glow `Arc<Vec<_>>` buffers into actors each frame.
/// A normal next frame recovers each uniquely owned buffer, clears it, and
/// performs no allocation; if an older actor still owns a buffer, the slot
/// replaces it rather than mutating shared data. Capacity is fixed to the
/// compiled vertex count or the 4x4 fade grid's 54 triangle vertices, with no
/// eviction or pruning. Buffers and replaced generations are freed outside
/// their live actor use, ultimately with the screen. Replacement and capacity
/// counters bound worst-case frame work to that actor's compiled vertex count.
/// Static `BitmapText` uppercase content and the seven rainbow-scroll phases are
/// also compiled into this overlay-local song-lifetime storage during screen
/// entry. Rainbow phase storage is capped at 64 characters per actor; larger
/// text reuses one current-phase buffer sized from the compiled text instead of
/// retaining seven copies or allocating during gameplay. `GraphDisplay` body/line geometry and its two-child frame are sized
/// from the compiled point count. Static Model glow vertices and stable
/// renderer geometry keys are computed once per layer during entry.
/// `NoteskinActor` slots get an exact-capacity, sealed model cache plus one
/// pre-whitened glow array per model slot. A gameplay miss preserves output but
/// counts as failed prewarm and may allocate; registered slots never grow,
/// prune, or evict, and all model storage is destroyed with the song screen.
/// `BitmapText` gets two buffers sized for its compiled
/// spans plus one whole-text span: one for dynamic diffuse composition and one
/// for glow/stroke extraction. Gameplay frames only refill or clone these
/// prewarmed buffers. The fallback conversion also supports test-only builders
/// that do not provide screen scratch.
/// Authored text changes reserve their largest string length and one uppercase
/// string per change at entry. They never grow or evict during playback and
/// are released with this song; selection costs one binary search per draw.
#[derive(Default)]
struct SongLuaProjectedMeshScratch {
    sprite_key: Option<Arc<str>>,
    sprite_revision: u64,
    sprite_binding: Option<deadlib_assets::BoundTexture>,
    textured_vertices: Option<Arc<Vec<TexturedMeshVertex>>>,
    textured_glow_vertices: Option<Arc<Vec<TexturedMeshVertex>>>,
    mesh_vertices: Option<Arc<Vec<MeshVertex>>>,
    mesh_glow_vertices: Option<Arc<Vec<MeshVertex>>>,
    graph_body_vertices: Option<Arc<Vec<MeshVertex>>>,
    graph_line_vertices: Option<Arc<Vec<MeshVertex>>>,
    graph_body_key: Option<[u32; 10]>,
    graph_line_key: Option<[u32; 11]>,
    graph_frame: Option<SharedActorFrameScratch>,
    model_passes: Option<Vec<Option<SongLuaModelGeometry>>>,
    noteskin_model_cache: Option<ModelMeshCache>,
    text_diffuse_attributes: Option<Arc<Vec<TextAttribute>>>,
    text_glow_attributes: Option<Arc<Vec<TextAttribute>>>,
    uppercase_source: Option<Arc<str>>,
    uppercase_text: Option<Arc<str>>,
    uppercase_changes: Vec<(Arc<str>, Arc<str>)>,
    rainbow_text_attributes: Option<[Arc<[TextAttribute]>; SONG_LUA_TEXT_RAINBOW_COLORS.len()]>,
    capacity: usize,
    text_attribute_capacity: usize,
    replacements: u64,
}

impl SongLuaProjectedMeshScratch {
    // One binding per overlay, owned by the screen's existing scratch. Prewarmed
    // for all sprites at entry, including hidden layers. No eviction or growth:
    // a steady draw only checks the revision and Arc identity. A changed key or
    // store revision performs one local lookup (and metadata fallback if needed).
    // Missing assets stay missing until that revision changes; no draw-time I/O.
    fn bind_sprite<T>(
        &mut self,
        key: &Arc<str>,
        textures: &deadlib_assets::TextureStore<T>,
    ) -> Option<deadlib_assets::BoundTexture> {
        let revision = textures.revision();
        if self.sprite_revision != revision
            || !self
                .sprite_key
                .as_ref()
                .is_some_and(|previous| Arc::ptr_eq(previous, key))
        {
            self.sprite_binding = textures.bind_texture(key);
            self.sprite_key = Some(Arc::clone(key));
            self.sprite_revision = revision;
        }
        self.sprite_binding
    }

    fn textured(capacity: usize) -> Self {
        Self {
            sprite_key: None,
            sprite_revision: 0,
            sprite_binding: None,
            textured_vertices: Some(Arc::new(Vec::with_capacity(capacity))),
            textured_glow_vertices: Some(Arc::new(Vec::with_capacity(capacity))),
            mesh_vertices: None,
            mesh_glow_vertices: None,
            graph_body_vertices: None,
            graph_line_vertices: None,
            graph_body_key: None,
            graph_line_key: None,
            graph_frame: None,
            model_passes: None,
            noteskin_model_cache: None,
            text_diffuse_attributes: None,
            text_glow_attributes: None,
            uppercase_source: None,
            uppercase_text: None,
            uppercase_changes: Vec::new(),
            rainbow_text_attributes: None,
            capacity,
            text_attribute_capacity: 0,
            replacements: 0,
        }
    }

    fn mesh(capacity: usize) -> Self {
        Self {
            sprite_key: None,
            sprite_revision: 0,
            sprite_binding: None,
            textured_vertices: None,
            textured_glow_vertices: None,
            mesh_vertices: Some(Arc::new(Vec::with_capacity(capacity))),
            mesh_glow_vertices: Some(Arc::new(Vec::with_capacity(capacity))),
            graph_body_vertices: None,
            graph_line_vertices: None,
            graph_body_key: None,
            graph_line_key: None,
            graph_frame: None,
            model_passes: None,
            noteskin_model_cache: None,
            text_diffuse_attributes: None,
            text_glow_attributes: None,
            uppercase_source: None,
            uppercase_text: None,
            uppercase_changes: Vec::new(),
            rainbow_text_attributes: None,
            capacity,
            text_attribute_capacity: 0,
            replacements: 0,
        }
    }

    fn graph(capacity: usize) -> Self {
        Self {
            graph_body_vertices: Some(Arc::new(Vec::with_capacity(capacity))),
            graph_line_vertices: Some(Arc::new(Vec::with_capacity(capacity))),
            graph_frame: Some(SharedActorFrameScratch::with_capacity(2)),
            capacity,
            ..Self::default()
        }
    }

    fn model(layers: &[SongLuaOverlayModelLayer]) -> Self {
        let model_passes = layers
            .iter()
            .map(|layer| Some(SongLuaModelGeometry::new(&layer.vertices)))
            .collect();
        Self {
            model_passes: Some(model_passes),
            ..Self::default()
        }
    }

    fn noteskin<S: NoteskinSlot + Clone>(slots: &[S]) -> Self {
        let mut model_cache = ModelMeshCache::with_capacity(slots.len());
        for slot in slots {
            model_cache.prewarm_slot(slot);
        }
        let model_passes = slots
            .iter()
            .map(|slot| {
                model_cache
                    .model_geometry(slot)
                    .map(|(_, vertices)| SongLuaModelGeometry::new(&vertices))
            })
            .collect();
        model_cache.seal();
        Self {
            noteskin_model_cache: Some(model_cache),
            model_passes: Some(model_passes),
            ..Self::default()
        }
    }

    fn prewarm_text_attributes(&mut self, attribute_count: usize, text_char_count: usize) {
        let capacity = attribute_count.saturating_add(1).max(text_char_count);
        self.text_diffuse_attributes = Some(Arc::new(Vec::with_capacity(capacity)));
        self.text_glow_attributes = Some(Arc::new(Vec::with_capacity(capacity)));
        self.text_attribute_capacity = capacity;
    }

    fn update_projected(
        &mut self,
        grid: &[TexturedMeshVertex],
        width: usize,
        height: usize,
        edge_fade: [f32; 4],
        colors: SongLuaSpriteColors,
    ) -> Arc<Vec<TexturedMeshVertex>> {
        update_song_lua_shared_vec(
            &mut self.textured_vertices,
            self.capacity,
            &mut self.replacements,
            |vertices| {
                append_projected_mesh_vertices(grid, width, height, edge_fade, colors, vertices);
            },
        )
    }

    fn update_textured(
        &mut self,
        fill: impl FnOnce(&mut Vec<TexturedMeshVertex>),
    ) -> Arc<Vec<TexturedMeshVertex>> {
        update_song_lua_shared_vec(
            &mut self.textured_vertices,
            self.capacity,
            &mut self.replacements,
            fill,
        )
    }

    fn update_textured_glow(
        &mut self,
        vertices: &[TexturedMeshVertex],
    ) -> Arc<Vec<TexturedMeshVertex>> {
        update_song_lua_shared_vec(
            &mut self.textured_glow_vertices,
            self.capacity,
            &mut self.replacements,
            |out| {
                out.extend(vertices.iter().copied().map(|mut vertex| {
                    // Native Sprite/ActorMultiVertex glow replaces diffuse RGBA.
                    vertex.color = [1.0; 4];
                    vertex
                }));
            },
        )
    }

    fn uppercase(&mut self, text: &Arc<str>, index: Option<usize>) -> Arc<str> {
        if let Some((source, uppercase)) = index.and_then(|index| self.uppercase_changes.get(index))
            && source == text
        {
            return Arc::clone(uppercase);
        }
        if self.uppercase_source.as_ref() != Some(text) {
            self.uppercase_source = Some(Arc::clone(text));
            self.uppercase_text = Some(Arc::from(text.to_uppercase()));
        }
        Arc::clone(self.uppercase_text.as_ref().expect("uppercase text has a source"))
    }

    fn rainbow_attributes(&mut self, text: &str, uptime_seconds: f64) -> TextAttributes {
        let phase = song_lua_rainbow_scroll_phase(uptime_seconds);
        let char_count = text.chars().count();
        // Live settext can change the number of glyphs after screen preparation.
        // Reuse a prewarmed phase only while it covers the current text exactly.
        if let Some(attributes) = self.rainbow_text_attributes.as_ref()
            && attributes[phase].len() == char_count
        {
            return TextAttributes::from(Arc::clone(&attributes[phase]));
        }
        self.text_attribute_capacity = self.text_attribute_capacity.max(char_count);
        self.update_text_diffuse(|out| {
            append_song_lua_rainbow_scroll_attributes_at_phase(text, phase, out);
        })
    }

    fn update_mesh(&mut self, fill: impl FnOnce(&mut Vec<MeshVertex>)) -> Arc<Vec<MeshVertex>> {
        update_song_lua_shared_vec(
            &mut self.mesh_vertices,
            self.capacity,
            &mut self.replacements,
            fill,
        )
    }

    fn update_mesh_glow(&mut self, vertices: &[MeshVertex]) -> Arc<Vec<MeshVertex>> {
        update_song_lua_shared_vec(
            &mut self.mesh_glow_vertices,
            self.capacity,
            &mut self.replacements,
            |out| out.extend(vertices.iter().copied().map(|mut vertex| {
                vertex.color = [1.0; 4];
                vertex
            })),
        )
    }

    fn update_graph_body(
        &mut self,
        key: [u32; 10],
        fill: impl FnOnce(&mut Vec<MeshVertex>),
    ) -> Arc<Vec<MeshVertex>> {
        if self.graph_body_key == Some(key)
            && let Some(vertices) = self.graph_body_vertices.as_ref()
        {
            return Arc::clone(vertices);
        }
        self.graph_body_key = Some(key);
        update_song_lua_shared_vec(
            &mut self.graph_body_vertices,
            self.capacity,
            &mut self.replacements,
            fill,
        )
    }

    fn update_graph_line(
        &mut self,
        key: [u32; 11],
        fill: impl FnOnce(&mut Vec<MeshVertex>),
    ) -> Arc<Vec<MeshVertex>> {
        if self.graph_line_key == Some(key)
            && let Some(vertices) = self.graph_line_vertices.as_ref()
        {
            return Arc::clone(vertices);
        }
        self.graph_line_key = Some(key);
        update_song_lua_shared_vec(
            &mut self.graph_line_vertices,
            self.capacity,
            &mut self.replacements,
            fill,
        )
    }

    fn update_text_diffuse(
        &mut self,
        fill: impl FnOnce(&mut Vec<TextAttribute>),
    ) -> TextAttributes {
        TextAttributes::from(update_song_lua_shared_vec(
            &mut self.text_diffuse_attributes,
            self.text_attribute_capacity,
            &mut self.replacements,
            fill,
        ))
    }

    fn update_text_glow(&mut self, fill: impl FnOnce(&mut Vec<TextAttribute>)) -> TextAttributes {
        TextAttributes::from(update_song_lua_shared_vec(
            &mut self.text_glow_attributes,
            self.text_attribute_capacity,
            &mut self.replacements,
            fill,
        ))
    }
}

fn song_lua_static_glow_vertices(vertices: &[TexturedMeshVertex]) -> Arc<[TexturedMeshVertex]> {
    Arc::from(
        vertices
            .iter()
            .copied()
            .map(|mut vertex| {
                // Native Sprite/ActorMultiVertex glow replaces diffuse RGBA.
                vertex.color = [1.0; 4];
                vertex
            })
            .collect::<Vec<_>>()
            .into_boxed_slice(),
    )
}

/// Song-local geometry, built at screen entry and released on transition.
/// Diffuse and secondary passes retain separate sphere-mapping flags; both
/// keep native per-vertex texture-matrix scaling. Gameplay only clones Arcs.
struct SongLuaModelGeometry {
    diffuse: (TMeshCacheKey, Arc<[TexturedMeshVertex]>),
    additive: Option<(TMeshCacheKey, Arc<[TexturedMeshVertex]>)>,
    glow: Arc<[TexturedMeshVertex]>,
}

impl SongLuaModelGeometry {
    fn new(vertices: &Arc<[TexturedMeshVertex]>) -> Self {
        let mode = vertices.first().map_or(0, |vertex| vertex.normal[3] as u8);
        let pass = |sphere: u8| {
            let vertices: Arc<[TexturedMeshVertex]> = if mode == sphere {
                Arc::clone(vertices)
            } else {
                vertices
                    .iter()
                    .copied()
                    .map(|mut vertex| {
                        vertex.normal[3] = f32::from(sphere);
                        vertex
                    })
                    .collect()
            };
            (song_lua_model_geometry_key(&vertices), vertices)
        };
        let diffuse = pass(mode & 1);
        let additive = (mode & 4 != 0).then(|| {
            let sphere = (mode >> 1) & 1;
            if sphere == mode & 1 {
                (diffuse.0, Arc::clone(&diffuse.1))
            } else {
                pass(sphere)
            }
        });
        let glow = song_lua_static_glow_vertices(&diffuse.1);
        Self {
            diffuse,
            additive,
            glow,
        }
    }
}

fn song_lua_model_geometry_key(vertices: &[TexturedMeshVertex]) -> TMeshCacheKey {
    let mut hasher = rustc_hash::FxHasher::default();
    hasher.write(b"deadsync-song-lua-model-v2");
    hasher.write_usize(vertices.len());
    for vertex in vertices {
        for value in vertex.normal {
            hasher.write_u32(value.to_bits());
        }
        for value in vertex.pos {
            hasher.write_u32(value.to_bits());
        }
        for value in vertex.uv {
            hasher.write_u32(value.to_bits());
        }
        for value in vertex.tex_matrix_scale {
            hasher.write_u32(value.to_bits());
        }
        for value in vertex.color {
            hasher.write_u32(value.to_bits());
        }
    }
    hasher.finish().max(1)
}

fn song_lua_glow_geometry_key(base: TMeshCacheKey) -> TMeshCacheKey {
    if base == INVALID_TMESH_CACHE_KEY {
        return INVALID_TMESH_CACHE_KEY;
    }
    let mut hasher = rustc_hash::FxHasher::default();
    hasher.write(b"deadsync-song-lua-glow-v1");
    hasher.write_u64(base);
    hasher.finish().max(1)
}

fn update_song_lua_shared_vec<T>(
    shared: &mut Option<Arc<Vec<T>>>,
    capacity: usize,
    replacements: &mut u64,
    fill: impl FnOnce(&mut Vec<T>),
) -> Arc<Vec<T>> {
    let shared = shared.get_or_insert_with(|| Arc::new(Vec::with_capacity(capacity)));
    let values = match Arc::get_mut(shared) {
        Some(values) => values,
        None => {
            *replacements = (*replacements).saturating_add(1);
            *shared = Arc::new(Vec::with_capacity(capacity));
            Arc::get_mut(shared).expect("shared vector was just made unique")
        }
    };
    values.clear();
    fill(values);
    Arc::clone(shared)
}

fn song_lua_projected_mesh_scratch_for<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
) -> Vec<SongLuaProjectedMeshScratch> {
    overlays
        .iter()
        .map(|overlay| {
            let mut scratch = match &overlay.kind {
                SongLuaOverlayKind::Sprite { .. } | SongLuaOverlayKind::Quad => {
                    SongLuaProjectedMeshScratch::textured(PROJECTED_MESH_VERTEX_CAPACITY)
                }
                SongLuaOverlayKind::ActorMultiVertex {
                    vertices,
                    texture_key: Some(_),
                    ..
                }
                | SongLuaOverlayKind::ActorMultiVertex {
                    vertices,
                    capture_name: Some(_),
                    ..
                } => SongLuaProjectedMeshScratch::textured(vertices.len()),
                SongLuaOverlayKind::ActorMultiVertex { vertices, .. } => {
                    SongLuaProjectedMeshScratch::mesh(vertices.len())
                }
                SongLuaOverlayKind::GraphDisplay { body_values, .. } => {
                    let vertex_count = graph_display_values_or_default(body_values)
                        .len()
                        .saturating_sub(1)
                        .saturating_mul(6);
                    SongLuaProjectedMeshScratch::graph(vertex_count)
                }
                SongLuaOverlayKind::Model { layers } => SongLuaProjectedMeshScratch::model(layers),
                SongLuaOverlayKind::NoteskinActor { slots, .. } => {
                    SongLuaProjectedMeshScratch::noteskin(slots)
                }
                _ => SongLuaProjectedMeshScratch::default(),
            };
            if let SongLuaOverlayKind::BitmapText {
                text,
                text_changes,
                attributes,
                ..
            } = &overlay.kind
            {
                let uppercase_text = Arc::<str>::from(text.to_uppercase());
                let char_count = text_changes
                    .iter()
                    .map(|(_, text)| text.chars().count())
                    .chain(std::iter::once(text.chars().count()))
                    .max()
                    .unwrap_or(0);
                scratch.prewarm_text_attributes(
                    attributes.len(),
                    char_count.max(uppercase_text.chars().count()),
                );
                scratch.uppercase_source = Some(Arc::clone(text));
                scratch.uppercase_text = Some(uppercase_text);
                scratch.uppercase_changes = text_changes
                    .iter()
                    .map(|(_, text)| (Arc::clone(text), Arc::from(text.to_uppercase())))
                    .collect();
                if text_changes.is_empty()
                    && (1..=SONG_LUA_RAINBOW_TEXT_PREWARM_MAX_CHARS).contains(&char_count)
                {
                    scratch.rainbow_text_attributes =
                        Some(song_lua_rainbow_scroll_phases(text.as_ref()));
                }
            }
            scratch
        })
        .collect()
}

#[derive(Default)]
struct SongLuaProxyRequestIndex {
    topology: SongLuaOverlayTopologyIndex,
    root_indices: Vec<usize>,
    capture_children: Vec<Vec<usize>>,
    proxy_indices: Vec<usize>,
}

/// Song-lifetime visitation marks for nested AFT/proxy traversals.
///
/// Owner/thread model: gameplay `State`, used only by the frame-building
/// thread. Lifetime: one song. Capacity is the largest compiled overlay layer
/// and is populated at screen entry. Each traversal advances a generation, so
/// gameplay frames neither clear the full array nor allocate a recursion stack.
/// A wrapped generation performs one bounded fill. Duplicate references and
/// cycles are skipped after their first visit; there is no eviction, pruning,
/// or destruction before the gameplay transition. Worst-case frame work is one
/// visit per compiled capture rather than one visit per reference.
#[derive(Default)]
struct SongLuaCaptureVisitScratch {
    marks: Vec<u32>,
    generation: u32,
}

impl SongLuaCaptureVisitScratch {
    fn with_capacity(capacity: usize) -> Self {
        Self {
            marks: vec![0; capacity],
            generation: 0,
        }
    }

    fn begin(&mut self, required: usize) {
        debug_assert!(
            required <= self.marks.len(),
            "song-lifetime capture marks must cover every compiled overlay"
        );
        self.generation = self.generation.wrapping_add(1);
        if self.generation == 0 {
            self.marks.fill(0);
            self.generation = 1;
        }
    }

    fn visit(&mut self, index: usize) -> bool {
        let Some(mark) = self.marks.get_mut(index) else {
            return false;
        };
        if *mark == self.generation {
            return false;
        }
        *mark = self.generation;
        true
    }
}

impl SongLuaProxyRequestIndex {
    fn new<S: NoteskinSlot + Clone>(overlays: &[SongLuaOverlayActor<S>]) -> Self {
        let topology = SongLuaOverlayTopologyIndex::new(overlays);
        let mut root_indices = Vec::with_capacity(overlays.len());
        let mut capture_children = vec![Vec::new(); overlays.len()];
        for (index, ancestor) in topology
            .aft_ancestors
            .iter()
            .copied()
            .map(SongLuaOverlayIndex::get)
            .enumerate()
        {
            if let Some(ancestor) = ancestor {
                if let Some(children) = capture_children.get_mut(ancestor) {
                    children.push(index);
                }
            } else {
                root_indices.push(index);
            }
        }
        let proxy_indices = overlays
            .iter()
            .enumerate()
            .filter_map(|(index, overlay)| {
                matches!(overlay.kind, SongLuaOverlayKind::ActorProxy { .. }).then_some(index)
            })
            .collect();
        Self {
            topology,
            root_indices,
            capture_children,
            proxy_indices,
        }
    }

    fn direct_proxy_capacity<S: NoteskinSlot + Clone>(
        &self,
        overlays: &[SongLuaOverlayActor<S>],
    ) -> usize {
        self.root_indices
            .iter()
            .map(
                |&index| match overlays.get(index).map(|overlay| &overlay.kind) {
                    Some(SongLuaOverlayKind::ActorProxy {
                        target: SongLuaProxyTarget::Player { .. },
                    }) => 3,
                    Some(SongLuaOverlayKind::ActorProxy {
                        target:
                            SongLuaProxyTarget::NoteField { .. }
                            | SongLuaProxyTarget::Judgment { .. }
                            | SongLuaProxyTarget::Combo { .. },
                    }) => 1,
                    _ => 0,
                },
            )
            .sum()
    }
}

/// Game-thread, song-lifetime cursor for one overlay's immutable message list.
///
/// It owns no variable-capacity storage and needs no synchronization. The first
/// frame/event transition advances source cursors and compiles the active
/// block's easing enum; steady tween frames only evaluate that enum. Backward
/// seeks reset and replay message/block cursors, with work bounded by crossed
/// events and blocks. There are no allocations, misses, eviction, or separate
/// destruction; the cache drops with frame scratch. Parity tests cover seeks.
#[derive(Clone, Copy, Debug)]
struct SongLuaMessageStateCache {
    initialized: bool,
    next_event: usize,
    processed_until: f32,
    base_state: SongLuaOverlayState,
    active_command_index: Option<usize>,
    active_start_second: f32,
    active_next_block: usize,
    active_easing: Option<(usize, SongLuaEase)>,
    active_block_state: SongLuaOverlayState,
    active_last_elapsed: f32,
}

impl Default for SongLuaMessageStateCache {
    fn default() -> Self {
        Self {
            initialized: false,
            next_event: 0,
            processed_until: f32::NEG_INFINITY,
            base_state: SongLuaOverlayState::default(),
            active_command_index: None,
            active_start_second: 0.0,
            active_next_block: 0,
            active_easing: None,
            active_block_state: SongLuaOverlayState::default(),
            active_last_elapsed: f32::NEG_INFINITY,
        }
    }
}

impl SongLuaMessageStateCache {
    #[inline(always)]
    const fn reset(&mut self, initial_state: SongLuaOverlayState) {
        self.initialized = true;
        self.next_event = 0;
        self.processed_until = f32::NEG_INFINITY;
        self.base_state = initial_state;
        self.active_command_index = None;
        self.active_start_second = 0.0;
        self.reset_active_blocks(initial_state);
    }

    #[inline(always)]
    const fn reset_active_blocks(&mut self, state: SongLuaOverlayState) {
        self.active_next_block = 0;
        self.active_easing = None;
        self.active_block_state = state;
        self.active_last_elapsed = f32::NEG_INFINITY;
    }
}

fn song_lua_overlay_child_list_index(parent_index: Option<usize>) -> usize {
    parent_index.map_or(0, |idx| idx + 1)
}

fn song_lua_order_source<S>(overlays: &[SongLuaOverlayActor<S>], mut index: usize) -> usize {
    // Prepared wrappers precede their child; live wrappers append without moving
    // existing visual slots. Both inherit their owner's sibling order.
    while matches!(overlays[index].kind, SongLuaOverlayKind::WrapperState) {
        let next = index + 1;
        let next = if overlays
            .get(next)
            .is_some_and(|actor| actor.parent_index == Some(index))
        {
            Some(next)
        } else {
            overlays.iter().position(|actor| actor.parent_index == Some(index))
        };
        let Some(next) = next else { break };
        index = next;
    }
    index
}

fn song_lua_sort_static_children<S>(overlays: &[SongLuaOverlayActor<S>], children: &mut [usize]) {
    children.sort_by_key(|&idx| {
        (
            overlays[song_lua_order_source(overlays, idx)]
                .initial_state
                .draw_order,
            song_lua_order_source(overlays, idx),
        )
    });
}

fn song_lua_push_static_order(
    child_lists: &[Vec<usize>],
    parent_index: Option<usize>,
    out: &mut Vec<usize>,
) {
    let list_idx = song_lua_overlay_child_list_index(parent_index);
    let Some(children) = child_lists.get(list_idx) else {
        return;
    };
    for &index in children {
        out.push(index);
        song_lua_push_static_order(child_lists, Some(index), out);
    }
}

fn song_lua_overlay_order_cache_from<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_eases: &[SongLuaOverlayEaseWindowRuntime],
) -> SongLuaOverlayOrderCache {
    let mut child_lists = vec![Vec::new(); overlays.len() + 1];
    for (idx, overlay) in overlays.iter().enumerate() {
        let list_idx = match overlay.parent_index {
            Some(parent_index) if parent_index < overlays.len() => parent_index + 1,
            Some(_) => continue,
            None => 0,
        };
        child_lists[list_idx].push(idx);
    }
    for children in &mut child_lists {
        song_lua_sort_static_children(overlays, children);
    }
    let mut tap_commands = Vec::new();
    for (overlay, actor) in overlays.iter().enumerate() {
        for (command, callback) in actor.message_commands.iter().enumerate() {
            let Some(key) = callback.message.strip_prefix("__songlua_tap_") else {
                continue;
            };
            let mut parts = key.split('_');
            let player = parts
                .next()
                .and_then(|part| part.parse::<usize>().ok())
                .and_then(|value| value.checked_sub(1));
            let column = parts
                .next()
                .and_then(|part| part.parse::<usize>().ok())
                .and_then(|value| value.checked_sub(1));
            let grade = match parts.next() {
                Some("W1") => JudgeGrade::Fantastic,
                Some("W2") => JudgeGrade::Excellent,
                Some("W3") => JudgeGrade::Great,
                Some("W4") => JudgeGrade::Decent,
                Some("W5") => JudgeGrade::WayOff,
                _ => continue,
            };
            if let (Some(player), Some(column)) = (player, column) {
                tap_commands.push(SongLuaTapCommand {
                    overlay,
                    command,
                    player,
                    column,
                    grade,
                    glow_started_at: None,
                });
            }
        }
    }
    let mut dynamic_actor_draw_order = vec![false; overlays.len()];
    let mut dynamic_local = vec![false; overlays.len()];
    let mut effect_capable = overlays
        .iter()
        .map(|overlay| {
            song_lua_compose_effect(overlay.initial_state.effect_mode)
                || overlay.initial_state.rainbow
                || overlay.initial_state.vibrate
                || overlay.message_commands.iter().any(|command| {
                    command.blocks.iter().any(|block| {
                        block.delta.effect_mode.is_some_and(song_lua_compose_effect)
                            || block.delta.rainbow == Some(true)
                            || block.delta.vibrate == Some(true)
                    })
                })
        })
        .collect::<Vec<_>>();
    let mut has_dynamic_z_order = overlays
        .iter()
        .any(|overlay| overlay.initial_state.draw_by_z_position);
    for (idx, overlay) in overlays.iter().enumerate() {
        dynamic_local[idx] = !overlay.message_commands.is_empty();
        dynamic_actor_draw_order[idx] = overlay.message_commands.iter().any(|command| {
            command
                .blocks
                .iter()
                .any(|block| block.delta.draw_order.is_some())
        });
        has_dynamic_z_order |= overlay.message_commands.iter().any(|command| {
            command
                .blocks
                .iter()
                .any(|block| block.delta.z.is_some() || block.delta.draw_by_z_position.is_some())
        });
    }
    for ease in overlay_eases {
        if ease.overlay_index < dynamic_actor_draw_order.len() {
            dynamic_local[ease.overlay_index] = true;
            effect_capable[ease.overlay_index] |= ease
                .from
                .delta
                .effect_mode
                .is_some_and(song_lua_compose_effect)
                || ease
                    .to
                    .delta
                    .effect_mode
                    .is_some_and(song_lua_compose_effect)
                || ease.from.delta.rainbow == Some(true)
                || ease.to.delta.rainbow == Some(true);
            if ease.from.delta.draw_order.is_some() || ease.to.delta.draw_order.is_some() {
                dynamic_actor_draw_order[ease.overlay_index] = true;
            }
            has_dynamic_z_order |= ease.from.delta.z.is_some()
                || ease.to.delta.z.is_some()
                || ease.from.delta.draw_by_z_position.is_some()
                || ease.to.delta.draw_by_z_position.is_some();
        }
    }
    let update_actor_index = SongLuaOverlayIndex::new(
        overlays
            .iter()
            .position(|overlay| matches!(overlay.kind, SongLuaOverlayKind::UpdateTracks { .. })),
    );
    let overlay_updates = song_lua_overlay_runtime_updates_at(overlays, update_actor_index);
    let mut visible_update_indices = SmallVec::new();
    for (track_index, track) in overlay_updates.iter().enumerate() {
        if matches!(
            track.target,
            crate::SongLuaOverlayUpdateTarget::Visible
                | crate::SongLuaOverlayUpdateTarget::Hibernating
        ) {
            visible_update_indices.push(track_index);
        }
        if track.overlay_index >= dynamic_local.len() {
            continue;
        }
        dynamic_local[track.overlay_index] = true;
        effect_capable[track.overlay_index] |= match track.target {
            crate::SongLuaOverlayUpdateTarget::EffectMode => track.samples.iter().any(|sample| {
                matches!(sample.value, crate::SongLuaOverlayUpdateValue::EffectMode(mode) if song_lua_compose_effect(mode))
            }),
            crate::SongLuaOverlayUpdateTarget::Rainbow
            | crate::SongLuaOverlayUpdateTarget::Vibrate => track.samples.iter().any(|sample| {
                matches!(sample.value, crate::SongLuaOverlayUpdateValue::Bool(true))
            }),
            _ => false,
        };
        dynamic_actor_draw_order[track.overlay_index] |=
            track.target == crate::SongLuaOverlayUpdateTarget::DrawOrder;
        has_dynamic_z_order |= matches!(
            track.target,
            crate::SongLuaOverlayUpdateTarget::Z
                | crate::SongLuaOverlayUpdateTarget::DrawByZPosition
        );
    }

    let mut update_ranges = Vec::with_capacity(overlays.len());
    let mut track_index = 0;
    for overlay_index in 0..overlays.len() {
        while overlay_updates
            .get(track_index)
            .is_some_and(|track| track.overlay_index < overlay_index)
        {
            track_index += 1;
        }
        let start = track_index;
        while overlay_updates
            .get(track_index)
            .is_some_and(|track| track.overlay_index == overlay_index)
        {
            track_index += 1;
        }
        update_ranges.push(start..track_index);
    }

    let dynamic_local_indices = dynamic_local
        .iter()
        .enumerate()
        .filter_map(|(index, dynamic)| dynamic.then_some(index))
        .collect::<Box<[_]>>();
    let mut dynamic_composed = vec![false; overlays.len()];
    let mut dynamic_composed_indices = Vec::new();
    let mut effect_ancestors = vec![false; overlays.len()];
    let mut effect_composed_indices = Vec::new();
    let parent_order = song_lua_parent_order(overlays);
    for ordinal in 0..overlays.len() {
        let index = parent_order.as_ref().map_or(ordinal, |order| order[ordinal]);
        let overlay = &overlays[index];
        let inherited_effect = overlay
            .parent_index
            .is_some_and(|parent| effect_ancestors[parent] || effect_capable[parent]);
        effect_ancestors[index] = inherited_effect;
        if inherited_effect || effect_capable[index] {
            effect_composed_indices.push(index);
        }
        let dynamic = inherited_effect
            || effect_capable[index]
            || dynamic_local[index]
            || overlay
                .parent_index
                .and_then(|parent| dynamic_composed.get(parent))
                .copied()
                .unwrap_or(false);
        dynamic_composed[index] = dynamic;
        if dynamic {
            dynamic_composed_indices.push(index);
        }
    }

    let dynamic_draw_order = child_lists
        .iter()
        .map(|children| {
            children.iter().any(|&idx| {
                dynamic_actor_draw_order
                    .get(song_lua_order_source(overlays, idx))
                    .copied()
                    .unwrap_or(false)
            })
        })
        .collect::<Vec<_>>();
    let static_root_order =
        if dynamic_actor_draw_order.iter().any(|dynamic| *dynamic) || has_dynamic_z_order {
            None
        } else {
            let mut order = Vec::with_capacity(overlays.len());
            song_lua_push_static_order(&child_lists, None, &mut order);
            Some(order.into_boxed_slice())
        };
    let sort_modes = vec![SONG_LUA_CHILD_ORDER_STATIC; child_lists.len()];
    SongLuaOverlayOrderCache {
        child_lists,
        dynamic_draw_order,
        tap_commands,
        dynamic_local_indices,
        dynamic_composed_indices: dynamic_composed_indices.into_boxed_slice(),
        effect_composed_indices: effect_composed_indices.into_boxed_slice(),
        static_root_order,
        update_actor_index,
        update_ranges: update_ranges.into_boxed_slice(),
        visible_update_indices,
        update_cursors: vec![0; overlay_updates.len()],
        sort_modes,
        last_draw_orders: vec![0; overlays.len()],
        last_z_keys: vec![0; overlays.len()],
    }
}
/// Song-lifetime activation index for one visual-layer list.
///
/// The gameplay thread owns three fixed-capacity buffers. Screen entry separates
/// source-order starts from their sorted index order and reserves the complete
/// active capacity. Two scalar deadlines make unchanged frames O(1) without
/// touching either boxed table. Chronological sources extend or truncate the
/// active prefix directly; unsorted sources retain the bounded binary
/// insert/remove and O(n log n) seek fallback, preserving source draw order.
/// There are no gameplay allocations, misses, eviction, pruning,
/// synchronization, or destruction before screen exit; all storage drops with
/// the screen.
struct SongLuaLayerActivity {
    start_seconds: Box<[f32]>,
    start_order: Box<[usize]>,
    active: Vec<usize>,
    next_start: usize,
    next_start_second: f32,
    previous_start_second: f32,
    source_ordered: bool,
}

impl Default for SongLuaLayerActivity {
    fn default() -> Self {
        Self {
            start_seconds: Box::default(),
            start_order: Box::default(),
            active: Vec::new(),
            next_start: 0,
            next_start_second: f32::INFINITY,
            previous_start_second: f32::NEG_INFINITY,
            source_ordered: true,
        }
    }
}

impl SongLuaLayerActivity {
    fn new(starts: impl IntoIterator<Item = f32>, now: f32) -> Self {
        let start_seconds = starts.into_iter().collect::<Box<[_]>>();
        let mut start_order = (0..start_seconds.len()).collect::<Vec<_>>();
        start_order.sort_by(|&left, &right| {
            start_seconds[left]
                .total_cmp(&start_seconds[right])
                .then_with(|| left.cmp(&right))
        });
        let source_ordered = start_order
            .iter()
            .enumerate()
            .all(|(position, &source_index)| position == source_index);
        let next_start_second = start_order
            .first()
            .map_or(f32::INFINITY, |&index| start_seconds[index]);
        let mut activity = Self {
            active: Vec::with_capacity(start_seconds.len()),
            start_seconds,
            start_order: start_order.into_boxed_slice(),
            next_start: 0,
            next_start_second,
            previous_start_second: f32::NEG_INFINITY,
            source_ordered,
        };
        activity.sync(now);
        activity
    }

    #[inline]
    fn sync(&mut self, now: f32) -> &[usize] {
        let old_next_start = self.next_start;
        while self.next_start < self.start_order.len()
            && now.partial_cmp(&self.next_start_second) != Some(std::cmp::Ordering::Less)
        {
            self.previous_start_second = self.next_start_second;
            self.next_start += 1;
            self.next_start_second = self
                .start_order
                .get(self.next_start)
                .map_or(f32::INFINITY, |&index| self.start_seconds[index]);
        }
        while self.next_start > 0 && now < self.previous_start_second {
            self.next_start_second = self.previous_start_second;
            self.next_start -= 1;
            self.previous_start_second = self
                .next_start
                .checked_sub(1)
                .map_or(f32::NEG_INFINITY, |position| {
                    self.start_seconds[self.start_order[position]]
                });
        }
        if self.next_start == old_next_start {
            return &self.active;
        }
        if self.source_ordered {
            if self.next_start > old_next_start {
                self.active.extend(old_next_start..self.next_start);
            } else {
                self.active.truncate(self.next_start);
            }
            return &self.active;
        }
        match self.next_start.abs_diff(old_next_start) {
            0 => {}
            1 if self.next_start > old_next_start => {
                let index = self.start_order[old_next_start];
                let insert_at = self.active.binary_search(&index).unwrap_or_else(|at| at);
                self.active.insert(insert_at, index);
            }
            1 => {
                let index = self.start_order[self.next_start];
                if let Ok(remove_at) = self.active.binary_search(&index) {
                    self.active.remove(remove_at);
                }
            }
            _ => {
                self.active.clear();
                self.active
                    .extend_from_slice(&self.start_order[..self.next_start]);
                self.active.sort_unstable();
            }
        }
        &self.active
    }
}
const SONG_LUA_FG_OWNER_ROOT: u8 = 0;
const SONG_LUA_FG_OWNER_BACKGROUND: u8 = 1;
const SONG_LUA_FG_OWNER_FOREGROUND: u8 = 2;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct SongLuaForegroundOwnerRef {
    source: u8,
    layer_index: usize,
    overlay_index: usize,
}

struct SongLuaForegroundOwnerPath {
    path: PathBuf,
    owner_start: usize,
    owner_end: usize,
}

/// Path-specific Song Lua ownership index for the active simfile foreground.
///
/// The gameplay thread owns immutable, exactly-sized path and owner tables built
/// at screen entry. Foreground events select a path with binary search; gameplay
/// frames read only its contiguous owner range. Misses saturate to an empty
/// range, there is no growth, eviction, synchronization, or live-frame pruning,
/// and storage is freed at screen exit.
#[derive(Default)]
struct SongLuaForegroundOwnerIndex {
    paths: Box<[SongLuaForegroundOwnerPath]>,
    owners: Box<[SongLuaForegroundOwnerRef]>,
    active_start: usize,
    active_end: usize,
}

impl SongLuaForegroundOwnerIndex {
    fn new<S: NoteskinSlot + Clone>(
        visuals: &SongLuaRuntimeVisuals<
            SongLuaOverlayActor<S>,
            SongLuaCapturedActor,
            SongLuaRuntimeOverlayStateDelta,
        >,
    ) -> Self {
        let capacity = visuals.overlays.len()
            + visuals
                .background_visual_layers
                .iter()
                .map(|layer| layer.overlays.len())
                .sum::<usize>()
            + visuals
                .foreground_visual_layers
                .iter()
                .map(|layer| layer.overlays.len())
                .sum::<usize>();
        let mut entries = Vec::with_capacity(capacity);
        Self::push_entries(&mut entries, SONG_LUA_FG_OWNER_ROOT, 0, &visuals.overlays);
        for (layer_index, layer) in visuals.background_visual_layers.iter().enumerate() {
            Self::push_entries(
                &mut entries,
                SONG_LUA_FG_OWNER_BACKGROUND,
                layer_index,
                &layer.overlays,
            );
        }
        for (layer_index, layer) in visuals.foreground_visual_layers.iter().enumerate() {
            Self::push_entries(
                &mut entries,
                SONG_LUA_FG_OWNER_FOREGROUND,
                layer_index,
                &layer.overlays,
            );
        }
        entries.sort_by(|left, right| {
            left.0
                .cmp(right.0)
                .then_with(|| left.1.source.cmp(&right.1.source))
                .then_with(|| left.1.layer_index.cmp(&right.1.layer_index))
                .then_with(|| left.1.overlay_index.cmp(&right.1.overlay_index))
        });

        let mut paths = Vec::new();
        let mut owners = Vec::with_capacity(entries.len());
        let mut cursor = 0;
        while cursor < entries.len() {
            let owner_start = owners.len();
            let path = entries[cursor].0.to_path_buf();
            while cursor < entries.len() && entries[cursor].0 == path.as_path() {
                owners.push(entries[cursor].1);
                cursor += 1;
            }
            paths.push(SongLuaForegroundOwnerPath {
                path,
                owner_start,
                owner_end: owners.len(),
            });
        }
        Self {
            paths: paths.into_boxed_slice(),
            owners: owners.into_boxed_slice(),
            active_start: 0,
            active_end: 0,
        }
    }

    fn push_entries<'a, S: NoteskinSlot + Clone>(
        out: &mut Vec<(&'a Path, SongLuaForegroundOwnerRef)>,
        source: u8,
        layer_index: usize,
        overlays: &'a [SongLuaOverlayActor<S>],
    ) {
        out.extend(
            overlays
                .iter()
                .enumerate()
                .filter_map(|(overlay_index, overlay)| match &overlay.kind {
                    SongLuaOverlayKind::Sprite { texture_path, .. } => Some((
                        texture_path.as_path(),
                        SongLuaForegroundOwnerRef {
                            source,
                            layer_index,
                            overlay_index,
                        },
                    )),
                    _ => None,
                }),
        );
    }

    fn select(&mut self, path: Option<&Path>) {
        let Some(path) = path else {
            self.active_start = 0;
            self.active_end = 0;
            return;
        };
        let Ok(index) = self
            .paths
            .binary_search_by(|candidate| candidate.path.as_path().cmp(path))
        else {
            self.active_start = 0;
            self.active_end = 0;
            return;
        };
        self.active_start = self.paths[index].owner_start;
        self.active_end = self.paths[index].owner_end;
    }

    fn owns<S: NoteskinSlot + Clone>(
        &self,
        now: f32,
        visuals: &SongLuaRuntimeVisuals<
            SongLuaOverlayActor<S>,
            SongLuaCapturedActor,
            SongLuaRuntimeOverlayStateDelta,
        >,
        overlay_states: &[SongLuaOverlayState],
        background_layer_states: &[Vec<SongLuaOverlayState>],
        foreground_layer_states: &[Vec<SongLuaOverlayState>],
    ) -> bool {
        self.owners[self.active_start..self.active_end]
            .iter()
            .any(|owner| {
                let state = match owner.source {
                    SONG_LUA_FG_OWNER_ROOT => overlay_states.get(owner.overlay_index),
                    SONG_LUA_FG_OWNER_BACKGROUND => visuals
                        .background_visual_layers
                        .get(owner.layer_index)
                        .filter(|layer| !(now < layer.start_second))
                        .and_then(|_| background_layer_states.get(owner.layer_index))
                        .and_then(|states| states.get(owner.overlay_index)),
                    SONG_LUA_FG_OWNER_FOREGROUND => visuals
                        .foreground_visual_layers
                        .get(owner.layer_index)
                        .filter(|layer| !(now < layer.start_second))
                        .and_then(|_| foreground_layer_states.get(owner.layer_index))
                        .and_then(|states| states.get(owner.overlay_index)),
                    _ => None,
                };
                state.is_some_and(|state| state.draw_visible() && state.diffuse[3] > f32::EPSILON)
            })
    }
}
#[inline(always)]
fn song_lua_overlay_space_width<
    P: deadsync_gameplay::GameplayProfileData,
    S: NoteskinSlot + Clone,
>(
    state: &GameplayCoreState<P, S>,
) -> f32 {
    state.song_lua_visuals().screen_width.max(1.0)
}

#[inline(always)]
fn song_lua_overlay_space_height<
    P: deadsync_gameplay::GameplayProfileData,
    S: NoteskinSlot + Clone,
>(
    state: &GameplayCoreState<P, S>,
) -> f32 {
    state.song_lua_visuals().screen_height.max(1.0)
}

#[inline(always)]
fn song_lua_valid_sprite_state_index(state: SongLuaOverlayState) -> Option<u32> {
    crate::song_lua_valid_sprite_state_index(state.sprite_state_index)
}

#[inline(always)]
fn song_lua_sprite_sheet_index(
    state: SongLuaOverlayState,
    sheet: (u32, u32),
    states: &[crate::SongLuaSpriteState],
    total_elapsed: f32,
) -> Option<u32> {
    let start = song_lua_valid_sprite_state_index(state).unwrap_or(0);
    let (cols, rows) = sheet;
    let total = cols.saturating_mul(rows).max(1);
    let logical_state = if state.sprite_animate && !states.is_empty() {
        crate::sprite_custom_animation_state_from(
            states,
            start,
            total_elapsed,
            state.sprite_playback_rate,
            state.sprite_loop,
        )
    } else if state.sprite_animate && state.sprite_state_delay > 0.0 && total > 1 {
        crate::sprite_animation_state_from(
            start,
            total_elapsed,
            state.sprite_playback_rate,
            state.sprite_state_delay,
            total,
            state.sprite_loop,
        )
    } else {
        start
    };
    (total > 1
        || !states.is_empty()
        || state.sprite_animate
        || song_lua_valid_sprite_state_index(state).is_some())
    .then_some(
        states
            .get(logical_state as usize)
            .map_or(logical_state, |sprite_state| sprite_state.frame),
    )
}

fn song_lua_overlay_sprite_size(
    state: SongLuaOverlayState,
    binding: deadlib_assets::BoundTexture,
) -> Option<[f32; 2]> {
    if let Some(size) = state.size {
        return Some(size);
    }
    let tex = binding.dimensions?;
    let (width, height) = crate::sprite_image_frame_size(
        Some((tex.w as f32, tex.h as f32)),
        state.sprite_animate,
        state.sprite_state_index,
        Some(binding.sheet),
    )?;
    Some([width, height])
}

fn song_lua_overlay_sprite_offscreen(
    state: SongLuaOverlayState,
    size: [f32; 2],
    overlay_space_width: f32,
    overlay_space_height: f32,
) -> bool {
    const EDGE_SLOP: f32 = 12.0;

    if state.rot_x_deg.abs() > f32::EPSILON
        || state.rot_y_deg.abs() > f32::EPSILON
        || state.rot_z_deg.abs() > f32::EPSILON
        || state.skew_x.abs() > f32::EPSILON
        || state.skew_y.abs() > f32::EPSILON
        || state.vibrate
        || !matches!(state.effect_mode, deadlib_present::anim::EffectMode::None)
    {
        return false;
    }
    let [scale_x, scale_y] = song_lua_overlay_axis_scale(state).map(f32::abs);
    let width = size[0] * scale_x;
    let height = size[1] * scale_y;
    let left = width.mul_add(-state.halign, state.x);
    let top = height.mul_add(-state.valign, state.y);
    left >= overlay_space_width + EDGE_SLOP
        || left + width <= -EDGE_SLOP
        || top >= overlay_space_height + EDGE_SLOP
        || top + height <= -EDGE_SLOP
}

fn song_lua_overlay_uv_rect(
    state: SongLuaOverlayState,
    sheet_dims: Option<(u32, u32)>,
    states: &[crate::SongLuaSpriteState],
    total_elapsed: f32,
) -> Option<[f32; 4]> {
    let state_index = sheet_dims
        .and_then(|sheet| song_lua_sprite_sheet_index(state, sheet, states, total_elapsed));
    crate::sprite_texture_rect_with_offset(
        state.custom_texture_rect,
        state_index,
        sheet_dims,
        state.texcoord_offset,
    )
}

#[inline(always)]
fn song_lua_overlay_axis_scale(state: SongLuaOverlayState) -> [f32; 2] {
    crate::overlay_state_axis_scale(state)
}

#[inline(always)]
fn song_lua_overlay_z_scale(state: SongLuaOverlayState) -> f32 {
    crate::overlay_state_z_scale(state)
}

#[inline(always)]
fn song_lua_overlay_parent_uses_center_origin<S: NoteskinSlot + Clone>(
    parent_kind: &SongLuaOverlayKind<S>,
    parent_axis: f32,
    overlay_space_axis: f32,
) -> bool {
    matches!(
        parent_kind,
        SongLuaOverlayKind::Actor
            | SongLuaOverlayKind::ActorFrame
            | SongLuaOverlayKind::WrapperState
            | SongLuaOverlayKind::ActorFrameTexture { .. }
    ) && 0.5f32.mul_add(-overlay_space_axis, parent_axis).abs() <= 0.01
}

#[inline(always)]
fn song_lua_overlay_linear_2d(state: SongLuaOverlayState) -> Matrix2 {
    let [scale_x, scale_y] = song_lua_overlay_axis_scale(state);
    let [ancestor, local] = state.scale_factors.unwrap_or([
        [1.0; 3],
        [scale_x, scale_y, song_lua_overlay_z_scale(state)],
    ]);
    let skew_x = Matrix2::from_cols_array(&[1.0, 0.0, state.skew_x, 1.0]);
    let skew_y = Matrix2::from_cols_array(&[1.0, state.skew_y, 0.0, 1.0]);
    Matrix2::from_diagonal(Vector2::new(ancestor[0], ancestor[1]))
        * Matrix2::from_angle(state.rot_z_deg.to_radians())
        * Matrix2::from_diagonal(Vector2::new(local[0], local[1]))
        * skew_x
        * skew_y
}

fn song_lua_overlay_set_linear_2d(
    state: &mut SongLuaOverlayState,
    linear: Matrix2,
    z_scale: f32,
) -> bool {
    if !linear.is_finite() || !z_scale.is_finite() {
        return false;
    }
    let scale_x = linear.x_axis.length();
    let (rotation, scale_y, skew_x) = if scale_x > 0.0 {
        let rotation = linear.x_axis.y.atan2(linear.x_axis.x);
        let local = Matrix2::from_angle(-rotation) * linear;
        if local.x_axis.y.abs() > 0.001 {
            return false;
        }
        (rotation, local.y_axis.y, local.y_axis.x / scale_x)
    } else {
        // A collapsed X axis still has a transformed Y column. Align that
        // column with local Y instead of falling back to reordered scales.
        let scale_y = linear.y_axis.length();
        let rotation = if scale_y > 0.0 {
            (-linear.y_axis.x).atan2(linear.y_axis.y)
        } else {
            0.0
        };
        (rotation, scale_y, 0.0)
    };

    state.rot_z_deg = rotation.to_degrees();
    // Actor::BeginDraw applies scale before skew. The X shear coefficient
    // therefore divides the off-diagonal entry by X scale, not Y scale.
    state.skew_x = skew_x;
    state.skew_y = 0.0;
    state.basezoom = 1.0;
    state.zoom = 1.0;
    state.basezoom_x = scale_x;
    state.zoom_x = 1.0;
    state.basezoom_y = scale_y;
    state.zoom_y = 1.0;
    state.basezoom_z = z_scale;
    state.zoom_z = 1.0;
    true
}

/// Compose a child's draw state with its parent, including screen layers.
pub fn song_lua_overlay_compose_state<S: NoteskinSlot + Clone>(
    parent_kind: &SongLuaOverlayKind<S>,
    parent: SongLuaOverlayState,
    mut child: SongLuaOverlayState,
    overlay_space_width: f32,
    overlay_space_height: f32,
    clock: [f32; 2],
) -> SongLuaOverlayState {
    let parent = song_lua_pulse_parent(song_lua_pre_draw_state(parent, clock), clock);
    child = song_lua_pre_draw_state(child, clock);
    // Actor::BeginDraw post-multiplies quaternions about the world origin.
    // They therefore collect outside the normal parent/child transforms.
    if parent.quaternion != crate::actor_quaternion::IDENTITY {
        child.quaternion = crate::actor_quaternion::multiply(child.quaternion, parent.quaternion);
    }
    let local_rotation = [child.rot_x_deg, child.rot_y_deg, child.rot_z_deg];
    let [parent_scale_x, parent_scale_y] = song_lua_overlay_axis_scale(parent);
    let local_z = child.z;
    child.z = parent.z + child.z * song_lua_overlay_z_scale(parent);
    let epsilon = 0.01;
    let raw_local_x = if matches!(
        parent_kind,
        SongLuaOverlayKind::Actor
            | SongLuaOverlayKind::ActorFrame
            | SongLuaOverlayKind::WrapperState
            | SongLuaOverlayKind::ActorFrameTexture { .. }
    ) && song_lua_overlay_parent_uses_center_origin(
        parent_kind,
        parent.x,
        overlay_space_width,
    ) && 0.5f32.mul_add(-overlay_space_width, child.x).abs() <= epsilon
    {
        0.0
    } else {
        child.x
    };
    let raw_local_y = if matches!(
        parent_kind,
        SongLuaOverlayKind::Actor
            | SongLuaOverlayKind::ActorFrame
            | SongLuaOverlayKind::WrapperState
            | SongLuaOverlayKind::ActorFrameTexture { .. }
    ) && song_lua_overlay_parent_uses_center_origin(
        parent_kind,
        parent.y,
        overlay_space_height,
    ) && 0.5f32.mul_add(-overlay_space_height, child.y).abs() <= epsilon
    {
        0.0
    } else {
        child.y
    };
    let local_x = raw_local_x * parent_scale_x;
    let local_y = raw_local_y * parent_scale_y;
    let parent_prefix_scale = [parent.rot_x_deg, parent.rot_y_deg, parent.rot_z_deg]
        .iter()
        .all(|value| value.to_radians().abs() <= f32::EPSILON)
        || parent
            .scale_factors
            .is_some_and(|[_, local]| local[0] == local[1] && local[1] == local[2]);
    // Compare radians, the unit used by rotation-matrix coefficients. Legacy
    // Lua degree/radian cancellation can leave a few millionths of a degree;
    // that roundoff must not change parent-scale/child-rotation composition.
    let affine_2d = parent.rot_x_deg.to_radians().abs() <= f32::EPSILON
        && parent.rot_y_deg.to_radians().abs() <= f32::EPSILON
        && child.rot_x_deg.to_radians().abs() <= f32::EPSILON
        && child.rot_y_deg.to_radians().abs() <= f32::EPSILON
        && (parent.skew_x.abs() > f32::EPSILON
            || parent.skew_y.abs() > f32::EPSILON
            || ((parent_scale_x - parent_scale_y).abs() > f32::EPSILON
                && child.rot_z_deg.abs() > f32::EPSILON
                && !parent_prefix_scale));
    // A child's own shear does not require decomposition when the parent can
    // retain the native rotation/scale order. Decomposing it moves some shear
    // into rotation and scale, which also transforms the alignment translation
    // even though Actor::BeginDraw applies that translation before skew.
    child.scale_factors = if !affine_2d
        && [
            parent.rot_x_deg,
            parent.rot_y_deg,
            parent.rot_z_deg,
            parent.skew_x,
            parent.skew_y,
        ]
        .iter()
        .all(|value| value.abs() <= f32::EPSILON)
    {
        let [sx, sy] = song_lua_overlay_axis_scale(child);
        let [ancestor, local] = child
            .scale_factors
            .unwrap_or([[1.0; 3], [sx, sy, song_lua_overlay_z_scale(child)]]);
        let parent_scale = [
            parent_scale_x,
            parent_scale_y,
            song_lua_overlay_z_scale(parent),
        ];
        Some([
            std::array::from_fn(|axis| parent_scale[axis] * ancestor[axis]),
            local,
        ])
    } else if !affine_2d
        && parent.skew_x.abs() <= f32::EPSILON
        && parent.skew_y.abs() <= f32::EPSILON
        && (local_rotation
            .iter()
            .all(|value| value.to_radians().abs() <= f32::EPSILON)
            || parent
                .scale_factors
                .is_some_and(|[_, local]| local[0] == local[1] && local[1] == local[2]))
    {
        // A uniform parent-local scale commutes with a rotated child. Keep
        // an ancestor's nonuniform scale before the combined rotations.
        parent.scale_factors.map(|[ancestor, parent_local]| {
            let [sx, sy] = song_lua_overlay_axis_scale(child);
            let local = [sx, sy, song_lua_overlay_z_scale(child)];
            [
                ancestor,
                std::array::from_fn(|axis| parent_local[axis] * local[axis]),
            ]
        })
    } else {
        None
    };
    if affine_2d {
        let parent_linear = song_lua_overlay_linear_2d(parent);
        let child_linear = song_lua_overlay_linear_2d(child);
        let position = Vector2::new(parent.x, parent.y)
            + parent_linear * Vector2::new(raw_local_x, raw_local_y);
        let z_scale = song_lua_overlay_z_scale(parent) * song_lua_overlay_z_scale(child);
        if song_lua_overlay_set_linear_2d(&mut child, parent_linear * child_linear, z_scale) {
            child.x = position.x;
            child.y = position.y;
        } else {
            let (sin_z, cos_z) = parent.rot_z_deg.to_radians().sin_cos();
            child.x = parent.x + local_x * cos_z - local_y * sin_z;
            child.y = parent.y + local_x * sin_z + local_y * cos_z;
            child.basezoom *= parent.basezoom * parent.zoom;
            child.basezoom_x *= parent.basezoom_x * parent.zoom_x;
            child.basezoom_y *= parent.basezoom_y * parent.zoom_y;
            child.basezoom_z *= parent.basezoom_z * parent.zoom_z;
            child.rot_z_deg += parent.rot_z_deg;
            child.skew_x += parent.skew_x;
            child.skew_y += parent.skew_y;
        }
    } else {
        let (sin_z, cos_z) = parent.rot_z_deg.to_radians().sin_cos();
        child.x = parent.x + local_x * cos_z - local_y * sin_z;
        child.y = parent.y + local_x * sin_z + local_y * cos_z;
        child.basezoom *= parent.basezoom * parent.zoom;
        child.basezoom_x *= parent.basezoom_x * parent.zoom_x;
        child.basezoom_y *= parent.basezoom_y * parent.zoom_y;
        child.basezoom_z *= parent.basezoom_z * parent.zoom_z;
        child.rot_z_deg += parent.rot_z_deg;
        child.skew_x += parent.skew_x;
        child.skew_y += parent.skew_y;
    }
    // Child translations follow the complete parent transform. In particular,
    // a road frame rotated around X maps its children's Y offsets into Z.
    if parent.rot_x_deg.to_radians().abs() > f32::EPSILON
        || parent.rot_y_deg.to_radians().abs() > f32::EPSILON
        || parent.scale_factors.is_some()
    {
        let matrix = song_lua_overlay_sprite_matrix(
            SongLuaOverlayState {
                quaternion: crate::actor_quaternion::IDENTITY,
                ..parent
            },
            [0.0; 2],
            [parent.x, parent.y, parent.z],
            [parent.rot_x_deg, parent.rot_y_deg, parent.rot_z_deg],
            [1.0; 3],
        );
        let position = matrix * Vector4::new(raw_local_x, raw_local_y, local_z, 1.0);
        [child.x, child.y, child.z] = position.truncate().to_array();
    }
    for i in 0..4 {
        child.diffuse[i] *= parent.diffuse[i];
        if parent.glow[3] > 0.0 {
            // Actor::PreDraw combines inherited glow independently of diffuse.
            child.glow[i] += parent.glow[i] - parent.glow[i] * child.glow[i];
        }
    }
    child.texcoord_offset = match (parent.texcoord_offset, child.texcoord_offset) {
        (Some(parent), Some(child)) => Some([parent[0] + child[0], parent[1] + child[1]]),
        (Some(parent), None) => Some(parent),
        (None, child) => child,
    };
    child.visible = parent.visible && child.visible;
    child.hibernating |= parent.hibernating;
    child.mask_source |= parent.mask_source;
    child.mask_dest |= parent.mask_dest;
    child.rot_x_deg += parent.rot_x_deg;
    child.rot_y_deg += parent.rot_y_deg;
    if let Some(rotation) = song_lua_join_rotation(
        [parent.rot_x_deg, parent.rot_y_deg, parent.rot_z_deg],
        local_rotation,
    ) {
        [child.rot_x_deg, child.rot_y_deg, child.rot_z_deg] = rotation;
    }
    if let Some([left, top, right, bottom]) = child.stretch_rect
        && parent.rot_x_deg.abs() <= f32::EPSILON
        && parent.rot_y_deg.abs() <= f32::EPSILON
        && parent.rot_z_deg.abs() <= f32::EPSILON
        && parent.skew_x.abs() <= f32::EPSILON
        && parent.skew_y.abs() <= f32::EPSILON
    {
        child.stretch_rect = Some([
            left.mul_add(parent_scale_x, parent.x),
            top.mul_add(parent_scale_y, parent.y),
            right.mul_add(parent_scale_x, parent.x),
            bottom.mul_add(parent_scale_y, parent.y),
        ]);
    }
    child
}

fn song_lua_join_rotation(parent: [f32; 3], child: [f32; 3]) -> Option<[f32; 3]> {
    let rotated = |angles: [f32; 3]| angles.iter().any(|v| v.to_radians().abs() > f32::EPSILON);
    if !rotated(parent)
        || !rotated(child)
        || [parent[0], parent[1], child[0], child[1]]
            .iter()
            .all(|v| v.to_radians().abs() <= f32::EPSILON)
    {
        return None;
    }
    let matrix = song_lua_overlay_local_transform(parent, 0.0, 0.0)
        * song_lua_overlay_local_transform(child, 0.0, 0.0);
    // Invert RageMatrixRotationXYZ's coefficients, including its gimbal pose.
    let cos_y = matrix.x_axis.x.hypot(matrix.y_axis.x);
    let y = (-matrix.z_axis.x).atan2(cos_y);
    let (x, z) = if cos_y > 0.000_001 {
        (
            matrix.z_axis.y.atan2(matrix.z_axis.z),
            (-matrix.y_axis.x).atan2(matrix.x_axis.x),
        )
    } else {
        ((-matrix.y_axis.z).atan2(matrix.y_axis.y), 0.0)
    };
    Some([x, y, z].map(f32::to_degrees))
}
fn song_lua_overlay_local_states_into<S: NoteskinSlot + Clone>(
    now: f32,
    overlays: &[SongLuaOverlayActor<S>],
    overlay_events: &[Vec<SongLuaOverlayMessageRuntime>],
    overlay_eases: &[SongLuaOverlayEaseWindowRuntime],
    overlay_ease_ranges: &[std::ops::Range<usize>],
    dynamic_indices: &[usize],
    update_actor_index: SongLuaOverlayIndex,
    update_ranges: &[std::ops::Range<usize>],
    visible_update_indices: &[usize],
    update_cursors: &mut [usize],
    message_caches: &mut Vec<SongLuaMessageStateCache>,
    out: &mut Vec<SongLuaOverlayState>,
) -> bool {
    let overlay_updates = song_lua_overlay_runtime_updates_at(overlays, update_actor_index);
    let update_snap =
        song_lua_overlay_update_snap(now, overlay_updates, visible_update_indices, update_cursors);
    let mut changed = false;
    if out.len() != overlays.len() {
        out.clear();
        out.extend(overlays.iter().map(|overlay| overlay.initial_state));
        changed = true;
    }
    message_caches.resize(overlays.len(), SongLuaMessageStateCache::default());
    for &idx in dynamic_indices {
        let Some(overlay) = overlays.get(idx) else {
            continue;
        };
        let next = song_lua_overlay_render_state_from(
            now,
            idx,
            overlay,
            overlay_events,
            overlay_eases,
            overlay_ease_ranges,
            overlay_updates,
            update_ranges.get(idx).cloned().unwrap_or(0..0),
            update_cursors,
            update_snap,
            &mut message_caches[idx],
        );
        changed |= out[idx] != next;
        out[idx] = next;
    }
    changed
}

fn song_lua_overlay_runtime_updates_at<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    update_actor_index: SongLuaOverlayIndex,
) -> &[crate::SongLuaOverlayRuntimeUpdateTrack] {
    update_actor_index
        .get()
        .and_then(|index| overlays.get(index))
        .and_then(|overlay| match &overlay.kind {
            SongLuaOverlayKind::UpdateTracks { tracks, .. } => Some(tracks.as_slice()),
            _ => None,
        })
        .unwrap_or(&[])
}

#[cfg(test)]
fn song_lua_overlay_states_from_local<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    local_states: &[SongLuaOverlayState],
    screen_width: f32,
    screen_height: f32,
) -> Vec<SongLuaOverlayState> {
    let mut out = Vec::with_capacity(overlays.len());
    song_lua_overlay_states_from_local_all_into(
        overlays,
        local_states,
        screen_width,
        screen_height,
        &mut out,
        [0.0; 2],
    );
    out
}

/// Live AddWrapperState appends a parent after its existing child. Visit each
/// parent before its child without reindexing any visual resource.
/// The ordinary prepared layout keeps its allocation-free numeric order.
fn song_lua_parent_order<S>(overlays: &[SongLuaOverlayActor<S>]) -> Option<Vec<usize>> {
    if overlays.iter().enumerate().all(|(index, actor)|
        actor.parent_index.is_none_or(|parent| parent < index))
    {
        return None;
    }
    let mut visited = vec![0u8; overlays.len()];
    let mut order = Vec::with_capacity(overlays.len());
    let mut chain = Vec::new();
    for start in 0..overlays.len() {
        let mut next = Some(start);
        while let Some(index) = next {
            assert!(index < overlays.len(), "owned overlay parent is out of bounds");
            if visited[index] == 2 { break; }
            assert_eq!(visited[index], 0, "cycle in owned overlay parents");
            visited[index] = 1;
            chain.push(index);
            next = overlays[index].parent_index;
        }
        while let Some(index) = chain.pop() {
            visited[index] = 2;
            order.push(index);
        }
    }
    Some(order)
}

fn song_lua_overlay_states_from_local_all_into<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    local_states: &[SongLuaOverlayState],
    screen_width: f32,
    screen_height: f32,
    out: &mut Vec<SongLuaOverlayState>,
    clock: [f32; 2],
) {
    out.clear();
    out.resize(overlays.len(), SongLuaOverlayState::default());
    let order = song_lua_parent_order(overlays);
    for ordinal in 0..overlays.len() {
        let idx = order.as_ref().map_or(ordinal, |order| order[ordinal]);
        let overlay = &overlays[idx];
        let local = song_lua_draw_input_state(
            local_states.get(idx).copied().unwrap_or_default(),
            idx,
            clock,
        );
        let composed = overlay
            .parent_index
            .and_then(|parent_index| {
                out.get(parent_index)
                    .copied()
                    .zip(overlays.get(parent_index))
            })
            .map(|(parent, parent_overlay)| {
                song_lua_overlay_compose_state(
                    &parent_overlay.kind,
                    parent,
                    local,
                    screen_width,
                    screen_height,
                    clock,
                )
            })
            .unwrap_or_else(|| song_lua_pre_draw_state(local, clock));
        out[idx] = composed;
    }
}

fn song_lua_overlay_states_from_local_into<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    local_states: &[SongLuaOverlayState],
    dynamic_indices: &[usize],
    screen_width: f32,
    screen_height: f32,
    out: &mut Vec<SongLuaOverlayState>,
    clock: [f32; 2],
) {
    if out.len() != overlays.len() {
        song_lua_overlay_states_from_local_all_into(
            overlays,
            local_states,
            screen_width,
            screen_height,
            out,
            clock,
        );
        return;
    }
    for &idx in dynamic_indices {
        let Some(overlay) = overlays.get(idx) else {
            continue;
        };
        let local = song_lua_draw_input_state(
            local_states.get(idx).copied().unwrap_or_default(),
            idx,
            clock,
        );
        out[idx] = overlay
            .parent_index
            .and_then(|parent_index| {
                out.get(parent_index)
                    .copied()
                    .zip(overlays.get(parent_index))
            })
            .map(|(parent, parent_overlay)| {
                song_lua_overlay_compose_state(
                    &parent_overlay.kind,
                    parent,
                    local,
                    screen_width,
                    screen_height,
                    clock,
                )
            })
            .unwrap_or_else(|| song_lua_pre_draw_state(local, clock));
    }
}

fn song_lua_overlay_initial_state_sets<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    screen_width: f32,
    screen_height: f32,
) -> (Vec<SongLuaOverlayState>, Vec<SongLuaOverlayState>) {
    let local = overlays
        .iter()
        .map(|overlay| overlay.initial_state)
        .collect::<Vec<_>>();
    let mut composed = Vec::with_capacity(overlays.len());
    song_lua_overlay_states_from_local_all_into(
        overlays,
        &local,
        screen_width,
        screen_height,
        &mut composed,
        [0.0; 2],
    );
    (local, composed)
}

fn song_lua_overlay_state_sets_from_into<S: NoteskinSlot + Clone>(
    now: f32,
    overlays: &[SongLuaOverlayActor<S>],
    overlay_events: &[Vec<SongLuaOverlayMessageRuntime>],
    overlay_eases: &[SongLuaOverlayEaseWindowRuntime],
    overlay_ease_ranges: &[std::ops::Range<usize>],
    screen_width: f32,
    screen_height: f32,
    order_cache: &mut SongLuaOverlayOrderCache,
    message_caches: &mut Vec<SongLuaMessageStateCache>,
    local_out: &mut Vec<SongLuaOverlayState>,
    overlay_out: &mut Vec<SongLuaOverlayState>,
    clock: [f32; 2],
) {
    if overlays.is_empty() {
        message_caches.clear();
        local_out.clear();
        overlay_out.clear();
        return;
    }
    song_lua_overlay_state_sets_active_into(
        now,
        overlays,
        overlay_events,
        overlay_eases,
        overlay_ease_ranges,
        screen_width,
        screen_height,
        order_cache,
        message_caches,
        local_out,
        overlay_out,
        clock,
    );
}

fn song_lua_overlay_state_sets_active_into<S: NoteskinSlot + Clone>(
    now: f32,
    overlays: &[SongLuaOverlayActor<S>],
    overlay_events: &[Vec<SongLuaOverlayMessageRuntime>],
    overlay_eases: &[SongLuaOverlayEaseWindowRuntime],
    overlay_ease_ranges: &[std::ops::Range<usize>],
    screen_width: f32,
    screen_height: f32,
    order_cache: &mut SongLuaOverlayOrderCache,
    message_caches: &mut Vec<SongLuaMessageStateCache>,
    local_out: &mut Vec<SongLuaOverlayState>,
    overlay_out: &mut Vec<SongLuaOverlayState>,
    clock: [f32; 2],
) {
    let SongLuaOverlayOrderCache {
        dynamic_local_indices,
        dynamic_composed_indices,
        effect_composed_indices,
        update_actor_index,
        update_ranges,
        visible_update_indices,
        update_cursors,
        ..
    } = order_cache;
    let local_changed = song_lua_overlay_local_states_into(
        now,
        overlays,
        overlay_events,
        overlay_eases,
        overlay_ease_ranges,
        dynamic_local_indices,
        *update_actor_index,
        update_ranges,
        visible_update_indices,
        update_cursors,
        message_caches,
        local_out,
    );
    if local_changed || overlay_out.len() != overlays.len() {
        song_lua_overlay_states_from_local_into(
            overlays,
            local_out,
            dynamic_composed_indices,
            screen_width,
            screen_height,
            overlay_out,
            clock,
        );
    } else if !effect_composed_indices.is_empty() {
        song_lua_overlay_states_from_local_into(
            overlays,
            local_out,
            effect_composed_indices,
            screen_width,
            screen_height,
            overlay_out,
            clock,
        );
    }
}
fn apply_song_lua_taps<S: NoteskinSlot + Clone>(
    feedback: &deadsync_gameplay::GameplayVisualFeedbackState,
    cols_per_player: usize,
    now: f32,
    effect_time: f32,
    overlays: &[SongLuaOverlayActor<S>],
    order: &mut SongLuaOverlayOrderCache,
    local: &mut [SongLuaOverlayState],
    composed: &mut Vec<SongLuaOverlayState>,
    screen: [f32; 2],
    clock: [f32; 2],
) {
    let mut changed = false;
    for tap in &mut order.tap_commands {
        if tap.player >= MAX_PLAYERS || tap.column >= cols_per_player {
            continue;
        }
        let Some(judgment) = feedback.last_tap_judgment(tap.player * cols_per_player + tap.column)
        else {
            continue;
        };
        if judgment.grade != tap.grade {
            continue;
        }
        let elapsed = now - judgment.at_screen_s;
        if elapsed < 0.0 {
            continue;
        }
        let current = local[tap.overlay];
        let mut next = crate::overlay_state_after_blocks(
            current,
            &overlays[tap.overlay].message_commands[tap.command].blocks,
            elapsed,
        );
        if next.effect_mode == deadlib_present::anim::EffectMode::GlowShift
            && next.effect_clock == deadlib_present::anim::EffectClock::Time
        {
            // Actor::ResetEffectTimeIfDifferent leaves repeated glowshift
            // commands running, including while the explosion is invisible.
            let start = tap.glow_started_at.get_or_insert(judgment.at_screen_s);
            next.effect_offset += now - *start - effect_time;
        }
        changed |= next != current;
        local[tap.overlay] = next;
    }
    if changed {
        song_lua_overlay_states_from_local_into(
            overlays,
            local,
            &order.dynamic_composed_indices,
            screen[0],
            screen[1],
            composed,
            clock,
        );
    }
}

fn song_lua_proxy_target_has_source(
    target: &SongLuaProxyTarget,
    proxy_sources: &[SongLuaPlayerProxySources<'_>; 2],
) -> bool {
    match target {
        SongLuaProxyTarget::Player { player_index } => {
            proxy_sources.get(*player_index).is_some_and(|sources| {
                sources.direct_player || sources.player.is_some_and(|source| !source.is_empty())
            })
        }
        SongLuaProxyTarget::NoteField { player_index } => {
            proxy_sources.get(*player_index).is_some_and(|sources| {
                sources.direct_note_field
                    || sources.note_field.is_some_and(|source| !source.is_empty())
            })
        }
        SongLuaProxyTarget::Judgment { player_index } => proxy_sources
            .get(*player_index)
            .and_then(|sources| sources.judgment)
            .is_some_and(|source| !source.is_empty()),
        SongLuaProxyTarget::Combo { player_index } => {
            proxy_sources.get(*player_index).is_some_and(|sources| {
                sources.direct_combo || sources.combo.is_some_and(|source| !source.is_empty())
            })
        }
        SongLuaProxyTarget::Underlay { .. }
        | SongLuaProxyTarget::Overlay { .. }
        | SongLuaProxyTarget::Actor { .. }
        | SongLuaProxyTarget::Score { .. } => false,
    }
}
fn song_lua_proxy_active_players_indexed<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    proxy_sources: &[SongLuaPlayerProxySources<'_>; 2],
    index: &SongLuaProxyRequestIndex,
) -> [bool; 2] {
    let mut out = [false; 2];
    for &overlay_index in &index.proxy_indices {
        let SongLuaOverlayKind::ActorProxy { target } = &overlays[overlay_index].kind else {
            continue;
        };
        let player_index = match target {
            SongLuaProxyTarget::Player { player_index }
            | SongLuaProxyTarget::NoteField { player_index } => *player_index,
            _ => continue,
        };
        if player_index >= out.len() || !song_lua_proxy_target_has_source(target, proxy_sources) {
            continue;
        }
        if overlay_states
            .get(overlay_index)
            .copied()
            .is_some_and(song_lua_overlay_is_visible)
        {
            out[player_index] = true;
        }
    }
    out
}

fn song_lua_replacement_active_players_indexed<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    proxy_sources: &[SongLuaPlayerProxySources<'_>; 2],
    index: &SongLuaProxyRequestIndex,
    visit_scratch: &mut SongLuaCaptureVisitScratch,
) -> [bool; 2] {
    if index.proxy_indices.is_empty() {
        return [false; 2];
    }
    song_lua_replacement_active_players_indexed_active(
        overlays,
        overlay_states,
        proxy_sources,
        index,
        visit_scratch,
    )
}

fn song_lua_replacement_active_players_indexed_active<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    proxy_sources: &[SongLuaPlayerProxySources<'_>; 2],
    index: &SongLuaProxyRequestIndex,
    visit_scratch: &mut SongLuaCaptureVisitScratch,
) -> [bool; 2] {
    let mut out =
        song_lua_proxy_active_players_indexed(overlays, overlay_states, proxy_sources, index);
    let mut requests = SongLuaScreenProxyRequests::default();
    visit_scratch.begin(overlays.len());
    for &overlay_index in &index.topology.aft_sprite_indices {
        let Some(capture_index) = index.topology.aft_sprite_targets[overlay_index].get() else {
            continue;
        };
        let Some(overlay_state) = overlay_states.get(overlay_index) else {
            continue;
        };
        if !song_lua_overlay_is_visible(*overlay_state) {
            continue;
        }
        song_lua_collect_capture_requests_indexed(
            overlays,
            overlay_states,
            capture_index,
            index,
            &mut requests,
            visit_scratch,
        );
    }
    for (player_index, active) in out.iter_mut().enumerate() {
        let player_requests = requests.players[player_index];
        *active |= (player_requests.player
            && (proxy_sources[player_index].direct_player
                || proxy_sources[player_index].player.is_some()))
            || (player_requests.note_field && proxy_sources[player_index].note_field.is_some());
    }
    out
}

fn song_lua_overlay_aft_ancestor<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    mut index: usize,
) -> Option<usize> {
    while let Some(parent_index) = overlays.get(index).and_then(|overlay| overlay.parent_index) {
        match overlays.get(parent_index).map(|overlay| &overlay.kind) {
            Some(SongLuaOverlayKind::ActorFrameTexture { .. }) => return Some(parent_index),
            Some(_) => index = parent_index,
            None => return None,
        }
    }
    None
}

fn song_lua_overlay_camera_ancestor<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    mut index: Option<usize>,
) -> Option<usize> {
    while let Some(current) = index {
        let overlay = overlays.get(current)?;
        if matches!(overlay.kind, SongLuaOverlayKind::ActorFrameTexture { .. }) {
            return None;
        }
        if matches!(
            overlay.kind,
            SongLuaOverlayKind::ActorFrame
                | SongLuaOverlayKind::WrapperState
                | SongLuaOverlayKind::ActorFrameTexture { .. }
        ) {
            return Some(current);
        }
        index = overlay.parent_index;
    }
    None
}

fn song_lua_aft_size<S: NoteskinSlot + Clone>(
    overlay: &SongLuaOverlayActor<S>,
    state: SongLuaOverlayState,
) -> Option<[f32; 2]> {
    let SongLuaOverlayKind::ActorFrameTexture { capture_size, .. } = overlay.kind else {
        return None;
    };
    state.aft_created.then_some(capture_size).flatten()
}

fn song_lua_overlay_capture_index_by_name<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    capture_name: &str,
) -> Option<usize> {
    overlays.iter().position(|overlay| {
        matches!(&overlay.kind, SongLuaOverlayKind::ActorFrameTexture { capture_name: name, capture_size: Some(_), .. }
            if name == capture_name)
    })
}

#[derive(Clone, Copy)]
struct SongLuaProxySource<'a> {
    segments: &'a [Arc<[Actor]>],
    offset: [f32; 2],
    pool_class: usize,
    source_view_proj: Option<Matrix4>,
    model: Option<Matrix4>,
}

impl<'a> SongLuaProxySource<'a> {
    #[inline(always)]
    const fn new(segments: &'a [Arc<[Actor]>]) -> Self {
        Self {
            segments,
            offset: [0.0, 0.0],
            source_view_proj: None,
            model: None,
            pool_class: if segments.len() == 1 {
                SONG_LUA_SMALL_PROXY_CLASS
            } else {
                SONG_LUA_MULTI_PROXY_CLASS
            },
        }
    }

    #[inline(always)]
    const fn offset(segments: &'a [Arc<[Actor]>], offset: [f32; 2]) -> Self {
        Self {
            segments,
            offset,
            source_view_proj: None,
            model: None,
            pool_class: if segments.len() == 1 {
                SONG_LUA_SMALL_PROXY_CLASS
            } else {
                SONG_LUA_MULTI_PROXY_CLASS
            },
        }
    }

    #[inline(always)]
    const fn with_pool_class(self, pool_class: usize) -> Self {
        Self { pool_class, ..self }
    }

    #[inline(always)]
    const fn is_empty(self) -> bool {
        self.segments.is_empty()
    }
}

#[derive(Clone, Copy, Default)]
struct SongLuaPlayerProxySources<'a> {
    player: Option<SongLuaProxySource<'a>>,
    direct_player: bool,
    note_field: Option<SongLuaProxySource<'a>>,
    direct_note_field: bool,
    judgment: Option<SongLuaProxySource<'a>>,
    combo: Option<SongLuaProxySource<'a>>,
    direct_combo: bool,
}

#[derive(Clone, Copy)]
struct SongLuaDirectProxySource {
    draws: SongLuaDirectDraws,
    draw_start: usize,
    draw_end: usize,
    target: [f32; 2],
    tint: [f32; 4],
    camera: Option<Matrix4>,
    player_camera: Option<SongLuaDirectPlayerCamera>,
}

#[derive(Clone, Copy)]
struct SongLuaDirectPlayerCamera {
    base: Matrix4,
    suffix: Matrix4,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum SongLuaDirectDraws {
    Field,
    Judgment,
    Combo,
}

type SongLuaDirectPlayerSource = [SongLuaDirectProxySource; 3];

#[derive(Clone, Copy, Debug, PartialEq)]
struct SongLuaDirectProxy {
    actor_insert: usize,
    player: usize,
    draws: SongLuaDirectDraws,
    draw_start: usize,
    draw_end: usize,
    offset: [f32; 2],
    z: i16,
    style: FlatProxyStyle,
    blend: BlendMode,
    enclosing_camera: Option<Matrix4>,
    camera: Option<Matrix4>,
}

/// Song-lifetime backing for direct root `ActorProxy` and exact AFT destinations.
///
/// Owner/thread model: gameplay frame scratch, used only by the game/render
/// thread. Lifetime: one song. Capacity is the compiled maximum: one entry per
/// `NoteField`, Judgment, Combo, or exact single-source AFT destination and three
/// entries per root whole-Player destination across the main and every
/// foreground layer, reserved at screen entry. Exact AFT Player destinations
/// use the same ordered combo, field and judgment runs. Each frame clears and refills the
/// retained storage; exceeding the compiled bound is a topology invariant
/// violation.
/// There is no miss path, eviction, pruning, synchronization, or gameplay-time
/// destruction. Focused proxy fixtures and warmed allocation tests cover the
/// capacity contract. Worst-case frame work is one append per visible compiled
/// direct destination, with three appends for a visible root whole-Player source.
#[derive(Debug, Default, PartialEq)]
struct SongLuaDirectProxies {
    entries: Vec<SongLuaDirectProxy>,
}

impl SongLuaDirectProxies {
    fn with_capacity(capacity: usize) -> Self {
        Self {
            entries: Vec::with_capacity(capacity),
        }
    }

    fn clear(&mut self) {
        self.entries.clear();
    }

    fn push(&mut self, proxy: SongLuaDirectProxy) {
        assert!(
            self.entries.len() < self.entries.capacity(),
            "direct proxy plan exceeded its compiled root-destination bound"
        );
        self.entries.push(proxy);
    }

    const fn len(&self) -> usize {
        self.entries.len()
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
struct SongLuaPlayerProxyRequests {
    player: bool,
    note_field: bool,
    judgment: bool,
    combo: bool,
}

#[derive(Clone, Copy, Default)]
struct SongLuaScreenProxySources<'a> {
    players: [SongLuaPlayerProxySources<'a>; 2],
    manual_players: [Option<&'a SongLuaManualPlayerSource>; MAX_PLAYERS],
    scores: [Option<&'a [Arc<[Actor]>]>; MAX_PLAYERS],
    direct_players: [Option<SongLuaDirectPlayerSource>; 2],
    direct_note_fields: [Option<SongLuaDirectProxySource>; 2],
    direct_judgments: [Option<SongLuaDirectProxySource>; 2],
    direct_combos: [Option<SongLuaDirectProxySource>; 2],
    underlay: Option<&'a [Arc<[Actor]>]>,
    overlay: Option<&'a [Arc<[Actor]>]>,
    background: Option<&'a [Arc<[Actor]>]>,
    stage: Option<&'a [Arc<[Actor]>]>,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
struct SongLuaScreenProxyRequests {
    players: [SongLuaPlayerProxyRequests; 2],
    scores: [bool; MAX_PLAYERS],
    underlay: bool,
    overlay: bool,
    background: bool,
    stage: bool,
    hide_underlay: bool,
    hide_overlay: bool,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
struct SongLuaProxyRequestAnalysis {
    all: SongLuaScreenProxyRequests,
    captured: SongLuaScreenProxyRequests,
    root_players: [u8; MAX_PLAYERS],
    root_note_fields: [u8; MAX_PLAYERS],
    root_judgments: [u8; MAX_PLAYERS],
    root_combos: [u8; MAX_PLAYERS],
}

type SongLuaSingleSource = [Arc<[Actor]>; 1];
type SongLuaActorSegments = SmallVec<[Arc<[Actor]>; 5]>;

struct SongLuaManualPlayerSource {
    field: Option<SongLuaSingleSource>,
    combo: Option<SongLuaSingleSource>,
    origin: [f32; 2],
    camera: NotefieldCameraCache,
    judgment: Option<SongLuaSingleSource>,
}

struct PreparedProxySource {
    segments: SongLuaSingleSource,
    // Remove the source origin after its own transform, before the proxy's.
    offset: [f32; 2],
    root_camera: bool,
    model: Option<Matrix4>,
}

impl PreparedProxySource {
    #[inline(always)]
    const fn new(segments: SongLuaSingleSource) -> Self {
        Self {
            segments,
            offset: [0.0, 0.0],
            root_camera: false,
            model: None,
        }
    }

    fn view(&self) -> SongLuaProxySource<'_> {
        // Prepared Player/child transforms use the Player root camera. Decode
        // that same depth range before an outer proxy rotates the source.
        SongLuaProxySource {
            model: self.model,
            source_view_proj: self
                .root_camera
                .then(|| song_lua_player_root_camera(Matrix4::IDENTITY)),
            ..SongLuaProxySource::offset(&self.segments, self.offset)
        }
    }
}

#[derive(Clone, Copy)]
enum ProxyCapturePart {
    Field,
    Hud,
}

const SONG_LUA_SCREEN_CAPTURE_SLOTS: usize = 64;
const SONG_LUA_SCREEN_CAPTURE_CAPACITY: usize = 32;
const SONG_LUA_PROXY_FRAME_BANKS: usize = 2;
const SONG_LUA_PROXY_SEGMENTS_PER_ACTOR: usize = 5;
const SONG_LUA_AFT_FRAME_BANKS: usize = 2;
const SONG_LUA_PLAYER_PROXY_SOURCE_COUNT: usize = 7;
const SONG_LUA_FIELD_PROXY_SOURCE: usize = 0;
const SONG_LUA_JUDGMENT_PROXY_SOURCE: usize = 1;
const SONG_LUA_COMBO_PROXY_SOURCE: usize = 2;
const SONG_LUA_PLAYER_PROXY_SOURCE: usize = 3;
const SONG_LUA_MANUAL_COMBO_SOURCE: usize = 4;
const SONG_LUA_MANUAL_FIELD_SOURCE: usize = 5;
const SONG_LUA_MANUAL_JUDGMENT_SOURCE: usize = 6;
const SONG_LUA_PLAYER_SOURCE_CAPS: [usize; SONG_LUA_PLAYER_PROXY_SOURCE_COUNT] = [
    NOTEFIELD_ACTOR_SCRATCH_CAPACITY,
    NOTEFIELD_HUD_ACTOR_SCRATCH_CAPACITY,
    NOTEFIELD_HUD_ACTOR_SCRATCH_CAPACITY,
    PLAYER_ACTOR_SCRATCH_CAPACITY,
    NOTEFIELD_HUD_ACTOR_SCRATCH_CAPACITY,
    NOTEFIELD_ACTOR_SCRATCH_CAPACITY,
    NOTEFIELD_HUD_ACTOR_SCRATCH_CAPACITY,
];
const SONG_LUA_PROXY_POOL_CLASSES: usize = 4;
const SONG_LUA_SMALL_PROXY_CLASS: usize = 0;
const SONG_LUA_NOTEFIELD_PROXY_CLASS: usize = 1;
const SONG_LUA_PLAYER_PROXY_CLASS: usize = 2;
const SONG_LUA_MULTI_PROXY_CLASS: usize = 3;
const SONG_LUA_PROXY_SEGMENTS_PER_GROUP: [usize; SONG_LUA_PROXY_POOL_CLASSES] =
    [1, 1, 1, SONG_LUA_PROXY_SEGMENTS_PER_ACTOR];
const SONG_LUA_PROXY_SEGMENT_CAPACITIES: [usize; SONG_LUA_PROXY_POOL_CLASSES] = [
    SONG_LUA_SCREEN_CAPTURE_CAPACITY,
    NOTEFIELD_ACTOR_SCRATCH_CAPACITY,
    PLAYER_ACTOR_SCRATCH_CAPACITY,
    SONG_LUA_SCREEN_CAPTURE_CAPACITY,
];

const fn song_lua_proxy_pool_class(target: &SongLuaProxyTarget) -> usize {
    match target {
        SongLuaProxyTarget::Player { .. } => SONG_LUA_PLAYER_PROXY_CLASS,
        SongLuaProxyTarget::NoteField { .. } => SONG_LUA_NOTEFIELD_PROXY_CLASS,
        SongLuaProxyTarget::Judgment { .. } | SongLuaProxyTarget::Combo { .. } => {
            SONG_LUA_SMALL_PROXY_CLASS
        }
        SongLuaProxyTarget::Underlay { .. } | SongLuaProxyTarget::Overlay { .. } => {
            SONG_LUA_MULTI_PROXY_CLASS
        }
        SongLuaProxyTarget::Actor { .. } | SongLuaProxyTarget::Score { .. } => {
            SONG_LUA_SMALL_PROXY_CLASS
        }
    }
}

fn song_lua_proxy_pool_counts<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    index: &SongLuaProxyRequestIndex,
) -> [usize; SONG_LUA_PROXY_POOL_CLASSES] {
    let mut counts = [0usize; SONG_LUA_PROXY_POOL_CLASSES];
    for &proxy_index in &index.proxy_indices {
        let Some(SongLuaOverlayKind::ActorProxy { target }) =
            overlays.get(proxy_index).map(|overlay| &overlay.kind)
        else {
            continue;
        };
        let class = song_lua_proxy_pool_class(target);
        counts[class] = counts[class].saturating_add(1);
    }
    if overlays.iter().any(|overlay| {
        matches!(&overlay.kind,
        SongLuaOverlayKind::UpdateTracks { draw_frames, .. } if !draw_frames.is_empty())
    }) {
        // Manual external draws need the same warmed source banks as proxies.
        counts[SONG_LUA_SMALL_PROXY_CLASS] += 3;
        counts[SONG_LUA_MULTI_PROXY_CLASS] += 2;
    }
    counts
}

struct SongLuaProxyJoinScratch {
    sources: [Arc<[Actor]>; SONG_LUA_PROXY_SEGMENTS_PER_ACTOR],
    _replacements: u64,
}

impl SongLuaProxyJoinScratch {
    fn new() -> Self {
        Self {
            sources: std::array::from_fn(|index| Self::new_source(index + 1)),
            _replacements: 0,
        }
    }

    fn new_source(len: usize) -> Arc<[Actor]> {
        Arc::from(
            (0..len)
                .map(|_| Actor::SharedFrame {
                    align: [0.0, 0.0],
                    offset: [0.0, 0.0],
                    size: [SizeSpec::Fill, SizeSpec::Fill],
                    children: Arc::from([]),
                    background: None,
                    z: 0,
                    tint: [1.0; 4],
                    blend: None,
                })
                .collect::<Vec<_>>()
                .into_boxed_slice(),
        )
    }

    fn refill(
        &mut self,
        segment_count: usize,
        diffuse: [f32; 4],
        blend: Option<BlendMode>,
        mut segment: impl FnMut(usize) -> Arc<[Actor]>,
    ) -> Arc<[Actor]> {
        let source = &mut self.sources[segment_count - 1];
        if Arc::strong_count(source) != 1 {
            *source = Self::new_source(segment_count);
            self._replacements = self._replacements.saturating_add(1);
        }
        let actors =
            Arc::get_mut(source).expect("proxy join source is uniquely owned after replacement");
        for (index, actor) in actors.iter_mut().enumerate() {
            let Actor::SharedFrame {
                children,
                tint,
                blend: actor_blend,
                ..
            } = actor
            else {
                panic!("proxy join source must remain shared frames");
            };
            *children = segment(index);
            *tint = diffuse;
            *actor_blend = blend;
        }
        Arc::clone(source)
    }
}

/// Song-lifetime backing for Song Lua `ActorProxy` sources.
///
/// Owner/thread model: gameplay `State`, exclusively mutated during actor
/// composition on the game/render frame thread. Lifetime: one song, allocated
/// only when a compiled overlay contains a proxy. Capacity/warmup: 64 bounded
/// screen segments and four pre-sized player sources per active player are
/// reserved at screen entry, plus unposed HUD and field sources for manual
/// Player draws. Player,
/// note-field, judgment, and combo proxies
/// each reserve their only possible normalized source segment. Underlay and
/// overlay proxies reserve up to five bounded segments and a prebuilt join
/// frame. Fixed target pools retain O(1) reservation. Two banks let composition
/// proceed while the renderer still owns the preceding frame. A
/// miss after slot saturation bypasses insertion and uses the owned fallback;
/// child-vector overflow grows only the affected slot. There is no lookup,
/// eviction, scan, pruning, or mid-song destruction. Replacements/growths are
/// tracked by each backing slot. Worst-case steady frame work is linear in
/// actors already emitted for the requested captures.
struct SongLuaProxyActorBank {
    screen: [SharedActorFrameScratch; SONG_LUA_SCREEN_CAPTURE_SLOTS],
    screen_used: usize,
    players: [[SharedActorFrameScratch; SONG_LUA_PLAYER_PROXY_SOURCE_COUNT]; MAX_PLAYERS],
    proxy_segments: Vec<SharedActorFrameScratch>,
    proxy_frames: Vec<SongLuaProxyJoinScratch>,
    proxy_segment_offsets: [usize; SONG_LUA_PROXY_POOL_CLASSES + 1],
    proxy_groups_used: [usize; SONG_LUA_PROXY_POOL_CLASSES],
}

impl SongLuaProxyActorBank {
    fn new(active_players: usize, proxy_counts: [usize; SONG_LUA_PROXY_POOL_CLASSES]) -> Self {
        let mut proxy_segment_offsets = [0usize; SONG_LUA_PROXY_POOL_CLASSES + 1];
        for class in 0..SONG_LUA_PROXY_POOL_CLASSES {
            proxy_segment_offsets[class + 1] = proxy_segment_offsets[class].saturating_add(
                proxy_counts[class].saturating_mul(SONG_LUA_PROXY_SEGMENTS_PER_GROUP[class]),
            );
        }
        let mut proxy_segments =
            Vec::with_capacity(proxy_segment_offsets[SONG_LUA_PROXY_POOL_CLASSES]);
        for class in 0..SONG_LUA_PROXY_POOL_CLASSES {
            for _ in 0..proxy_counts[class] {
                for _ in 0..SONG_LUA_PROXY_SEGMENTS_PER_GROUP[class] {
                    proxy_segments.push(SharedActorFrameScratch::with_capacity(
                        SONG_LUA_PROXY_SEGMENT_CAPACITIES[class],
                    ));
                }
            }
        }
        Self {
            screen: std::array::from_fn(|_| {
                SharedActorFrameScratch::with_capacity(SONG_LUA_SCREEN_CAPTURE_CAPACITY)
            }),
            screen_used: 0,
            players: std::array::from_fn(|player| {
                let active = player < active_players;
                std::array::from_fn(|source| {
                    SharedActorFrameScratch::with_capacity(
                        usize::from(active) * SONG_LUA_PLAYER_SOURCE_CAPS[source],
                    )
                })
            }),
            proxy_segments,
            proxy_frames: (0..proxy_counts[SONG_LUA_MULTI_PROXY_CLASS])
                .map(|_| SongLuaProxyJoinScratch::new())
                .collect(),
            proxy_segment_offsets,
            proxy_groups_used: [0; SONG_LUA_PROXY_POOL_CLASSES],
        }
    }

    fn begin_frame(&mut self) {
        self.screen_used = 0;
        self.proxy_groups_used.fill(0);
        for player in &mut self.players {
            for source in player {
                source.clear();
            }
        }
    }
}

struct SongLuaProxyActorScratch {
    banks: [SongLuaProxyActorBank; SONG_LUA_PROXY_FRAME_BANKS],
    active_bank: usize,
    frame_banks: usize,
}

impl SongLuaProxyActorScratch {
    #[cfg(test)]
    fn new(active_players: usize) -> Self {
        Self::with_proxy_counts(active_players, [1, 0, 0, 0])
    }

    fn with_proxy_counts(
        active_players: usize,
        proxy_counts: [usize; SONG_LUA_PROXY_POOL_CLASSES],
    ) -> Self {
        Self::with_proxy_counts_and_banks(active_players, proxy_counts, SONG_LUA_PROXY_FRAME_BANKS)
    }

    fn with_proxy_counts_and_banks(
        active_players: usize,
        proxy_counts: [usize; SONG_LUA_PROXY_POOL_CLASSES],
        frame_banks: usize,
    ) -> Self {
        let frame_banks = frame_banks.clamp(1, SONG_LUA_PROXY_FRAME_BANKS);
        Self {
            banks: std::array::from_fn(|_| {
                SongLuaProxyActorBank::new(active_players, proxy_counts)
            }),
            active_bank: frame_banks - 1,
            frame_banks,
        }
    }

    fn begin_frame(&mut self) {
        self.active_bank = (self.active_bank + 1) % self.frame_banks;
        self.banks[self.active_bank].begin_frame();
    }

    fn next_screen(&mut self) -> Option<&mut SharedActorFrameScratch> {
        let bank = &mut self.banks[self.active_bank];
        let slot = bank.screen.get_mut(bank.screen_used)?;
        bank.screen_used += 1;
        Some(slot)
    }

    fn player(&mut self, player: usize, source: usize) -> Option<&mut SharedActorFrameScratch> {
        self.banks[self.active_bank]
            .players
            .get_mut(player)?
            .get_mut(source)
    }

    fn player_source(&self, player: usize, source: usize) -> Option<&[Actor]> {
        self.banks[self.active_bank]
            .players
            .get(player)?
            .get(source)
            .map(SharedActorFrameScratch::actors)
    }

    fn reserve_proxy_group(&mut self, pool_class: usize) -> Option<SongLuaProxyGroup> {
        let bank = &mut self.banks[self.active_bank];
        let used = bank.proxy_groups_used.get_mut(pool_class)?;
        let local_group = *used;
        *used = used.saturating_add(1);
        let segment_start = bank.proxy_segment_offsets[pool_class].saturating_add(
            local_group.saturating_mul(SONG_LUA_PROXY_SEGMENTS_PER_GROUP[pool_class]),
        );
        if segment_start >= bank.proxy_segment_offsets[pool_class + 1] {
            return None;
        }
        Some(SongLuaProxyGroup {
            frame_index: (pool_class == SONG_LUA_MULTI_PROXY_CLASS).then_some(local_group),
            segment_start,
        })
    }

    fn normalize_segment(&mut self, segment: &Arc<[Actor]>, slot_index: usize) -> Arc<[Actor]> {
        let bank = &mut self.banks[self.active_bank];
        song_lua_normalize_proxy_segment(segment, bank.proxy_segments.get_mut(slot_index))
    }

    fn join_proxy_segments(
        &mut self,
        group: SongLuaProxyGroup,
        source: &[Arc<[Actor]>],
        diffuse: [f32; 4],
        blend: Option<BlendMode>,
    ) -> Arc<[Actor]> {
        let bank = &mut self.banks[self.active_bank];
        let proxy_frames = &mut bank.proxy_frames;
        let proxy_segments = &mut bank.proxy_segments;
        let frame_index = group
            .frame_index
            .expect("multi-segment proxy group requires join storage");
        proxy_frames[frame_index].refill(source.len(), diffuse, blend, |index| {
            song_lua_normalize_proxy_segment(
                &source[index],
                proxy_segments.get_mut(group.segment_start + index),
            )
        })
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct SongLuaProxyGroup {
    frame_index: Option<usize>,
    segment_start: usize,
}

fn song_lua_normalize_proxy_segment(
    segment: &Arc<[Actor]>,
    slot: Option<&mut SharedActorFrameScratch>,
) -> Arc<[Actor]> {
    if !segment.iter().any(song_lua_proxy_actor_has_z) {
        return Arc::clone(segment);
    }
    let Some(slot) = slot else {
        return song_lua_proxy_source_segment_owned(segment);
    };
    let (offset, actors) = song_lua_proxy_segment_actors(segment);
    slot.refill(offset, |children| {
        song_lua_proxy_local_children_into(actors.iter().cloned(), children);
    })
    .unwrap_or_else(|| Arc::from([]))
}

/// Song-lifetime backing for `ActorFrameTexture` capture output.
///
/// Owner/thread model: gameplay `State`, exclusively mutated during actor
/// composition on the game/render frame thread. Lifetime: one song. Capacity:
/// each AFT has two frame banks sized at screen entry from its compiled
/// capture descendants, including the maximum two actors emitted by glow and
/// model layers. Warmup occurs during screen initialization. Gameplay misses
/// grow only the affected slot and retain that high-water mark; there is no
/// lookup, eviction, pruning, or gameplay destruction. Two banks cover the
/// renderer retaining the preceding frame. Per-slot replacement/growth counts
/// are available from `SharedActorFrameScratch::stats`. Worst-case frame work
/// remains linear in the already-required captured actors.
#[derive(Default)]
struct SongLuaAftCaptureScratch {
    slots: Vec<Option<[SharedActorFrameScratch; SONG_LUA_AFT_FRAME_BANKS]>>,
    active_bank: usize,
    manual: SongLuaManualScratch,
}

impl SongLuaAftCaptureScratch {
    fn new<S: NoteskinSlot + Clone>(
        overlays: &[SongLuaOverlayActor<S>],
        topology: &SongLuaOverlayTopologyIndex,
    ) -> Self {
        let slots = overlays
            .iter()
            .enumerate()
            .map(|(index, overlay)| {
                matches!(overlay.kind, SongLuaOverlayKind::ActorFrameTexture { .. }).then(|| {
                    let capacity = song_lua_aft_capture_capacity(overlays, topology, index);
                    std::array::from_fn(|_| SharedActorFrameScratch::with_capacity(capacity))
                })
            })
            .collect();
        Self {
            slots,
            active_bank: SONG_LUA_AFT_FRAME_BANKS - 1,
            manual: SongLuaManualScratch::new(overlays),
        }
    }

    fn begin_frame(&mut self) {
        self.active_bank = (self.active_bank + 1) % SONG_LUA_AFT_FRAME_BANKS;
        self.manual.begin_frame();
    }

    fn overlay(&mut self, index: usize) -> Option<&mut SharedActorFrameScratch> {
        self.slots
            .get_mut(index)?
            .as_mut()
            .map(|banks| &mut banks[self.active_bank])
    }
}

struct SongLuaManualSlot {
    actors: Vec<Actor>,
    capture: SharedActorFrameScratch,
    // Native BeginRenderingTo replaces the camera with the image viewport.
    viewport: [f32; 2],
    // Captured Player/ScreenLayer children retain their original layout basis.
    source_layout: Option<SharedActorFrameScratch>,
    meshes: Vec<(usize, SongLuaProjectedMeshScratch)>,
}

/// Song-owned custom draw playback, single-threaded with FrameScratch. Screen
/// entry converts immutable mesh snapshots and sizes two independent frame
/// banks from peak recorded operation/actor counts. Selection is logarithmic;
/// playback visits only that frame, without I/O, pruning or mesh allocation.
/// Captures are released at transition. SharedActorFrameScratch reports buffer
/// growth/replacements if a consumer retains more than the preceding frame.
#[derive(Default)]
struct SongLuaManualScratch {
    frames: Arc<[SongLuaDrawFrame]>,
    normal_frames: Box<[usize]>,
    immediate_frames: Box<[usize]>,
    immediate_cursor: usize,
    immediate_second: f32,
    meshes: Vec<Box<[Option<Arc<[TexturedMeshVertex]>>]>>,
    owners: Box<[Option<usize>]>,
    banks: [Vec<SongLuaManualSlot>; SONG_LUA_AFT_FRAME_BANKS],
    bank: usize,
    targets: Vec<usize>,
}

impl SongLuaManualScratch {
    fn new<S: NoteskinSlot + Clone>(overlays: &[SongLuaOverlayActor<S>]) -> Self {
        let frames = overlays
            .iter()
            .find_map(|overlay| match &overlay.kind {
                SongLuaOverlayKind::UpdateTracks { draw_frames, .. } => {
                    Some(Arc::clone(draw_frames))
                }
                _ => None,
            })
            .unwrap_or_default();
        Self::with_frames(overlays, frames)
    }

    fn with_frames<S: NoteskinSlot + Clone>(
        overlays: &[SongLuaOverlayActor<S>],
        frames: Arc<[SongLuaDrawFrame]>,
    ) -> Self {
        let mut owner_flags = vec![false; overlays.len()];
        for frame in frames.iter().filter(|frame| !frame.immediate) {
            for &owner in &frame.owners {
                owner_flags[owner] = true;
            }
        }
        let owners = (0..overlays.len())
            .map(|index| {
                let mut current = Some(index);
                while let Some(index) = current {
                    if owner_flags[index] {
                        return Some(index);
                    }
                    current = overlays[index].parent_index;
                }
                None
            })
            .collect();
        let peak = frames
            .iter()
            .map(|frame| frame.ops.len())
            .max()
            .unwrap_or(0);
        let capacity = overlays
            .iter()
            .map(|overlay| song_lua_aft_actor_capacity(&overlay.kind))
            .max()
            .unwrap_or(0)
            .max(5)
            + 2;
        let mut sources = vec![Vec::new(); peak];
        let mut target_ops = vec![false; peak];
        let mut source_layout_ops = vec![false; peak];
        for frame in frames.iter() {
            for (op, draw) in frame.ops.iter().enumerate() {
                target_ops[op] |= matches!(draw, SongLuaDrawOp::Begin { .. });
                source_layout_ops[op] |= matches!(draw, SongLuaDrawOp::Draw {
                    source: SongLuaDrawSource::Player(_) | SongLuaDrawSource::ScreenLayer(_),
                    ..
                });
                if let SongLuaDrawOp::Draw {
                    source: SongLuaDrawSource::Overlay(index),
                    ..
                } = draw
                    && !sources[op].contains(index)
                {
                    sources[op].push(*index);
                }
            }
        }
        let meshes = frames
            .iter()
            .map(|frame| {
                frame
                    .ops
                    .iter()
                    .map(|op| match op {
                        SongLuaDrawOp::Draw {
                            source: SongLuaDrawSource::Overlay(index),
                            vertices,
                            ..
                        } if matches!(
                            overlays[*index].kind,
                            SongLuaOverlayKind::ActorMultiVertex {
                                texture_key: Some(_),
                                ..
                            } | SongLuaOverlayKind::ActorMultiVertex {
                                capture_name: Some(_),
                                ..
                            }
                        ) =>
                        {
                            let SongLuaOverlayKind::ActorMultiVertex {
                                vertices: initial, ..
                            } = &overlays[*index].kind
                            else {
                                unreachable!()
                            };
                            Some(
                                vertices
                                    .as_ref()
                                    .unwrap_or(initial)
                                    .iter()
                                    .map(|vertex| TexturedMeshVertex {
                                        normal: [0.0; 4],
                                        pos: [vertex.pos[0], vertex.pos[1], vertex.z],
                                        uv: vertex.uv,
                                        tex_matrix_scale: [1.0; 2],
                                        color: vertex.color,
                                    })
                                    .collect(),
                            )
                        }
                        _ => None,
                    })
                    .collect()
            })
            .collect();
        let normal_frames = frames
            .iter()
            .enumerate()
            .filter_map(|(i, frame)| (!frame.immediate).then_some(i))
            .collect();
        let immediate_frames = frames
            .iter()
            .enumerate()
            .filter_map(|(i, frame)| frame.immediate.then_some(i))
            .collect();
        Self {
            frames,
            normal_frames,
            immediate_frames,
            immediate_cursor: 0,
            immediate_second: f32::NEG_INFINITY,
            meshes,
            owners,
            banks: std::array::from_fn(|_| {
                (0..peak)
                    .map(|op| SongLuaManualSlot {
                        actors: Vec::with_capacity(if target_ops[op] {
                            peak * capacity
                        } else {
                            capacity
                        }),
                        capture: SharedActorFrameScratch::with_capacity(if target_ops[op] {
                            peak * capacity
                        } else {
                            capacity
                        }),
                        viewport: [0.0; 2],
                        source_layout: source_layout_ops[op]
                            .then(|| SharedActorFrameScratch::with_capacity(capacity)),
                        meshes: sources[op]
                            .iter()
                            .map(|&index| {
                                let mut meshes =
                                    song_lua_projected_mesh_scratch_for(&overlays[index..=index]);
                                (
                                    index,
                                    meshes
                                        .pop()
                                        .expect("one compiled overlay has one scratch slot"),
                                )
                            })
                            .collect(),
                    })
                    .collect()
            }),
            bank: SONG_LUA_AFT_FRAME_BANKS - 1,
            targets: Vec::with_capacity(peak),
        }
    }

    fn begin_frame(&mut self) {
        self.release_next();
        self.bank = (self.bank + 1) % SONG_LUA_AFT_FRAME_BANKS;
        self.targets.clear();
    }

    fn release_next(&mut self) {
        let next = (self.bank + 1) % SONG_LUA_AFT_FRAME_BANKS;
        for slot in &mut self.banks[next] {
            slot.actors.clear();
            slot.capture.clear();
            if let Some(source_layout) = &mut slot.source_layout {
                source_layout.clear();
            }
        }
    }

    fn frame_at(&self, second: f32) -> Option<usize> {
        self.normal_frames
            .partition_point(|&index| self.frames[index].second <= second)
            .checked_sub(1)
            .map(|index| self.normal_frames[index])
    }

    fn pending_immediate(&self, second: f32) -> std::ops::Range<usize> {
        let end = self
            .immediate_frames
            .partition_point(|&index| self.frames[index].second <= second);
        let start = if second < self.immediate_second {
            0
        } else {
            self.immediate_cursor.min(end)
        };
        start..end
    }

    fn take_immediate(&mut self, second: f32) -> std::ops::Range<usize> {
        let range = self.pending_immediate(second);
        self.immediate_cursor = range.end;
        self.immediate_second = second;
        range
    }

    fn requests(&self, second: f32) -> SongLuaScreenProxyRequests {
        let mut requests = SongLuaScreenProxyRequests::default();
        let normal = self.frame_at(second).into_iter();
        let immediate = self.immediate_frames[self.pending_immediate(second)]
            .iter()
            .copied();
        for index in normal.chain(immediate) {
            for op in &self.frames[index].ops {
                let SongLuaDrawOp::Draw { source, .. } = op else {
                    continue;
                };
                match source {
                    SongLuaDrawSource::Player(index) => requests.players[*index].player = true,
                    SongLuaDrawSource::Judgment(index) => requests.players[*index].judgment = true,
                    SongLuaDrawSource::Combo(index) => requests.players[*index].combo = true,
                    SongLuaDrawSource::ScreenLayer(0) => requests.underlay = true,
                    SongLuaDrawSource::ScreenLayer(1) => requests.overlay = true,
                    SongLuaDrawSource::ScreenLayer(2) => requests.background = true,
                    SongLuaDrawSource::ScreenLayer(3) => requests.stage = true,
                    _ => {}
                }
            }
        }
        requests
    }
}

fn song_lua_draw_matrix(state: SongLuaOverlayState, clock: [f32; 2]) -> (Matrix4, [f32; 4]) {
    let mut tint = state.diffuse;
    let mut glow = state.glow;
    let mut position = [state.x, state.y, state.z];
    let [x, y] = song_lua_overlay_axis_scale(state);
    let mut scale = [x, y, song_lua_overlay_z_scale(state)];
    let mut rotation = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
    song_lua_apply_overlay_effect(
        state,
        clock[0],
        clock[1],
        0,
        &mut tint,
        &mut glow,
        &mut position,
        &mut scale,
        &mut rotation,
    );
    let model = song_lua_overlay_sprite_matrix(
        state,
        state.size.unwrap_or([0.0; 2]),
        position,
        rotation,
        std::array::from_fn(|axis| {
            let base = [x, y, song_lua_overlay_z_scale(state)][axis];
            if base == 0.0 { 1.0 } else { scale[axis] / base }
        }),
    );
    (model, tint)
}

fn song_lua_screen_projection(
    state: SongLuaOverlayState,
    source_size: [f32; 2],
    clock: [f32; 2],
) -> Matrix4 {
    let (model, _) = song_lua_draw_matrix(state, clock);
    if model == Matrix4::IDENTITY {
        return Matrix4::IDENTITY;
    }
    let (view, projection) = song_lua_overlay_view_proj(state, source_size[0], source_size[1])
    .unwrap_or_else(|| {
        (
            Matrix4::IDENTITY,
            glam::camera::rh::proj::opengl::orthographic(
                // Lua geometry carries LoadMenuPerspective(0)'s native depth,
                // even when the presentation camera itself spans -1/+1.
                0.0,
                source_size[0],
                source_size[1],
                0.0,
                -1000.0,
                1000.0,
            ),
        )
    });
    song_lua_camera_world_projection(projection * view, model)
}

fn song_lua_camera_world_projection(camera: Matrix4, model: Matrix4) -> Matrix4 {
    if model == Matrix4::IDENTITY {
        return Matrix4::IDENTITY;
    }
    let camera = camera.as_dmat4();
    // Perspective depth and W are nearly equal at the screen plane. Inverting
    // that camera in f32 amplifies cancellation into visible clip-coordinate
    // errors. Keep the native f32 coefficients, but calculate this change of
    // basis in f64 before storing the presentation matrix.
    (camera * model.as_dmat4() * camera.inverse()).as_mat4()
}

#[derive(Clone, Copy)]
struct SongLuaDrawCamera {
    state: Option<SongLuaOverlayState>,
    world: Matrix4,
    // Explicit ActorFrame FOV always resolves against SCREEN_WIDTH/HEIGHT,
    // including when a smaller render target is the active destination.
    resolved: Option<(Matrix4, Matrix4)>,
}

impl From<Option<SongLuaOverlayState>> for SongLuaDrawCamera {
    fn from(state: Option<SongLuaOverlayState>) -> Self {
        Self { state, world: Matrix4::IDENTITY, resolved: None }
    }
}

impl SongLuaDrawCamera {
    fn with_screen(
        state: Option<SongLuaOverlayState>,
        screen: Option<SongLuaOverlayState>,
        clock: [f32; 2],
    ) -> Self {
        Self {
            state,
            world: screen.map_or(Matrix4::IDENTITY, |screen| song_lua_draw_matrix(screen, clock).0),
            resolved: None,
        }
    }

    fn resolve_for(mut self, screen: [f32; 2]) -> Self {
        self.resolved = self.state.and_then(|state| {
            song_lua_overlay_view_proj(state, screen[0], screen[1])
        });
        self
    }

    fn explicit_view_proj(self, width: f32, height: f32) -> Option<(Matrix4, Matrix4)> {
        self.resolved.or_else(|| {
            self.state.and_then(|state| song_lua_overlay_view_proj(state, width, height))
        })
    }

    fn is_active(self) -> bool {
        self.state.is_some() || self.world != Matrix4::IDENTITY
    }

    fn uses_generic_mask(self, state: SongLuaOverlayState, size: [f32; 2]) -> bool {
        (state.mask_source || state.mask_dest)
            && self.explicit_view_proj(size[0], size[1]).is_none()
    }

    fn view_proj(self, width: f32, height: f32) -> Option<SongLuaDrawViewProjection> {
        let camera = self.explicit_view_proj(width, height);
        if camera.is_none() && self.world == Matrix4::IDENTITY {
            return None;
        }
        let (view, projection) = camera.unwrap_or((Matrix4::IDENTITY, song_lua_screen_proj(1000.0)));
        Some(SongLuaDrawViewProjection { view, projection, world: self.world })
    }
}

#[derive(Clone, Copy)]
struct SongLuaDrawViewProjection {
    view: Matrix4,
    projection: Matrix4,
    world: Matrix4,
}

impl From<(Matrix4, Matrix4)> for SongLuaDrawViewProjection {
    fn from((view, projection): (Matrix4, Matrix4)) -> Self {
        Self { view, projection, world: Matrix4::IDENTITY }
    }
}

fn song_lua_manual_mesh<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    topology: &SongLuaOverlayTopologyIndex,
    op: &SongLuaDrawOp,
    vertices: &Arc<[TexturedMeshVertex]>,
    camera: SongLuaDrawCamera,
    assets: &AssetManager,
    screen: [f32; 2],
    clock: [f32; 2],
    z: i16,
) -> Option<Actor> {
    let SongLuaDrawOp::Draw {
        source: SongLuaDrawSource::Overlay(index),
        state,
        parents,
        ..
    } = op
    else {
        return None;
    };
    let SongLuaOverlayKind::ActorMultiVertex { texture_key, .. } = &overlays[*index].kind else {
        return None;
    };
    let texture = if let Some(handle) = topology.texture_handle(*index) {
        deadlib_present::actors::MeshTexture::Handle(render_target_sample_handle(
            handle,
            !state.texture_filtering,
        ))
    } else {
        let key = texture_key.as_ref()?;
        if !assets.has_texture_key(key) {
            return None;
        }
        deadlib_present::actors::MeshTexture::Key(Arc::clone(key))
    };
    let mut model = Matrix4::IDENTITY;
    for parent in parents.iter() {
        model *= song_lua_draw_matrix(*parent, clock).0;
    }
    let (leaf, tint) = song_lua_draw_matrix(*state, clock);
    let canvas = Matrix4::from_scale(Vector3::new(
        screen_width() / screen[0],
        screen_height() / screen[1],
        1.0,
    ));
    let view_proj = camera.view_proj(screen[0], screen[1])
        .unwrap_or_else(|| (Matrix4::IDENTITY, song_lua_screen_proj(1000.0)).into());
    Some(Actor::TexturedMesh {
        environment: Some(deadlib_present::actors::MeshEnvironment {
            // ActorMultiVertex applies the sampling state captured by each Draw,
            // including its native default Clamp, before diffuse and glow.
            sampler: Some(deadlib_render_core::MeshSampler::Override {
                filter: if state.texture_filtering {
                    deadlib_render_core::SamplerFilter::Linear
                } else {
                    deadlib_render_core::SamplerFilter::Nearest
                },
                wrap: if state.texture_wrapping {
                    deadlib_render_core::SamplerWrap::Repeat
                } else {
                    deadlib_render_core::SamplerWrap::Clamp
                },
            }),
            camera: None,
            transform: Matrix4::IDENTITY,
            additive_texture: None,
            additive_uv: [0.0, 0.0, 1.0, 1.0],
        }),
        vertex_color_encoding: deadlib_present::actors::VertexColorEncoding::RageMultiVertex,
        align: [0.0; 2],
        offset: [0.0; 2],
        world_z: 0.0,
        size: [SizeSpec::Px(0.0); 2],
        local_transform: song_lua_projected_local_transform(
            view_proj,
            canvas * model * leaf,
            *state,
        ),
        texture,
        tint,
        glow: state.glow,
        vertices: Arc::clone(vertices),
        geom_cache_key: INVALID_TMESH_CACHE_KEY,
        uv_scale: [1.0; 2],
        uv_offset: [0.0; 2],
        uv_tex_shift: [0.0; 2],
        depth_test: state.depth_test,
        depth_write: state.depth_write,
        depth_test_on_fail: state.depth_test_on_fail,
        clear_depth: false,
        clear_depth_after: false,
        cull_mode: deadlib_render_core::CullMode::None,
        visible: state.draw_visible(),
        blend: song_lua_overlay_blend(state.blend),
        z,
    })
}

fn song_lua_capture_size(size: [f32; 2]) -> ([u32; 2], [u32; 2]) {
    // ActorFrameTexture::Create converts its requested size to integer pixels.
    let viewport = size.map(|value| value.clamp(1.0, u32::MAX as f32) as u32);
    let backing = viewport.map(|value| value.checked_next_power_of_two().unwrap_or(value));
    (backing, viewport)
}

fn capture_manual_player(
    field: Option<SongLuaSingleSource>,
    hud: &[Actor],
    combo_end: usize,
    origin: [f32; 2],
    camera: NotefieldCameraCache,
    scratch: &mut [SharedActorFrameScratch; SONG_LUA_PLAYER_PROXY_SOURCE_COUNT],
) -> SongLuaManualPlayerSource {
    SongLuaManualPlayerSource {
        // Strip only the outer Player perspective scope. Inverting that
        // projective camera loses precision and cannot recover root geometry
        // collapsed by a final zero zoom. Copy the untouched child actors.
        field: field.and_then(|field| {
            scratch[SONG_LUA_MANUAL_FIELD_SOURCE]
                .refill([0.0; 2], |out| {
                    out.extend(song_lua_note_field_proxy_actors(&field[0]).iter().cloned())
                })
                .map(|actors| [actors])
        }),
        combo: scratch[SONG_LUA_MANUAL_COMBO_SOURCE]
            .refill([0.0; 2], |out| out.extend(hud[..combo_end].iter().cloned()))
            .map(|actors| [actors]),
        judgment: scratch[SONG_LUA_MANUAL_JUDGMENT_SOURCE]
            .refill([0.0; 2], |out| out.extend(hud[combo_end..].iter().cloned()))
            .map(|actors| [actors]),
        origin,
        camera,
    }
}

fn append_manual_player(
    out: &mut Vec<Actor>,
    source: &SongLuaManualPlayerSource,
    state: SongLuaOverlayState,
    parents: &[SongLuaOverlayState],
    camera: SongLuaDrawCamera,
    screen: [f32; 2],
    source_metrics: deadlib_present::space::Metrics,
    source_screen: [f32; 2],
    clock: [f32; 2],
    z: i16,
) {
    let (leaf, tint) = song_lua_draw_matrix(state, clock);
    if !state.draw_visible() || (tint[3] <= 0.0 && state.glow[3] <= 0.0) {
        return;
    }
    let mut model = Matrix4::IDENTITY;
    for parent in parents {
        let (matrix, tint) = song_lua_draw_matrix(*parent, clock);
        if !parent.draw_visible() || (tint[3] <= 0.0 && parent.glow[3] <= 0.0) {
            return;
        }
        model *= matrix;
    }
    let source_canvas = Matrix4::from_scale(Vector3::new(
        (source_metrics.right - source_metrics.left) / source_screen[0],
        (source_metrics.top - source_metrics.bottom) / source_screen[1],
        1.0,
    ));
    let canvas = Matrix4::from_scale(Vector3::new(
        screen_width() / screen[0],
        screen_height() / screen[1],
        1.0,
    ));
    let model = canvas * model * leaf * source_canvas.inverse();
    let world_to_local = Matrix4::from_translation(Vector3::new(
        -source_metrics.left - source.origin[0],
        source_metrics.top - source.origin[1],
        0.0,
    )) * Matrix4::from_scale(Vector3::new(1.0, -1.0, 1.0));
    let view_proj = camera.view_proj(screen[0], screen[1]).map_or_else(
        || song_lua_screen_proj(1000.0),
        |camera| camera.projection * camera.view * camera.world,
    );
    let root = song_lua_proxy_source_view_proj();
    let source_root = source_metrics.projection();
    let (field_camera, field_model) = source
        .camera
        .draw_camera([
            state.x * screen_width() / screen[0],
            state.y * screen_height() / screen[1],
        ])
        .unwrap_or((view_proj, Matrix4::IDENTITY));
    // Player::DrawPrimitives draws its children explicitly; its own diffuse,
    // glow and blend are opacity gates, not styles inherited by those children.
    for (segments, camera, local) in [
        (&source.combo, view_proj, Matrix4::IDENTITY),
        (&source.field, field_camera, field_model),
        (&source.judgment, view_proj, Matrix4::IDENTITY),
    ] {
        if let Some(segments) = segments {
            for children in segments {
                out.push(Actor::SharedTransform {
                    isolate_order: true,
                    transform: root.inverse() * camera * model * local * world_to_local,
                    source_view_proj: source_root,
                    children: Arc::clone(children),
                    z,
                    tint: [1.0; 4],
                    blend: None,
                });
            }
        }
    }
}

fn append_manual_screen(
    out: &mut Vec<Actor>,
    source: SongLuaProxySource<'_>,
    state: SongLuaOverlayState,
    parents: &[SongLuaOverlayState],
    camera: SongLuaDrawCamera,
    screen: [f32; 2],
    source_metrics: deadlib_present::space::Metrics,
    source_screen: [f32; 2],
    clock: [f32; 2],
    z: i16,
) {
    let mut model = Matrix4::IDENTITY;
    for parent in parents.iter().chain(std::iter::once(&state)) {
        let (matrix, tint) = song_lua_draw_matrix(*parent, clock);
        if !parent.draw_visible() || (tint[3] <= 0.0 && parent.glow[3] <= 0.0) {
            return;
        }
        model *= matrix;
    }
    let source_canvas = Matrix4::from_scale(Vector3::new(
        (source_metrics.right - source_metrics.left) / source_screen[0],
        (source_metrics.top - source_metrics.bottom) / source_screen[1],
        1.0,
    ));
    let canvas = Matrix4::from_scale(Vector3::new(
        screen_width() / screen[0],
        screen_height() / screen[1],
        1.0,
    ));
    let local = Matrix4::from_translation(Vector3::new(-source_metrics.left, source_metrics.top, 0.0))
        * Matrix4::from_scale(Vector3::new(1.0, -1.0, 1.0));
    let view_proj = camera.view_proj(screen[0], screen[1]).map_or_else(
        || song_lua_screen_proj(1000.0),
        |camera| camera.projection * camera.view * camera.world,
    );
    let root = song_lua_proxy_source_view_proj();
    let source_root = source_metrics.projection();
    for children in source.segments {
        out.push(Actor::SharedTransform {
            isolate_order: true,
            transform: root.inverse() * view_proj * canvas * model * source_canvas.inverse() * local,
            source_view_proj: source_root,
            children: Arc::clone(children),
            z,
            tint: [1.0; 4],
            blend: None,
        });
    }
}

// The bounded draw program stays together: begin/finish change the destination,
// and each leaf consumes its own immutable snapshot instead of final state.
fn song_lua_draw_owner<S: NoteskinSlot + Clone>(
    out: &mut Vec<Actor>,
    targets: &mut Vec<deadlib_present::actors::RenderTarget>,
    overlays: &[SongLuaOverlayActor<S>],
    states: &[SongLuaOverlayState],
    topology: &SongLuaOverlayTopologyIndex,
    scratch: &mut SongLuaManualScratch,
    frame_index: usize,
    owner: usize,
    sources: &SongLuaScreenProxySources<'_>,
    assets: &AssetManager,
    screen: [f32; 2],
    clock: [f32; 2],
    elapsed: impl Into<SongLuaDrawTime>,
    z: i16,
) {
    let elapsed = elapsed.into();
    let source_metrics = deadlib_present::space::current_metrics();
    let source_size = [source_metrics.right - source_metrics.left,
        source_metrics.top - source_metrics.bottom];
    let frame = &scratch.frames[frame_index];
    let Some(batch) = frame.owners.iter().position(|index| *index == owner) else {
        return;
    };
    let start = batch
        .checked_sub(1)
        .map_or(0, |index| frame.owner_ends[index]);
    let end = frame.owner_ends[batch];
    let slots = &mut scratch.banks[scratch.bank];
    let stack = &mut scratch.targets;
    for op_index in start..end {
        match &frame.ops[op_index] {
            SongLuaDrawOp::Begin { capture, .. } => {
                slots[op_index].actors.clear();
                slots[op_index].viewport = song_lua_aft_size(&overlays[*capture], states[*capture])
                    .map(|size| song_lua_capture_size(size).1.map(|value| value as f32))
                    .unwrap_or(source_size);
                stack.push(op_index);
            }
            SongLuaDrawOp::Finish { capture } => {
                let begin = stack
                    .pop()
                    .expect("compiled capture program has balanced targets");
                let SongLuaDrawOp::Begin { preserve, .. } = frame.ops[begin] else {
                    unreachable!()
                };
                let SongLuaOverlayKind::ActorFrameTexture {
                    alpha_buffer,
                    depth_buffer,
                    float_buffer,
                    ..
                } = overlays[*capture].kind
                else {
                    continue;
                };
                let Some(size) = song_lua_aft_size(&overlays[*capture], states[*capture]) else {
                    continue;
                };
                let (backing, viewport) = song_lua_capture_size(size);
                let size = viewport.map(|value| value as f32);
                let slot = &mut slots[begin];
                // An empty manual capture must still clear the previous image.
                let children = slot
                    .capture
                    .refill([0.0; 2], |children| {
                        children.push(Actor::CameraPush {
                            // Leaf builders cancel this ±1 outer projection
                            // before applying the native ±1000 camera once.
                            view_proj: deadlib_present::space::Metrics::centered(size[0], size[1]).projection(),
                        });
                        children.append(&mut slot.actors);
                        children.push(Actor::CameraPop);
                    })
                    .expect("capture includes its camera scope");
                targets.push(deadlib_present::actors::RenderTarget {
                    texture_handle: topology.aft_texture_handles[*capture],
                    size: backing,
                    viewport,
                    logical_size: size,
                    float_color: float_buffer,
                    alpha: alpha_buffer,
                    depth: depth_buffer,
                    preserve,
                    children,
                });
            }
            op @ SongLuaDrawOp::Draw {
                source,
                state,
                parents,
                camera,
                ..
            } => {
                let captured = stack.last().copied();
                let viewport = captured.map_or(source_size, |begin| slots[begin].viewport);
                let draw_screen = if captured.is_some() { viewport } else { screen };
                // Resolve native ActorFrame cameras while the original screen
                // metrics are still active; only the default target camera is
                // image-sized. BeginRenderingTo already reset the draw stack.
                let camera = SongLuaDrawCamera::from(*camera).resolve_for(screen);
                let metrics = if captured.is_some() {
                    deadlib_present::space::Metrics::centered(viewport[0], viewport[1])
                } else {
                    source_metrics
                };
                deadlib_present::space::with_current_metrics(metrics, || {
                    let slot = &mut slots[op_index];
                    slot.actors.clear();
                    slot.viewport = viewport;
                    if let Some(vertices) = &scratch.meshes[frame_index][op_index] {
                        if let Some(actor) = song_lua_manual_mesh(
                            overlays, topology, op, vertices, camera, assets, draw_screen, clock, z,
                        ) {
                            slot.actors.push(actor);
                        }
                    } else if let SongLuaDrawSource::Overlay(index) = source {
                        let mut mesh = slot
                            .meshes
                            .iter_mut()
                            .find_map(|(source, mesh)| (source == index).then_some(mesh));
                        let mut composed = *state;
                        for parent in parents.iter().rev() {
                            let mut parent = *parent;
                            // Custom Draw callbacks do not pass their own diffuse
                            // to an explicitly drawn actor (ActorFrame.cpp).
                            parent.diffuse = [1.0; 4];
                            parent.glow[3] = 0.0;
                            composed = song_lua_overlay_compose_state(
                                &SongLuaOverlayKind::<S>::ActorFrame,
                                parent,
                                composed,
                                draw_screen[0],
                                draw_screen[1],
                                clock,
                            );
                        }
                        if let SongLuaOverlayKind::AftSprite { .. } = overlays[*index].kind {
                            if let Some(target) = topology.aft_sprite_targets[*index].get()
                                && let Some(size) = song_lua_aft_size(&overlays[target], states[target])
                                && let Some(actors) = build_song_lua_aft_sprite_actor(
                                    composed,
                                    topology.aft_texture_handles[target],
                                    size,
                                    z,
                                    draw_screen[0],
                                    draw_screen[1],
                                    clock[0],
                                    clock[1],
                                    elapsed.animation_elapsed,
                                    mesh.as_deref_mut(),
                                )
                            {
                                slot.actors.extend(actors);
                            }
                        } else if append_song_lua_multi_actor_overlay(
                            &mut slot.actors,
                            &overlays[*index],
                            composed,
                            camera,
                            assets,
                            z,
                            draw_screen[0],
                            draw_screen[1],
                            clock[0],
                            clock[1],
                            elapsed.animation_elapsed,
                            mesh.as_deref_mut(),
                        )
                        .is_none()
                            && let Some(actors) = build_song_lua_overlay_actor_with_scratch(
                                &overlays[*index],
                                composed,
                                camera,
                                assets,
                                z,
                                draw_screen[0],
                                draw_screen[1],
                                clock[0],
                                clock[1],
                                elapsed,
                                topology.texture_handle(*index),
                                mesh.as_deref_mut(),
                            )
                        {
                            slot.actors.extend(actors);
                        }
                    } else if let SongLuaDrawSource::Player(index) = source {
                        if let Some(source) = sources.manual_players[*index] {
                            append_manual_player(
                                &mut slot.actors,
                                source,
                                *state,
                                parents,
                                camera,
                                draw_screen,
                                source_metrics,
                                screen,
                                clock,
                                z,
                            );
                        }
                    } else {
                        let source = match source {
                            SongLuaDrawSource::Judgment(index) => sources.players[*index].judgment,
                            SongLuaDrawSource::Combo(index) => sources.players[*index].combo,
                            SongLuaDrawSource::ScreenLayer(0) => {
                                sources.underlay.map(SongLuaProxySource::new)
                            }
                            SongLuaDrawSource::ScreenLayer(1) => {
                                sources.overlay.map(SongLuaProxySource::new)
                            }
                            SongLuaDrawSource::ScreenLayer(2) => {
                                sources.background.map(SongLuaProxySource::new)
                            }
                            SongLuaDrawSource::ScreenLayer(3) => {
                                sources.stage.map(SongLuaProxySource::new)
                            }
                            _ => None,
                        };
                        if let Some(source) = source {
                            if matches!(
                                op,
                                SongLuaDrawOp::Draw {
                                    source: SongLuaDrawSource::ScreenLayer(_),
                                    ..
                                }
                            ) {
                                append_manual_screen(
                                    &mut slot.actors,
                                    source,
                                    *state,
                                    parents,
                                    camera,
                                    draw_screen,
                                    source_metrics,
                                    screen,
                                    clock,
                                    z,
                                );
                            } else {
                                for segment in source.segments {
                                    slot.actors.push(Actor::SharedFrame {
                                        align: [0.0; 2],
                                        offset: [0.0; 2],
                                        size: [SizeSpec::Fill; 2],
                                        children: Arc::clone(segment),
                                        background: None,
                                        z,
                                        tint: [1.0; 4],
                                        blend: None,
                                    });
                                }
                            }
                        }
                    }
                    if captured.is_some()
                        && matches!(source, SongLuaDrawSource::Player(_) | SongLuaDrawSource::ScreenLayer(_))
                        && let Some(source_layout) = &mut slot.source_layout
                        && let Some(children) = source_layout.refill([0.0; 2], |children| {
                            children.append(&mut slot.actors);
                        })
                    {
                        // Existing shared source actors were authored for the
                        // original screen. Preserve both their layout extent
                        // and world origin under the destination's metrics.
                        slot.actors.push(Actor::SharedFrame {
                            align: [0.0; 2],
                            offset: [source_metrics.left - metrics.left,
                                metrics.top - source_metrics.top],
                            size: source_size.map(SizeSpec::Px),
                            children,
                            background: None,
                            z: 0,
                            tint: [1.0; 4],
                            blend: None,
                        });
                    }
                });
                let slot = &mut slots[op_index];
                if let Some(&begin) = stack.last() {
                    let [draw, target] = slots
                        .get_disjoint_mut([op_index, begin])
                        .expect("draw and begin are distinct operations");
                    target.actors.extend(draw.actors.iter().cloned());
                } else if matches!(
                    source,
                    SongLuaDrawSource::Player(_)
                        | SongLuaDrawSource::Overlay(_)
                        | SongLuaDrawSource::ScreenLayer(_)
                ) {
                    // Recorded draws include their full parent stack. Replay in
                    // that absolute space, including singular parent scales.
                    if let Some(children) = slot.capture.refill([0.0; 2], |children| {
                        children.extend(slot.actors.iter().cloned())
                    }) {
                        out.push(Actor::SharedCamera {
                            view_proj: song_lua_proxy_source_view_proj(),
                            children,
                        });
                    }
                } else {
                    out.extend(slots[op_index].actors.iter().cloned());
                }
            }
        }
    }
    debug_assert!(stack.is_empty());
}

fn song_lua_aft_actor_capacity<S: NoteskinSlot + Clone>(kind: &SongLuaOverlayKind<S>) -> usize {
    match kind {
        SongLuaOverlayKind::Actor
        | SongLuaOverlayKind::ActorFrame
        | SongLuaOverlayKind::WrapperState
        | SongLuaOverlayKind::ActorFrameTexture { .. }
        | SongLuaOverlayKind::Sound { .. } => 0,
        SongLuaOverlayKind::AftSprite { .. } => 2,
        SongLuaOverlayKind::ActorProxy { .. } => 1,
        SongLuaOverlayKind::Model { layers } => layers.len().saturating_mul(2),
        SongLuaOverlayKind::NoteskinActor { slots, .. } => slots.len().saturating_mul(2),
        _ => 2,
    }
}

fn song_lua_aft_capture_capacity<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    topology: &SongLuaOverlayTopologyIndex,
    capture_index: usize,
) -> usize {
    overlays
        .iter()
        .enumerate()
        .filter(|(index, _)| {
            topology
                .aft_ancestors
                .get(*index)
                .copied()
                .and_then(SongLuaOverlayIndex::get)
                == Some(capture_index)
        })
        .fold(4usize, |capacity, (_, overlay)| {
            capacity.saturating_add(song_lua_aft_actor_capacity(&overlay.kind))
        })
}

#[derive(Clone, Copy)]
struct SongLuaCaptureTransform {
    z_shift: i16,
    tint: [f32; 4],
    blend: Option<BlendMode>,
    playfield_center_x: f32,
    target_x: f32,
    target_y: f32,
    rotation_x: f32,
    rotation_z: f32,
    rotation_y: f32,
    skew_x: f32,
    skew_y: f32,
    zoom_x: f32,
    zoom_y: f32,
    zoom_z: f32,
    /// Player Z translation (BeginDraw), toward the camera.
    target_z: f32,
    /// Native screen-space matrix of the Player's wrapper states.
    wrappers: Matrix4,
    /// Menu camera and child NoteField model, kept apart so Player precedes
    /// the child's wrappers and tilt even when either has zero zoom.
    field_camera_parts: Option<(Matrix4, Matrix4)>,
}

#[inline(always)]
fn song_lua_overlay_is_visible(state: SongLuaOverlayState) -> bool {
    state.sprite_texture && state.draw_visible() && state.diffuse[3] > f32::EPSILON
}

#[inline(always)]
fn song_lua_capture_new_actors(
    dest: &mut Option<SongLuaActorSegments>,
    actors: &mut Vec<Actor>,
    start: usize,
    scratch: Option<&mut SongLuaProxyActorScratch>,
    retain_original: bool,
) {
    let Some(dest) = dest.as_mut() else {
        return;
    };
    let children = scratch
        .and_then(SongLuaProxyActorScratch::next_screen)
        .and_then(|scratch| scratch.capture_range(actors, start))
        .or_else(|| song_lua_capture_new_actors_owned(actors, start));
    let Some(children) = children else { return };
    dest.push(Arc::clone(&children));
    if retain_original {
        actors.push(Actor::SharedFrame {
            align: [0.0, 0.0],
            offset: [0.0, 0.0],
            size: [SizeSpec::Fill, SizeSpec::Fill],
            children,
            background: None,
            z: 0,
            tint: [1.0; 4],
            blend: None,
        });
    }
}

fn song_lua_capture_screen_actors(
    dest: &mut Option<SongLuaActorSegments>,
    actors: &mut Vec<Actor>,
    start: usize,
    scratch: Option<&mut SongLuaProxyActorScratch>,
    retain_original: bool,
    projections: &mut Vec<SongLuaScreenProjectionRange>,
    originals: &SongLuaScreenCaptureOriginals,
) {
    if dest.is_none() {
        return;
    }
    let has_projection = projections.last().is_some_and(|range| range.end > start);
    let has_originals = originals.ranges.iter().any(|range| {
        range.start >= start && range.end <= actors.len()
    });
    if !has_originals && (!retain_original || !has_projection) {
        song_lua_capture_new_actors(dest, actors, start, scratch, retain_original);
        if !retain_original {
            projections.retain(|range| range.end <= start);
        }
        return;
    }
    // Background proxies capture their target before ScreenGameplay's model.
    // Replace only leaves that baked that model, preserving HUD, AFT, and
    // immediate-draw spans. Retained ordinary actors keep their original indices
    // so the presentation's borrowed projection ranges remain valid.
    let fill = |children: &mut Vec<Actor>| {
        let mut cursor = start;
        for range in originals.ranges.iter().filter(|range| {
            range.start >= start && range.end <= actors.len()
        }) {
            debug_assert!(range.start >= cursor && range.end >= range.start);
            children.extend_from_slice(&actors[cursor..range.start]);
            children.extend_from_slice(
                &originals.actors[range.original_start..range.original_end],
            );
            cursor = range.end;
        }
        children.extend_from_slice(&actors[cursor..]);
    };
    let children = scratch
        .and_then(SongLuaProxyActorScratch::next_screen)
        .and_then(|scratch| {
            scratch.refill([0.0; 2], fill)
        })
        .or_else(|| {
            let mut children = Vec::with_capacity(actors.len() - start + originals.actors.len());
            fill(&mut children);
            (!children.is_empty()).then(|| Arc::from(children))
        });
    if let Some(children) = children {
        dest.as_mut()
            .expect("capture destination was checked")
            .push(children);
    }
    if !retain_original {
        actors.truncate(start);
        projections.retain(|range| range.end <= start);
    }
}

fn song_lua_capture_new_actors_owned(
    actors: &mut Vec<Actor>,
    start: usize,
) -> Option<Arc<[Actor]>> {
    if start >= actors.len() {
        return None;
    }
    Some(Arc::from_iter(actors.drain(start..)))
}

#[cfg(test)]
fn song_lua_player_child_proxy_source(
    actors: &mut Vec<Actor>,
    origin_x: f32,
    origin_y: f32,
    scratch: &mut SharedActorFrameScratch,
) -> Option<SongLuaSingleSource> {
    scratch
        .refill([-origin_x, -origin_y], |children| children.append(actors))
        .map(|source| [source])
}

fn song_lua_render_captured_source(
    field_source: Option<&CapturedActorSource>,
    hud_source: Option<&CapturedActorSource>,
    transform: SongLuaCaptureTransform,
    scratch: &mut SharedActorFrameScratch,
) -> Option<SongLuaSingleSource> {
    if field_source.is_none() && hud_source.is_none() {
        return None;
    }
    let field_len = field_source.map_or(0, |source| {
        source
            .iter()
            .map(|segment| song_lua_note_field_proxy_actors(segment).len())
            .sum()
    });
    let hud_len = hud_source.map_or(0, |source| {
        source
            .iter()
            .map(|segment| song_lua_captured_segment_actors(segment).len())
            .sum()
    });
    let field_has_camera = field_source.is_some_and(|source| {
        source.iter().any(|segment| {
            song_lua_note_field_proxy_actors(segment)
                .iter()
                .any(|actor| {
                    matches!(
                        actor,
                        Actor::Camera { .. } | Actor::CameraPush { .. } | Actor::CameraPop
                    )
                })
        })
    });
    let field_actors = field_source
        .into_iter()
        .flat_map(|source| source.iter())
        .flat_map(|segment| song_lua_note_field_proxy_actors(segment).iter().cloned());
    let hud_actors = hud_source
        .into_iter()
        .flat_map(|source| source.iter())
        .flat_map(|segment| song_lua_captured_segment_actors(segment).iter().cloned());
    scratch
        .refill([0.0, 0.0], |out| {
            append_song_lua_player_transform(
                field_actors,
                hud_actors,
                field_len,
                hud_len,
                field_has_camera,
                out,
                transform.z_shift,
                transform.tint,
                transform.blend,
                transform.playfield_center_x,
                transform.target_x,
                transform.target_y,
                transform.rotation_x,
                transform.rotation_z,
                transform.rotation_y,
                transform.skew_x,
                transform.skew_y,
                transform.zoom_x,
                transform.zoom_y,
                transform.zoom_z,
                transform.target_z,
                transform.wrappers,
                transform.field_camera_parts,
            );
        })
        .map(|source| [source])
}

fn prepare_proxy_source(
    source: CapturedActorSource,
    part: ProxyCapturePart,
    transform: SongLuaCaptureTransform,
    scratch: &mut SharedActorFrameScratch,
) -> Option<PreparedProxySource> {
    if song_lua_player_transform_is_direct_identity(transform) {
        if matches!(part, ProxyCapturePart::Field)
            && source.iter().any(|segment| {
                song_lua_note_field_proxy_actors(segment).len()
                    != song_lua_captured_segment_actors(segment).len()
            })
        {
            let segments = scratch
                .refill([0.0, 0.0], |out| {
                    out.extend(source.iter().flat_map(|segment| {
                        song_lua_note_field_proxy_actors(segment).iter().cloned()
                    }));
                })
                .map(|source| [source])?;
            return Some(PreparedProxySource {
                segments,
                offset: [-transform.target_x, -transform.target_y],
                root_camera: false,
                model: None,
            });
        }
        return Some(PreparedProxySource {
            segments: source,
            offset: [-transform.target_x, -transform.target_y],
            root_camera: false,
            model: None,
        });
    }
    let segments = match part {
        ProxyCapturePart::Field => {
            song_lua_render_captured_source(Some(&source), None, transform, scratch)
        }
        ProxyCapturePart::Hud => {
            song_lua_render_captured_source(None, Some(&source), transform, scratch)
        }
    }?;
    Some(PreparedProxySource {
        segments,
        offset: [-transform.target_x, -transform.target_y],
        root_camera: true,
        model: None,
    })
}

fn prepare_flat_proxy_source(
    draws: &[FlatDraw],
    transform: SongLuaCaptureTransform,
    scratch: &mut SharedActorFrameScratch,
) -> Option<PreparedProxySource> {
    if draws.is_empty() {
        return None;
    }
    if song_lua_player_transform_is_direct_identity(transform) {
        let segments = scratch
            .refill([0.0, 0.0], |out| {
                out.extend(draws.iter().cloned().map(actor_from_flat_draw));
            })
            .map(|source| [source])?;
        return Some(PreparedProxySource {
            segments,
            offset: [-transform.target_x, -transform.target_y],
            root_camera: false,
            model: None,
        });
    }

    let segments = scratch
        .refill([0.0, 0.0], |out| {
            append_song_lua_player_transform(
                std::iter::empty(),
                draws.iter().cloned().map(actor_from_flat_draw),
                0,
                draws.len(),
                false,
                out,
                transform.z_shift,
                transform.tint,
                transform.blend,
                transform.playfield_center_x,
                transform.target_x,
                transform.target_y,
                transform.rotation_x,
                transform.rotation_z,
                transform.rotation_y,
                transform.skew_x,
                transform.skew_y,
                transform.zoom_x,
                transform.zoom_y,
                transform.zoom_z,
                transform.target_z,
                transform.wrappers,
                transform.field_camera_parts,
            );
        })
        .map(|source| [source])?;
    Some(PreparedProxySource {
        segments,
        offset: [-transform.target_x, -transform.target_y],
        root_camera: true,
        model: None,
    })
}

fn prepare_field_proxy_source(
    actors: &[Actor],
    draws: &[FlatDraw],
    camera: Option<Matrix4>,
    transform: SongLuaCaptureTransform,
    scratch: &mut SharedActorFrameScratch,
) -> Option<PreparedProxySource> {
    if actors.is_empty() && draws.is_empty() {
        return None;
    }
    let field_len = actors.len() + draws.len() + usize::from(camera.is_some()) * 2;
    let field_actors = || {
        camera
            .map(|view_proj| Actor::CameraPush { view_proj })
            .into_iter()
            .chain(actors.iter().cloned())
            .chain(draws.iter().cloned().map(actor_from_flat_draw))
            .chain(camera.map(|_| Actor::CameraPop))
    };
    if song_lua_player_transform_is_direct_identity(transform) {
        let segments = scratch
            .refill([0.0, 0.0], |out| out.extend(field_actors()))
            .map(|source| [source])?;
        return Some(PreparedProxySource {
            segments,
            offset: [-transform.target_x, -transform.target_y],
            root_camera: false,
            model: None,
        });
    }
    let segments = scratch
        .refill([0.0, 0.0], |out| {
            append_song_lua_player_transform(
                field_actors(),
                std::iter::empty(),
                field_len,
                0,
                camera.is_some(),
                out,
                transform.z_shift,
                transform.tint,
                transform.blend,
                transform.playfield_center_x,
                transform.target_x,
                transform.target_y,
                transform.rotation_x,
                transform.rotation_z,
                transform.rotation_y,
                transform.skew_x,
                transform.skew_y,
                transform.zoom_x,
                transform.zoom_y,
                transform.zoom_z,
                transform.target_z,
                transform.wrappers,
                transform.field_camera_parts,
            );
        })
        .map(|source| [source])?;
    Some(PreparedProxySource {
        segments,
        offset: [-transform.target_x, -transform.target_y],
        root_camera: true,
        model: None,
    })
}

fn capture_player_source(
    field_actors: &mut Vec<Actor>,
    hud_actors: &mut Vec<Actor>,
    combo_end: usize,
    transform: SongLuaCaptureTransform,
    scratch: &mut SharedActorFrameScratch,
) -> Option<SongLuaSingleSource> {
    if song_lua_player_transform_is_direct_identity(transform) {
        return scratch
            .refill([0.0, 0.0], |out| {
                out.reserve(field_actors.len().saturating_add(hud_actors.len()));
                out.extend(hud_actors.drain(..combo_end));
                out.append(field_actors);
                out.append(hud_actors);
            })
            .map(|source| [source]);
    }

    let field_len = field_actors.len();
    let hud_len = hud_actors.len();
    let field_has_camera = field_actors.iter().any(|actor| {
        matches!(
            actor,
            Actor::Camera { .. } | Actor::CameraPush { .. } | Actor::CameraPop
        )
    });
    scratch
        .refill([0.0, 0.0], |out| {
            let mut hud = hud_actors.drain(..);
            append_song_lua_player_transform(
                field_actors.drain(..),
                hud.by_ref().take(combo_end),
                field_len,
                combo_end,
                field_has_camera,
                out,
                transform.z_shift,
                transform.tint,
                transform.blend,
                transform.playfield_center_x,
                transform.target_x,
                transform.target_y,
                transform.rotation_x,
                transform.rotation_z,
                transform.rotation_y,
                transform.skew_x,
                transform.skew_y,
                transform.zoom_x,
                transform.zoom_y,
                transform.zoom_z,
                transform.target_z,
                transform.wrappers,
                transform.field_camera_parts,
            );
            append_song_lua_player_transform(
                std::iter::empty(),
                hud,
                0,
                hud_len - combo_end,
                false,
                out,
                transform.z_shift,
                transform.tint,
                transform.blend,
                transform.playfield_center_x,
                transform.target_x,
                transform.target_y,
                transform.rotation_x,
                transform.rotation_z,
                transform.rotation_y,
                transform.skew_x,
                transform.skew_y,
                transform.zoom_x,
                transform.zoom_y,
                transform.zoom_z,
                transform.target_z,
                transform.wrappers,
                transform.field_camera_parts,
            );
        })
        .map(|source| [source])
}

#[allow(clippy::too_many_arguments)]
fn capture_flat_player_source(
    field_actors: &mut Vec<Actor>,
    field_draws: &[FlatDraw],
    field_camera: Option<Matrix4>,
    hud_actors: &mut Vec<Actor>,
    hud_draws: &[FlatDraw],
    combo_end: usize,
    transform: SongLuaCaptureTransform,
    scratch: &mut SharedActorFrameScratch,
) -> Option<SongLuaSingleSource> {
    hud_actors.extend(hud_draws.iter().cloned().map(actor_from_flat_draw));
    if let Some(view_proj) = field_camera {
        field_actors.insert(0, Actor::CameraPush { view_proj });
    }
    field_actors.extend(field_draws.iter().cloned().map(actor_from_flat_draw));
    if field_camera.is_some() {
        field_actors.push(Actor::CameraPop);
    }
    capture_player_source(field_actors, hud_actors, combo_end, transform, scratch)
}

fn song_lua_captured_segment_actors(segment: &[Actor]) -> &[Actor] {
    match segment {
        [
            Actor::Frame {
                align: [0.0, 0.0],
                offset: [0.0, 0.0],
                size: [SizeSpec::Fill, SizeSpec::Fill],
                children,
                background: None,
                z: 0,
            },
        ] => children,
        _ => segment,
    }
}

fn song_lua_captured_camera_range(actors: &[Actor], camera: Matrix4) -> Option<[usize; 2]> {
    for (start, actor) in actors.iter().enumerate() {
        match actor {
            Actor::Camera { view_proj, .. } if *view_proj == camera => {
                return Some([start, start + 1]);
            }
            Actor::CameraPush { view_proj } if *view_proj == camera => {
                let mut depth = 1usize;
                for (offset, actor) in actors[start + 1..].iter().enumerate() {
                    match actor {
                        Actor::CameraPush { .. } => depth += 1,
                        Actor::CameraPop => {
                            depth -= 1;
                            if depth == 0 {
                                return Some([start, start + offset + 2]);
                            }
                        }
                        _ => {}
                    }
                }
                return None;
            }
            _ => {}
        }
    }
    None
}

fn song_lua_note_field_proxy_actors(segment: &[Actor]) -> &[Actor] {
    let actors = song_lua_captured_segment_actors(segment);
    match actors {
        [Actor::CameraPush { .. }, contents @ .., Actor::CameraPop] => contents,
        _ => actors,
    }
}

#[inline(always)]
fn song_lua_proxy_source<'a>(
    target: &SongLuaProxyTarget,
    proxy_sources: &SongLuaScreenProxySources<'a>,
) -> Option<SongLuaProxySource<'a>> {
    let source = match target {
        SongLuaProxyTarget::Player { player_index } => proxy_sources
            .players
            .get(*player_index)
            .and_then(|sources| sources.player.filter(|source| !source.is_empty())),
        SongLuaProxyTarget::NoteField { player_index } => proxy_sources
            .players
            .get(*player_index)
            .and_then(|sources| sources.note_field.filter(|source| !source.is_empty())),
        SongLuaProxyTarget::Judgment { player_index } => proxy_sources
            .players
            .get(*player_index)
            .and_then(|sources| sources.judgment.filter(|source| !source.is_empty())),
        SongLuaProxyTarget::Combo { player_index } => proxy_sources
            .players
            .get(*player_index)
            .and_then(|sources| sources.combo.filter(|source| !source.is_empty())),
        SongLuaProxyTarget::Score { player_index } => proxy_sources
            .scores
            .get(*player_index)
            .copied()
            .flatten()
            .map(SongLuaProxySource::new),
        SongLuaProxyTarget::Underlay { .. } => proxy_sources
            .underlay
            .filter(|segments| !segments.is_empty())
            .map(SongLuaProxySource::new),
        SongLuaProxyTarget::Overlay { .. } => proxy_sources
            .overlay
            .filter(|segments| !segments.is_empty())
            .map(SongLuaProxySource::new),
        SongLuaProxyTarget::Actor { .. } => None,
    };
    source.map(|source| source.with_pool_class(song_lua_proxy_pool_class(target)))
}

fn song_lua_mark_proxy_target(
    requests: &mut SongLuaScreenProxyRequests,
    target: &SongLuaProxyTarget,
) {
    match target {
        SongLuaProxyTarget::Player { player_index } => {
            if let Some(player) = requests.players.get_mut(*player_index) {
                player.player = true;
            }
        }
        SongLuaProxyTarget::NoteField { player_index } => {
            if let Some(player) = requests.players.get_mut(*player_index) {
                player.note_field = true;
            }
        }
        SongLuaProxyTarget::Judgment { player_index } => {
            if let Some(player) = requests.players.get_mut(*player_index) {
                player.judgment = true;
            }
        }
        SongLuaProxyTarget::Combo { player_index } => {
            if let Some(player) = requests.players.get_mut(*player_index) {
                player.combo = true;
            }
        }
        SongLuaProxyTarget::Score { player_index } => {
            if let Some(score) = requests.scores.get_mut(*player_index) {
                *score = true;
            }
        }
        SongLuaProxyTarget::Underlay { hidden } => {
            requests.underlay = true;
            requests.hide_underlay |= *hidden;
        }
        SongLuaProxyTarget::Overlay { hidden } => {
            requests.overlay = true;
            requests.hide_overlay |= *hidden;
        }
        SongLuaProxyTarget::Actor { .. } => {}
    }
}
fn song_lua_collect_capture_requests_indexed<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    capture_index: usize,
    index: &SongLuaProxyRequestIndex,
    requests: &mut SongLuaScreenProxyRequests,
    visit_scratch: &mut SongLuaCaptureVisitScratch,
) {
    if song_lua_aft_size(&overlays[capture_index], overlay_states[capture_index]).is_none()
        || !visit_scratch.visit(capture_index)
    {
        return;
    }
    let Some(children) = index.capture_children.get(capture_index) else {
        return;
    };
    for &overlay_index in children {
        let Some(overlay_state) = overlay_states.get(overlay_index).copied() else {
            continue;
        };
        if !song_lua_overlay_is_visible(overlay_state) {
            continue;
        }
        match &overlays[overlay_index].kind {
            SongLuaOverlayKind::ActorProxy { target } => {
                song_lua_mark_proxy_target(requests, target);
            }
            SongLuaOverlayKind::AftSprite { .. } => {
                if !overlay_state.sprite_texture {
                    continue;
                }
                if let Some(nested_capture) = index
                    .topology
                    .aft_sprite_targets
                    .get(overlay_index)
                    .copied()
                    .and_then(SongLuaOverlayIndex::get)
                {
                    song_lua_collect_capture_requests_indexed(
                        overlays,
                        overlay_states,
                        nested_capture,
                        index,
                        requests,
                        visit_scratch,
                    );
                }
            }
            _ => {}
        }
    }
}

#[cfg(test)]
fn song_lua_proxy_requests_indexed<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    index: &SongLuaProxyRequestIndex,
    visit_scratch: &mut SongLuaCaptureVisitScratch,
) -> SongLuaScreenProxyRequests {
    if index.proxy_indices.is_empty() {
        return SongLuaScreenProxyRequests::default();
    }
    song_lua_proxy_request_analysis_indexed_active(overlays, overlay_states, index, visit_scratch)
        .all
}

fn song_lua_proxy_request_analysis_indexed<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    index: &SongLuaProxyRequestIndex,
    visit_scratch: &mut SongLuaCaptureVisitScratch,
) -> SongLuaProxyRequestAnalysis {
    if index.proxy_indices.is_empty() {
        return SongLuaProxyRequestAnalysis::default();
    }
    song_lua_proxy_request_analysis_indexed_active(overlays, overlay_states, index, visit_scratch)
}

fn song_lua_proxy_request_analysis_indexed_active<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    index: &SongLuaProxyRequestIndex,
    visit_scratch: &mut SongLuaCaptureVisitScratch,
) -> SongLuaProxyRequestAnalysis {
    let mut analysis = SongLuaProxyRequestAnalysis::default();
    visit_scratch.begin(overlays.len());
    // Only root proxies and root AFT sprites contribute. Proxy marks are ORed
    // and counts saturate, so visiting the two kinds separately is equivalent.
    for &overlay_index in &index.proxy_indices {
        if !song_lua_overlay_is_aft_root(index, overlay_index) {
            continue;
        }
        let Some(overlay_state) = overlay_states.get(overlay_index).copied() else {
            continue;
        };
        if !song_lua_overlay_is_visible(overlay_state) {
            continue;
        }
        let SongLuaOverlayKind::ActorProxy { target } = &overlays[overlay_index].kind else {
            continue;
        };
        song_lua_mark_proxy_target(&mut analysis.all, target);
        match target {
            SongLuaProxyTarget::Player { player_index } => {
                if let Some(count) = analysis.root_players.get_mut(*player_index) {
                    *count = count.saturating_add(1);
                }
            }
            SongLuaProxyTarget::NoteField { player_index } => {
                if let Some(count) = analysis.root_note_fields.get_mut(*player_index) {
                    *count = count.saturating_add(1);
                }
            }
            SongLuaProxyTarget::Judgment { player_index } => {
                if let Some(count) = analysis.root_judgments.get_mut(*player_index) {
                    *count = count.saturating_add(1);
                }
            }
            SongLuaProxyTarget::Combo { player_index } => {
                if let Some(count) = analysis.root_combos.get_mut(*player_index) {
                    *count = count.saturating_add(1);
                }
            }
            _ => {}
        }
    }
    for &overlay_index in &index.topology.aft_sprite_indices {
        if !song_lua_overlay_is_aft_root(index, overlay_index) {
            continue;
        }
        let Some(overlay_state) = overlay_states.get(overlay_index).copied() else {
            continue;
        };
        if !song_lua_overlay_is_visible(overlay_state) || !overlay_state.sprite_texture {
            continue;
        }
        if let Some(capture_index) = index
            .topology
            .aft_sprite_targets
            .get(overlay_index)
            .copied()
            .and_then(SongLuaOverlayIndex::get)
        {
            song_lua_collect_capture_requests_indexed(
                overlays,
                overlay_states,
                capture_index,
                index,
                &mut analysis.captured,
                visit_scratch,
            );
        }
    }
    song_lua_merge_proxy_requests(&mut analysis.all, analysis.captured);
    analysis
}

/// Whether an overlay draws at the layer root rather than inside an AFT capture.
#[inline(always)]
fn song_lua_overlay_is_aft_root(index: &SongLuaProxyRequestIndex, overlay_index: usize) -> bool {
    index
        .topology
        .aft_ancestors
        .get(overlay_index)
        .copied()
        .and_then(SongLuaOverlayIndex::get)
        .is_none()
}

fn song_lua_covering_capture_requests<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    local_overlay_states: &[SongLuaOverlayState],
    overlay_states: &[SongLuaOverlayState],
    index: &SongLuaProxyRequestIndex,
    overlay_space_width: f32,
    overlay_space_height: f32,
    visit_scratch: &mut SongLuaCaptureVisitScratch,
) -> SongLuaScreenProxyRequests {
    if index.proxy_indices.is_empty() {
        return SongLuaScreenProxyRequests::default();
    }
    let mut requests = SongLuaScreenProxyRequests::default();
    for &overlay_index in &index.topology.aft_sprite_indices {
        if !song_lua_overlay_is_aft_root(index, overlay_index) {
            continue;
        }
        let Some(overlay_state) = overlay_states.get(overlay_index).copied() else {
            continue;
        };
        if !overlay_state.sprite_texture {
            continue;
        }
        let Some(capture_index) = index
            .topology
            .aft_sprite_targets
            .get(overlay_index)
            .copied()
            .and_then(SongLuaOverlayIndex::get)
        else {
            continue;
        };
        visit_scratch.begin(overlays.len());
        let Some(opaque_rect) = song_lua_capture_opaque_rect(
            overlays,
            local_overlay_states,
            capture_index,
            index,
            overlay_space_width,
            overlay_space_height,
            visit_scratch,
        ) else {
            continue;
        };
        let Some(capture_state) = local_overlay_states.get(capture_index).copied() else {
            continue;
        };
        let Some(texture_size) = song_lua_aft_size(&overlays[capture_index], capture_state) else {
            continue;
        };
        let Some(screen_rect) = song_lua_map_opaque_rect(overlay_state, texture_size, opaque_rect)
        else {
            continue;
        };
        if !song_lua_rect_covers(
            screen_rect,
            SongLuaOpaqueRect::new(0.0, 0.0, overlay_space_width, overlay_space_height),
        ) {
            continue;
        }
        visit_scratch.begin(overlays.len());
        song_lua_collect_capture_requests_indexed(
            overlays,
            overlay_states,
            capture_index,
            index,
            &mut requests,
            visit_scratch,
        );
    }
    requests
}

#[derive(Clone, Copy, Debug)]
struct SongLuaOpaqueRect {
    left: f32,
    top: f32,
    right: f32,
    bottom: f32,
}

impl SongLuaOpaqueRect {
    const fn new(left: f32, top: f32, right: f32, bottom: f32) -> Self {
        Self {
            left: left.min(right),
            top: top.min(bottom),
            right: left.max(right),
            bottom: top.max(bottom),
        }
    }

    fn area(self) -> f32 {
        (self.right - self.left).max(0.0) * (self.bottom - self.top).max(0.0)
    }
}

fn song_lua_capture_opaque_rect<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    local_overlay_states: &[SongLuaOverlayState],
    capture_index: usize,
    index: &SongLuaProxyRequestIndex,
    overlay_space_width: f32,
    overlay_space_height: f32,
    visit_scratch: &mut SongLuaCaptureVisitScratch,
) -> Option<SongLuaOpaqueRect> {
    if !visit_scratch.visit(capture_index) {
        return None;
    }
    let state = local_overlay_states.get(capture_index).copied()?;
    if !state.draw_visible() {
        return None;
    }
    let SongLuaOverlayKind::ActorFrameTexture { alpha_buffer, .. } =
        overlays.get(capture_index).map(|overlay| &overlay.kind)?
    else {
        return None;
    };
    let size = song_lua_aft_size(&overlays[capture_index], state)?;
    if !*alpha_buffer {
        return Some(SongLuaOpaqueRect::new(0.0, 0.0, size[0], size[1]));
    }
    if state.aft_preserve {
        return None;
    }

    let direct_children = index
        .capture_children
        .get(capture_index)?
        .iter()
        .copied()
        .filter(|&child_index| overlays[child_index].parent_index == Some(capture_index));
    // A strip compositor can cover the target only as the union of many
    // sprites. Treating its largest strip as opaque hides the live screen
    // behind effects such as 7th Gear, so only recurse through one AFT image.
    if direct_children
        .clone()
        .filter(|&child_index| {
            matches!(
                overlays[child_index].kind,
                SongLuaOverlayKind::AftSprite { .. }
            )
        })
        .count()
        > 1
    {
        return None;
    }

    direct_children.fold(None, |largest, child_index| {
        let Some(child_state) = local_overlay_states.get(child_index).copied() else {
            return largest;
        };
        let rect = match overlays.get(child_index).map(|overlay| &overlay.kind) {
            Some(SongLuaOverlayKind::Quad) => {
                let Some(child_size) = child_state.size.or_else(|| {
                    child_state.stretch_rect.map(|[left, top, right, bottom]| {
                        [(right - left).abs(), (bottom - top).abs()]
                    })
                }) else {
                    return largest;
                };
                song_lua_map_opaque_rect(
                    child_state,
                    child_size,
                    SongLuaOpaqueRect::new(0.0, 0.0, child_size[0], child_size[1]),
                )
            }
            Some(SongLuaOverlayKind::AftSprite { .. }) => {
                let Some(target_index) = index
                    .topology
                    .aft_sprite_targets
                    .get(child_index)
                    .copied()
                    .and_then(SongLuaOverlayIndex::get)
                else {
                    return largest;
                };
                let Some(target_state) = local_overlay_states.get(target_index).copied() else {
                    return largest;
                };
                let target_size = target_state
                    .size
                    .unwrap_or([overlay_space_width, overlay_space_height]);
                let Some(source_rect) = song_lua_capture_opaque_rect(
                    overlays,
                    local_overlay_states,
                    target_index,
                    index,
                    overlay_space_width,
                    overlay_space_height,
                    visit_scratch,
                ) else {
                    return largest;
                };
                song_lua_map_opaque_rect(child_state, target_size, source_rect)
            }
            _ => None,
        };
        match (largest, rect) {
            (Some(current), Some(candidate)) if candidate.area() > current.area() => {
                Some(candidate)
            }
            (None, Some(candidate)) => Some(candidate),
            (current, _) => current,
        }
    })
}

fn song_lua_map_opaque_rect(
    state: SongLuaOverlayState,
    texture_size: [f32; 2],
    source: SongLuaOpaqueRect,
) -> Option<SongLuaOpaqueRect> {
    let opaque = song_lua_overlay_is_visible(state)
        && state.diffuse[3] >= 1.0 - f32::EPSILON
        && state
            .vertex_colors
            .is_none_or(|colors| colors.iter().all(|color| color[3] >= 1.0 - f32::EPSILON))
        && state.blend == SongLuaOverlayBlendMode::Alpha
        && !state.mask_source
        && !state.mask_dest
        && !state.depth_test
        && !state.depth_write
        && state.cropleft <= f32::EPSILON
        && state.cropright <= f32::EPSILON
        && state.croptop <= f32::EPSILON
        && state.cropbottom <= f32::EPSILON
        && state.fadeleft <= f32::EPSILON
        && state.faderight <= f32::EPSILON
        && state.fadetop <= f32::EPSILON
        && state.fadebottom <= f32::EPSILON
        && state.rot_x_deg.abs() <= f32::EPSILON
        && state.rot_y_deg.abs() <= f32::EPSILON
        && state.rot_z_deg.abs() <= f32::EPSILON
        && state.skew_x.abs() <= f32::EPSILON
        && state.skew_y.abs() <= f32::EPSILON
        && !state.vibrate
        && state.effect_mode == deadlib_present::anim::EffectMode::None
        && !state.texture_wrapping
        && state.texcoord_offset.is_none()
        && state.custom_texture_rect.is_none()
        && state.texcoord_velocity.is_none();
    if !opaque {
        return None;
    }

    let [axis_x, axis_y] = song_lua_overlay_axis_scale(state);
    let [texture_width, texture_height] = texture_size;
    if texture_width <= f32::EPSILON || texture_height <= f32::EPSILON {
        return None;
    }
    let (origin_x, origin_y, scale_x, scale_y) =
        if let Some([left, top, right, bottom]) = state.stretch_rect {
            (
                left,
                top,
                (right - left) * axis_x / texture_width,
                (bottom - top) * axis_y / texture_height,
            )
        } else {
            (
                (state.halign * texture_width).mul_add(-axis_x, state.x),
                (state.valign * texture_height).mul_add(-axis_y, state.y),
                axis_x,
                axis_y,
            )
        };
    Some(SongLuaOpaqueRect::new(
        source.left.mul_add(scale_x, origin_x),
        source.top.mul_add(scale_y, origin_y),
        source.right.mul_add(scale_x, origin_x),
        source.bottom.mul_add(scale_y, origin_y),
    ))
}

fn song_lua_rect_covers(outer: SongLuaOpaqueRect, inner: SongLuaOpaqueRect) -> bool {
    const EDGE_EPSILON: f32 = 0.5;
    outer.left <= inner.left + EDGE_EPSILON
        && outer.top <= inner.top + EDGE_EPSILON
        && outer.right >= inner.right - EDGE_EPSILON
        && outer.bottom >= inner.bottom - EDGE_EPSILON
}

fn song_lua_merge_proxy_requests(
    into: &mut SongLuaScreenProxyRequests,
    from: SongLuaScreenProxyRequests,
) {
    for player_index in 0..into.players.len() {
        into.players[player_index].player |= from.players[player_index].player;
        into.players[player_index].note_field |= from.players[player_index].note_field;
        into.players[player_index].judgment |= from.players[player_index].judgment;
        into.players[player_index].combo |= from.players[player_index].combo;
        into.scores[player_index] |= from.scores[player_index];
    }
    into.underlay |= from.underlay;
    into.overlay |= from.overlay;
    into.background |= from.background;
    into.stage |= from.stage;
    into.hide_underlay |= from.hide_underlay;
    into.hide_overlay |= from.hide_overlay;
}

fn song_lua_merge_proxy_analysis(
    into: &mut SongLuaProxyRequestAnalysis,
    from: SongLuaProxyRequestAnalysis,
) {
    song_lua_merge_proxy_requests(&mut into.all, from.all);
    song_lua_merge_proxy_requests(&mut into.captured, from.captured);
    for (count, add) in into.root_players.iter_mut().zip(from.root_players) {
        *count = count.saturating_add(add);
    }
    for (count, add) in into.root_note_fields.iter_mut().zip(from.root_note_fields) {
        *count = count.saturating_add(add);
    }
    for (count, add) in into.root_judgments.iter_mut().zip(from.root_judgments) {
        *count = count.saturating_add(add);
    }
    for (count, add) in into.root_combos.iter_mut().zip(from.root_combos) {
        *count = count.saturating_add(add);
    }
}

#[cfg(test)]
fn song_lua_build_proxy_actor(
    state: SongLuaOverlayState,
    z: i16,
    source: &[Arc<[Actor]>],
    overlay_space_width: f32,
    overlay_space_height: f32,
) -> Option<Actor> {
    song_lua_build_proxy_actor_with_scratch(
        state,
        z,
        SongLuaProxySource::new(source),
        overlay_space_width,
        overlay_space_height,
        None,
    )
}

fn song_lua_build_proxy_actor_with_scratch(
    state: SongLuaOverlayState,
    z: i16,
    source: SongLuaProxySource<'_>,
    overlay_space_width: f32,
    overlay_space_height: f32,
    scratch: Option<&mut SongLuaProxyActorScratch>,
) -> Option<Actor> {
    song_lua_build_proxy_actor_in_space_with_scratch(
        state,
        z,
        source,
        overlay_space_width,
        overlay_space_height,
        screen_width(),
        screen_height(),
        scratch,
    )
}

#[allow(clippy::too_many_arguments)]
fn song_lua_build_proxy_actor_in_space_with_scratch(
    state: SongLuaOverlayState,
    z: i16,
    source: SongLuaProxySource<'_>,
    overlay_space_width: f32,
    overlay_space_height: f32,
    render_space_width: f32,
    render_space_height: f32,
    mut scratch: Option<&mut SongLuaProxyActorScratch>,
) -> Option<Actor> {
    if !state.draw_visible() || state.diffuse[3] <= f32::EPSILON || source.is_empty() {
        return None;
    }
    let blend = Some(song_lua_overlay_blend(state.blend));
    let offset = song_lua_proxy_offset(
        state,
        source.offset,
        overlay_space_width,
        overlay_space_height,
    );
    let transform = (song_lua_proxy_needs_transform(state) || source.model.is_some()).then(|| {
        song_lua_proxy_transform(
            state,
            source.offset,
            overlay_space_width,
            overlay_space_height,
            render_space_width,
            render_space_height,
        ) * source.model.unwrap_or(Matrix4::IDENTITY)
    });
    if let [segment] = source.segments {
        let slot_index = scratch
            .as_deref_mut()
            .and_then(|scratch| scratch.reserve_proxy_group(source.pool_class))
            .map(|group| group.segment_start);
        let children = match (scratch.as_deref_mut(), slot_index) {
            (Some(scratch), Some(slot_index)) => scratch.normalize_segment(segment, slot_index),
            _ => song_lua_proxy_source_segment_owned(segment),
        };
        return Some(song_lua_proxy_wrapper(
            children,
            offset,
            transform,
            source.source_view_proj,
            z,
            state.diffuse,
            blend,
        ));
    }
    song_lua_build_proxy_frame_actor_in_space_with_scratch(
        state, z, source, offset, transform, scratch,
    )
}

fn song_lua_proxy_offset(
    state: SongLuaOverlayState,
    source_offset: [f32; 2],
    overlay_space_width: f32,
    overlay_space_height: f32,
) -> [f32; 2] {
    [
        state.x * screen_width() / overlay_space_width.max(1.0) + source_offset[0],
        state.y * screen_height() / overlay_space_height.max(1.0) + source_offset[1],
    ]
}

fn song_lua_proxy_needs_transform(state: SongLuaOverlayState) -> bool {
    let [scale_x, scale_y] = song_lua_overlay_axis_scale(state);
    (scale_x - 1.0).abs() > f32::EPSILON
        || (scale_y - 1.0).abs() > f32::EPSILON
        || (song_lua_overlay_z_scale(state) - 1.0).abs() > f32::EPSILON
        || state.z.abs() > f32::EPSILON
        || state.rot_x_deg.abs() > f32::EPSILON
        || state.rot_y_deg.abs() > f32::EPSILON
        || state.rot_z_deg.abs() > f32::EPSILON
        || state.skew_x.abs() > f32::EPSILON
        || state.skew_y.abs() > f32::EPSILON
}

fn song_lua_proxy_wrapper(
    children: Arc<[Actor]>,
    offset: [f32; 2],
    transform: Option<Matrix4>,
    source_view_proj: Option<Matrix4>,
    z: i16,
    tint: [f32; 4],
    blend: Option<BlendMode>,
) -> Actor {
    if let Some(transform) = transform {
        return Actor::SharedTransform {
            isolate_order: false,
            transform,
            source_view_proj: source_view_proj.unwrap_or_else(song_lua_proxy_source_view_proj),
            children,
            z,
            tint,
            blend,
        };
    }
    Actor::SharedFrame {
        align: [0.0, 0.0],
        offset,
        size: [SizeSpec::Fill, SizeSpec::Fill],
        children,
        background: None,
        z,
        tint,
        blend,
    }
}

fn song_lua_proxy_source_view_proj() -> Matrix4 {
    glam::camera::rh::proj::opengl::orthographic(
        -0.5 * screen_width(),
        0.5 * screen_width(),
        -0.5 * screen_height(),
        0.5 * screen_height(),
        -1.0,
        1.0,
    )
}

fn song_lua_proxy_transform(
    state: SongLuaOverlayState,
    source_offset: [f32; 2],
    overlay_space_width: f32,
    overlay_space_height: f32,
    render_space_width: f32,
    render_space_height: f32,
) -> Matrix4 {
    let render_width = render_space_width.max(1.0);
    let render_height = render_space_height.max(1.0);
    let x = state.x * screen_width() / overlay_space_width.max(1.0);
    let y = state.y * screen_height() / overlay_space_height.max(1.0);
    let [scale_x, scale_y] = song_lua_overlay_axis_scale(state);
    // Proxy sources are already in Y-up world coordinates. Conjugate the
    // screen-space actor rotation/skew across Y before applying it to them.
    Matrix4::from_translation(Vector3::new(
        (-0.5f32).mul_add(render_width, x),
        0.5f32.mul_add(render_height, -y),
        state.z,
    )) * song_lua_overlay_local_transform(
        [-state.rot_x_deg, state.rot_y_deg, -state.rot_z_deg],
        -state.skew_x,
        -state.skew_y,
    ) * Matrix4::from_scale(Vector3::new(
        scale_x,
        scale_y,
        song_lua_overlay_z_scale(state),
    )) * Matrix4::from_translation(Vector3::new(source_offset[0], -source_offset[1], 0.0))
        * Matrix4::from_translation(Vector3::new(0.5 * render_width, -0.5 * render_height, 0.0))
}

fn song_lua_direct_proxy_source(
    target: &SongLuaProxyTarget,
    proxy_sources: &SongLuaScreenProxySources<'_>,
) -> Option<(usize, SongLuaDirectProxySource)> {
    match target {
        SongLuaProxyTarget::NoteField { player_index } => proxy_sources
            .direct_note_fields
            .get(*player_index)
            .copied()
            .flatten()
            .map(|source| (*player_index, source)),
        SongLuaProxyTarget::Judgment { player_index } => proxy_sources
            .direct_judgments
            .get(*player_index)
            .copied()
            .flatten()
            .map(|source| (*player_index, source)),
        SongLuaProxyTarget::Combo { player_index } => proxy_sources
            .direct_combos
            .get(*player_index)
            .copied()
            .flatten()
            .map(|source| (*player_index, source)),
        SongLuaProxyTarget::Player { .. }
        | SongLuaProxyTarget::Underlay { .. }
        | SongLuaProxyTarget::Overlay { .. }
        | SongLuaProxyTarget::Actor { .. }
        | SongLuaProxyTarget::Score { .. } => None,
    }
}

fn song_lua_direct_player_proxy_source(
    target: &SongLuaProxyTarget,
    proxy_sources: &SongLuaScreenProxySources<'_>,
) -> Option<(usize, SongLuaDirectPlayerSource)> {
    let SongLuaProxyTarget::Player { player_index } = target else {
        return None;
    };
    proxy_sources
        .direct_players
        .get(*player_index)
        .copied()
        .flatten()
        .map(|source| (*player_index, source))
}

fn song_lua_direct_proxy(
    state: SongLuaOverlayState,
    z: i16,
    source: SongLuaDirectProxySource,
    player: usize,
    actor_insert: usize,
    overlay_space_width: f32,
    overlay_space_height: f32,
) -> Option<SongLuaDirectProxy> {
    if !song_lua_overlay_is_visible(state) || source.draw_start >= source.draw_end {
        return None;
    }
    let transformed = song_lua_proxy_needs_transform(state);
    let (offset, enclosing_camera, camera) = if transformed {
        let transform = song_lua_proxy_transform(
            state,
            [-source.target[0], -source.target[1]],
            overlay_space_width,
            overlay_space_height,
            screen_width(),
            screen_height(),
        );
        if let Some(player_camera) = source.player_camera {
            // ITGmania's ActorProxy draws its target with the proxy transform
            // already on the world stack. Player then installs the notefield
            // projection and applies its own transform, so the order is
            // projection * proxy * Player. In particular, an enclosing
            // zoomz(0) must flatten Bumpy before perspective projection.
            (
                [0.0, 0.0],
                None,
                Some(player_camera.base * transform * player_camera.suffix),
            )
        } else {
            let source_view_proj = song_lua_proxy_source_view_proj();
            let prefix = source_view_proj * transform * source_view_proj.inverse();
            (
                [0.0, 0.0],
                Some(source_view_proj * transform),
                source.camera.map(|camera| prefix * camera),
            )
        }
    } else {
        (
            [
                state.x * screen_width() / overlay_space_width.max(1.0) - source.target[0],
                state.y * screen_height() / overlay_space_height.max(1.0) - source.target[1],
            ],
            None,
            source.camera,
        )
    };
    Some(SongLuaDirectProxy {
        actor_insert,
        player,
        draws: source.draws,
        draw_start: source.draw_start,
        draw_end: source.draw_end,
        offset,
        z,
        style: FlatProxyStyle::new(source.tint, state.diffuse, None),
        blend: song_lua_overlay_blend(state.blend),
        enclosing_camera,
        camera,
    })
}

#[cfg(test)]
fn song_lua_build_proxy_frame_actor_with_scratch(
    state: SongLuaOverlayState,
    z: i16,
    source: SongLuaProxySource<'_>,
    overlay_space_width: f32,
    overlay_space_height: f32,
    scratch: Option<&mut SongLuaProxyActorScratch>,
) -> Option<Actor> {
    let offset = song_lua_proxy_offset(
        state,
        source.offset,
        overlay_space_width,
        overlay_space_height,
    );
    let transform = (song_lua_proxy_needs_transform(state) || source.model.is_some()).then(|| {
        song_lua_proxy_transform(
            state,
            source.offset,
            overlay_space_width,
            overlay_space_height,
            screen_width(),
            screen_height(),
        ) * source.model.unwrap_or(Matrix4::IDENTITY)
    });
    song_lua_build_proxy_frame_actor_in_space_with_scratch(
        state, z, source, offset, transform, scratch,
    )
}

fn song_lua_build_proxy_frame_actor_in_space_with_scratch(
    state: SongLuaOverlayState,
    z: i16,
    source: SongLuaProxySource<'_>,
    offset: [f32; 2],
    transform: Option<Matrix4>,
    mut scratch: Option<&mut SongLuaProxyActorScratch>,
) -> Option<Actor> {
    if !state.draw_visible() || state.diffuse[3] <= f32::EPSILON || source.is_empty() {
        return None;
    }
    let blend = Some(song_lua_overlay_blend(state.blend));
    if source.segments.len() <= SONG_LUA_PROXY_SEGMENTS_PER_ACTOR
        && let Some(group) = scratch
            .as_deref_mut()
            .and_then(|scratch| scratch.reserve_proxy_group(source.pool_class))
    {
        let children = scratch
            .as_deref_mut()
            .expect("reserved proxy group requires scratch")
            .join_proxy_segments(group, source.segments, state.diffuse, blend);
        return Some(song_lua_proxy_wrapper(
            children,
            offset,
            transform,
            source.source_view_proj,
            z,
            [1.0; 4],
            None,
        ));
    }

    let mut children = Vec::with_capacity(source.segments.len());
    for segment in source.segments {
        children.push(Actor::SharedFrame {
            align: [0.0, 0.0],
            offset: [0.0, 0.0],
            size: [SizeSpec::Fill, SizeSpec::Fill],
            children: song_lua_proxy_source_segment_owned(segment),
            background: None,
            z: 0,
            tint: state.diffuse,
            blend,
        });
    }
    Some(song_lua_proxy_wrapper(
        Arc::from(children),
        offset,
        transform,
        source.source_view_proj,
        z,
        [1.0; 4],
        None,
    ))
}

fn song_lua_proxy_source_segment_owned(segment: &Arc<[Actor]>) -> Arc<[Actor]> {
    if !segment.iter().any(song_lua_proxy_actor_has_z) {
        return Arc::clone(segment);
    }
    let (offset, actors) = song_lua_proxy_segment_actors(segment);
    let mut children = Vec::with_capacity(actors.len());
    song_lua_proxy_local_children_into(actors.iter().cloned(), &mut children);
    if offset == [0.0, 0.0] {
        Arc::from(children)
    } else {
        Arc::from([Actor::Frame {
            align: [0.0, 0.0],
            offset,
            size: [SizeSpec::Fill, SizeSpec::Fill],
            children,
            background: None,
            z: 0,
        }])
    }
}

fn song_lua_proxy_segment_actors(segment: &[Actor]) -> ([f32; 2], &[Actor]) {
    let [
        Actor::Frame {
            align,
            offset,
            size,
            children,
            background,
            z,
        },
    ] = segment
    else {
        return ([0.0, 0.0], segment);
    };
    if *align == [0.0, 0.0]
        && matches!(*size, [SizeSpec::Fill, SizeSpec::Fill])
        && background.is_none()
        && *z == 0
    {
        (*offset, children)
    } else {
        ([0.0, 0.0], segment)
    }
}

fn song_lua_proxy_actor_has_z(actor: &Actor) -> bool {
    match actor {
        Actor::Sprite { z, .. }
        | Actor::Text { z, .. }
        | Actor::Mesh { z, .. }
        | Actor::ReusableMesh { z, .. }
        | Actor::TexturedMesh { z, .. }
        | Actor::ReusableTexturedMesh { z, .. } => *z != 0,
        Actor::Frame { z, children, .. } => {
            *z != 0 || children.iter().any(song_lua_proxy_actor_has_z)
        }
        Actor::SharedFrame { z, children, .. } | Actor::SharedTransform { z, children, .. } => {
            *z != 0 || children.iter().any(song_lua_proxy_actor_has_z)
        }
        Actor::RetainedFrame { z, frame, .. } => {
            *z != 0 || frame.children().iter().any(song_lua_proxy_actor_has_z)
        }
        Actor::Camera { children, .. } => children.iter().any(song_lua_proxy_actor_has_z),
        Actor::SharedCamera { children, .. } => children.iter().any(song_lua_proxy_actor_has_z),
        Actor::Shadow { child, .. } => song_lua_proxy_actor_has_z(child),
        Actor::CameraPush { .. } | Actor::CameraPop => false,
    }
}

fn song_lua_proxy_actor_z(actor: &Actor) -> i16 {
    match actor {
        Actor::Sprite { z, .. }
        | Actor::Text { z, .. }
        | Actor::Mesh { z, .. }
        | Actor::ReusableMesh { z, .. }
        | Actor::TexturedMesh { z, .. }
        | Actor::ReusableTexturedMesh { z, .. }
        | Actor::Frame { z, .. }
        | Actor::SharedFrame { z, .. }
        | Actor::SharedTransform { z, .. }
        | Actor::RetainedFrame { z, .. } => *z,
        Actor::Shadow { child, .. } => song_lua_proxy_actor_z(child),
        Actor::Camera { .. }
        | Actor::SharedCamera { .. }
        | Actor::CameraPush { .. }
        | Actor::CameraPop => 0,
    }
}

fn song_lua_proxy_local_children_into(children: impl Iterator<Item = Actor>, out: &mut Vec<Actor>) {
    out.extend(children);
    song_lua_proxy_local_children_in_place(out);
}

fn song_lua_proxy_expand_retained(children: &mut Vec<Actor>) {
    let mut index = 0;
    while index < children.len() {
        let frame = match &children[index] {
            Actor::RetainedFrame {
                align: [0.0, 0.0],
                offset: [0.0, 0.0],
                size: [SizeSpec::Fill, SizeSpec::Fill],
                frame,
                z: 0,
                tint: [1.0, 1.0, 1.0, 1.0],
                blend: None,
                visible: true,
            } => Some(Arc::clone(frame)),
            _ => None,
        };
        let Some(frame) = frame else {
            index += 1;
            continue;
        };
        // The exact-size iterator lets Vec move the tail once and reserve at
        // most once, instead of shifting every large Actor for every child.
        children.splice(index..index + 1, frame.children().iter().cloned());
        // Inspect the inserted actors too in case a retained static fragment
        // contains another identity retained frame.
    }
}

fn song_lua_proxy_local_children_in_place(children: &mut Vec<Actor>) {
    // Static gameplay fragments retain their authored absolute z values behind
    // an identity wrapper. ActorProxy establishes a new draw plane, so expose
    // those children before sorting and zeroing their local z values.
    song_lua_proxy_expand_retained(children);
    let mut run_start = 0;
    for index in 0..children.len() {
        if matches!(children[index], Actor::CameraPush { .. } | Actor::CameraPop) {
            song_lua_proxy_local_run(&mut children[run_start..index]);
            song_lua_proxy_zero_local_z(&mut children[index]);
            run_start = index + 1;
        }
    }
    song_lua_proxy_local_run(&mut children[run_start..]);
}

fn song_lua_proxy_local_run(children: &mut [Actor]) {
    if children.len() <= 8 || children.len() > PLAYER_ACTOR_SCRATCH_CAPACITY {
        // Tiny and overflow runs avoid auxiliary setup while retaining stable
        // equal-z ordering and a hard zero-allocation fallback.
        for index in 1..children.len() {
            let z = song_lua_proxy_actor_z(&children[index]);
            let mut insert = index;
            while insert > 0 && song_lua_proxy_actor_z(&children[insert - 1]) > z {
                children.swap(insert - 1, insert);
                insert -= 1;
            }
        }
    } else {
        // Sort compact indices by (z, original position), then apply the
        // permutation to the large Actor values. This is stable and uses no
        // heap-backed merge buffer.
        let mut order = [0u16; PLAYER_ACTOR_SCRATCH_CAPACITY];
        let mut target = [0u16; PLAYER_ACTOR_SCRATCH_CAPACITY];
        for (index, slot) in order[..children.len()].iter_mut().enumerate() {
            *slot = index as u16;
        }
        order[..children.len()].sort_unstable_by_key(|&index| {
            (song_lua_proxy_actor_z(&children[index as usize]), index)
        });
        for (new_index, &old_index) in order[..children.len()].iter().enumerate() {
            target[old_index as usize] = new_index as u16;
        }
        for index in 0..children.len() {
            while target[index] as usize != index {
                let swap_index = target[index] as usize;
                children.swap(index, swap_index);
                target.swap(index, swap_index);
            }
        }
    }
    for child in children {
        song_lua_proxy_zero_local_z(child);
    }
}

fn song_lua_proxy_zero_local_z(actor: &mut Actor) {
    match actor {
        Actor::Sprite { z, .. }
        | Actor::Text { z, .. }
        | Actor::Mesh { z, .. }
        | Actor::ReusableMesh { z, .. }
        | Actor::TexturedMesh { z, .. }
        | Actor::ReusableTexturedMesh { z, .. }
        | Actor::RetainedFrame { z, .. } => *z = 0,
        Actor::Frame { z, children, .. } => {
            *z = 0;
            song_lua_proxy_local_children_in_place(children);
        }
        Actor::SharedFrame { z, children, .. } | Actor::SharedTransform { z, children, .. } => {
            *z = 0;
            *children = song_lua_proxy_source_segment_owned(children);
        }
        Actor::Camera { children, .. } => song_lua_proxy_local_children_in_place(children),
        Actor::SharedCamera { children, .. } => {
            *children = song_lua_proxy_source_segment_owned(children);
        }
        Actor::Shadow { child, .. } => song_lua_proxy_zero_local_z(child),
        Actor::CameraPush { .. } | Actor::CameraPop => {}
    }
}

#[cfg(test)]
fn song_lua_overlay_order<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    parent_index: Option<usize>,
) -> Vec<usize> {
    let mut cache = song_lua_overlay_order_cache_from(overlays, &[]);
    let mut out = Vec::with_capacity(overlays.len());
    song_lua_overlay_order_into(overlays, overlay_states, &mut cache, parent_index, &mut out);
    out
}

fn song_lua_overlay_order_into<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    order_cache: &mut SongLuaOverlayOrderCache,
    parent_index: Option<usize>,
    out: &mut Vec<usize>,
) {
    out.clear();
    out.reserve(overlays.len());
    if parent_index.is_none()
        && let Some(static_order) = order_cache.static_root_order.as_deref()
    {
        out.extend_from_slice(static_order);
        return;
    }
    song_lua_push_order(overlays, overlay_states, order_cache, parent_index, out);
}

fn song_lua_push_order<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    order_cache: &mut SongLuaOverlayOrderCache,
    parent_index: Option<usize>,
    out: &mut Vec<usize>,
) {
    let list_idx = song_lua_overlay_child_list_index(parent_index);
    if list_idx >= order_cache.child_lists.len() || order_cache.child_lists[list_idx].is_empty() {
        return;
    }
    let draw_by_z_position = parent_index.is_some_and(|idx| {
        overlay_states
            .get(idx)
            .map_or(overlays[idx].initial_state.draw_by_z_position, |state| {
                state.draw_by_z_position
            })
    });
    if draw_by_z_position {
        let mut changed = order_cache.sort_modes[list_idx] != SONG_LUA_CHILD_ORDER_Z;
        for &idx in &order_cache.child_lists[list_idx] {
            let z = overlay_states
                .get(idx)
                .map_or(overlays[idx].initial_state.z, |state| state.z);
            let key = z.to_bits();
            if order_cache.last_z_keys[idx] != key {
                order_cache.last_z_keys[idx] = key;
                changed = true;
            }
        }
        if changed {
            order_cache.child_lists[list_idx].sort_by(|&left, &right| {
                let left_z = f32::from_bits(order_cache.last_z_keys[left]);
                let right_z = f32::from_bits(order_cache.last_z_keys[right]);
                left_z.total_cmp(&right_z).then_with(||
                    song_lua_order_source(overlays, left).cmp(&song_lua_order_source(overlays, right)))
            });
        }
        order_cache.sort_modes[list_idx] = SONG_LUA_CHILD_ORDER_Z;
    } else if order_cache
        .dynamic_draw_order
        .get(list_idx)
        .copied()
        .unwrap_or(false)
    {
        let mut changed = order_cache.sort_modes[list_idx] != SONG_LUA_CHILD_ORDER_DRAW;
        for &idx in &order_cache.child_lists[list_idx] {
            let source = song_lua_order_source(overlays, idx);
            let draw_order = overlay_states
                .get(source)
                .map_or(overlays[source].initial_state.draw_order, |state| {
                    state.draw_order
                });
            if order_cache.last_draw_orders[idx] != draw_order {
                order_cache.last_draw_orders[idx] = draw_order;
                changed = true;
            }
        }
        if changed {
            order_cache.child_lists[list_idx]
                .sort_by_key(|&idx| (order_cache.last_draw_orders[idx], song_lua_order_source(overlays, idx)));
        }
        order_cache.sort_modes[list_idx] = SONG_LUA_CHILD_ORDER_DRAW;
    } else if order_cache
        .sort_modes
        .get(list_idx)
        .copied()
        .unwrap_or(SONG_LUA_CHILD_ORDER_STATIC)
        != SONG_LUA_CHILD_ORDER_STATIC
    {
        song_lua_sort_static_children(overlays, &mut order_cache.child_lists[list_idx]);
        order_cache.sort_modes[list_idx] = SONG_LUA_CHILD_ORDER_STATIC;
    }
    let child_count = order_cache.child_lists[list_idx].len();
    for child_pos in 0..child_count {
        let idx = order_cache.child_lists[list_idx][child_pos];
        out.push(idx);
        let child_list_idx = song_lua_overlay_child_list_index(Some(idx));
        if order_cache
            .child_lists
            .get(child_list_idx)
            .is_some_and(|children| !children.is_empty())
        {
            song_lua_push_order(overlays, overlay_states, order_cache, Some(idx), out);
        }
    }
}

fn song_lua_capture_root_state(state: SongLuaOverlayState) -> SongLuaOverlayState {
    SongLuaOverlayState {
        draw_order: state.draw_order,
        draw_by_z_position: state.draw_by_z_position,
        glow: state.glow,
        diffuse: state.diffuse,
        visible: state.visible,
        hibernating: state.hibernating,
        mask_source: state.mask_source,
        mask_dest: state.mask_dest,
        depth_test: state.depth_test,
        depth_write: state.depth_write,
        depth_test_on_fail: state.depth_test_on_fail,
        blend: state.blend,
        ..SongLuaOverlayState::default()
    }
}

fn song_lua_capture_overlay_states_into_scratch<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    local_overlay_states: &[SongLuaOverlayState],
    order_cache: &SongLuaOverlayOrderCache,
    capture_index: usize,
    overlay_space_width: f32,
    overlay_space_height: f32,
    out: &mut Vec<SongLuaOverlayState>,
    clock: [f32; 2],
) {
    if out.len() != overlays.len() {
        out.resize(overlays.len(), SongLuaOverlayState::default());
    }
    song_lua_fill_capture_overlay_states(
        overlays,
        overlay_states,
        local_overlay_states,
        order_cache,
        capture_index,
        overlay_space_width,
        overlay_space_height,
        out,
        clock,
    );
}

fn song_lua_fill_capture_overlay_states<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    local_overlay_states: &[SongLuaOverlayState],
    order_cache: &SongLuaOverlayOrderCache,
    capture_index: usize,
    overlay_space_width: f32,
    overlay_space_height: f32,
    out: &mut [SongLuaOverlayState],
    clock: [f32; 2],
) {
    let Some(capture_state) = overlay_states.get(capture_index).copied() else {
        return;
    };
    // AFTs capture in texture space; placement transforms apply to the sprite
    // that consumes the texture, not to the captured children.
    out[capture_index] = song_lua_capture_root_state(capture_state);
    song_lua_capture_overlay_child_states(
        overlays,
        local_overlay_states,
        order_cache,
        capture_index,
        overlay_space_width,
        overlay_space_height,
        out,
        clock,
    );
}

fn song_lua_capture_overlay_child_states<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    local_overlay_states: &[SongLuaOverlayState],
    order_cache: &SongLuaOverlayOrderCache,
    parent_index: usize,
    overlay_space_width: f32,
    overlay_space_height: f32,
    out: &mut [SongLuaOverlayState],
    clock: [f32; 2],
) {
    let list_idx = song_lua_overlay_child_list_index(Some(parent_index));
    let Some(children) = order_cache.child_lists.get(list_idx) else {
        return;
    };
    for &idx in children {
        let Some(overlay) = overlays.get(idx) else {
            continue;
        };
        let local = song_lua_draw_input_state(
            local_overlay_states.get(idx).copied().unwrap_or_default(),
            idx,
            clock,
        );
        let parent = out.get(parent_index).copied().unwrap_or_default();
        let parent_overlay = &overlays[parent_index];
        out[idx] = song_lua_overlay_compose_state(
            &parent_overlay.kind,
            parent,
            local,
            overlay_space_width,
            overlay_space_height,
            clock,
        );
        if !matches!(overlay.kind, SongLuaOverlayKind::ActorFrameTexture { .. }) {
            song_lua_capture_overlay_child_states(
                overlays,
                local_overlay_states,
                order_cache,
                idx,
                overlay_space_width,
                overlay_space_height,
                out,
                clock,
            );
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn song_lua_append_local_proxy_target<S: NoteskinSlot + Clone>(
    out: &mut Vec<Actor>,
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    local_overlay_states: &[SongLuaOverlayState],
    order_cache: &SongLuaOverlayOrderCache,
    topology_index: &SongLuaOverlayTopologyIndex,
    asset_manager: &AssetManager,
    index: usize,
    state: SongLuaOverlayState,
    overlay_space_width: f32,
    overlay_space_height: f32,
    effect_time: f32,
    effect_beat: f32,
    total_elapsed: impl Into<SongLuaDrawTime>,
    projected_mesh_scratch: &mut [SongLuaProjectedMeshScratch],
) {
    let total_elapsed = total_elapsed.into();
    let Some(overlay) = overlays.get(index) else {
        return;
    };
    match overlay.kind {
        SongLuaOverlayKind::Actor
        | SongLuaOverlayKind::ActorFrame
        | SongLuaOverlayKind::WrapperState => {
            let list_idx = song_lua_overlay_child_list_index(Some(index));
            let Some(children) = order_cache.child_lists.get(list_idx) else {
                return;
            };
            for &child_index in children {
                if child_index >= overlays.len() {
                    continue;
                }
                let local = local_overlay_states
                    .get(child_index)
                    .copied()
                    .unwrap_or_default();
                let child_state = song_lua_overlay_compose_state(
                    &overlay.kind,
                    state,
                    local,
                    overlay_space_width,
                    overlay_space_height,
                    [effect_time, effect_beat],
                );
                song_lua_append_local_proxy_target(
                    out,
                    overlays,
                    overlay_states,
                    local_overlay_states,
                    order_cache,
                    topology_index,
                    asset_manager,
                    child_index,
                    child_state,
                    overlay_space_width,
                    overlay_space_height,
                    effect_time,
                    effect_beat,
                    total_elapsed,
                    projected_mesh_scratch,
                );
            }
        }
        SongLuaOverlayKind::ActorFrameTexture { .. }
        | SongLuaOverlayKind::ActorProxy { .. }
        | SongLuaOverlayKind::AftSprite { .. }
        | SongLuaOverlayKind::Sound { .. } => {}
        _ => {
            let z = out.len().min(i16::MAX as usize) as i16;
            if append_song_lua_multi_actor_overlay(
                out,
                overlay,
                state,
                topology_index.camera_state(overlay_states, index),
                asset_manager,
                z,
                overlay_space_width,
                overlay_space_height,
                effect_time,
                effect_beat,
                total_elapsed.animation_elapsed,
                projected_mesh_scratch.get_mut(index),
            )
            .is_none()
                && let Some(actors) = build_song_lua_overlay_actor_with_scratch(
                    overlay,
                    state,
                    topology_index.camera_state(overlay_states, index),
                    asset_manager,
                    z,
                    overlay_space_width,
                    overlay_space_height,
                    effect_time,
                    effect_beat,
                    total_elapsed,
                    topology_index.texture_handle(index),
                    projected_mesh_scratch.get_mut(index),
                )
            {
                out.extend(actors);
            }
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn song_lua_build_local_proxy_actor<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    local_overlay_states: &[SongLuaOverlayState],
    order_cache: &SongLuaOverlayOrderCache,
    topology_index: &SongLuaOverlayTopologyIndex,
    asset_manager: &AssetManager,
    target_index: usize,
    proxy_state: SongLuaOverlayState,
    z: i16,
    overlay_space_width: f32,
    overlay_space_height: f32,
    render_space_width: f32,
    render_space_height: f32,
    effect_time: f32,
    effect_beat: f32,
    total_elapsed: impl Into<SongLuaDrawTime>,
    projected_mesh_scratch: &mut [SongLuaProjectedMeshScratch],
    mut proxy_actor_scratch: Option<&mut SongLuaProxyActorScratch>,
) -> Option<Actor> {
    let total_elapsed = total_elapsed.into();
    let mut target_state = local_overlay_states.get(target_index).copied()?;
    // ITG ActorProxy::DrawPrimitives temporarily unhides its target for the
    // proxied draw, then restores the target's hidden state.
    target_state.visible = true;
    if matches!(
        overlays[target_index].kind,
        SongLuaOverlayKind::WrapperState
    ) {
        // A native wrapper ActorFrame has no draw children of its own.
        return None;
    }
    let mut parent = overlays[target_index].parent_index;
    while let Some(index) = parent {
        let wrapper = &overlays[index];
        if !matches!(wrapper.kind, SongLuaOverlayKind::WrapperState) {
            break;
        }
        target_state = song_lua_overlay_compose_state(
            &wrapper.kind,
            local_overlay_states[index],
            target_state,
            overlay_space_width,
            overlay_space_height,
            [effect_time, effect_beat],
        );
        parent = wrapper.parent_index;
    }
    let source = if let Some(slot) = proxy_actor_scratch
        .as_deref_mut()
        .and_then(SongLuaProxyActorScratch::next_screen)
    {
        slot.refill([0.0, 0.0], |out| {
            song_lua_append_local_proxy_target(
                out,
                overlays,
                overlay_states,
                local_overlay_states,
                order_cache,
                topology_index,
                asset_manager,
                target_index,
                target_state,
                overlay_space_width,
                overlay_space_height,
                effect_time,
                effect_beat,
                total_elapsed,
                projected_mesh_scratch,
            );
        })?
    } else {
        let mut out = Vec::new();
        song_lua_append_local_proxy_target(
            &mut out,
            overlays,
            overlay_states,
            local_overlay_states,
            order_cache,
            topology_index,
            asset_manager,
            target_index,
            target_state,
            overlay_space_width,
            overlay_space_height,
            effect_time,
            effect_beat,
            total_elapsed,
            projected_mesh_scratch,
        );
        if out.is_empty() {
            return None;
        }
        Arc::from(out)
    };
    let segments = [source];
    song_lua_build_proxy_actor_in_space_with_scratch(
        proxy_state,
        z,
        SongLuaProxySource::new(&segments),
        overlay_space_width,
        overlay_space_height,
        render_space_width,
        render_space_height,
        proxy_actor_scratch,
    )
}

fn song_lua_capture_children_into<S: NoteskinSlot + Clone>(
    out: &mut Vec<Actor>,
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    local_overlay_states: &[SongLuaOverlayState],
    order_cache: &mut SongLuaOverlayOrderCache,
    topology_index: &SongLuaOverlayTopologyIndex,
    asset_manager: &AssetManager,
    capture_index: usize,
    proxy_sources: &SongLuaScreenProxySources<'_>,
    mut proxy_actor_scratch: Option<&mut SongLuaProxyActorScratch>,
    overlay_space_width: f32,
    overlay_space_height: f32,
    effect_time: f32,
    effect_beat: f32,
    total_elapsed: impl Into<SongLuaDrawTime>,
    capture_states: &mut Vec<SongLuaOverlayState>,
    order_scratch: &mut Vec<usize>,
    projected_mesh_scratch: &mut [SongLuaProjectedMeshScratch],
) {
    let total_elapsed = total_elapsed.into();
    let Some(render_space) =
        song_lua_aft_size(&overlays[capture_index], overlay_states[capture_index])
    else {
        return;
    };
    song_lua_capture_overlay_states_into_scratch(
        overlays,
        overlay_states,
        local_overlay_states,
        order_cache,
        capture_index,
        overlay_space_width,
        overlay_space_height,
        capture_states,
        [effect_time, effect_beat],
    );
    song_lua_overlay_order_into(
        overlays,
        capture_states,
        order_cache,
        Some(capture_index),
        order_scratch,
    );
    out.reserve(order_scratch.len());
    for (draw_idx, idx) in order_scratch.iter().copied().enumerate() {
        let Some(overlay) = overlays.get(idx) else {
            continue;
        };
        if topology_index
            .aft_ancestors
            .get(idx)
            .copied()
            .and_then(SongLuaOverlayIndex::get)
            != Some(capture_index)
        {
            continue;
        }
        if matches!(
            overlay.kind,
            SongLuaOverlayKind::Actor
                | SongLuaOverlayKind::ActorFrame
                | SongLuaOverlayKind::WrapperState
                | SongLuaOverlayKind::ActorFrameTexture { .. }
        ) {
            continue;
        }
        let overlay_state = capture_states.get(idx).copied().unwrap_or_default();
        match &overlay.kind {
            SongLuaOverlayKind::ActorProxy { target } => {
                let z = draw_idx.min(i16::MAX as usize) as i16;
                let overlay_state =
                    song_lua_proxy_effect(overlay_state, effect_time, effect_beat, idx as u32);
                let actor = match target {
                    SongLuaProxyTarget::Actor { overlay_index } => {
                        song_lua_build_local_proxy_actor(
                            overlays,
                            overlay_states,
                            local_overlay_states,
                            order_cache,
                            topology_index,
                            asset_manager,
                            *overlay_index,
                            overlay_state,
                            z,
                            overlay_space_width,
                            overlay_space_height,
                            render_space[0],
                            render_space[1],
                            effect_time,
                            effect_beat,
                            total_elapsed,
                            projected_mesh_scratch,
                            proxy_actor_scratch.as_deref_mut(),
                        )
                    }
                    _ => song_lua_proxy_source(target, proxy_sources).and_then(|source| {
                        song_lua_build_proxy_actor_in_space_with_scratch(
                            overlay_state,
                            z,
                            source,
                            overlay_space_width,
                            overlay_space_height,
                            render_space[0],
                            render_space[1],
                            proxy_actor_scratch.as_deref_mut(),
                        )
                    }),
                };
                if let Some(actor) = actor {
                    out.push(actor);
                }
            }
            SongLuaOverlayKind::AftSprite { .. } => {
                let Some(target_index) = topology_index
                    .aft_sprite_targets
                    .get(idx)
                    .copied()
                    .and_then(SongLuaOverlayIndex::get)
                else {
                    continue;
                };
                let Some(&texture_handle) = topology_index.aft_texture_handles.get(target_index)
                else {
                    continue;
                };
                let Some(texture_size) =
                    song_lua_aft_size(&overlays[target_index], overlay_states[target_index])
                else {
                    continue;
                };
                let z = draw_idx.min(i16::MAX as usize) as i16;
                if let Some(actors) = build_song_lua_aft_sprite_actor(
                    overlay_state,
                    texture_handle,
                    texture_size,
                    z,
                    overlay_space_width,
                    overlay_space_height,
                    effect_time,
                    effect_beat,
                    total_elapsed.animation_elapsed,
                    projected_mesh_scratch.get_mut(idx),
                ) {
                    out.extend(actors);
                }
            }
            _ => {
                let z = draw_idx.min(i16::MAX as usize) as i16;
                if append_song_lua_multi_actor_overlay(
                    out,
                    overlay,
                    overlay_state,
                    topology_index.camera_state(capture_states, idx),
                    asset_manager,
                    z,
                    overlay_space_width,
                    overlay_space_height,
                    effect_time,
                    effect_beat,
                    total_elapsed.animation_elapsed,
                    projected_mesh_scratch.get_mut(idx),
                )
                .is_none()
                    && let Some(actors) = build_song_lua_overlay_actor_with_scratch(
                        overlay,
                        overlay_state,
                        topology_index.camera_state(capture_states, idx),
                        asset_manager,
                        z,
                        overlay_space_width,
                        overlay_space_height,
                        effect_time,
                        effect_beat,
                        total_elapsed,
                        topology_index.texture_handle(idx),
                        projected_mesh_scratch.get_mut(idx),
                    )
                {
                    out.extend(actors);
                }
            }
        }
    }
}

#[cfg(test)]
fn song_lua_capture_children<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    local_overlay_states: &[SongLuaOverlayState],
    order_cache: &mut SongLuaOverlayOrderCache,
    topology_index: &SongLuaOverlayTopologyIndex,
    asset_manager: &AssetManager,
    capture_index: usize,
    proxy_sources: &SongLuaScreenProxySources<'_>,
    overlay_space_width: f32,
    overlay_space_height: f32,
    capture_states: &mut Vec<SongLuaOverlayState>,
    order_scratch: &mut Vec<usize>,
    projected_mesh_scratch: &mut [SongLuaProjectedMeshScratch],
) -> Vec<Actor> {
    let mut out = Vec::new();
    song_lua_capture_children_into(
        &mut out,
        overlays,
        overlay_states,
        local_overlay_states,
        order_cache,
        topology_index,
        asset_manager,
        capture_index,
        proxy_sources,
        None,
        overlay_space_width,
        overlay_space_height,
        0.0,
        0.0,
        0.0,
        capture_states,
        order_scratch,
        projected_mesh_scratch,
    );
    out
}

fn song_lua_overlay_apply_blocks(
    state: SongLuaOverlayState,
    blocks: &[SongLuaOverlayCommandBlock],
    elapsed: f32,
) -> SongLuaOverlayState {
    if !elapsed.is_finite() {
        return state;
    }
    let mut current = state;
    for block in blocks {
        let Some(factor) = crate::overlay_block_factor(block, elapsed) else {
            break;
        };
        if factor >= 1.0 {
            apply_overlay_delta(&mut current, &block.delta);
            continue;
        }
        let t = song_lua_ease_factor(block.easing.as_deref(), factor, block.opt1, block.opt2);
        overlay_state_lerp(&mut current, &block.delta, t);
        return current;
    }
    current
}

fn song_lua_overlay_apply_blocks_cached(
    state: SongLuaOverlayState,
    blocks: &[SongLuaOverlayCommandBlock],
    elapsed: f32,
    next_block: &mut usize,
    active_easing: &mut Option<(usize, SongLuaEase)>,
    block_state: &mut SongLuaOverlayState,
    last_elapsed: &mut f32,
) -> SongLuaOverlayState {
    if !elapsed.is_finite() {
        return state;
    }
    if elapsed < *last_elapsed {
        *next_block = 0;
        *active_easing = None;
        *block_state = state;
    }
    *last_elapsed = elapsed;

    while let Some(block) = blocks.get(*next_block) {
        let Some(factor) = crate::overlay_block_factor(block, elapsed) else {
            break;
        };
        if factor >= 1.0 {
            apply_overlay_delta(block_state, &block.delta);
            *next_block += 1;
            continue;
        }
        let easing = match *active_easing {
            Some((index, easing)) if index == *next_block => easing,
            _ => {
                let easing = SongLuaEase::from_name(block.easing.as_deref());
                *active_easing = Some((*next_block, easing));
                easing
            }
        };
        let t = easing.factor(factor, block.opt1, block.opt2);
        let mut current = *block_state;
        overlay_state_lerp(&mut current, &block.delta, t);
        return current;
    }
    *block_state
}

#[derive(Clone, Copy)]
struct SongLuaOverlayUpdateSnap {
    start_second: f32,
    end_second: f32,
    t: f32,
}

// UpdateFunction state is sampled at 10 Hz. A visibility edge can bracket a
// short geometry update, but a longer span is a dormant actor waiting for a
// future command and must not be snapped active across that whole span.
const SONG_LUA_UPDATE_SNAP_MAX_SECONDS: f32 = 0.25;

fn song_lua_overlay_update_snap(
    now: f32,
    tracks: &[crate::SongLuaOverlayRuntimeUpdateTrack],
    visible_track_indices: &[usize],
    track_cursors: &mut [usize],
) -> Option<SongLuaOverlayUpdateSnap> {
    use crate::SongLuaOverlayUpdateValue as Value;
    for &track_index in visible_track_indices {
        let track = tracks.get(track_index)?;
        let cursor = track_cursors.get_mut(track_index)?;
        let next =
            deadsync_gameplay::partition_point_from_hint(&track.samples, *cursor, |sample| {
                sample.second <= now
            });
        *cursor = next;
        let Some(from) = track.samples.get(next.wrapping_sub(1)) else {
            continue;
        };
        let Some(to) = track.samples.get(next) else {
            continue;
        };
        if to.second - from.second > SONG_LUA_UPDATE_SNAP_MAX_SECONDS {
            continue;
        }
        let t = match (&from.value, &to.value) {
            (Value::Bool(false), Value::Bool(true)) => {
                if track.target == crate::SongLuaOverlayUpdateTarget::Hibernating {
                    0.0
                } else {
                    1.0
                }
            }
            (Value::Bool(true), Value::Bool(false)) => {
                if track.target == crate::SongLuaOverlayUpdateTarget::Hibernating {
                    1.0
                } else {
                    0.0
                }
            }
            _ => continue,
        };
        return Some(SongLuaOverlayUpdateSnap {
            start_second: from.second,
            end_second: to.second,
            t,
        });
    }
    None
}

/// Apply a captured actor property using gameplay's playback rules.
pub fn apply_overlay_update(
    state: &mut SongLuaOverlayState,
    target: crate::SongLuaOverlayUpdateTarget,
    value: &crate::SongLuaOverlayUpdateValue,
) {
    use crate::{SongLuaOverlayUpdateTarget as Target, SongLuaOverlayUpdateValue as Value};
    macro_rules! set_value {
        ($target:ident, $variant:ident, $field:ident) => {
            if target == Target::$target {
                if let Value::$variant(value) = value {
                    state.$field = *value;
                }
                return;
            }
        };
    }
    macro_rules! set_option {
        ($target:ident, $variant:ident, $field:ident) => {
            if target == Target::$target {
                state.$field = match value {
                    Value::$variant(value) => Some(*value),
                    Value::None => None,
                    _ => state.$field,
                };
                return;
            }
        };
    }
    if let (Target::X | Target::Y, Value::F32(value)) = (target, value) {
        let x = if target == Target::X { *value } else { state.x };
        let y = if target == Target::Y { *value } else { state.y };
        crate::move_overlay(state, x, y);
        return;
    }
    set_value!(Aux, F32, aux);
    set_value!(Z, F32, z);
    set_value!(ZBias, F32, z_bias);
    set_value!(DrawOrder, I32, draw_order);
    set_value!(DrawByZPosition, Bool, draw_by_z_position);
    set_value!(AftCreated, Bool, aft_created);
    set_value!(AftPreserve, Bool, aft_preserve);
    set_value!(HAlign, F32, halign);
    set_value!(VAlign, F32, valign);
    set_value!(TextAlign, TextAlign, text_align);
    set_value!(Uppercase, Bool, uppercase);
    set_value!(ShadowLen, Vec2, shadow_len);
    set_value!(ShadowColor, Vec4, shadow_color);
    set_value!(Glow, Vec4, glow);
    set_option!(Fov, F32, fov);
    set_option!(Vanishpoint, Vec2, vanishpoint);
    set_value!(Diffuse, Vec4, diffuse);
    if target == Target::VertexColors {
        state.vertex_colors = match value {
            Value::VertexColors(value) => Some(**value),
            Value::None => None,
            _ => state.vertex_colors,
        };
        return;
    }
    set_value!(Visible, Bool, visible);
    set_value!(Hibernating, Bool, hibernating);
    set_value!(CropLeft, F32, cropleft);
    set_value!(CropRight, F32, cropright);
    set_value!(CropTop, F32, croptop);
    set_value!(CropBottom, F32, cropbottom);
    set_value!(FadeLeft, F32, fadeleft);
    set_value!(FadeRight, F32, faderight);
    set_value!(FadeTop, F32, fadetop);
    set_value!(FadeBottom, F32, fadebottom);
    set_value!(MaskSource, Bool, mask_source);
    set_value!(MaskDest, Bool, mask_dest);
    set_value!(DepthTest, Bool, depth_test);
    set_value!(DepthWrite, Bool, depth_write);
    set_value!(DepthTestOnFail, Bool, depth_test_on_fail);
    set_value!(CullMode, CullMode, cull_mode);
    set_value!(Zoom, F32, zoom);
    set_value!(ZoomX, F32, zoom_x);
    set_value!(ZoomY, F32, zoom_y);
    set_value!(ZoomZ, F32, zoom_z);
    set_value!(BaseZoom, F32, basezoom);
    set_value!(BaseZoomX, F32, basezoom_x);
    set_value!(BaseZoomY, F32, basezoom_y);
    set_value!(BaseZoomZ, F32, basezoom_z);
    set_value!(RotationX, F32, rot_x_deg);
    set_value!(RotationY, F32, rot_y_deg);
    set_value!(RotationZ, F32, rot_z_deg);
    set_value!(BaseRotation, Vec3, base_rotation);
    set_value!(Quaternion, Quaternion, quaternion);
    set_value!(BaseAlpha, F32, base_alpha);
    set_value!(SkewX, F32, skew_x);
    set_value!(SkewY, F32, skew_y);
    set_value!(Blend, Blend, blend);
    set_value!(Vibrate, Bool, vibrate);
    set_value!(EffectMagnitude, Vec3, effect_magnitude);
    set_value!(EffectClock, EffectClock, effect_clock);
    set_value!(EffectTimer, Bool, effect_timer);
    set_value!(EffectNoOffset, Bool, effect_no_offset);
    set_value!(EffectMode, EffectMode, effect_mode);
    set_value!(EffectColor1, Vec4, effect_color1);
    set_value!(EffectColor2, Vec4, effect_color2);
    set_value!(EffectPeriod, F32, effect_period);
    set_value!(EffectOffset, F32, effect_offset);
    set_option!(EffectTime, Vec2, effect_time);
    set_option!(EffectTiming, Vec5, effect_timing);
    set_value!(Rainbow, Bool, rainbow);
    set_value!(RainbowScroll, Bool, rainbow_scroll);
    set_value!(TextJitter, Bool, text_jitter);
    set_value!(TextDistortion, F32, text_distortion);
    set_value!(TextGlowMode, TextGlowMode, text_glow_mode);
    set_value!(MultAttrsWithDiffuse, Bool, mult_attrs_with_diffuse);
    set_value!(SpriteTexture, Bool, sprite_texture);
    set_value!(SpriteAnimate, Bool, sprite_animate);
    set_value!(SpriteLoop, Bool, sprite_loop);
    set_value!(SpritePlaybackRate, F32, sprite_playback_rate);
    set_value!(SpriteStateDelay, F32, sprite_state_delay);
    set_value!(MoviePositionSeconds, F32, movie_position_seconds);
    set_option!(SpriteStateIndex, U32, sprite_state_index);
    set_option!(VertSpacing, I32, vert_spacing);
    set_option!(WrapWidthPixels, I32, wrap_width_pixels);
    set_option!(MaxWidth, F32, max_width);
    set_option!(MaxHeight, F32, max_height);
    set_value!(MaxWPreZoom, Bool, max_w_pre_zoom);
    set_value!(MaxHPreZoom, Bool, max_h_pre_zoom);
    set_value!(MaxDimensionUsesZoom, Bool, max_dimension_uses_zoom);
    set_value!(TextureFiltering, Bool, texture_filtering);
    set_value!(TextureWrapping, Bool, texture_wrapping);
    set_option!(TexcoordOffset, Vec2, texcoord_offset);
    set_option!(CustomTextureRect, Vec4, custom_texture_rect);
    set_option!(TexcoordVelocity, Vec2, texcoord_velocity);
    set_option!(Size, Vec2, size);
    set_option!(StretchRect, Vec4, stretch_rect);
}

/// Interpolate samples from the 60 Hz native actor capture. An idle Spin axis
/// can be recorded as -90 degrees and, much later, as its wrapped +270-degree
/// equivalent. The capture suppresses unchanged frames; interpolating that
/// sparse gap would invent a visible full turn that the actor never made.
/// Consecutive frame samples still interpolate, including authored full turns.
#[must_use]
pub fn song_lua_overlay_sample_lerp(
    target: crate::SongLuaOverlayUpdateTarget,
    from: &crate::SongLuaOverlayUpdateValue,
    to: &crate::SongLuaOverlayUpdateValue,
    t: f32,
    span_seconds: f32,
) -> crate::SongLuaOverlayUpdateValue {
    use crate::{SongLuaOverlayUpdateTarget as Target, SongLuaOverlayUpdateValue as Value};
    if matches!(target, Target::RotationX | Target::RotationY | Target::RotationZ)
        && span_seconds > 2.0 / 60.0
        && let (Value::F32(start), Value::F32(end)) = (from, to)
        && ((end - start).abs() - 360.0).abs() <= 0.001
    {
        return if t < 1.0 { from.clone() } else { to.clone() };
    }
    from.lerp(to, t)
}

fn apply_song_lua_overlay_runtime_updates_for(
    now: f32,
    tracks: &[crate::SongLuaOverlayRuntimeUpdateTrack],
    track_range: std::ops::Range<usize>,
    track_cursors: &mut [usize],
    update_snap: Option<SongLuaOverlayUpdateSnap>,
    current: &mut SongLuaOverlayState,
) {
    for track_index in track_range {
        let Some(track) = tracks.get(track_index) else {
            continue;
        };
        let samples = &track.samples;
        let Some(cursor) = track_cursors.get_mut(track_index) else {
            continue;
        };
        let next = deadsync_gameplay::partition_point_from_hint(samples, *cursor, |sample| {
            sample.second <= now
        });
        *cursor = next;
        if next == 0 {
            continue;
        }
        let from = &samples[next - 1];
        let to = samples.get(next).unwrap_or(from);
        let mut t = if to.second <= from.second + f32::EPSILON {
            1.0
        } else {
            (now - from.second) / (to.second - from.second)
        };
        if let Some(snap) = update_snap
            && (from.second - snap.start_second).abs() <= 0.000_1
            && (to.second - snap.end_second).abs() <= 0.000_1
        {
            t = snap.t;
        }
        // Native clocks and base rotations take effect on their recorded frame.
        // In particular, interpolating toward a future movie seek would show
        // its frames early, before SetSecondsIntoAnimation actually ran.
        let value = if matches!(
            track.target,
            crate::SongLuaOverlayUpdateTarget::EffectTime
                | crate::SongLuaOverlayUpdateTarget::MoviePositionSeconds
                | crate::SongLuaOverlayUpdateTarget::BaseRotation
                | crate::SongLuaOverlayUpdateTarget::BaseAlpha
        ) {
            from.value.clone()
        } else {
            song_lua_overlay_sample_lerp(
                track.target,
                &from.value,
                &to.value,
                t,
                to.second - from.second,
            )
        };
        apply_overlay_update(current, track.target, &value);
        if track.target == crate::SongLuaOverlayUpdateTarget::SpriteStateIndex {
            current.sprite_animation_epoch = Some(if t >= 1.0 - f32::EPSILON {
                to.second
            } else {
                from.second
            });
        }
    }
}

fn apply_song_lua_overlay_runtime_eases_for(
    now: f32,
    overlay_index: usize,
    overlay_eases: &[SongLuaOverlayEaseWindowRuntime],
    overlay_ease_ranges: &[std::ops::Range<usize>],
    current: &mut SongLuaOverlayState,
) {
    let Some(ease_range) = overlay_ease_ranges.get(overlay_index) else {
        return;
    };
    for ease in &overlay_eases[ease_range.clone()] {
        debug_assert_eq!(ease.overlay_index, overlay_index);
        // Grouped ease ranges are sorted by start time.
        if now < ease.start_second {
            break;
        }
        if let Some(cutoff_second) = ease.cutoff_second
            && now >= cutoff_second
        {
            continue;
        }
        if now >= ease.sustain_end_second {
            apply_overlay_delta(current, &ease.to.delta);
            if ease.to.delta.sprite_state_index.is_some() {
                current.sprite_animation_epoch = Some(ease.end_second);
            }
            continue;
        }
        if ease.end_second <= ease.start_second || now >= ease.end_second {
            apply_overlay_delta(current, &ease.to.delta);
            if ease.to.delta.sprite_state_index.is_some() {
                current.sprite_animation_epoch = Some(ease.end_second);
            }
            continue;
        }
        let t = ease.easing.factor(
            ((now - ease.start_second) / (ease.end_second - ease.start_second)).clamp(0.0, 1.0),
            ease.opt1,
            ease.opt2,
        );
        apply_overlay_delta(current, &ease.from.delta);
        overlay_state_lerp(current, &ease.to.delta, t);
        if ease.from.delta.sprite_state_index.is_some() {
            current.sprite_animation_epoch = Some(ease.start_second);
        }
    }
}

fn reapply_active_song_lua_overlay_runtime_eases_for(
    now: f32,
    overlay_index: usize,
    overlay_eases: &[SongLuaOverlayEaseWindowRuntime],
    overlay_ease_ranges: &[std::ops::Range<usize>],
    current: &mut SongLuaOverlayState,
) {
    let Some(ease_range) = overlay_ease_ranges.get(overlay_index) else {
        return;
    };
    for ease in &overlay_eases[ease_range.clone()] {
        if now < ease.start_second {
            break;
        }
        if ease
            .cutoff_second
            .is_some_and(|cutoff_second| now >= cutoff_second)
            || now >= ease.sustain_end_second
        {
            continue;
        }
        if ease.end_second <= ease.start_second || now >= ease.end_second {
            apply_overlay_delta(current, &ease.to.delta);
            continue;
        }
        let t = ease.easing.factor(
            ((now - ease.start_second) / (ease.end_second - ease.start_second)).clamp(0.0, 1.0),
            ease.opt1,
            ease.opt2,
        );
        apply_overlay_delta(current, &ease.from.delta);
        overlay_state_lerp(current, &ease.to.delta, t);
        if ease.from.delta.sprite_state_index.is_some() {
            current.sprite_animation_epoch = Some(ease.start_second);
        }
    }
}

fn song_lua_overlay_render_state_from<S: NoteskinSlot + Clone>(
    now: f32,
    overlay_index: usize,
    overlay: &SongLuaOverlayActor<S>,
    overlay_events: &[Vec<SongLuaOverlayMessageRuntime>],
    overlay_eases: &[SongLuaOverlayEaseWindowRuntime],
    overlay_ease_ranges: &[std::ops::Range<usize>],
    overlay_updates: &[crate::SongLuaOverlayRuntimeUpdateTrack],
    update_range: std::ops::Range<usize>,
    update_cursors: &mut [usize],
    update_snap: Option<SongLuaOverlayUpdateSnap>,
    message_cache: &mut SongLuaMessageStateCache,
) -> SongLuaOverlayState {
    let events = overlay_events.get(overlay_index).map(Vec::as_slice);
    let has_events = events.is_some_and(|events| !events.is_empty());
    let has_eases = overlay_ease_ranges
        .get(overlay_index)
        .is_some_and(|range| !range.is_empty());
    let has_updates = !update_range.is_empty();
    if !has_events && !has_eases && !has_updates {
        return overlay.initial_state;
    }
    song_lua_overlay_render_state_dynamic(
        now,
        overlay_index,
        overlay,
        events,
        overlay_eases,
        overlay_ease_ranges,
        overlay_updates,
        update_range,
        update_cursors,
        update_snap,
        message_cache,
    )
}

fn song_lua_overlay_render_state_dynamic<S: NoteskinSlot + Clone>(
    now: f32,
    overlay_index: usize,
    overlay: &SongLuaOverlayActor<S>,
    events: Option<&[SongLuaOverlayMessageRuntime]>,
    overlay_eases: &[SongLuaOverlayEaseWindowRuntime],
    overlay_ease_ranges: &[std::ops::Range<usize>],
    overlay_updates: &[crate::SongLuaOverlayRuntimeUpdateTrack],
    update_range: std::ops::Range<usize>,
    update_cursors: &mut [usize],
    update_snap: Option<SongLuaOverlayUpdateSnap>,
    message_cache: &mut SongLuaMessageStateCache,
) -> SongLuaOverlayState {
    let mut current = song_lua_message_state_cached(
        now,
        overlay.initial_state,
        &overlay.message_commands,
        events,
        message_cache,
    );
    apply_song_lua_overlay_runtime_eases_for(
        now,
        overlay_index,
        overlay_eases,
        overlay_ease_ranges,
        &mut current,
    );
    apply_song_lua_overlay_runtime_updates_for(
        now,
        overlay_updates,
        update_range,
        update_cursors,
        update_snap,
        &mut current,
    );
    // Exact function eases and sampled UpdateFunction tracks can describe the
    // same Lua setter. ITGmania executes that function ease every frame, so it
    // must remain authoritative while active instead of being replaced by the
    // lower-rate sampled approximation.
    reapply_active_song_lua_overlay_runtime_eases_for(
        now,
        overlay_index,
        overlay_eases,
        overlay_ease_ranges,
        &mut current,
    );
    current
}

/// Sample immutable message commands, including when seeking a song timeline.
pub fn replay_song_lua_message_state(
    now: f32,
    initial_state: SongLuaOverlayState,
    message_commands: &[SongLuaOverlayMessageCommand],
    events: Option<&[SongLuaOverlayMessageRuntime]>,
) -> SongLuaOverlayState {
    let Some(events) = events else {
        return initial_state;
    };
    let mut current = initial_state;
    let mut active: Option<(&SongLuaOverlayMessageCommand, SongLuaOverlayState, f32)> = None;
    for event in events {
        let event_second = event.event_second;
        if event_second > now {
            break;
        }
        let Some(command) = message_commands.get(event.command_index) else {
            continue;
        };
        if let Some((command, base, start_second)) = active.take() {
            let blocks = &command.blocks;
            let elapsed = event_second - start_second + command.frame_advance;
            current = song_lua_overlay_apply_blocks(base, blocks, elapsed);
            if let Some(epoch) = song_lua_sprite_animation_epoch(
                blocks,
                elapsed,
                start_second - command.frame_advance,
            ) {
                current.sprite_animation_epoch = Some(epoch);
            }
        }
        let base = current;
        current = song_lua_overlay_apply_blocks(base, &command.blocks, command.frame_advance);
        active = Some((command, base, event_second));
    }
    if let Some((command, base, start_second)) = active {
        let blocks = &command.blocks;
        let elapsed = now - start_second + command.frame_advance;
        current = song_lua_overlay_apply_blocks(base, blocks, elapsed);
        if let Some(epoch) =
            song_lua_sprite_animation_epoch(blocks, elapsed, start_second - command.frame_advance)
        {
            current.sprite_animation_epoch = Some(epoch);
        }
    }
    current
}

fn song_lua_sprite_animation_epoch(
    blocks: &[SongLuaOverlayCommandBlock],
    elapsed: f32,
    command_start_second: f32,
) -> Option<f32> {
    blocks.iter().rev().find_map(|block| {
        let activation = crate::overlay_block_end(block);
        (block.delta.sprite_state_index.is_some() && elapsed >= activation)
            .then_some(command_start_second + activation)
    })
}

fn song_lua_message_state_cached(
    now: f32,
    initial_state: SongLuaOverlayState,
    message_commands: &[SongLuaOverlayMessageCommand],
    events: Option<&[SongLuaOverlayMessageRuntime]>,
    cache: &mut SongLuaMessageStateCache,
) -> SongLuaOverlayState {
    let Some(events) = events else {
        cache.reset(initial_state);
        return initial_state;
    };
    if !now.is_finite() {
        return replay_song_lua_message_state(now, initial_state, message_commands, Some(events));
    }
    if !cache.initialized || now < cache.processed_until {
        cache.reset(initial_state);
    }

    while let Some(event) = events.get(cache.next_event) {
        if event.event_second > now {
            break;
        }
        cache.next_event += 1;
        cache.processed_until = event.event_second;
        if message_commands.get(event.command_index).is_none() {
            continue;
        }
        if let Some(active_command_index) = cache.active_command_index
            && let Some(active_command) = message_commands.get(active_command_index)
        {
            let command_base = cache.base_state;
            let elapsed =
                event.event_second - cache.active_start_second + active_command.frame_advance;
            cache.base_state = song_lua_overlay_apply_blocks_cached(
                command_base,
                &active_command.blocks,
                elapsed,
                &mut cache.active_next_block,
                &mut cache.active_easing,
                &mut cache.active_block_state,
                &mut cache.active_last_elapsed,
            );
            if let Some(epoch) = song_lua_sprite_animation_epoch(
                &active_command.blocks,
                elapsed,
                cache.active_start_second - active_command.frame_advance,
            ) {
                cache.base_state.sprite_animation_epoch = Some(epoch);
            }
        }
        cache.active_command_index = Some(event.command_index);
        cache.active_start_second = event.event_second;
        cache.reset_active_blocks(cache.base_state);
    }

    let Some(command) = cache
        .active_command_index
        .and_then(|command_index| message_commands.get(command_index))
    else {
        return cache.base_state;
    };
    let elapsed = now - cache.active_start_second + command.frame_advance;
    let mut current = song_lua_overlay_apply_blocks_cached(
        cache.base_state,
        &command.blocks,
        elapsed,
        &mut cache.active_next_block,
        &mut cache.active_easing,
        &mut cache.active_block_state,
        &mut cache.active_last_elapsed,
    );
    if let Some(epoch) = song_lua_sprite_animation_epoch(
        &command.blocks,
        elapsed,
        cache.active_start_second - command.frame_advance,
    ) {
        current.sprite_animation_epoch = Some(epoch);
    }
    current
}

fn song_lua_player_render_state<
    P: deadsync_gameplay::GameplayProfileData,
    S: NoteskinSlot + Clone,
>(
    state: &GameplayCoreState<P, S>,
    player_index: usize,
    message_cache: &mut SongLuaMessageStateCache,
) -> SongLuaOverlayState {
    let song_lua_visuals = state.song_lua_visuals();
    let Some(actor) = song_lua_visuals.player_actors.get(player_index) else {
        return SongLuaOverlayState::default();
    };
    song_lua_captured_actor_state_from(
        state.current_music_time_display(),
        actor,
        song_lua_visuals
            .player_events
            .get(player_index)
            .map(Vec::as_slice),
        message_cache,
    )
}

fn song_lua_layer_parent_state<S: NoteskinSlot + Clone>(
    outer: SongLuaOverlayState,
    inner: SongLuaOverlayState,
    size: [f32; 2],
    clock: [f32; 2],
) -> SongLuaOverlayState {
    if outer == SongLuaOverlayState::default() {
        inner
    } else {
        song_lua_overlay_compose_state(
            &SongLuaOverlayKind::<S>::ActorFrame,
            outer,
            inner,
            size[0],
            size[1],
            clock,
        )
    }
}

fn song_lua_song_foreground_state_from(
    now: f32,
    song_foreground: &SongLuaCapturedActor,
    events: &[SongLuaOverlayMessageRuntime],
    message_cache: &mut SongLuaMessageStateCache,
) -> SongLuaOverlayState {
    song_lua_captured_actor_state_from(now, song_foreground, Some(events), message_cache)
}

fn song_lua_captured_actor_state_from(
    now: f32,
    actor: &SongLuaCapturedActor,
    events: Option<&[SongLuaOverlayMessageRuntime]>,
    message_cache: &mut SongLuaMessageStateCache,
) -> SongLuaOverlayState {
    song_lua_captured_state_from(
        now,
        actor.initial_state,
        &actor.message_commands,
        events,
        message_cache,
    )
}

fn song_lua_child_render(
    now: f32,
    clock: [f32; 2],
    actor: &SongLuaCapturedChildActor,
    events: &[SongLuaOverlayMessageRuntime],
    message_cache: &mut SongLuaMessageStateCache,
    captured: bool,
) -> (Option<deadsync_notefield::HudActorTransform>, bool) {
    if actor
        .render_frames
        .first()
        .is_some_and(|frame| frame.second <= clock[0])
    {
        let (matrix, tint, visible) = song_lua_render_chain(&actor.render_frames, clock, captured);
        return (
            Some(deadsync_notefield::HudActorTransform { matrix, tint }),
            visible,
        );
    }
    let state = song_lua_captured_state_from(
        now,
        actor.initial_state,
        &actor.message_commands,
        Some(events),
        message_cache,
    );
    (None, !state.hibernating && (state.visible || captured))
}

fn song_lua_captured_state_from(
    now: f32,
    initial_state: SongLuaOverlayState,
    message_commands: &[SongLuaOverlayMessageCommand],
    events: Option<&[SongLuaOverlayMessageRuntime]>,
    message_cache: &mut SongLuaMessageStateCache,
) -> SongLuaOverlayState {
    if events.is_none_or(<[_]>::is_empty) {
        message_cache.initialized = false;
        return initial_state;
    }
    song_lua_message_state_cached(now, initial_state, message_commands, events, message_cache)
}

fn song_lua_song_foreground_state<
    P: deadsync_gameplay::GameplayProfileData,
    S: NoteskinSlot + Clone,
>(
    state: &GameplayCoreState<P, S>,
    message_cache: &mut SongLuaMessageStateCache,
) -> SongLuaOverlayState {
    let song_lua_visuals = state.song_lua_visuals();
    song_lua_song_foreground_state_from(
        state.current_music_time_display(),
        &song_lua_visuals.song_foreground,
        song_lua_visuals.song_foreground_events.as_slice(),
        message_cache,
    )
}

fn song_lua_capture_tint(color: [f32; 4], tint: [f32; 4]) -> [f32; 4] {
    [
        color[0] * tint[0],
        color[1] * tint[1],
        color[2] * tint[2],
        color[3] * tint[3],
    ]
}

fn song_lua_biased_world_z(state: SongLuaOverlayState, effect_z: f32) -> f32 {
    effect_z + state.z_bias
}

fn song_lua_add_z(z: i16, delta: i16) -> i16 {
    (i32::from(z) + i32::from(delta)).clamp(i32::from(i16::MIN), i32::from(i16::MAX)) as i16
}

const SONG_LUA_PLAYER_LAYER_Z_BASE: i16 = 900;
const SONG_LUA_OVERLAY_LAYER_Z_BASE: i16 = 1100;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct SongLuaLayerDepth {
    base: i16,
    ceiling: i16,
}

impl SongLuaLayerDepth {
    fn draw_z(self, draw_idx: usize) -> i16 {
        song_lua_add_z(self.base, draw_idx.min(i16::MAX as usize) as i16).min(self.ceiling)
    }
}

const SONG_LUA_BACKGROUND_DEPTH: SongLuaLayerDepth = SongLuaLayerDepth {
    base: 0,
    ceiling: SONG_LUA_PLAYER_LAYER_Z_BASE - 1,
};
/// Highest song-Lua foreground z; theme transitions must draw above this.
pub const LUA_FOREGROUND_Z_MAX: i16 = 1199;

const SONG_LUA_FOREGROUND_DEPTH: SongLuaLayerDepth = SongLuaLayerDepth {
    base: SONG_LUA_OVERLAY_LAYER_Z_BASE,
    // ScreenWithMenuElements draws transitions above the entire foreground.
    ceiling: LUA_FOREGROUND_Z_MAX,
};

fn song_lua_player_layer_z(song_lua_active: bool) -> i16 {
    // Actor::SetZ changes geometry, independently of Actor::SetDrawOrder.
    // Player depth must not move receptors above SongForeground's pad model.
    if song_lua_active {
        SONG_LUA_PLAYER_LAYER_Z_BASE
    } else {
        0
    }
}

fn song_lua_style_capture_actor(
    mut actor: Actor,
    capture_tint: [f32; 4],
    blend: Option<BlendMode>,
    z_shift: i16,
) -> Actor {
    song_lua_style_capture_actor_in_place(&mut actor, capture_tint, blend, z_shift);
    actor
}

fn song_lua_style_capture_actor_in_place(
    actor: &mut Actor,
    capture_tint: [f32; 4],
    blend: Option<BlendMode>,
    z_shift: i16,
) {
    // Only live style fields change. Keep child Vec/Box storage and shared
    // geometry in place, including the style boundary of shared wrappers.
    match actor {
        Actor::Sprite {
            tint,
            glow,
            shadow_color,
            vertex_color_encoding,
            blend: actor_blend,
            z,
            ..
        } => {
            *tint = song_lua_capture_tint(*tint, capture_tint);
            *glow = song_lua_capture_tint(*glow, capture_tint);
            if *vertex_color_encoding == deadlib_present::actors::VertexColorEncoding::Float {
                *shadow_color = song_lua_capture_tint(*shadow_color, capture_tint);
            }
            *actor_blend = blend.unwrap_or(*actor_blend);
            *z = song_lua_add_z(*z, z_shift);
        }
        Actor::Text {
            color,
            stroke_color,
            glow,
            shadow_color,
            blend: actor_blend,
            z,
            ..
        } => {
            *color = song_lua_capture_tint(*color, capture_tint);
            *stroke_color = stroke_color.map(|color| song_lua_capture_tint(color, capture_tint));
            *glow = song_lua_capture_tint(*glow, capture_tint);
            *shadow_color = song_lua_capture_tint(*shadow_color, capture_tint);
            *actor_blend = blend.unwrap_or(*actor_blend);
            *z = song_lua_add_z(*z, z_shift);
        }
        Actor::Mesh {
            tint,
            blend: actor_blend,
            z,
            ..
        }
        | Actor::ReusableMesh {
            tint,
            blend: actor_blend,
            z,
            ..
        } => {
            *tint = song_lua_capture_tint(*tint, capture_tint);
            *actor_blend = blend.unwrap_or(*actor_blend);
            *z = song_lua_add_z(*z, z_shift);
        }
        Actor::TexturedMesh {
            tint,
            glow,
            blend: actor_blend,
            z,
            ..
        }
        | Actor::ReusableTexturedMesh {
            tint,
            glow,
            blend: actor_blend,
            z,
            ..
        } => {
            *tint = song_lua_capture_tint(*tint, capture_tint);
            *glow = song_lua_capture_tint(*glow, capture_tint);
            *actor_blend = blend.unwrap_or(*actor_blend);
            *z = song_lua_add_z(*z, z_shift);
        }
        Actor::Frame { children, z, .. } => {
            *z = song_lua_add_z(*z, z_shift);
            for child in children {
                song_lua_style_capture_actor_in_place(child, capture_tint, blend, z_shift);
            }
        }
        Actor::SharedFrame {
            tint,
            blend: actor_blend,
            z,
            ..
        }
        | Actor::SharedTransform {
            tint,
            blend: actor_blend,
            z,
            ..
        }
        | Actor::RetainedFrame {
            tint,
            blend: actor_blend,
            z,
            ..
        } => {
            *tint = song_lua_capture_tint(*tint, capture_tint);
            *actor_blend = blend.or(*actor_blend);
            *z = song_lua_add_z(*z, z_shift);
        }
        Actor::Camera { children, .. } => {
            for child in children {
                song_lua_style_capture_actor_in_place(child, capture_tint, blend, z_shift);
            }
        }
        Actor::SharedCamera { children, .. } => {
            for child in Arc::make_mut(children) {
                song_lua_style_capture_actor_in_place(child, capture_tint, blend, z_shift);
            }
        }
        Actor::Shadow { color, child, .. } => {
            if !song_lua_has_native_sprite_colors(child) {
                *color = song_lua_capture_tint(*color, capture_tint);
            }
            song_lua_style_capture_actor_in_place(child, capture_tint, blend, z_shift);
        }
        Actor::CameraPush { .. } | Actor::CameraPop => {}
    }
}

#[inline(always)]
const fn song_lua_overlay_blend(blend: SongLuaOverlayBlendMode) -> BlendMode {
    match blend {
        SongLuaOverlayBlendMode::NoEffect => BlendMode::NoEffect,
        SongLuaOverlayBlendMode::Alpha => BlendMode::Alpha,
        SongLuaOverlayBlendMode::Add => BlendMode::Add,
        SongLuaOverlayBlendMode::Multiply => BlendMode::Multiply,
        SongLuaOverlayBlendMode::Subtract => BlendMode::Subtract,
    }
}

fn song_lua_effect_clock(state: SongLuaOverlayState, mut clock: [f32; 2]) -> [f32; 2] {
    if (state.rainbow || state.vibrate || song_lua_compose_effect(state.effect_mode))
        && let Some([at, units]) = state.effect_time
    {
        let axis = matches!(state.effect_clock, deadlib_present::anim::EffectClock::Beat) as usize;
        clock[axis] = units + (clock[axis] - at);
    }
    clock
}

#[inline(always)]
fn song_lua_overlay_effect_state(state: SongLuaOverlayState) -> EffectState {
    let period = state.effect_period.max(f32::EPSILON);
    EffectState {
        clock: state.effect_clock,
        mode: if state.spin_baked && state.effect_mode == deadlib_present::anim::EffectMode::Spin {
            deadlib_present::anim::EffectMode::None
        } else {
            state.effect_mode
        },
        color1: state.effect_color1,
        color2: state.effect_color2,
        period,
        offset: state.effect_offset,
        timing: state
            .effect_timing
            .unwrap_or([period * 0.5, 0.0, period * 0.5, 0.0, 0.0]),
        magnitude: state.effect_magnitude,
        ..deadlib_present::anim::EffectState::default()
    }
}

#[inline(always)]
fn song_lua_effect_lerp(a: f32, b: f32, t: f32) -> f32 {
    (b - a) * t + a
}

const fn song_lua_compose_effect(mode: deadlib_present::anim::EffectMode) -> bool {
    use deadlib_present::anim::EffectMode;
    matches!(
        mode,
        EffectMode::Pulse | EffectMode::Bob | EffectMode::Bounce | EffectMode::Wag
    ) || song_lua_color_effect(mode)
}

const fn song_lua_color_effect(mode: deadlib_present::anim::EffectMode) -> bool {
    use deadlib_present::anim::EffectMode;
    matches!(
        mode,
        EffectMode::DiffuseBlink
            | EffectMode::DiffuseShift
            | EffectMode::DiffuseRamp
            | EffectMode::GlowBlink
            | EffectMode::GlowShift
            | EffectMode::GlowRamp
    )
}

fn song_lua_effect_percent(effect: EffectState, clock: [f32; 2]) -> Option<f32> {
    if matches!(
        effect.mode,
        deadlib_present::anim::EffectMode::None | deadlib_present::anim::EffectMode::Spin
    ) {
        return None;
    }
    let t = effect.timing;
    let total = t[0] + t[1] + t[2] + t[3] + t[4];
    if !total.is_finite() || total <= 0.0 {
        return None;
    }
    let units =
        deadlib_present::anim::effect_clock_units(effect, clock[0], clock[1]) + effect.offset;
    let x = (units % total + total) % total;
    let half = t[0] + t[1];
    let full = half + t[2];
    let percent = if x < t[0] {
        x * 0.5 / t[0]
    } else if x < half {
        0.5
    } else if x < full {
        (x - half) * 0.5 / (full - half) + 0.5
    } else if x < full + t[3] {
        1.0
    } else {
        0.0
    };
    Some(percent)
}

fn song_lua_pulse_scale(effect: EffectState, clock: [f32; 2], scale: &mut [f32; 3]) {
    let Some(percent) = song_lua_effect_percent(effect, clock) else {
        return;
    };
    let pulse = (percent * std::f32::consts::PI).sin();
    let zoom = song_lua_effect_lerp(effect.magnitude[0], effect.magnitude[1], pulse);
    for (axis, value) in scale.iter_mut().enumerate() {
        *value *= zoom;
        *value *= song_lua_effect_lerp(effect.color1[axis], effect.color2[axis], pulse);
    }
}

fn song_lua_apply_motion(
    effect: EffectState,
    percent: f32,
    position: &mut [f32; 3],
    rotation: &mut [f32; 3],
) {
    use deadlib_present::anim::EffectMode;
    let angle = match effect.mode {
        EffectMode::Bob => percent * std::f32::consts::PI * 2.0,
        EffectMode::Bounce => percent * std::f32::consts::PI,
        EffectMode::Wag => percent * 2.0 * std::f32::consts::PI,
        _ => return,
    };
    let wave = angle.sin();
    let target = if effect.mode == EffectMode::Wag {
        rotation
    } else {
        position
    };
    for axis in 0..3 {
        target[axis] += effect.magnitude[axis] * wave;
    }
}

fn song_lua_pre_draw_state(mut state: SongLuaOverlayState, clock: [f32; 2]) -> SongLuaOverlayState {
    use deadlib_present::anim::EffectMode;
    let clock = song_lua_effect_clock(state, clock);
    if state.vibrate {
        let mut position = [state.x, state.y, state.z];
        song_lua_apply_state_vibration(state, clock[0], 0, &mut position);
        [state.x, state.y, state.z] = position;
        // Each parent's sampled local translation is shared by its children.
        // It must not be resampled or folded into a child's effect magnitude.
        state.vibrate = false;
        state.vibrate_input = None;
        state.vibrate_zoom = None;
    }
    // Actor::BeginDraw adds the independent base pose after tween/effect state.
    state.rot_x_deg += state.base_rotation[0];
    state.rot_y_deg += state.base_rotation[1];
    state.rot_z_deg += state.base_rotation[2];
    state.base_rotation = [0.0; 3];
    if state.rainbow || song_lua_color_effect(state.effect_mode) {
        let mut tint = state.diffuse;
        tint[3] = state.vertex_colors.map_or(tint[3], |colors| colors[0][3]);
        if song_lua_apply_color_effect(
            song_lua_overlay_effect_state(state),
            state.rainbow,
            clock,
            &mut tint,
            &mut state.glow,
        ) {
            state.diffuse = tint;
            state.vertex_colors = None;
        }
        // Color effects replace local colors before inherited tint and glow.
        // Keep the compiled/getter state intact; only the draw state is consumed.
        state.effect_mode = EffectMode::None;
        state.rainbow = false;
    }
    // Actor::PreDraw applies base alpha after local color effects.
    state.diffuse[3] *= state.base_alpha;
    state.base_alpha = 1.0;
    if !matches!(
        state.effect_mode,
        EffectMode::Bob | EffectMode::Bounce | EffectMode::Wag
    ) {
        return state;
    }
    let effect = song_lua_overlay_effect_state(state);
    if let Some(percent) = song_lua_effect_percent(effect, clock) {
        let mut position = [state.x, state.y, state.z];
        let mut rotation = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
        song_lua_apply_motion(effect, percent, &mut position, &mut rotation);
        [state.x, state.y, state.z] = position;
        [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg] = rotation;
    }
    // PreDraw changes this actor's local pose before its parent is applied.
    // The composed draw pose must not apply the same motion again at the leaf.
    state.effect_mode = EffectMode::None;
    state
}

fn song_lua_pulse_parent(mut parent: SongLuaOverlayState, clock: [f32; 2]) -> SongLuaOverlayState {
    if parent.effect_mode != deadlib_present::anim::EffectMode::Pulse {
        return parent;
    }
    let effect = song_lua_overlay_effect_state(parent);
    let clock = song_lua_effect_clock(parent, clock);
    // Common zoom and axis zoom are aliases, rather than independent factors.
    let current = SongLuaOverlayState {
        basezoom: 1.0,
        basezoom_x: 1.0,
        basezoom_y: 1.0,
        basezoom_z: 1.0,
        ..parent
    };
    let [x, y] = song_lua_overlay_axis_scale(current);
    let mut zoom = [x, y, song_lua_overlay_z_scale(current)];
    song_lua_pulse_scale(effect, clock, &mut zoom);
    parent.zoom = 1.0;
    [parent.zoom_x, parent.zoom_y, parent.zoom_z] = zoom;
    if let Some([_, local]) = parent.scale_factors.as_mut() {
        song_lua_pulse_scale(effect, clock, local);
    }
    parent
}

fn song_lua_proxy_effect(
    mut state: SongLuaOverlayState,
    effect_time: f32,
    effect_beat: f32,
    actor_seed: u32,
) -> SongLuaOverlayState {
    let mut offset = [0.0; 3];
    let mut scale = [1.0; 3];
    let mut rotation = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
    song_lua_apply_overlay_effect(
        state,
        effect_time,
        effect_beat,
        actor_seed,
        &mut state.diffuse,
        &mut state.glow,
        &mut offset,
        &mut scale,
        &mut rotation,
    );
    state.x += offset[0];
    state.y += offset[1];
    state.z += offset[2];
    state.zoom_x *= scale[0];
    state.zoom_y *= scale[1];
    state.zoom_z *= scale[2];
    [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg] = rotation;
    state
}

#[inline(always)]
fn song_lua_overlay_has_visible_output(state: SongLuaOverlayState) -> bool {
    // Actor::BeginDraw multiplies glow effects by the original diffuse alpha.
    // Only an explicit, non-effect glow can outlive a transparent actor.
    // Native diffuse submission tests the float before RageVColor quantization;
    // even a positive alpha that packs to byte zero must retain its geometry.
    state.diffuse[3] > 0.0 || state.glow[3] > f32::EPSILON
}

// Native color macros replace RGB and retain the original local diffuse alpha.
// The return value identifies uniform diffuse output, which replaces gradients.
fn song_lua_apply_color_effect(
    effect: EffectState,
    rainbow: bool,
    clock: [f32; 2],
    tint: &mut [f32; 4],
    glow: &mut [f32; 4],
) -> bool {
    use deadlib_present::anim::EffectMode;
    if !rainbow && !song_lua_color_effect(effect.mode) {
        return false;
    }
    let color_effect = EffectState {
        mode: if rainbow {
            EffectMode::DiffuseShift
        } else {
            effect.mode
        },
        ..effect
    };
    let Some(percent) = song_lua_effect_percent(color_effect, clock) else {
        return false;
    };
    if rainbow {
        tint[..3].copy_from_slice(&song_lua_rainbow_color(percent));
        return true;
    }
    let color = match effect.mode {
        EffectMode::DiffuseBlink | EffectMode::GlowBlink => {
            if percent > 0.5 {
                effect.color1
            } else {
                effect.color2
            }
        }
        _ => {
            let mix = if matches!(
                effect.mode,
                EffectMode::DiffuseShift | EffectMode::GlowShift
            ) {
                song_lua_color_mix(percent)
            } else {
                percent
            };
            std::array::from_fn(|channel| {
                effect.color1[channel] * mix + effect.color2[channel] * (1.0 - mix)
            })
        }
    };
    let diffuse = matches!(
        effect.mode,
        EffectMode::DiffuseBlink | EffectMode::DiffuseShift | EffectMode::DiffuseRamp
    );
    let alpha = tint[3];
    let target = if diffuse { tint } else { glow };
    *target = color;
    target[3] *= alpha;
    diffuse
}

fn song_lua_apply_overlay_effect(
    state: SongLuaOverlayState,
    effect_time: f32,
    effect_beat: f32,
    actor_seed: u32,
    tint: &mut [f32; 4],
    glow: &mut [f32; 4],
    offset: &mut [f32; 3],
    scale: &mut [f32; 3],
    rot_deg: &mut [f32; 3],
) {
    let effect = song_lua_overlay_effect_state(state);
    let [effect_time, effect_beat] = song_lua_effect_clock(state, [effect_time, effect_beat]);
    let rainbow = state.rainbow;
    song_lua_apply_state_vibration(state, effect_time, actor_seed, offset);
    if matches!(effect.mode, deadlib_present::anim::EffectMode::Spin) {
        let units = deadlib_present::anim::effect_clock_units(effect, effect_time, effect_beat);
        for axis in 0..3 {
            // Actor::Update rounds the product before adding the base angle.
            rot_deg[axis] = (effect.magnitude[axis] * units + rot_deg[axis]).rem_euclid(360.0);
        }
    }
    if let Some(percent) = song_lua_effect_percent(effect, [effect_time, effect_beat]) {
        match effect.mode {
            deadlib_present::anim::EffectMode::DiffuseBlink
            | deadlib_present::anim::EffectMode::DiffuseShift
            | deadlib_present::anim::EffectMode::DiffuseRamp
            | deadlib_present::anim::EffectMode::GlowBlink
            | deadlib_present::anim::EffectMode::GlowShift
            | deadlib_present::anim::EffectMode::GlowRamp => {}
            deadlib_present::anim::EffectMode::Pulse => {
                song_lua_pulse_scale(effect, [effect_time, effect_beat], scale);
            }
            deadlib_present::anim::EffectMode::Bob
            | deadlib_present::anim::EffectMode::Bounce
            | deadlib_present::anim::EffectMode::Wag => {
                song_lua_apply_motion(effect, percent, offset, rot_deg);
            }
            deadlib_present::anim::EffectMode::Spin | deadlib_present::anim::EffectMode::None => {}
        }
    }
    song_lua_apply_color_effect(effect, rainbow, [effect_time, effect_beat], tint, glow);
    offset[0] = offset[0].max(-1_000_000.0).min(1_000_000.0);
    offset[1] = offset[1].max(-1_000_000.0).min(1_000_000.0);
    offset[2] = offset[2].max(-1_000_000.0).min(1_000_000.0);
    // Native RageColor remains floating point through corner and inherited
    // color multiplication. RageVColor clamps only the final submitted value.
}

fn song_lua_clamp_float_output_colors(tint: &mut [f32; 4], glow: &mut [f32; 4]) {
    // Keep the existing output range for actors that do not yet submit
    // RageVColor. Sprite and Quad colors are packed after all multiplication.
    for channel in tint.iter_mut().chain(glow.iter_mut()) {
        *channel = channel.clamp(0.0, 1.0);
    }
}

fn song_lua_vibration_input(effect_time: f32, actor_seed: u32) -> [f32; 3] {
    let frame = (effect_time.max(0.0) * 60.0).floor() as u32;
    std::array::from_fn(|axis| {
        let mut hash = frame
            ^ actor_seed.wrapping_mul(0x85eb_ca6b)
            ^ (axis as u32 + 1).wrapping_mul(0x9e37_79b9);
        hash ^= hash >> 16;
        hash = hash.wrapping_mul(0x7feb_352d);
        hash ^= hash >> 15;
        hash = hash.wrapping_mul(0x846c_a68b);
        hash ^= hash >> 16;
        (hash as f32 / u32::MAX as f32).mul_add(2.0, -1.0)
    })
}

fn song_lua_draw_input_state(
    mut state: SongLuaOverlayState,
    actor: usize,
    clock: [f32; 2],
) -> SongLuaOverlayState {
    if state.vibrate && state.vibrate_input.is_none() {
        state.vibrate_input = Some(song_lua_vibration_input(
            song_lua_effect_clock(state, clock)[0],
            actor as u32,
        ));
    }
    state
}

fn song_lua_apply_state_vibration(
    state: SongLuaOverlayState,
    effect_time: f32,
    actor_seed: u32,
    position: &mut [f32; 3],
) {
    if !state.vibrate {
        return;
    }
    let jitter = state
        .vibrate_input
        .unwrap_or_else(|| song_lua_vibration_input(effect_time, actor_seed));
    let zoom = state.vibrate_zoom.unwrap_or_else(|| {
        if (state.zoom_x - 1.0).abs() <= f32::EPSILON {
            state.zoom
        } else {
            state.zoom_x
        }
    });
    // Actor::PreDraw rounds each multiplication before adding the offset.
    // GetZoom is the destination X scale; base zoom is applied by BeginDraw.
    for axis in 0..3 {
        position[axis] += state.effect_magnitude[axis] * jitter[axis] * zoom;
    }
}

fn song_lua_color_mix(percent: f32) -> f32 {
    ((percent + 0.25) * 2.0 * std::f32::consts::PI).sin() / 2.0 + 0.5
}

fn song_lua_rainbow_color(percent: f32) -> [f32; 3] {
    let between = song_lua_color_mix(percent);
    std::array::from_fn(|axis| {
        (between * 2.0 * std::f32::consts::PI + std::f32::consts::PI * (axis * 2) as f32 / 3.0)
            .cos()
            * 0.5
            + 0.5
    })
}

const SONG_LUA_TEXT_RAINBOW_COLORS: [[f32; 4]; 7] = [
    [1.0, 0.0, 0.4, 1.0],
    [0.8, 0.2, 0.6, 1.0],
    [0.4, 0.3, 0.5, 1.0],
    [0.2, 0.6, 1.0, 1.0],
    [0.2, 0.8, 0.8, 1.0],
    [0.2, 0.8, 0.4, 1.0],
    [1.0, 0.8, 0.2, 1.0],
];

fn song_lua_rainbow_scroll_attributes(text: &str, uptime_seconds: f64) -> Vec<TextAttribute> {
    song_lua_rainbow_scroll_attributes_at_phase(text, song_lua_rainbow_scroll_phase(uptime_seconds))
}

fn song_lua_rainbow_scroll_attributes_at_phase(
    text: &str,
    first_color: usize,
) -> Vec<TextAttribute> {
    let char_count = text.chars().count();
    let mut out = Vec::with_capacity(char_count);
    append_song_lua_rainbow_scroll_attributes_at_phase(text, first_color, &mut out);
    out
}

fn append_song_lua_rainbow_scroll_attributes_at_phase(
    text: &str,
    first_color: usize,
    out: &mut Vec<TextAttribute>,
) {
    let char_count = text.chars().count();
    for index in 0..char_count {
        out.push(TextAttribute {
            start: index,
            length: 1,
            color: SONG_LUA_TEXT_RAINBOW_COLORS
                [(first_color + index) % SONG_LUA_TEXT_RAINBOW_COLORS.len()],
            vertex_colors: None,
            glow: None,
        });
    }
}

#[inline(always)]
fn song_lua_rainbow_scroll_phase(uptime_seconds: f64) -> usize {
    ((uptime_seconds / 0.2).floor() as usize) % SONG_LUA_TEXT_RAINBOW_COLORS.len()
}

fn song_lua_rainbow_scroll_phases(
    text: &str,
) -> [Arc<[TextAttribute]>; SONG_LUA_TEXT_RAINBOW_COLORS.len()] {
    std::array::from_fn(|phase| {
        Arc::from(song_lua_rainbow_scroll_attributes_at_phase(text, phase).into_boxed_slice())
    })
}

fn song_lua_transparent_text_attributes(
    text: &str,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> TextAttributes {
    let char_count = text.chars().count();
    if char_count == 0 {
        return TextAttributes::default();
    }
    let fill = |out: &mut Vec<TextAttribute>| {
        out.push(TextAttribute {
            start: 0,
            length: char_count,
            color: [1.0, 1.0, 1.0, 0.0],
            vertex_colors: None,
            glow: None,
        });
    };
    if let Some(scratch) = scratch {
        scratch.update_text_glow(fill)
    } else {
        let mut out = Vec::with_capacity(1);
        fill(&mut out);
        out.into()
    }
}

fn song_lua_text_attributes_have_glow(attributes: &[TextAttribute]) -> bool {
    attributes
        .iter()
        .any(|attr| attr.glow.is_some_and(|glow| glow[3] > f32::EPSILON))
}

fn song_lua_text_glow_attributes(
    text: &str,
    attributes: &[TextAttribute],
    glow: [f32; 4],
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> TextAttributes {
    let char_count = text.chars().count();
    if char_count == 0 {
        return TextAttributes::default();
    }
    let fill = |out: &mut Vec<TextAttribute>| {
        if glow[3] > f32::EPSILON {
            out.push(TextAttribute {
                start: 0,
                length: char_count,
                color: glow,
                vertex_colors: None,
                glow: None,
            });
        }
        for attr in attributes {
            let Some(glow) = attr.glow else {
                continue;
            };
            if glow[3] <= f32::EPSILON {
                continue;
            }
            out.push(TextAttribute {
                start: attr.start,
                length: attr.length,
                color: glow,
                vertex_colors: None,
                glow: None,
            });
        }
    };
    if let Some(scratch) = scratch {
        scratch.update_text_glow(fill)
    } else {
        let mut out = Vec::with_capacity(attributes.len() + usize::from(glow[3] > f32::EPSILON));
        fill(&mut out);
        out.into()
    }
}

fn song_lua_text_attributes_for_diffuse_mode(
    attributes: &Arc<[TextAttribute]>,
    color: [f32; 4],
    text: &str,
    mult_attrs_with_diffuse: bool,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> (TextAttributes, [f32; 4]) {
    if attributes.is_empty() || mult_attrs_with_diffuse {
        return (TextAttributes::from(Arc::clone(attributes)), color);
    }
    let char_count = text.chars().count();
    if char_count == 0 {
        return (TextAttributes::from(Arc::clone(attributes)), color);
    }
    if color
        .iter()
        .all(|component| (*component - 1.0).abs() <= f32::EPSILON)
    {
        return (
            TextAttributes::from(Arc::clone(attributes)),
            [1.0, 1.0, 1.0, 1.0],
        );
    }
    let fill = |out: &mut Vec<TextAttribute>| {
        out.push(TextAttribute {
            start: 0,
            length: char_count,
            color,
            vertex_colors: None,
            glow: None,
        });
        out.extend_from_slice(attributes);
    };
    let attributes = if let Some(scratch) = scratch {
        scratch.update_text_diffuse(fill)
    } else {
        let mut out = Vec::with_capacity(attributes.len() + 1);
        fill(&mut out);
        out.into()
    };
    (attributes, [1.0, 1.0, 1.0, 1.0])
}

#[cfg(any(test, feature = "test-support"))]
fn song_lua_overlay_camera_state<S: NoteskinSlot + Clone>(
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    mut index: Option<usize>,
) -> Option<SongLuaOverlayState> {
    while let Some(current) = index {
        let overlay = overlays.get(current)?;
        if matches!(overlay.kind, SongLuaOverlayKind::ActorFrameTexture { .. }) {
            return None;
        }
        let state = overlay_states.get(current).copied()?;
        if matches!(
            overlay.kind,
            SongLuaOverlayKind::ActorFrame
                | SongLuaOverlayKind::WrapperState
                | SongLuaOverlayKind::ActorFrameTexture { .. }
        ) && state.fov.is_some()
        {
            return Some(state);
        }
        index = overlay.parent_index;
    }
    None
}
fn song_lua_overlay_view_proj(
    camera_state: SongLuaOverlayState,
    overlay_space_width: f32,
    overlay_space_height: f32,
) -> Option<(Matrix4, Matrix4)> {
    let mut fov_deg = camera_state.fov?;
    if !fov_deg.is_finite() || fov_deg == -1.0 {
        return None;
    }
    let width = screen_width().max(1.0);
    let height = screen_height().max(1.0);
    // ActorFrame::BeginDraw pushes a camera for FOV zero too. Native
    // LoadMenuPerspective resets the view and selects the ortho depth range.
    if fov_deg == 0.0 {
        let projection = Matrix4::from_cols_array(&[
            2.0 / width,
            0.0,
            0.0,
            0.0,
            0.0,
            -2.0 / height,
            0.0,
            0.0,
            0.0,
            0.0,
            -2.0 / 2000.0,
            0.0,
            -1.0,
            1.0,
            0.0,
            1.0,
        ]);
        return Some((Matrix4::IDENTITY, projection));
    }
    fov_deg = fov_deg.clamp(0.1, 179.9);
    let x_scale = width / overlay_space_width.max(1.0);
    let y_scale = height / overlay_space_height.max(1.0);
    let vanish = camera_state
        .vanishpoint
        .unwrap_or([0.5 * overlay_space_width, 0.5 * overlay_space_height]);
    let mut vanish_x = vanish[0].mul_add(-x_scale, width);
    let mut vanish_y = vanish[1].mul_add(-y_scale, height);
    vanish_x = 0.5f32.mul_add(-width, vanish_x);
    vanish_y = 0.5f32.mul_add(-height, vanish_y);

    let theta = (fov_deg / 180.0 * std::f32::consts::PI) / 2.0;
    let dist = width / 2.0 / theta.tan();
    let left = (vanish_x - width / 2.0) / dist;
    let right = (vanish_x + width / 2.0) / dist;
    let bottom = (vanish_y + height / 2.0) / dist;
    let top = (vanish_y - height / 2.0) / dist;
    let far = dist + 1000.0;
    // RageDisplay divides each coefficient directly. Multiplying by rounded
    // reciprocals (glam's frustum) shifts projected vertices near W=0.
    let proj = Matrix4::from_cols_array(&[
        2.0 / (right - left),
        0.0,
        0.0,
        0.0,
        0.0,
        2.0 / (top - bottom),
        0.0,
        0.0,
        (right + left) / (right - left),
        (top + bottom) / (top - bottom),
        -(far + 1.0) / (far - 1.0),
        -1.0,
        0.0,
        0.0,
        -(2.0 * far) / (far - 1.0),
        0.0,
    ]);
    let eye_x = 0.5f32.mul_add(width, -vanish_x);
    let eye_y = 0.5f32.mul_add(height, -vanish_y);
    // RageLookAt normalizes all three basis vectors, including the derived
    // up vector. glam's look-at retains its small normalization error.
    let camera_z = Vector3::new(0.0, 0.0, dist).normalize();
    let camera_x = Vector3::Y.cross(camera_z);
    let camera_y = camera_z.cross(camera_x).normalize();
    let camera_x = camera_x.normalize();
    let view = Matrix4::from_cols(
        Vector4::new(camera_x.x, camera_y.x, camera_z.x, 0.0),
        Vector4::new(camera_x.y, camera_y.y, camera_z.y, 0.0),
        Vector4::new(camera_x.z, camera_y.z, camera_z.z, 0.0),
        Vector4::W,
    ) * Matrix4::from_translation(Vector3::new(-eye_x, -eye_y, -dist));
    Some((view, proj))
}

fn song_lua_actor_multi_vertex_mesh(
    vertices: &Arc<[SongLuaOverlayMeshVertex]>,
    x_scale: f32,
    y_scale: f32,
    actor_scale: [f32; 2],
    effect_scale: [f32; 3],
    rotation_z_deg: f32,
    skew: [f32; 2],
) -> Arc<[MeshVertex]> {
    let mut out = Vec::with_capacity(vertices.len());
    append_song_lua_actor_multi_vertex_mesh(
        &mut out,
        vertices,
        x_scale,
        y_scale,
        actor_scale,
        effect_scale,
        rotation_z_deg,
        skew,
    );
    Arc::from(out.into_boxed_slice())
}

#[allow(clippy::too_many_arguments)]
fn append_song_lua_actor_multi_vertex_mesh(
    out: &mut Vec<MeshVertex>,
    vertices: &[SongLuaOverlayMeshVertex],
    x_scale: f32,
    y_scale: f32,
    actor_scale: [f32; 2],
    effect_scale: [f32; 3],
    rotation_z_deg: f32,
    skew: [f32; 2],
) {
    out.reserve(vertices.len());
    for vertex in vertices.iter() {
        out.push(MeshVertex {
            pos: song_lua_actor_multi_vertex_pos(
                vertex.pos,
                x_scale,
                y_scale,
                actor_scale,
                effect_scale,
                rotation_z_deg,
                skew,
            ),
            color: vertex.color,
        });
    }
}

fn song_lua_actor_multi_vertex_textured_mesh(
    vertices: &[SongLuaOverlayMeshVertex],
) -> Arc<[TexturedMeshVertex]> {
    let mut out = Vec::with_capacity(vertices.len());
    append_song_lua_actor_multi_vertex_textured_mesh(&mut out, vertices);
    out.into()
}

fn append_song_lua_actor_multi_vertex_textured_mesh(
    out: &mut Vec<TexturedMeshVertex>,
    vertices: &[SongLuaOverlayMeshVertex],
) {
    out.extend(vertices.iter().map(|vertex| TexturedMeshVertex {
        normal: [0.0; 4],
        pos: [vertex.pos[0], vertex.pos[1], vertex.z],
        uv: vertex.uv,
        tex_matrix_scale: [1.0, 1.0],
        color: vertex.color,
    }));
}

fn song_lua_actor_multi_vertex_pos(
    pos: [f32; 2],
    x_scale: f32,
    y_scale: f32,
    actor_scale: [f32; 2],
    effect_scale: [f32; 3],
    rotation_z_deg: f32,
    skew: [f32; 2],
) -> [f32; 2] {
    let scale = [
        x_scale * actor_scale[0] * effect_scale[0],
        y_scale * actor_scale[1] * effect_scale[1],
    ];
    let (sin_z, cos_z) = rotation_z_deg.to_radians().sin_cos();
    let mut x = pos[0] * scale[0];
    let mut y = -pos[1] * scale[1];
    if skew[0].abs() > f32::EPSILON {
        x = skew[0].mul_add(y, x);
    }
    if skew[1].abs() > f32::EPSILON {
        y = skew[1].mul_add(x, y);
    }
    [y.mul_add(-sin_z, x * cos_z), y.mul_add(cos_z, x * sin_z)]
}

#[allow(clippy::too_many_arguments)]
fn append_song_lua_model_actors(
    out: &mut impl Extend<Actor>,
    layers: &[SongLuaOverlayModelLayer],
    state: SongLuaOverlayState,
    camera_state: impl Into<SongLuaDrawCamera>,
    asset_manager: &AssetManager,
    z: i16,
    x_scale: f32,
    y_scale: f32,
    actor_scale: [f32; 2],
    effect_scale: [f32; 3],
    effect_rot: [f32; 3],
    effect_offset: [f32; 3],
    tint: [f32; 4],
    glow: [f32; 4],
    blend: BlendMode,
    total_elapsed: f32,
    prewarmed_passes: Option<&[Option<SongLuaModelGeometry>]>,
) -> bool {
    // Model::DrawPrimitives skips both passes below this joint alpha cutoff.
    if tint[3] < 0.001 && glow[3] < 0.001 {
        return false;
    }
    let mut emitted = false;
    let [projection, view, space] = song_lua_model_camera(camera_state, x_scale, y_scale);
    out.extend([Actor::CameraPush {
        view_proj: projection * view * space,
    }]);
    let offset = [
        effect_offset[0].mul_add(x_scale, state.x * x_scale),
        effect_offset[1].mul_add(y_scale, state.y * y_scale),
    ];
    // Model::DrawPrimitives emits every diffuse mesh before its glow pass.
    // Keep one z bucket so composition preserves that native insertion order.
    for glow_pass in [false, true] {
        if glow_pass && glow[3] <= f32::EPSILON {
            continue;
        }
        for (idx, layer) in layers.iter().enumerate() {
            let sample = crate::model_texture_at(&layer.texture_samples, total_elapsed);
            let texture_key =
                layer.texture_key_at(sample.map_or(0, |sample| sample.diffuse_state as usize));
            if !layer.draw.visible || !asset_manager.has_texture_key(texture_key) {
                continue;
            }
            let cold_geometry;
            let geometry = if let Some(geometry) = prewarmed_passes
                .and_then(|passes| passes.get(idx))
                .and_then(Option::as_ref)
            {
                geometry
            } else {
                cold_geometry = SongLuaModelGeometry::new(&layer.vertices);
                &cold_geometry
            };
            let scroll = if sample.is_some() {
                [0.0; 2]
            } else {
                song_lua_model_layer_scroll(layer, total_elapsed)
            };
            let shift = match state.texcoord_offset {
                Some([dx, dy]) => [scroll[0] + dx, scroll[1] + dy],
                None => scroll,
            };
            let mut uv_offset = [layer.uv_offset[0] + shift[0], layer.uv_offset[1] + shift[1]];
            let mut uv_tex_shift = [
                layer.uv_tex_shift[0] + shift[0],
                layer.uv_tex_shift[1] + shift[1],
            ];
            let mut uv_scale = layer.uv_scale;
            if let Some(sample) = sample {
                let uv = song_lua_model_uv(
                    if glow_pass {
                        sample.glow
                    } else {
                        sample.diffuse
                    },
                    state.texcoord_offset,
                );
                uv_scale = uv.scale;
                uv_offset = uv.offset;
                uv_tex_shift = uv.shift;
            }
            let (ancestor_scale, model_scale) = state.scale_factors.map_or(
                (
                    Matrix4::IDENTITY,
                    [
                        actor_scale[0],
                        actor_scale[1],
                        song_lua_overlay_z_scale(state),
                    ],
                ),
                |[ancestor, local]| (Matrix4::from_scale(Vector3::from(ancestor)), local),
            );
            let local_transform = ancestor_scale
                * song_lua_model_local_transform(
                    layer.model_size,
                    layer.draw,
                    x_scale,
                    y_scale,
                    model_scale,
                    effect_scale,
                    effect_rot,
                    [state.skew_x, state.skew_y],
                );
            let environment = Some(deadlib_present::actors::MeshEnvironment {
                sampler: Some(deadlib_render_core::MeshSampler::Override {
                    filter: if state.texture_filtering {
                        deadlib_render_core::SamplerFilter::Linear
                    } else {
                        deadlib_render_core::SamplerFilter::Nearest
                    },
                    wrap: if state.texture_wrapping {
                        deadlib_render_core::SamplerWrap::Repeat
                    } else {
                        deadlib_render_core::SamplerWrap::Clamp
                    },
                }),
                camera: None,
                transform: local_transform,
                additive_texture: None,
                additive_uv: [0.0, 0.0, 1.0, 1.0],
            });
            let actor = Actor::TexturedMesh {
                environment,
                vertex_color_encoding: Default::default(),
                align: [0.0, 0.0],
                offset,
                world_z: state.z + song_lua_biased_world_z(state, effect_offset[2]),
                size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
                local_transform,
                texture: Arc::clone(texture_key).into(),
                tint: deadsync_noteskin::model_unlit_color(
                    layer.material,
                    song_lua_capture_tint(layer.draw.tint, tint),
                ),
                glow: [1.0, 1.0, 1.0, 0.0],
                vertices: Arc::clone(&geometry.diffuse.1),
                geom_cache_key: if prewarmed_passes.is_some() {
                    geometry.diffuse.0
                } else {
                    INVALID_TMESH_CACHE_KEY
                },
                uv_scale,
                uv_offset,
                uv_tex_shift,
                depth_test: state.depth_test,
                depth_write: state.depth_write,
                depth_test_on_fail: state.depth_test_on_fail,
                clear_depth: false,
                clear_depth_after: false,
                cull_mode: state.cull_mode,
                visible: true,
                // Native Model resets blending after each diffuse mesh.
                blend: if (glow_pass && tint[3] > 0.0) || idx != 0 {
                    BlendMode::Alpha
                } else if layer.draw.blend_add {
                    BlendMode::Add
                } else {
                    blend
                },
                z: z.min(SONG_LUA_FOREGROUND_DEPTH.ceiling),
            };
            if !glow_pass {
                let secondary = layer
                    .additive_key_at(
                        sample.and_then(|sample| sample.additive_state).unwrap_or(0) as usize
                    )
                    .filter(|key| asset_manager.has_texture_key(key))
                    .and_then(|key| {
                        let uv = sample
                            .and_then(|sample| sample.additive)
                            .map(|uv| song_lua_model_uv(uv, state.texcoord_offset))
                            .or_else(|| {
                                let mut uv = layer.additive_frames.first()?.glow;
                                for axis in 0..2 {
                                    let shift =
                                        uv_tex_shift[axis] / uv_scale[axis] * uv.scale[axis];
                                    uv.offset[axis] += shift;
                                    uv.shift[axis] += shift;
                                }
                                Some(uv)
                            })?;
                        song_lua_secondary_model_actor(&actor, Arc::clone(key), geometry, uv)
                    });
                out.extend([actor]);
                if let Some(secondary) = secondary {
                    out.extend([secondary]);
                }
                emitted = true;
                continue;
            }
            let glow_actor = song_lua_overlay_glow_actor_with_static_vertices(
                &actor,
                glow,
                state.text_glow_mode,
                None,
                Some(&geometry.glow),
            );
            if let Some(glow_actor) = glow_actor {
                out.extend([glow_actor]);
                emitted = true;
            }
        }
    }
    out.extend([Actor::CameraPop]);
    emitted
}

fn song_lua_secondary_model_actor(
    actor: &Actor,
    key: Arc<str>,
    geometry: &SongLuaModelGeometry,
    uv: crate::SongLuaModelTextureUv,
) -> Option<Actor> {
    let (geom_key, secondary) = geometry.additive.as_ref()?;
    let mut actor = actor.clone();
    let Actor::TexturedMesh {
        texture,
        vertices,
        geom_cache_key,
        uv_scale,
        uv_offset,
        uv_tex_shift,
        blend,
        environment,
        local_transform,
        ..
    } = &mut actor
    else {
        return None;
    };
    *texture = key.into();
    *vertices = Arc::clone(secondary);
    *geom_cache_key = if *geom_cache_key == INVALID_TMESH_CACHE_KEY {
        INVALID_TMESH_CACHE_KEY
    } else {
        *geom_key
    };
    *uv_scale = uv.scale;
    *uv_offset = uv.offset;
    *uv_tex_shift = uv.shift;
    *blend = BlendMode::Add;
    let transform = environment
        .as_ref()
        .map_or(*local_transform, |environment| environment.transform);
    let sampler = environment
        .as_ref()
        .and_then(|environment| environment.sampler)
        .map(|sampler| match sampler {
            deadlib_render_core::MeshSampler::Override { wrap, .. } => {
                deadlib_render_core::MeshSampler::Override {
                    filter: deadlib_render_core::SamplerFilter::Linear,
                    wrap,
                }
            }
            deadlib_render_core::MeshSampler::Texture => sampler,
        });
    *environment = Some(deadlib_present::actors::MeshEnvironment {
        sampler,
        camera: None,
        transform,
        additive_texture: None,
        additive_uv: [0.0, 0.0, 1.0, 1.0],
    });
    Some(actor)
}

fn song_lua_model_camera(
    camera: impl Into<SongLuaDrawCamera>,
    x_scale: f32,
    y_scale: f32,
) -> [Matrix4; 3] {
    let camera = camera.into();
    let SongLuaDrawViewProjection { view, projection, world } = camera
        .view_proj(screen_width() / x_scale, screen_height() / y_scale)
        .unwrap_or_else(|| (Matrix4::IDENTITY, song_lua_screen_proj(1000.0)).into());
    let view = if world == Matrix4::IDENTITY { view } else { view * world };
    // Composition uses centered coordinates with positive Y up. RageDisplay
    // menu cameras consume top-left coordinates with positive Y down.
    let space = Matrix4::from_translation(Vector3::new(
        screen_width() * 0.5,
        screen_height() * 0.5,
        0.0,
    )) * Matrix4::from_scale(Vector3::new(1.0, -1.0, 1.0));
    [projection, view, space]
}

fn song_lua_model_layer_scroll(layer: &SongLuaOverlayModelLayer, total_elapsed: f32) -> [f32; 2] {
    if layer.uv_velocity == [0.0, 0.0] {
        return [0.0, 0.0];
    }
    let clock = layer
        .uv_cycle_seconds
        .filter(|total| *total > f32::EPSILON && total.is_finite())
        .map_or(total_elapsed, |total| {
            total_elapsed.rem_euclid(total) / total
        });
    [layer.uv_velocity[0] * clock, layer.uv_velocity[1] * clock]
}

fn song_lua_model_uv(
    mut uv: crate::SongLuaModelTextureUv,
    offset: Option<[f32; 2]>,
) -> crate::SongLuaModelTextureUv {
    if let Some(offset) = offset {
        for axis in 0..2 {
            let shift = offset[axis] * uv.scale[axis];
            uv.offset[axis] += shift;
            uv.shift[axis] += shift;
        }
    }
    uv
}

#[allow(clippy::too_many_arguments)]
fn append_song_lua_noteskin_actors<S: NoteskinSlot + Clone>(
    out: &mut impl Extend<Actor>,
    slots: &[S],
    texture_samples: &[Arc<[crate::SongLuaTextureSample]>],
    state: SongLuaOverlayState,
    camera_state: impl Into<SongLuaDrawCamera>,
    asset_manager: &AssetManager,
    z: i16,
    x_scale: f32,
    y_scale: f32,
    actor_scale: [f32; 2],
    effect_scale: [f32; 3],
    effect_rot: [f32; 3],
    effect_offset: [f32; 3],
    tint: [f32; 4],
    glow: [f32; 4],
    blend: BlendMode,
    total_elapsed: f32,
    effect_beat: f32,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> bool {
    let camera_state = camera_state.into();
    let mut emitted = false;
    let camera =
        (camera_state.is_active() || slots.iter().any(|slot| slot.model().is_some())).then(|| {
            let [projection, view, space] = song_lua_model_camera(camera_state, x_scale, y_scale);
            projection * view * space
        });
    if let Some(view_proj) = camera {
        out.extend([Actor::CameraPush { view_proj }]);
    }
    let (mut model_cache, prewarmed_passes) = match scratch {
        Some(scratch) => (
            scratch.noteskin_model_cache.as_mut(),
            scratch.model_passes.as_deref(),
        ),
        None => (None, None),
    };
    // Uncached callers already build geometry during load/inspection. Gameplay
    // supplies the sealed, prewarmed slot cache and never takes this cold path.
    let mut cold_geometry = (model_cache.is_none()
        && slots.iter().any(|slot| slot.model().is_some()))
    .then(|| ModelMeshCache::with_capacity(slots.len()));
    let center = [
        effect_offset[0].mul_add(x_scale, state.x * x_scale),
        effect_offset[1].mul_add(y_scale, state.y * y_scale),
    ];
    let [ancestor, local] = state.scale_factors.unwrap_or([
        [1.0; 3],
        [
            actor_scale[0],
            actor_scale[1],
            song_lua_overlay_z_scale(state),
        ],
    ]);
    // Slots extracted from one native Model share its diffuse/glow passes.
    // Other noteskin actor trees retain their per-actor draw order.
    let model_passes = slots.iter().all(|slot| slot.model().is_some());
    for glow_pass in [false, true] {
        if glow_pass && (!model_passes || glow[3] <= f32::EPSILON) {
            continue;
        }
        for (idx, slot) in slots.iter().enumerate() {
            let sample = texture_samples
                .get(idx)
                .and_then(|samples| crate::model_texture_at(samples, total_elapsed));
            let texture_key = sample
                .and_then(|sample| {
                    slot.model_texture_keys()
                        .get(sample.diffuse_state as usize)
                        .cloned()
                })
                .unwrap_or_else(|| slot.model_texture_at(total_elapsed));
            if !asset_manager.has_texture_key(&texture_key) {
                continue;
            }
            let mut draw = model_cache.as_deref_mut().map_or_else(
                || slot.model_draw_at(total_elapsed, effect_beat),
                |cache| cache.draw_at(slot, total_elapsed, effect_beat),
            );
            let scales = if slot.model().is_some() {
                local
            } else {
                [
                    actor_scale[0],
                    actor_scale[1],
                    song_lua_overlay_z_scale(state),
                ]
            };
            draw.pos[0] *= x_scale * scales[0] * effect_scale[0];
            draw.pos[1] *= y_scale * scales[1] * effect_scale[1];
            draw.pos[2] *= scales[2] * effect_scale[2];
            draw.rot[0] += effect_rot[0];
            draw.rot[1] += effect_rot[1];
            let frame = slot.frame_index(total_elapsed, effect_beat);
            let uv = song_lua_noteskin_slot_uv(slot, frame, total_elapsed, state.texcoord_offset);
            let base_size = song_lua_noteskin_slot_size(slot);
            let size = [
                base_size[0] * x_scale * actor_scale[0] * effect_scale[0],
                base_size[1] * y_scale * actor_scale[1] * effect_scale[1],
            ];
            if size[0].abs() <= f32::EPSILON || size[1].abs() <= f32::EPSILON {
                continue;
            }
            let layer_z = if model_passes {
                z
            } else {
                song_lua_add_z(z, idx.min(i16::MAX as usize) as i16)
            }
            .min(SONG_LUA_FOREGROUND_DEPTH.ceiling);
            let actor = if slot.model().is_some() {
                // Actor::BeginDraw scales each model axis independently. The
                // noteskin renderer fits models uniformly from size[1], so pass
                // native dimensions and put the composed Lua scale in the draw.
                draw.zoom[0] *= x_scale * local[0] * effect_scale[0];
                draw.zoom[1] *= y_scale * local[1] * effect_scale[1];
                draw.zoom[2] *= local[2] * effect_scale[2];
                let size = base_size;
                let cache = model_cache
                    .as_deref_mut()
                    .or(cold_geometry.as_mut())
                    .expect("Model slots have either a prewarmed or a cold geometry cache");
                let Some((key, vertices)) = cache.model_geometry(slot) else {
                    continue;
                };
                let key = if cold_geometry.is_some() {
                    INVALID_TMESH_CACHE_KEY
                } else {
                    key
                };
                // Song Models use their inherited RageDisplay camera. The
                // notefield's local focal approximation would project twice.
                noteskin_model_actor_from_draw_depth_sorted_affine_cached_geometry(
                    slot,
                    draw,
                    center,
                    size,
                    uv,
                    slot.sprite_def().rotation_deg as f32 + effect_rot[2],
                    tint,
                    blend,
                    layer_z,
                    vertices,
                    key,
                )
            } else {
                song_lua_noteskin_sprite_actor(
                    slot,
                    draw,
                    center,
                    size,
                    uv,
                    effect_rot[2],
                    tint,
                    blend,
                    layer_z,
                )
            };
            let Some(mut actor) = actor else {
                continue;
            };
            let cold_passes;
            let passes = if let Some(passes) = prewarmed_passes
                .and_then(|passes| passes.get(idx))
                .and_then(Option::as_ref)
            {
                Some(passes)
            } else if slot.model().is_some()
                && let Actor::TexturedMesh { vertices, .. } = &actor
            {
                cold_passes = SongLuaModelGeometry::new(vertices);
                Some(&cold_passes)
            } else {
                None
            };
            if slot.model().is_some()
                && let Actor::TexturedMesh { texture, .. } = &mut actor
            {
                *texture = texture_key.into();
            }
            if let Some(sample) = sample
                && let Actor::TexturedMesh {
                    uv_scale,
                    uv_offset,
                    uv_tex_shift,
                    ..
                } = &mut actor
            {
                let uv = song_lua_model_uv(
                    if glow_pass {
                        sample.glow
                    } else {
                        sample.diffuse
                    },
                    state.texcoord_offset,
                );
                *uv_scale = uv.scale;
                *uv_offset = uv.offset;
                *uv_tex_shift = uv.shift;
            }
            if slot.model().is_some() {
                if let Actor::TexturedMesh {
                    local_transform,
                    environment,
                    depth_test,
                    depth_write,
                    depth_test_on_fail,
                    world_z,
                    ..
                } = &mut actor
                {
                    let environment = environment.get_or_insert_with(|| {
                        deadlib_present::actors::MeshEnvironment {
                            sampler: None,
                            camera: None,
                            transform: *local_transform,
                            additive_texture: None,
                            additive_uv: [0.0, 0.0, 1.0, 1.0],
                        }
                    });
                    environment.sampler = Some(deadlib_render_core::MeshSampler::Override {
                        filter: if state.texture_filtering {
                            deadlib_render_core::SamplerFilter::Linear
                        } else {
                            deadlib_render_core::SamplerFilter::Nearest
                        },
                        wrap: if state.texture_wrapping {
                            deadlib_render_core::SamplerWrap::Repeat
                        } else {
                            deadlib_render_core::SamplerWrap::Clamp
                        },
                    });
                    *depth_test = state.depth_test;
                    *depth_write = state.depth_write;
                    *depth_test_on_fail = state.depth_test_on_fail;
                    *world_z += state.z + song_lua_biased_world_z(state, effect_offset[2]);
                    *local_transform =
                        Matrix4::from_scale(Vector3::from(ancestor)) * *local_transform;
                }
            }
            let secondary = if !glow_pass {
                passes.and_then(|passes| {
                    let key = sample
                        .and_then(|sample| sample.additive_state)
                        .and_then(|state| slot.model_additive_keys().get(state as usize).cloned())
                        .or_else(|| slot.model_additive(total_elapsed).map(|(key, _)| key))?;
                    if !asset_manager.has_texture_key(&key) {
                        return None;
                    }
                    let uv = sample
                        .and_then(|sample| sample.additive)
                        .map(|uv| song_lua_model_uv(uv, state.texcoord_offset))
                        .or_else(|| {
                            let Actor::TexturedMesh {
                                environment: Some(environment),
                                uv_scale,
                                uv_tex_shift,
                                ..
                            } = &actor
                            else {
                                return None;
                            };
                            let rect = environment.additive_uv;
                            let scale = [rect[2] - rect[0], rect[3] - rect[1]];
                            let shift = std::array::from_fn(|axis| {
                                uv_tex_shift[axis] / uv_scale[axis] * scale[axis]
                            });
                            Some(crate::SongLuaModelTextureUv {
                                scale,
                                offset: [rect[0], rect[1]],
                                shift,
                            })
                        })?;
                    song_lua_secondary_model_actor(&actor, key, passes, uv)
                })
            } else {
                None
            };
            if let Some(passes) = passes
                && let Actor::TexturedMesh {
                    vertices,
                    geom_cache_key,
                    environment,
                    blend: pass_blend,
                    ..
                } = &mut actor
            {
                *vertices = Arc::clone(&passes.diffuse.1);
                *geom_cache_key = if prewarmed_passes.is_some() {
                    passes.diffuse.0
                } else {
                    INVALID_TMESH_CACHE_KEY
                };
                if let Some(environment) = environment {
                    environment.additive_texture = None;
                }
                if model_passes && (idx != 0 || (glow_pass && tint[3] > 0.0)) {
                    *pass_blend = BlendMode::Alpha;
                }
            }
            let glow_actor = (glow_pass || !model_passes)
                .then(|| {
                    song_lua_overlay_glow_actor_with_static_vertices(
                        &actor,
                        glow,
                        state.text_glow_mode,
                        None,
                        passes.map(|passes| &passes.glow),
                    )
                })
                .flatten();
            if !glow_pass {
                out.extend([actor]);
                if let Some(secondary) = secondary {
                    out.extend([secondary]);
                }
                emitted = true;
            }
            if let Some(glow_actor) = glow_actor {
                out.extend([glow_actor]);
                emitted = true;
            }
        }
    }
    if camera.is_some() {
        out.extend([Actor::CameraPop]);
    }
    emitted
}

#[cfg(test)]
#[allow(clippy::too_many_arguments)]
fn song_lua_noteskin_actor<S: NoteskinSlot + Clone>(
    slots: &[S],
    state: SongLuaOverlayState,
    asset_manager: &AssetManager,
    z: i16,
    x_scale: f32,
    y_scale: f32,
    actor_scale: [f32; 2],
    effect_scale: [f32; 3],
    effect_rot: [f32; 3],
    effect_offset: [f32; 3],
    tint: [f32; 4],
    glow: [f32; 4],
    blend: BlendMode,
    total_elapsed: f32,
    effect_beat: f32,
) -> Option<SongLuaActorList> {
    let mut out = SongLuaActorList::new();
    append_song_lua_noteskin_actors(
        &mut out,
        slots,
        &[],
        state,
        None,
        asset_manager,
        z,
        x_scale,
        y_scale,
        actor_scale,
        effect_scale,
        effect_rot,
        effect_offset,
        tint,
        glow,
        blend,
        total_elapsed,
        effect_beat,
        None,
    )
    .then_some(out)
}

fn song_lua_noteskin_slot_uv<S: NoteskinSlot + Clone>(
    slot: &S,
    frame: usize,
    total_elapsed: f32,
    texcoord_offset: Option<[f32; 2]>,
) -> [f32; 4] {
    let mut uv = slot.uv_for_frame_at(frame, total_elapsed);
    if let Some([dx, dy]) = texcoord_offset {
        uv[0] += dx;
        uv[1] += dy;
        uv[2] += dx;
        uv[3] += dy;
    }
    uv
}

fn song_lua_noteskin_slot_size<S: NoteskinSlot + Clone>(slot: &S) -> [f32; 2] {
    if let Some(model) = slot.model() {
        let size = model.size();
        if size[0] > f32::EPSILON && size[1] > f32::EPSILON {
            return size;
        }
    }
    slot.logical_size()
}

fn song_lua_noteskin_sprite_actor<S: NoteskinSlot + Clone>(
    slot: &S,
    draw: ModelDrawState,
    center: [f32; 2],
    size: [f32; 2],
    uv: [f32; 4],
    rotation_z: f32,
    tint: [f32; 4],
    blend: BlendMode,
    z: i16,
) -> Option<Actor> {
    if !draw.visible {
        return None;
    }
    let size = [
        size[0] * draw.zoom[0].max(0.0),
        size[1] * draw.zoom[1].max(0.0),
    ];
    if size[0].abs() <= f32::EPSILON || size[1].abs() <= f32::EPSILON {
        return None;
    }
    Some(Actor::Sprite {
        align: [0.5, 0.5],
        vertex_color_encoding: Default::default(),
        offset: [center[0] + draw.pos[0], center[1] - draw.pos[1]],
        world_z: 0.0,
        size: [SizeSpec::Px(size[0]), SizeSpec::Px(size[1])],
        source: SpriteSource::Texture(slot.texture_key_shared()),
        tint: [
            tint[0] * draw.tint[0],
            tint[1] * draw.tint[1],
            tint[2] * draw.tint[2],
            tint[3] * draw.tint[3],
        ],
        glow: [1.0, 1.0, 1.0, 0.0],
        z,
        cell: None,
        grid: None,
        uv_rect: Some(uv),
        visible: true,
        flip_x: false,
        flip_y: false,
        cropleft: 0.0,
        cropright: 0.0,
        croptop: 0.0,
        cropbottom: 0.0,
        fadeleft: 0.0,
        faderight: 0.0,
        fadetop: 0.0,
        fadebottom: 0.0,
        blend: if draw.blend_add {
            BlendMode::Add
        } else {
            blend
        },
        mask_source: false,
        mask_dest: false,
        rot_x_deg: draw.rot[0],
        rot_y_deg: draw.rot[1],
        rot_z_deg: draw.rot[2] - slot.sprite_def().rotation_deg as f32 - rotation_z,
        skew: [0.0, 0.0],
        local_offset: [0.0, 0.0],
        local_offset_rot_sin_cos: [0.0, 1.0],
        texcoordvelocity: None,
        animate: false,
        state_delay: 0.1,
        scale: [1.0, 1.0],
        shadow_len: [0.0, 0.0],
        shadow_color: [0.0, 0.0, 0.0, 0.5],
        effect: deadlib_present::anim::EffectState::default(),
    })
}

fn song_lua_model_local_transform(
    model_size: [f32; 2],
    draw: SongLuaOverlayModelDraw,
    x_scale: f32,
    y_scale: f32,
    actor_scale: [f32; 3],
    effect_scale: [f32; 3],
    effect_rot: [f32; 3],
    skew: [f32; 2],
) -> Matrix4 {
    let align_y = (0.5 - draw.vert_align) * model_size[1];
    let scale = Vector3::new(
        x_scale * actor_scale[0] * effect_scale[0] * draw.zoom[0],
        y_scale * actor_scale[1] * effect_scale[1] * draw.zoom[1],
        actor_scale[2] * effect_scale[2] * draw.zoom[2],
    );
    Matrix4::from_translation(Vector3::new(
        draw.pos[0] * x_scale,
        -draw.pos[1] * y_scale,
        draw.pos[2],
    )) * song_lua_overlay_local_transform(
        [
            draw.rot[0] + effect_rot[0],
            draw.rot[1] + effect_rot[1],
            draw.rot[2] + effect_rot[2],
        ],
        skew[0],
        skew[1],
    ) * Matrix4::from_translation(Vector3::new(0.0, align_y, 0.0))
        * Matrix4::from_scale(scale)
        * Matrix4::from_scale(Vector3::new(1.0, -1.0, 1.0))
}

fn song_lua_song_meter_actor(
    state: SongLuaOverlayState,
    stream_state: SongLuaOverlayState,
    stream_width: f32,
    music_length_seconds: f32,
    x_scale: f32,
    y_scale: f32,
    z: i16,
    total_elapsed: f32,
) -> Option<Actor> {
    let progress = if music_length_seconds > f32::EPSILON {
        (total_elapsed / music_length_seconds).clamp(0.0, 1.0)
    } else {
        1.0
    };
    let parent_scale = song_lua_overlay_axis_scale(state);
    let stream_scale = song_lua_overlay_axis_scale(stream_state);
    let full_width = stream_width * parent_scale[0].abs() * stream_scale[0].abs();
    let progress_width = full_width * progress;
    if progress_width <= f32::EPSILON {
        return None;
    }
    let stream_height = stream_state.size.map_or(1.0, |size| size[1].abs())
        * parent_scale[1].abs()
        * stream_scale[1].abs();
    let left = full_width.mul_add(-0.5, stream_state.x.mul_add(parent_scale[0], state.x));
    let y = stream_state.y.mul_add(parent_scale[1], state.y);
    let tint = [
        state.diffuse[0] * stream_state.diffuse[0],
        state.diffuse[1] * stream_state.diffuse[1],
        state.diffuse[2] * stream_state.diffuse[2],
        state.diffuse[3] * stream_state.diffuse[3],
    ];
    let mut actor = deadlib_present::__act_from_builder!((
        align(0.0, stream_state.valign):
        xy(left * x_scale, y * y_scale):
        zoomto(progress_width * x_scale, stream_height * y_scale):
        diffuse(tint[0], tint[1], tint[2], tint[3]):
        z(z)
    ) deadlib_assets::SpriteBuilder::solid());
    if let Actor::Sprite {
        visible,
        blend,
        mask_source,
        mask_dest,
        ..
    } = &mut actor
    {
        *visible = state.draw_visible() && stream_state.draw_visible();
        *blend = if stream_state.blend == SongLuaOverlayBlendMode::Alpha {
            song_lua_overlay_blend(state.blend)
        } else {
            song_lua_overlay_blend(stream_state.blend)
        };
        *mask_source = state.mask_source || stream_state.mask_source;
        *mask_dest = state.mask_dest || stream_state.mask_dest;
    }
    Some(actor)
}

#[inline(always)]
pub fn song_meter_progress(current_seconds: f32, first_second: f32, last_second: f32) -> f32 {
    if !current_seconds.is_finite() || !first_second.is_finite() || !last_second.is_finite() {
        return 0.0;
    }
    let duration = last_second - first_second;
    if duration <= f32::EPSILON {
        return 0.0;
    }
    ((current_seconds - first_second) / duration).clamp(0.0, 1.0)
}

#[allow(clippy::too_many_arguments)]
fn song_lua_graph_display_actor(
    state: SongLuaOverlayState,
    body_values: &Arc<[f32]>,
    body_state: SongLuaOverlayState,
    line_state: SongLuaOverlayState,
    size: [f32; 2],
    x_scale: f32,
    y_scale: f32,
    z: i16,
    mut scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Option<Actor> {
    let reuse_graph = scratch
        .as_ref()
        .is_some_and(|scratch| scratch.graph_frame.is_some());
    if reuse_graph
        && let Some(frame) = scratch
            .as_deref_mut()
            .and_then(|scratch| scratch.graph_frame.as_mut())
    {
        // Release last frame's child mesh Arcs before refilling their buffers.
        frame.clear();
    }
    let mut children = SmallVec::<[Actor; 2]>::new();
    if let Some(body) = song_lua_graph_display_body_actor(
        state,
        body_values,
        body_state,
        size,
        x_scale,
        y_scale,
        z,
        if reuse_graph {
            scratch.as_deref_mut()
        } else {
            None
        },
    ) {
        children.push(body);
    }
    if let Some(line) = song_lua_graph_display_line_actor(
        state,
        body_values,
        line_state,
        size,
        x_scale,
        y_scale,
        z,
        if reuse_graph {
            scratch.as_deref_mut()
        } else {
            None
        },
    ) {
        children.push(line);
    }
    match children.len() {
        0 => None,
        1 => children.pop(),
        _ if reuse_graph => {
            let shared = scratch
                .and_then(|scratch| scratch.graph_frame.as_mut())
                .and_then(|frame| frame.refill([0.0, 0.0], |out| out.extend(children.drain(..))))
                .expect("visible GraphDisplay body and line must refill the shared frame");
            Some(Actor::SharedFrame {
                align: [0.0, 0.0],
                offset: [0.0, 0.0],
                size: [SizeSpec::Fill, SizeSpec::Fill],
                children: shared,
                background: None,
                z: 0,
                tint: [1.0, 1.0, 1.0, 1.0],
                blend: None,
            })
        }
        _ => Some(Actor::Frame {
            align: [0.0, 0.0],
            offset: [0.0, 0.0],
            size: [SizeSpec::Fill, SizeSpec::Fill],
            children: children.into_vec(),
            background: None,
            z: 0,
        }),
    }
}

#[allow(clippy::too_many_arguments)]
fn song_lua_graph_display_body_actor(
    state: SongLuaOverlayState,
    body_values: &[f32],
    body_state: SongLuaOverlayState,
    size: [f32; 2],
    x_scale: f32,
    y_scale: f32,
    z: i16,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Option<Actor> {
    if !body_state.draw_visible() || body_state.diffuse[3] <= f32::EPSILON {
        return None;
    }
    let values = graph_display_values_or_default(body_values);
    let graph_scale = song_lua_overlay_axis_scale(state);
    let body_scale = song_lua_overlay_axis_scale(body_state);
    let width = size[0] * graph_scale[0].abs() * body_scale[0].abs();
    let height = size[1] * graph_scale[1].abs() * body_scale[1].abs();
    if width <= f32::EPSILON || height <= f32::EPSILON {
        return None;
    }
    let left = body_state
        .x
        .mul_add(graph_scale[0], width.mul_add(-state.halign, state.x));
    let top = body_state.y.mul_add(
        graph_scale[1],
        (size[1] * graph_scale[1].abs()).mul_add(-state.valign, state.y),
    );
    let tint = [
        state.diffuse[0] * body_state.diffuse[0],
        state.diffuse[1] * body_state.diffuse[1],
        state.diffuse[2] * body_state.diffuse[2],
        state.diffuse[3] * body_state.diffuse[3],
    ];
    let bottom = top + height;
    let geometry_key = [
        left.to_bits(),
        top.to_bits(),
        width.to_bits(),
        height.to_bits(),
        tint[0].to_bits(),
        tint[1].to_bits(),
        tint[2].to_bits(),
        tint[3].to_bits(),
        x_scale.to_bits(),
        y_scale.to_bits(),
    ];
    let fill = |vertices: &mut Vec<MeshVertex>| {
        for (index, pair) in values.windows(2).enumerate() {
            let x0 = left + width * index as f32 / (values.len() - 1) as f32;
            let x1 = left + width * (index + 1) as f32 / (values.len() - 1) as f32;
            let y0 = (1.0 - pair[0].clamp(0.0, 1.0)).mul_add(height, top);
            let y1 = (1.0 - pair[1].clamp(0.0, 1.0)).mul_add(height, top);
            push_graph_display_tri(
                vertices,
                [x0 * x_scale, y0 * y_scale],
                [x0 * x_scale, bottom * y_scale],
                [x1 * x_scale, bottom * y_scale],
                tint,
            );
            push_graph_display_tri(
                vertices,
                [x0 * x_scale, y0 * y_scale],
                [x1 * x_scale, bottom * y_scale],
                [x1 * x_scale, y1 * y_scale],
                tint,
            );
        }
    };
    let visible = state.draw_visible() && body_state.draw_visible();
    let blend = if body_state.blend == SongLuaOverlayBlendMode::Alpha {
        song_lua_overlay_blend(state.blend)
    } else {
        song_lua_overlay_blend(body_state.blend)
    };
    Some(if let Some(scratch) = scratch {
        Actor::ReusableMesh {
            vertex_color_encoding: Default::default(),
            align: [0.0, 0.0],
            offset: [0.0, 0.0],
            size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
            tint: [1.0, 1.0, 1.0, 1.0],
            vertices: scratch.update_graph_body(geometry_key, fill),
            visible,
            blend,
            z,
        }
    } else {
        let mut vertices = Vec::with_capacity((values.len().saturating_sub(1)) * 6);
        fill(&mut vertices);
        Actor::Mesh {
            vertex_color_encoding: Default::default(),
            align: [0.0, 0.0],
            offset: [0.0, 0.0],
            size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
            tint: [1.0; 4],
            vertices: Arc::from(vertices.into_boxed_slice()),
            visible,
            blend,
            z,
        }
    })
}

#[allow(clippy::too_many_arguments)]
fn song_lua_graph_display_line_actor(
    state: SongLuaOverlayState,
    body_values: &[f32],
    line_state: SongLuaOverlayState,
    size: [f32; 2],
    x_scale: f32,
    y_scale: f32,
    z: i16,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Option<Actor> {
    if !line_state.draw_visible() || line_state.diffuse[3] <= f32::EPSILON {
        return None;
    }
    let values = graph_display_values_or_default(body_values);
    let graph_scale = song_lua_overlay_axis_scale(state);
    let line_scale = song_lua_overlay_axis_scale(line_state);
    let width = size[0] * graph_scale[0].abs() * line_scale[0].abs();
    if width <= f32::EPSILON {
        return None;
    }
    let line_height = line_state.size.map_or(1.0, |line_size| line_size[1].abs())
        * graph_scale[1].abs()
        * line_scale[1].abs();
    let left = line_state
        .x
        .mul_add(graph_scale[0], width.mul_add(-state.halign, state.x));
    let top = (size[1] * graph_scale[1].abs()).mul_add(-state.valign, state.y);
    let height = size[1] * graph_scale[1].abs();
    let y = line_state
        .y
        .mul_add(graph_scale[1], height.mul_add(0.5, top));
    let tint = [
        state.diffuse[0] * line_state.diffuse[0],
        state.diffuse[1] * line_state.diffuse[1],
        state.diffuse[2] * line_state.diffuse[2],
        state.diffuse[3] * line_state.diffuse[3],
    ];
    let stroke = line_height.max(1.0);
    let geometry_key = [
        left.to_bits(),
        y.to_bits(),
        width.to_bits(),
        height.to_bits(),
        stroke.to_bits(),
        tint[0].to_bits(),
        tint[1].to_bits(),
        tint[2].to_bits(),
        tint[3].to_bits(),
        x_scale.to_bits(),
        y_scale.to_bits(),
    ];
    let fill = |vertices: &mut Vec<MeshVertex>| {
        for (index, pair) in values.windows(2).enumerate() {
            let x0 = left + width * index as f32 / (values.len() - 1) as f32;
            let x1 = left + width * (index + 1) as f32 / (values.len() - 1) as f32;
            let y0 = (0.5 - pair[0].clamp(0.0, 1.0)).mul_add(height, y);
            let y1 = (0.5 - pair[1].clamp(0.0, 1.0)).mul_add(height, y);
            push_graph_display_line_segment(
                vertices,
                [x0 * x_scale, y0 * y_scale],
                [x1 * x_scale, y1 * y_scale],
                stroke * y_scale,
                tint,
            );
        }
    };
    let visible = state.draw_visible() && line_state.draw_visible();
    let blend = if line_state.blend == SongLuaOverlayBlendMode::Alpha {
        song_lua_overlay_blend(state.blend)
    } else {
        song_lua_overlay_blend(line_state.blend)
    };
    Some(if let Some(scratch) = scratch {
        Actor::ReusableMesh {
            vertex_color_encoding: Default::default(),
            align: [0.0, 0.0],
            offset: [0.0, 0.0],
            size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
            tint: [1.0, 1.0, 1.0, 1.0],
            vertices: scratch.update_graph_line(geometry_key, fill),
            visible,
            blend,
            z,
        }
    } else {
        let mut vertices = Vec::with_capacity((values.len().saturating_sub(1)) * 6);
        fill(&mut vertices);
        Actor::Mesh {
            vertex_color_encoding: Default::default(),
            align: [0.0, 0.0],
            offset: [0.0, 0.0],
            size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
            tint: [1.0; 4],
            vertices: Arc::from(vertices.into_boxed_slice()),
            visible,
            blend,
            z,
        }
    })
}

fn graph_display_values_or_default(values: &[f32]) -> &[f32] {
    static DEFAULT: [f32; 2] = [0.5, 0.5];
    if values.len() >= 2 { values } else { &DEFAULT }
}

fn push_graph_display_line_segment(
    out: &mut Vec<MeshVertex>,
    start: [f32; 2],
    end: [f32; 2],
    stroke: f32,
    color: [f32; 4],
) {
    let dx = end[0] - start[0];
    let dy = end[1] - start[1];
    let len = (dx * dx + dy * dy).sqrt();
    if len <= f32::EPSILON {
        return;
    }
    let half = stroke * 0.5;
    let nx = -dy / len * half;
    let ny = dx / len * half;
    let a = [start[0] + nx, start[1] + ny];
    let b = [start[0] - nx, start[1] - ny];
    let c = [end[0] - nx, end[1] - ny];
    let d = [end[0] + nx, end[1] + ny];
    push_graph_display_tri(out, a, b, c, color);
    push_graph_display_tri(out, a, c, d, color);
}

fn push_graph_display_tri(
    out: &mut Vec<MeshVertex>,
    a: [f32; 2],
    b: [f32; 2],
    c: [f32; 2],
    color: [f32; 4],
) {
    out.push(MeshVertex { pos: a, color });
    out.push(MeshVertex { pos: b, color });
    out.push(MeshVertex { pos: c, color });
}

#[cfg(test)]
fn song_lua_project_overlay_point(
    (view, projection): (Matrix4, Matrix4),
    point: [f32; 3],
) -> Option<[f32; 2]> {
    let clip = projection * (view * Vector4::new(point[0], point[1], point[2], 1.0));
    if !clip.w.is_finite() || clip.w <= f32::EPSILON {
        return None;
    }
    let inv_w = clip.w.recip();
    let ndc_x = clip.x * inv_w;
    let ndc_y = clip.y * inv_w;
    if !(ndc_x.is_finite() && ndc_y.is_finite()) {
        return None;
    }
    Some([
        0.5f32.mul_add(ndc_x, 0.5) * screen_width(),
        0.5f32.mul_add(-ndc_y, 0.5) * screen_height(),
    ])
}

fn song_lua_overlay_rect(
    state: SongLuaOverlayState,
    default_size: [f32; 2],
    x_scale: f32,
    y_scale: f32,
    size_scale_x: f32,
    size_scale_y: f32,
) -> Option<([f32; 2], [f32; 2])> {
    let (base_center, base_size) = if let Some([left, top, right, bottom]) = state.stretch_rect {
        (
            [
                f32::midpoint(left, right) * x_scale,
                f32::midpoint(top, bottom) * y_scale,
            ],
            [
                (right - left).abs() * x_scale * size_scale_x,
                (bottom - top).abs() * y_scale * size_scale_y,
            ],
        )
    } else {
        (
            [
                (0.5 - state.halign)
                    .mul_add(default_size[0] * x_scale * size_scale_x, state.x * x_scale),
                (0.5 - state.valign)
                    .mul_add(default_size[1] * y_scale * size_scale_y, state.y * y_scale),
            ],
            [
                default_size[0] * x_scale * size_scale_x,
                default_size[1] * y_scale * size_scale_y,
            ],
        )
    };
    if base_size[0] <= f32::EPSILON || base_size[1] <= f32::EPSILON {
        return None;
    }
    let cl = state.cropleft.clamp(0.0, 1.0);
    let cr = state.cropright.clamp(0.0, 1.0);
    let ct = state.croptop.clamp(0.0, 1.0);
    let cb = state.cropbottom.clamp(0.0, 1.0);
    let sx_crop = (1.0 - cl - cr).max(0.0);
    let sy_crop = (1.0 - ct - cb).max(0.0);
    if sx_crop <= f32::EPSILON || sy_crop <= f32::EPSILON {
        return None;
    }
    Some((
        [
            ((cl - cr) * base_size[0]).mul_add(0.5, base_center[0]),
            ((ct - cb) * base_size[1]).mul_add(0.5, base_center[1]),
        ],
        [base_size[0] * sx_crop, base_size[1] * sy_crop],
    ))
}

fn song_lua_overlay_uvs(
    state: SongLuaOverlayState,
    sheet_dims: Option<(u32, u32)>,
    states: &[crate::SongLuaSpriteState],
    flip_x: bool,
    flip_y: bool,
    animation_elapsed: f32,
    texture_elapsed: f32,
) -> [[f32; 2]; 4] {
    let cl = state.cropleft.clamp(0.0, 1.0);
    let cr = state.cropright.clamp(0.0, 1.0);
    let ct = state.croptop.clamp(0.0, 1.0);
    let cb = state.cropbottom.clamp(0.0, 1.0);
    let [
        mut uv_scale_x,
        mut uv_scale_y,
        mut uv_offset_x,
        mut uv_offset_y,
    ] = if let Some([u0, v0, u1, v1]) =
        song_lua_overlay_uv_rect(state, sheet_dims, states, animation_elapsed)
    {
        // Sprite::DrawTexture interpolates the authored endpoints in order.
        // Reversed and constant texture coordinates remain valid when cropped.
        [u1 - u0, v1 - v0, u0, v0]
    } else {
        [1.0, 1.0, 0.0, 0.0]
    };
    uv_offset_x = uv_scale_x.mul_add(cl, uv_offset_x);
    uv_offset_y = uv_scale_y.mul_add(ct, uv_offset_y);
    uv_scale_x *= (1.0 - cl - cr).max(0.0);
    uv_scale_y *= (1.0 - ct - cb).max(0.0);
    if flip_x {
        uv_offset_x += uv_scale_x;
        uv_scale_x = -uv_scale_x;
    }
    if flip_y {
        uv_offset_y += uv_scale_y;
        uv_scale_y = -uv_scale_y;
    }
    if let Some(velocity) = state.texcoord_velocity {
        uv_offset_x = velocity[0].mul_add(texture_elapsed, uv_offset_x);
        uv_offset_y = velocity[1].mul_add(texture_elapsed, uv_offset_y);
    }
    [
        [uv_offset_x, uv_offset_y],
        [uv_offset_x + uv_scale_x, uv_offset_y],
        [uv_offset_x + uv_scale_x, uv_offset_y + uv_scale_y],
        [uv_offset_x, uv_offset_y + uv_scale_y],
    ]
}

#[inline(always)]
fn song_lua_projected_overlay_edge_fade(
    state: SongLuaOverlayState,
    flip_x: bool,
    flip_y: bool,
) -> [f32; 4] {
    let cl = state.cropleft.clamp(0.0, 1.0);
    let cr = state.cropright.clamp(0.0, 1.0);
    let ct = state.croptop.clamp(0.0, 1.0);
    let cb = state.cropbottom.clamp(0.0, 1.0);
    let sx_crop = (1.0 - cl - cr).max(0.0);
    let sy_crop = (1.0 - ct - cb).max(0.0);
    if sx_crop <= f32::EPSILON || sy_crop <= f32::EPSILON {
        return [0.0, 0.0, 0.0, 0.0];
    }

    let fl = state.fadeleft.clamp(0.0, 1.0);
    let fr = state.faderight.clamp(0.0, 1.0);
    let ft = state.fadetop.clamp(0.0, 1.0);
    let fb = state.fadebottom.clamp(0.0, 1.0);

    let mut fl_size = (fl + state.cropleft.min(0.0)).max(0.0);
    let mut fr_size = (fr + state.cropright.min(0.0)).max(0.0);
    let mut ft_size = (ft + state.croptop.min(0.0)).max(0.0);
    let mut fb_size = (fb + state.cropbottom.min(0.0)).max(0.0);

    let sum_x = fl_size + fr_size;
    if sum_x > 0.0 && sx_crop < sum_x {
        let scale = sx_crop / sum_x;
        fl_size *= scale;
        fr_size *= scale;
    }

    let sum_y = ft_size + fb_size;
    if sum_y > 0.0 && sy_crop < sum_y {
        let scale = sy_crop / sum_y;
        ft_size *= scale;
        fb_size *= scale;
    }

    let mut fl_eff = (fl_size / sx_crop).clamp(0.0, 1.0);
    let mut fr_eff = (fr_size / sx_crop).clamp(0.0, 1.0);
    let mut ft_eff = (ft_size / sy_crop).clamp(0.0, 1.0);
    let mut fb_eff = (fb_size / sy_crop).clamp(0.0, 1.0);

    if flip_x {
        std::mem::swap(&mut fl_eff, &mut fr_eff);
    }
    if flip_y {
        std::mem::swap(&mut ft_eff, &mut fb_eff);
    }

    [fl_eff, fr_eff, ft_eff, fb_eff]
}

fn song_lua_projected_overlay_axis_slices(start_fade: f32, end_fade: f32) -> SmallVec<[f32; 4]> {
    let mut out: SmallVec<[f32; 4]> = SmallVec::new();
    out.push(0.0);
    for value in [start_fade, 1.0 - end_fade, 1.0] {
        let value = value.clamp(0.0, 1.0);
        if out
            .last()
            .is_none_or(|last| (value - *last).abs() > f32::EPSILON)
        {
            out.push(value);
        }
    }
    out
}

#[inline(always)]
fn song_lua_projected_overlay_uv_point(uv: [[f32; 2]; 4], x: f32, y: f32) -> [f32; 2] {
    let top_u = song_lua_effect_lerp(uv[0][0], uv[1][0], x);
    let top_v = song_lua_effect_lerp(uv[0][1], uv[1][1], x);
    let bottom_u = song_lua_effect_lerp(uv[3][0], uv[2][0], x);
    let bottom_v = song_lua_effect_lerp(uv[3][1], uv[2][1], x);
    [
        song_lua_effect_lerp(top_u, bottom_u, y),
        song_lua_effect_lerp(top_v, bottom_v, y),
    ]
}

#[inline(always)]
fn song_lua_overlay_fold_xy_rot(
    mut flip_x: bool,
    mut flip_y: bool,
    mut size_x: f32,
    mut size_y: f32,
    rot_x_deg: f32,
    rot_y_deg: f32,
) -> (bool, bool, f32, f32) {
    let cos_y = rot_y_deg.to_radians().cos();
    size_x *= cos_y.abs();
    if cos_y.is_sign_negative() {
        flip_x = !flip_x;
    }

    let cos_x = rot_x_deg.to_radians().cos();
    size_y *= cos_x.abs();
    if cos_x.is_sign_negative() {
        flip_y = !flip_y;
    }

    (flip_x, flip_y, size_x, size_y)
}

#[inline(always)]
fn song_lua_overlay_local_transform(rot_deg: [f32; 3], skew_x: f32, skew_y: f32) -> Matrix4 {
    // Preserve RageMatrixRotationXYZ's coefficients and float operation order.
    // Three separate rotation matrices accumulate error near the camera plane.
    let [x, y, z] = rot_deg.map(|degrees| degrees * (std::f32::consts::PI / 180.0));
    let (sx, cx) = (x.sin(), x.cos());
    let (sy, cy) = (y.sin(), y.cos());
    let (sz, cz) = (z.sin(), z.cos());
    Matrix4::from_cols_array(&[
        cz * cy,
        cz * sy * sx + sz * cx,
        cz * sy * cx + sz * -sx,
        0.0,
        -sz * cy,
        -sz * sy * sx + cz * cx,
        -sz * sy * cx + cz * -sx,
        0.0,
        -sy,
        cy * sx,
        cy * cx,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
    ]) * song_lua_player_skew_x_matrix(skew_x)
        * song_lua_player_skew_y_matrix(skew_y)
}

fn song_lua_overlay_sprite_matrix(
    state: SongLuaOverlayState,
    size: [f32; 2],
    position: [f32; 3],
    rotation: [f32; 3],
    effect_scale: [f32; 3],
) -> Matrix4 {
    let [sx, sy] = song_lua_overlay_axis_scale(state);
    let [ancestor, local] = state
        .scale_factors
        .unwrap_or([[1.0; 3], [sx, sy, song_lua_overlay_z_scale(state)]]);
    let local = std::array::from_fn(|axis| local[axis] * effect_scale[axis]);
    let linear = Matrix4::from_scale(Vector3::from(ancestor))
        * song_lua_overlay_local_transform(rotation, 0.0, 0.0)
        * Matrix4::from_scale(Vector3::from(local));
    Matrix4::from_cols_array(&crate::actor_quaternion::matrix(state.quaternion))
        * Matrix4::from_translation(Vector3::from(position))
        * linear
        * Matrix4::from_translation(Vector3::new(
            (0.5 - state.halign) * size[0],
            (0.5 - state.valign) * size[1],
            0.0,
        ))
        * song_lua_overlay_local_transform([0.0; 3], state.skew_x, state.skew_y)
}

fn song_lua_projected_sprite_geometry(
    state: SongLuaOverlayState,
    size: [f32; 2],
    canvas_scale: [f32; 2],
    offset: [f32; 3],
    rotation: [f32; 3],
    effect_scale: [f32; 3],
) -> Option<(Matrix4, [f32; 2])> {
    let [x_scale, y_scale] = canvas_scale;
    if state.stretch_rect.is_some() {
        let [sx, sy] = song_lua_overlay_axis_scale(state);
        let (center, size) =
            song_lua_overlay_rect(state, size, x_scale, y_scale, sx.abs(), sy.abs())?;
        let model = Matrix4::from_translation(Vector3::new(
            center[0] + offset[0] * x_scale,
            center[1] + offset[1] * y_scale,
            state.z + offset[2],
        )) * song_lua_overlay_local_transform(rotation, state.skew_x, state.skew_y);
        return Some((
            model,
            [size[0] * effect_scale[0], size[1] * effect_scale[1]],
        ));
    }
    let (crop_center, cropped_size) = song_lua_overlay_rect(
        SongLuaOverlayState {
            x: 0.0,
            y: 0.0,
            halign: 0.5,
            valign: 0.5,
            ..state
        },
        size,
        1.0,
        1.0,
        1.0,
        1.0,
    )?;
    let model = Matrix4::from_scale(Vector3::new(x_scale, y_scale, 1.0))
        * song_lua_overlay_sprite_matrix(
            state,
            size,
            [
                state.x + offset[0],
                state.y + offset[1],
                state.z + offset[2],
            ],
            rotation,
            effect_scale,
        )
        * Matrix4::from_translation(Vector3::new(crop_center[0], crop_center[1], 0.0));
    Some((model, cropped_size))
}

fn song_lua_screen_proj(depth: f32) -> Matrix4 {
    glam::camera::rh::proj::opengl::orthographic(
        0.0,
        screen_width(),
        screen_height(),
        0.0,
        -depth,
        depth,
    )
}

fn song_lua_depth_range(state: SongLuaOverlayState) -> Matrix4 {
    // Actor::SetGlobalRenderStates gives NoEffect masks an implicit ZBias=1.
    // RageDisplay_OGL maps the depth range to [.05*(1-bias), 1-.05*bias].
    // Apply that range in homogeneous clip space before the screen projection
    // is cancelled; painter order must not replace the mask's depth ordering.
    let bias = if state.z_bias == 0.0 && state.blend == SongLuaOverlayBlendMode::NoEffect {
        1.0
    } else {
        state.z_bias
    };
    let mut depth_range = Matrix4::from_scale(Vector3::new(1.0, 1.0, 0.95));
    depth_range.w_axis.z = 0.05 - 0.1 * bias;
    if !state.depth_test && !state.depth_write {
        depth_range = Matrix4::IDENTITY;
    }
    depth_range
}

fn song_lua_projected_local_transform(
    camera: impl Into<SongLuaDrawViewProjection>,
    model: Matrix4,
    state: SongLuaOverlayState,
) -> Matrix4 {
    let SongLuaDrawViewProjection { view, projection, world } = camera.into();
    // ActorFrame replaces the camera but leaves ScreenGameplay on the world
    // stack. Apply that world matrix before projection, without recovering it
    // through a nearly singular perspective inverse in clip space.
    let model = if world == Matrix4::IDENTITY { model } else { world * model };
    song_lua_screen_proj(1.0).inverse() * song_lua_depth_range(state) * projection * (view * model)
}

#[derive(Clone, Copy)]
struct SongLuaSpriteColors {
    corners: [[f32; 4]; 4],
    fade_alpha: [f32; 4],
    // Authored left/right/top/bottom after geometry mirrors its edge bands.
    edge_order: [u8; 4],
}

impl SongLuaSpriteColors {
    fn new(state: SongLuaOverlayState, flip_x: bool, flip_y: bool) -> Self {
        let mut corners = state.vertex_colors.unwrap_or([[1.0; 4]; 4]);
        let mut fade_alpha = [1.0; 4];
        for (axis, crop, distances) in [
            (
                0,
                [state.cropleft, state.cropright],
                [state.fadeleft, state.faderight],
            ),
            (
                2,
                [state.croptop, state.cropbottom],
                [state.fadetop, state.fadebottom],
            ),
        ] {
            let remaining = 1.0 - (crop[0] + crop[1]);
            let sum = distances[0] + distances[1];
            if sum > 0.0 && remaining < sum {
                let percent = distances[0] / sum;
                let sizes = [percent * remaining, (1.0 - percent) * remaining];
                for side in 0..2 {
                    if distances[side] > 0.0 {
                        // Preserve Sprite::DrawPrimitives' SCALE evaluation.
                        fade_alpha[axis + side] =
                            (sizes[side] - distances[side]) * -1.0 / -distances[side] + 1.0;
                    }
                }
            }
        }
        if flip_x {
            corners.swap(0, 1);
            corners.swap(2, 3);
            fade_alpha.swap(0, 1);
        }
        if flip_y {
            corners.swap(0, 2);
            corners.swap(1, 3);
            fade_alpha.swap(2, 3);
        }
        Self {
            corners,
            fade_alpha,
            edge_order: [
                if flip_x { 2 } else { 1 },
                if flip_x { 1 } else { 2 },
                if flip_y { 4 } else { 3 },
                if flip_y { 3 } else { 4 },
            ],
        }
    }
}

fn append_projected_mesh_vertices(
    grid: &[TexturedMeshVertex],
    width: usize,
    height: usize,
    edge_fade: [f32; 4],
    colors: SongLuaSpriteColors,
    vertices: &mut Vec<TexturedMeshVertex>,
) {
    vertices.reserve(width.saturating_sub(1) * height.saturating_sub(1) * 6);
    // Sprite::DrawPrimitives submits the inside, then left/right/top/bottom.
    // Keep those primitive boundaries even when one mesh batches the pieces.
    for region in std::iter::once(0).chain(colors.edge_order) {
        for y in 0..height.saturating_sub(1) {
            for x in 0..width.saturating_sub(1) {
                let left = x == 0 && edge_fade[0] > f32::EPSILON;
                let right = x + 2 == width && edge_fade[1] > f32::EPSILON;
                let top = y == 0 && edge_fade[2] > f32::EPSILON;
                let bottom = y + 2 == height && edge_fade[3] > f32::EPSILON;
                // Native omits diagonal corner cells where both axes fade.
                if (left || right) && (top || bottom) {
                    continue;
                }
                let cell_region = if left { 1 } else if right { 2 } else if top { 3 }
                    else if bottom { 4 } else { 0 };
                if cell_region != region {
                    continue;
                }
                let tl = y * width + x;
                let tr = tl + 1;
                let bl = (y + 1) * width + x;
                let br = bl + 1;
                let mut quad = [grid[tl], grid[tr], grid[br], grid[tl], grid[br], grid[bl]];
                for (vertex, [cx, cy]) in
                    quad.iter_mut()
                        .zip([[0, 0], [1, 0], [1, 1], [0, 0], [1, 1], [0, 1]])
                {
                    let color_x = if left {
                        0
                    } else if right {
                        1
                    } else {
                        cx
                    };
                    let color_y = if top {
                        0
                    } else if bottom {
                        1
                    } else {
                        cy
                    };
                    let alpha = if left {
                        if cx == 0 { 0.0 } else { colors.fade_alpha[0] }
                    } else if right {
                        if cx == 0 { colors.fade_alpha[1] } else { 0.0 }
                    } else if top {
                        if cy == 0 { 0.0 } else { colors.fade_alpha[2] }
                    } else if bottom {
                        if cy == 0 { colors.fade_alpha[3] } else { 0.0 }
                    } else {
                        1.0
                    };
                    vertex.color = colors.corners[color_y * 2 + color_x];
                    vertex.color[3] *= alpha;
                }
                vertices.extend_from_slice(&quad);
            }
        }
    }
}

struct SongLuaProjectedMeshParams {
    texture: Arc<str>,
    sampler: deadlib_render_core::MeshSampler,
    tint: [f32; 4],
    glow: [f32; 4],
    local_transform: Matrix4,
    world_z: f32,
    depth_test: bool,
    depth_write: bool,
    depth_test_on_fail: bool,
    visible: bool,
    blend: BlendMode,
    z: i16,
}

fn song_lua_projected_mesh_actor_from_grid(
    params: SongLuaProjectedMeshParams,
    grid: &[TexturedMeshVertex],
    width: usize,
    height: usize,
    edge_fade: [f32; 4],
    colors: SongLuaSpriteColors,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Actor {
    if let Some(scratch) = scratch {
        return Actor::ReusableTexturedMesh {
            vertex_color_encoding: Default::default(),
            environment: Some(deadlib_present::actors::MeshEnvironment {
                sampler: Some(params.sampler),
                camera: None,
                transform: Matrix4::IDENTITY,
                additive_texture: None,
                additive_uv: [0.0, 0.0, 1.0, 1.0],
            }),
            align: [0.0, 0.0],
            offset: [0.0, 0.0],
            world_z: params.world_z,
            size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
            local_transform: params.local_transform,
            texture: params.texture.into(),
            tint: params.tint,
            glow: params.glow,
            vertices: scratch.update_projected(grid, width, height, edge_fade, colors),
            geom_cache_key: INVALID_TMESH_CACHE_KEY,
            uv_scale: [1.0, 1.0],
            uv_offset: [0.0, 0.0],
            uv_tex_shift: [0.0, 0.0],
            depth_test: params.depth_test,
            depth_write: params.depth_write,
            depth_test_on_fail: params.depth_test_on_fail,
            clear_depth: false,
            clear_depth_after: false,
            cull_mode: deadlib_render_core::CullMode::None,
            visible: params.visible,
            blend: params.blend,
            z: params.z,
        };
    }
    let mut vertices = Vec::with_capacity(
        width
            .saturating_sub(1)
            .saturating_mul(height.saturating_sub(1))
            .saturating_mul(6),
    );
    append_projected_mesh_vertices(grid, width, height, edge_fade, colors, &mut vertices);
    Actor::TexturedMesh {
        vertex_color_encoding: Default::default(),
        environment: Some(deadlib_present::actors::MeshEnvironment {
            sampler: Some(params.sampler),
            camera: None,
            transform: Matrix4::IDENTITY,
            additive_texture: None,
            additive_uv: [0.0, 0.0, 1.0, 1.0],
        }),
        align: [0.0, 0.0],
        offset: [0.0, 0.0],
        world_z: params.world_z,
        size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
        local_transform: params.local_transform,
        texture: params.texture.into(),
        tint: params.tint,
        glow: params.glow,
        vertices: Arc::from(vertices.into_boxed_slice()),
        geom_cache_key: INVALID_TMESH_CACHE_KEY,
        uv_scale: [1.0, 1.0],
        uv_offset: [0.0, 0.0],
        uv_tex_shift: [0.0, 0.0],
        depth_test: params.depth_test,
        depth_write: params.depth_write,
        depth_test_on_fail: params.depth_test_on_fail,
        clear_depth: false,
        clear_depth_after: false,
        cull_mode: deadlib_render_core::CullMode::None,
        visible: params.visible,
        blend: params.blend,
        z: params.z,
    }
}

fn song_lua_flat_skewed_overlay_actor(
    texture: Arc<str>,
    tint: [f32; 4],
    blend: BlendMode,
    z: i16,
    center: [f32; 2],
    size: [f32; 2],
    rot_deg: [f32; 3],
    uv: [[f32; 2]; 4],
    state: SongLuaOverlayState,
    flip_x: bool,
    flip_y: bool,
    world_z: f32,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Option<Actor> {
    let (flip_x, flip_y, size_x, size_y) =
        song_lua_overlay_fold_xy_rot(flip_x, flip_y, size[0], size[1], rot_deg[0], rot_deg[1]);
    let half_w = 0.5 * size_x;
    let half_h = 0.5 * size_y;
    if half_w <= f32::EPSILON || half_h <= f32::EPSILON {
        return None;
    }
    let edge_fade = song_lua_projected_overlay_edge_fade(state, flip_x, flip_y);
    let xs = song_lua_projected_overlay_axis_slices(edge_fade[0], edge_fade[1]);
    let ys = song_lua_projected_overlay_axis_slices(edge_fade[2], edge_fade[3]);
    let transform = Matrix4::from_translation(Vector3::new(center[0], center[1], 0.0))
        * song_lua_overlay_local_transform(rot_deg, state.skew_x, state.skew_y);
    let mut grid = SmallVec::<[TexturedMeshVertex; 16]>::new();
    for &y in &ys {
        for &x in &xs {
            let local_x = song_lua_effect_lerp(-half_w, half_w, x);
            let local_y = song_lua_effect_lerp(-half_h, half_h, y);
            let point = transform * Vector4::new(local_x, local_y, 0.0, 1.0);
            grid.push(TexturedMeshVertex {
                normal: [0.0; 4],
                pos: [point.x, point.y, 0.0],
                uv: song_lua_projected_overlay_uv_point(uv, x, y),
                tex_matrix_scale: [1.0, 1.0],
                color: [1.0; 4],
            });
        }
    }
    Some(song_lua_projected_mesh_actor_from_grid(
        SongLuaProjectedMeshParams {
            sampler: deadlib_render_core::MeshSampler::Override {
                filter: if state.texture_filtering {
                    deadlib_render_core::SamplerFilter::Linear
                } else {
                    deadlib_render_core::SamplerFilter::Nearest
                },
                wrap: if state.texture_wrapping {
                    deadlib_render_core::SamplerWrap::Repeat
                } else {
                    deadlib_render_core::SamplerWrap::Clamp
                },
            },
            local_transform: Matrix4::IDENTITY,
            world_z,
            depth_test: state.depth_test,
            depth_write: state.depth_write,
            depth_test_on_fail: state.depth_test_on_fail,
            visible: state.draw_visible(),
            glow: [1.0, 1.0, 1.0, 0.0],
            texture,
            tint,
            blend,
            z,
        },
        &grid,
        xs.len(),
        ys.len(),
        edge_fade,
        SongLuaSpriteColors::new(state, flip_x, flip_y),
        scratch,
    ))
}

fn song_lua_projected_overlay_actor(
    texture: Arc<str>,
    tint: [f32; 4],
    blend: BlendMode,
    z: i16,
    model: Matrix4,
    size: [f32; 2],
    uv: [[f32; 2]; 4],
    state: SongLuaOverlayState,
    flip_x: bool,
    flip_y: bool,
    view_proj: impl Into<SongLuaDrawViewProjection>,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Option<Actor> {
    let half_w = 0.5 * size[0];
    let half_h = 0.5 * size[1];
    if half_w <= f32::EPSILON || half_h <= f32::EPSILON {
        return None;
    }
    let edge_fade = song_lua_projected_overlay_edge_fade(state, flip_x, flip_y);
    let xs = song_lua_projected_overlay_axis_slices(edge_fade[0], edge_fade[1]);
    let ys = song_lua_projected_overlay_axis_slices(edge_fade[2], edge_fade[3]);
    // Preserve homogeneous clip-space W until the GPU rasterizer.  ITGmania
    // submits the actor's world vertices under its perspective camera and lets
    // the GPU clip triangles which cross the near/camera planes.  Dividing by
    // W here made one behind-camera corner discard the whole sprite and also
    // forced affine texture interpolation across projected quads.
    let local_transform = song_lua_projected_local_transform(view_proj, model, state);
    let mut grid = SmallVec::<[TexturedMeshVertex; 16]>::new();
    for &y in &ys {
        for &x in &xs {
            let local_x = song_lua_effect_lerp(-half_w, half_w, x);
            let local_y = song_lua_effect_lerp(-half_h, half_h, y);
            grid.push(TexturedMeshVertex {
                normal: [0.0; 4],
                pos: [local_x, local_y, 0.0],
                uv: song_lua_projected_overlay_uv_point(uv, x, y),
                tex_matrix_scale: [1.0, 1.0],
                color: [1.0; 4],
            });
        }
    }
    Some(song_lua_projected_mesh_actor_from_grid(
        SongLuaProjectedMeshParams {
            sampler: deadlib_render_core::MeshSampler::Override {
                filter: if state.texture_filtering {
                    deadlib_render_core::SamplerFilter::Linear
                } else {
                    deadlib_render_core::SamplerFilter::Nearest
                },
                wrap: if state.texture_wrapping {
                    deadlib_render_core::SamplerWrap::Repeat
                } else {
                    deadlib_render_core::SamplerWrap::Clamp
                },
            },
            local_transform,
            world_z: 0.0,
            depth_test: state.depth_test,
            depth_write: state.depth_write,
            depth_test_on_fail: state.depth_test_on_fail,
            visible: true,
            glow: [1.0, 1.0, 1.0, 0.0],
            texture,
            tint,
            blend,
            z,
        },
        &grid,
        xs.len(),
        ys.len(),
        edge_fade,
        SongLuaSpriteColors::new(state, flip_x, flip_y),
        scratch,
    ))
}

type SongLuaActorList = SmallVec<[Actor; 2]>;

#[derive(Clone, Copy)]
struct SongLuaDrawTime {
    animation_elapsed: f32,
    uptime_seconds: f64,
}

impl From<f32> for SongLuaDrawTime {
    fn from(elapsed: f32) -> Self {
        Self { animation_elapsed: elapsed, uptime_seconds: f64::from(elapsed) }
    }
}

#[allow(clippy::too_many_arguments)]
fn build_song_lua_aft_sprite_actor(
    state: SongLuaOverlayState,
    texture_handle: TextureHandle,
    texture_size: [f32; 2],
    z: i16,
    overlay_space_width: f32,
    overlay_space_height: f32,
    effect_time: f32,
    effect_beat: f32,
    total_elapsed: f32,
    mut projected_mesh_scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Option<SongLuaActorList> {
    if !state.draw_visible() || !state.sprite_texture || !song_lua_overlay_has_visible_output(state)
    {
        return None;
    }
    let (backing, viewport) = song_lua_capture_size(texture_size);
    let texture_size = texture_size.map(f32::trunc);
    let x_scale = screen_width() / overlay_space_width.max(1.0);
    let y_scale = screen_height() / overlay_space_height.max(1.0);
    let axis_scale = song_lua_overlay_axis_scale(state);
    let (size_scale_x, flip_x) = if axis_scale[0] < 0.0 {
        (-axis_scale[0], true)
    } else {
        (axis_scale[0], false)
    };
    let (size_scale_y, flip_y) = if axis_scale[1] < 0.0 {
        (-axis_scale[1], true)
    } else {
        (axis_scale[1], false)
    };
    let (align, mut offset, size) = if let Some([left, top, right, bottom]) = state.stretch_rect {
        (
            [0.0, 0.0],
            [left * x_scale, top * y_scale],
            [
                (right - left).abs() * x_scale * size_scale_x,
                (bottom - top).abs() * y_scale * size_scale_y,
            ],
        )
    } else {
        (
            [state.halign, state.valign],
            [state.x * x_scale, state.y * y_scale],
            [
                texture_size[0] * x_scale * size_scale_x,
                texture_size[1] * y_scale * size_scale_y,
            ],
        )
    };
    if size[0] <= f32::EPSILON || size[1] <= f32::EPSILON {
        return None;
    }
    let mut tint = state.diffuse;
    let mut glow = state.glow;
    let mut effect_offset = [0.0, 0.0, 0.0];
    let mut effect_scale = [1.0, 1.0, 1.0];
    let mut effect_rot = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
    song_lua_apply_overlay_effect(
        state,
        effect_time,
        effect_beat,
        z as u32,
        &mut tint,
        &mut glow,
        &mut effect_offset,
        &mut effect_scale,
        &mut effect_rot,
    );
    offset[0] = effect_offset[0].mul_add(x_scale, offset[0]);
    offset[1] = effect_offset[1].mul_add(y_scale, offset[1]);
    if (state.vertex_colors.is_some()
        || state.fadeleft > 0.0
        || state.faderight > 0.0
        || state.fadetop > 0.0
        || state.fadebottom > 0.0)
        && !state.mask_source
        && !state.mask_dest
    {
        let (center, size) = song_lua_overlay_rect(
            state,
            texture_size,
            x_scale,
            y_scale,
            size_scale_x,
            size_scale_y,
        )?;
        let uv_state = SongLuaOverlayState {
            custom_texture_rect: Some(state.custom_texture_rect.unwrap_or([
                0.0,
                0.0,
                viewport[0] as f32 / backing[0] as f32,
                viewport[1] as f32 / backing[1] as f32,
            ])),
            ..state
        };
        let mut actor = song_lua_flat_skewed_overlay_actor(
            white_texture_key(),
            tint,
            song_lua_overlay_blend(state.blend),
            z,
            [
                effect_offset[0].mul_add(x_scale, center[0]),
                effect_offset[1].mul_add(y_scale, center[1]),
            ],
            [size[0] * effect_scale[0], size[1] * effect_scale[1]],
            effect_rot,
            song_lua_overlay_uvs(
                uv_state,
                None,
                &[],
                flip_x,
                flip_y,
                total_elapsed,
                total_elapsed,
            ),
            state,
            flip_x,
            flip_y,
            song_lua_biased_world_z(state, effect_offset[2] / 1000.0),
            projected_mesh_scratch.as_deref_mut(),
        )?;
        match &mut actor {
            Actor::TexturedMesh { texture, .. } | Actor::ReusableTexturedMesh { texture, .. } => {
                *texture = deadlib_present::actors::MeshTexture::Handle(
                    render_target_sample_handle(texture_handle, !state.texture_filtering),
                );
            }
            _ => unreachable!("sprite color grid is a textured mesh"),
        }
        let mut actors = song_lua_finalize_overlay_actor(
            state,
            actor,
            glow,
            x_scale,
            y_scale,
            projected_mesh_scratch,
        );
        for actor in &mut actors {
            song_lua_set_native_sprite_colors(actor);
        }
        return Some(actors);
    }
    let actor = Actor::Sprite {
        align,
        vertex_color_encoding: deadlib_present::actors::VertexColorEncoding::RageVColor,
        offset,
        // This sprite uses the main pass's normalized depth. ITG's menu
        // camera spans Â±1000, so a ten-pixel RGB vibration must not clip it.
        world_z: song_lua_biased_world_z(state, effect_offset[2] / 1000.0),
        size: [SizeSpec::Px(size[0]), SizeSpec::Px(size[1])],
        source: SpriteSource::RenderTarget {
            handle: render_target_sample_handle(texture_handle, !state.texture_filtering),
            size: texture_size,
        },
        tint,
        glow,
        z,
        cell: None,
        grid: None,
        uv_rect: {
            let uv_state = SongLuaOverlayState {
                custom_texture_rect: Some(state.custom_texture_rect.unwrap_or([
                    0.0,
                    0.0,
                    viewport[0] as f32 / backing[0] as f32,
                    viewport[1] as f32 / backing[1] as f32,
                ])),
                ..state
            };
            song_lua_overlay_uv_rect(uv_state, None, &[], total_elapsed)
        },
        visible: state.draw_visible(),
        flip_x,
        flip_y,
        cropleft: state.cropleft.clamp(0.0, 1.0),
        cropright: state.cropright.clamp(0.0, 1.0),
        croptop: state.croptop.clamp(0.0, 1.0),
        cropbottom: state.cropbottom.clamp(0.0, 1.0),
        fadeleft: state.fadeleft.clamp(0.0, 1.0),
        faderight: state.faderight.clamp(0.0, 1.0),
        fadetop: state.fadetop.clamp(0.0, 1.0),
        fadebottom: state.fadebottom.clamp(0.0, 1.0),
        blend: song_lua_overlay_blend(state.blend),
        mask_source: state.mask_source,
        mask_dest: state.mask_dest,
        rot_x_deg: effect_rot[0],
        rot_y_deg: effect_rot[1],
        // ITG actors are authored in screen space (Y down), while the AFT
        // sprite is emitted in render space (Y up). Reflect the in-plane
        // transform so the strip's authored position compensation cancels
        // its skew instead of doubling it.
        rot_z_deg: -effect_rot[2],
        // Sprite geometry already includes the actor's axis scales. Native
        // BeginDraw scales before skew; the renderer skews that sized quad.
        // Conjugate the shear by scale to preserve the native matrix.
        skew: {
            let sx = axis_scale[0] * effect_scale[0];
            let sy = axis_scale[1] * effect_scale[1];
            [
                if sy != 0.0 {
                    -state.skew_x * sx / sy
                } else {
                    0.0
                },
                if sx != 0.0 {
                    -state.skew_y * sy / sx
                } else {
                    0.0
                },
            ]
        },
        local_offset: [0.0, 0.0],
        local_offset_rot_sin_cos: [0.0, 1.0],
        texcoordvelocity: state.texcoord_velocity,
        animate: false,
        state_delay: 0.0,
        scale: [effect_scale[0], effect_scale[1]],
        shadow_len: state.shadow_len,
        shadow_color: state.shadow_color,
        effect: deadlib_present::anim::EffectState::default(),
    };
    Some(song_lua_finalize_overlay_actor(
        state,
        actor,
        glow,
        x_scale,
        y_scale,
        projected_mesh_scratch,
    ))
}

fn append_song_lua_overlay_output<S: NoteskinSlot + Clone>(
    out: &mut Vec<Actor>,
    overlay: &SongLuaOverlayActor<S>,
    state: SongLuaOverlayState,
    camera: SongLuaDrawCamera,
    assets: &AssetManager,
    z: i16,
    size: [f32; 2],
    clock: [f32; 2],
    elapsed: impl Into<SongLuaDrawTime>,
    texture: Option<TextureHandle>,
    mut scratch: Option<&mut SongLuaProjectedMeshScratch>,
) {
    let elapsed = elapsed.into();
    let start = out.len();
    let flat_camera = camera.world != Matrix4::IDENTITY
        && (matches!(overlay.kind, SongLuaOverlayKind::BitmapText { .. })
            || texture.is_none()
                && matches!(overlay.kind, SongLuaOverlayKind::ActorMultiVertex { texture_key: None, .. })
            || matches!(overlay.kind, SongLuaOverlayKind::Sprite { .. } | SongLuaOverlayKind::Quad)
                && camera.uses_generic_mask(state, size));
    if flat_camera {
        let [projection, view, space] = song_lua_model_camera(
            camera, screen_width() / size[0].max(1.0), screen_height() / size[1].max(1.0),
        );
        out.push(Actor::CameraPush {
            view_proj: song_lua_depth_range(state) * projection * view * space,
        });
    }
    if append_song_lua_multi_actor_overlay(
        out, overlay, state, camera, assets, z, size[0], size[1],
        clock[0], clock[1], elapsed.animation_elapsed, scratch.as_deref_mut(),
    ).is_none()
        && let Some(actors) = build_song_lua_overlay_actor_with_scratch(
            overlay, state, camera, assets, z, size[0], size[1],
            clock[0], clock[1], elapsed, texture, scratch,
        )
    {
        out.extend(actors);
    }
    if flat_camera {
        if out.len() > start + 1 {
            out.push(Actor::CameraPop);
        } else {
            out.truncate(start);
        }
    }
}

/// Emits compiled multi-output overlays directly into the caller's reused
/// frame buffer. Returning `None` means the overlay is a single-output kind and
/// should continue through the compact inline builder.
#[allow(clippy::too_many_arguments)]
fn append_song_lua_multi_actor_overlay<S: NoteskinSlot + Clone>(
    out: &mut Vec<Actor>,
    overlay: &SongLuaOverlayActor<S>,
    state: SongLuaOverlayState,
    camera_state: impl Into<SongLuaDrawCamera>,
    asset_manager: &AssetManager,
    z: i16,
    overlay_space_width: f32,
    overlay_space_height: f32,
    effect_time: f32,
    effect_beat: f32,
    total_elapsed: f32,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Option<bool> {
    let camera_state = camera_state.into();
    if !matches!(
        overlay.kind,
        SongLuaOverlayKind::Model { .. } | SongLuaOverlayKind::NoteskinActor { .. }
    ) {
        return None;
    }
    if !state.draw_visible() || !song_lua_overlay_has_visible_output(state) {
        return Some(false);
    }

    let x_scale = screen_width() / overlay_space_width.max(1.0);
    let y_scale = screen_height() / overlay_space_height.max(1.0);
    let overlay_scale = song_lua_overlay_axis_scale(state);
    if overlay_scale
        .iter()
        .any(|scale| !scale.is_finite() || scale.abs() <= f32::EPSILON)
    {
        return Some(false);
    }
    let actor_scale = [overlay_scale[0].abs(), overlay_scale[1].abs()];
    let mut tint = state.diffuse;
    let mut glow = state.glow;
    let mut effect_offset = [0.0, 0.0, 0.0];
    let mut effect_scale = [1.0, 1.0, 1.0];
    let mut effect_rot = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
    song_lua_apply_overlay_effect(
        state,
        effect_time,
        effect_beat,
        z as u32,
        &mut tint,
        &mut glow,
        &mut effect_offset,
        &mut effect_scale,
        &mut effect_rot,
    );
    song_lua_clamp_float_output_colors(&mut tint, &mut glow);
    let blend = song_lua_overlay_blend(state.blend);

    Some(match &overlay.kind {
        SongLuaOverlayKind::Model { layers } => {
            let passes = scratch
                .as_deref()
                .and_then(|scratch| scratch.model_passes.as_deref());
            append_song_lua_model_actors(
                out,
                layers,
                state,
                camera_state,
                asset_manager,
                z,
                x_scale,
                y_scale,
                actor_scale,
                effect_scale,
                effect_rot,
                effect_offset,
                tint,
                glow,
                blend,
                total_elapsed,
                passes,
            )
        }
        SongLuaOverlayKind::NoteskinActor {
            slots,
            texture_samples,
        } => append_song_lua_noteskin_actors(
            out,
            slots,
            texture_samples,
            state,
            camera_state,
            asset_manager,
            z,
            x_scale,
            y_scale,
            actor_scale,
            effect_scale,
            effect_rot,
            effect_offset,
            tint,
            glow,
            blend,
            total_elapsed,
            effect_beat,
            scratch,
        ),
        _ => false,
    })
}

fn build_song_lua_overlay_actor_with_scratch<S: NoteskinSlot + Clone>(
    overlay: &SongLuaOverlayActor<S>,
    state: SongLuaOverlayState,
    camera_state: impl Into<SongLuaDrawCamera>,
    asset_manager: &AssetManager,
    z: i16,
    overlay_space_width: f32,
    overlay_space_height: f32,
    effect_time: f32,
    effect_beat: f32,
    draw_time: impl Into<SongLuaDrawTime>,
    texture_handle: Option<TextureHandle>,
    mut projected_mesh_scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Option<SongLuaActorList> {
    let draw_time = draw_time.into();
    let total_elapsed = draw_time.animation_elapsed;
    let camera_state = camera_state.into();
    if !state.draw_visible() || !song_lua_overlay_has_visible_output(state) {
        return None;
    }
    let x_scale = screen_width() / overlay_space_width.max(1.0);
    let y_scale = screen_height() / overlay_space_height.max(1.0);
    let overlay_scale = song_lua_overlay_axis_scale(state);
    // A zero zoom has no geometry in ITGmania. Do not pass a 0x0 sprite to
    // `deadlib-present`: generic sprites use 0x0 as the sentinel for native
    // texture size, which would resurrect a hidden sprite sheet at full size.
    if overlay_scale
        .iter()
        .any(|scale| !scale.is_finite() || scale.abs() <= f32::EPSILON)
    {
        return None;
    }
    let (size_scale_x, flip_x) = if overlay_scale[0] < 0.0 {
        (-overlay_scale[0], true)
    } else {
        (overlay_scale[0], false)
    };
    let (size_scale_y, flip_y) = if overlay_scale[1] < 0.0 {
        (-overlay_scale[1], true)
    } else {
        (overlay_scale[1], false)
    };
    let overlay_blend = song_lua_overlay_blend(state.blend);
    // Depth, tilted sprites and rotated anchors need the native matrix under an
    // orthographic camera. Generic sprites fold X/Y angles around their center,
    // losing the rotated anchor and combined-axis geometry. Per-actor filtering
    // and wrapping also need the mesh path's explicit sampler override.
    let sprite_view_proj = || {
        // Generic Sprite composition owns mask registration and clipping. A
        // screen-only world transform must not replace it with an unmasked mesh.
        if camera_state.uses_generic_mask(state, [overlay_space_width, overlay_space_height]) {
            return None;
        }
        camera_state
            .view_proj(overlay_space_width, overlay_space_height)
            .or_else(|| {
                let rotated_anchor = (state.halign != 0.5 || state.valign != 0.5)
                    && state.rot_z_deg.abs() > f32::EPSILON;
                // Actor::BeginDraw leaves an ancestor's scale before the
                // child's rotation. Generic sprites fold scale into their
                // size, which reverses this order when the axes differ.
                let rotated_ancestor_scale = state.scale_factors.is_some_and(|[ancestor, _]| {
                    ancestor[0] != ancestor[1]
                        && (state.rot_z_deg % 180.0).to_radians().abs() > f32::EPSILON
                });
                let native_mesh = state.quaternion != crate::actor_quaternion::IDENTITY
                    || state.z != 0.0
                    || state.depth_test
                    || state.depth_write
                    || state.rot_x_deg.abs() > f32::EPSILON
                    || state.rot_y_deg.abs() > f32::EPSILON
                    || rotated_anchor
                    || rotated_ancestor_scale
                    || !state.texture_filtering
                    || state.texture_wrapping
                    || matches!(
                        state.effect_mode,
                        deadlib_present::anim::EffectMode::Spin
                            | deadlib_present::anim::EffectMode::Wag
                    );
                (native_mesh && !state.mask_source && !state.mask_dest)
                    // RageDisplay::LoadMenuPerspective(0) uses +/-1000 depth.
                    .then(|| (Matrix4::IDENTITY, song_lua_screen_proj(1000.0)).into())
            })
    };
    let finalize_actor = |actor, glow, scratch| {
        let mut actors =
            song_lua_finalize_overlay_actor(state, actor, glow, x_scale, y_scale, scratch);
        if matches!(
            overlay.kind,
            SongLuaOverlayKind::Sprite { .. } | SongLuaOverlayKind::Quad
        ) {
            for actor in &mut actors {
                song_lua_set_native_sprite_colors(actor);
            }
        }
        actors
    };
    match &overlay.kind {
        SongLuaOverlayKind::Actor => None,
        SongLuaOverlayKind::ActorFrame | SongLuaOverlayKind::WrapperState => None,
        SongLuaOverlayKind::UpdateTracks { .. } => None,
        SongLuaOverlayKind::ActorFrameTexture { .. } => None,
        SongLuaOverlayKind::ActorProxy { .. } => None,
        SongLuaOverlayKind::AftSprite { .. } => None,
        SongLuaOverlayKind::Sound { .. } => None,
        SongLuaOverlayKind::Sprite {
            texture_key,
            states,
            textures: bindings,
            ..
        } => {
            let active = crate::sprite_texture_at(bindings, effect_time);
            let texture_key = active.map_or(texture_key, |texture| &texture.key);
            let states = active.map_or(states.as_ref(), |texture| texture.states.as_ref());
            let textures = asset_manager.texture_context();
            let binding = match projected_mesh_scratch.as_deref_mut() {
                Some(scratch) => scratch.bind_sprite(texture_key, textures),
                None => textures.bind_texture(texture_key),
            }?;
            let frame_sheet = active
                .and_then(|texture| texture.frame_sheet)
                .unwrap_or(binding.sheet);
            let epoch = match (
                state.sprite_animation_epoch,
                active.and_then(|texture| texture.animation_epoch),
            ) {
                (Some(state), Some(texture)) => Some(state.max(texture)),
                (state, texture) => state.or(texture),
            };
            let animation_elapsed =
                epoch.map_or(total_elapsed, |epoch| (effect_time - epoch).max(0.0));
            let source_size = song_lua_overlay_sprite_size(state, binding)?;
            if !camera_state.is_active()
                && state.stretch_rect.is_none()
                && song_lua_overlay_sprite_offscreen(
                    state,
                    source_size,
                    overlay_space_width,
                    overlay_space_height,
                )
            {
                return None;
            }
            if let Some(view_proj) = sprite_view_proj() {
                // Signed zoom is in the model matrix; UV/color flips are only
                // needed by the stretched geometry path, which uses abs size.
                let (flip_x, flip_y) = if state.stretch_rect.is_some() {
                    (flip_x, flip_y)
                } else {
                    (false, false)
                };
                let mut tint = state.diffuse;
                let mut glow = state.glow;
                let mut effect_offset = [0.0, 0.0, 0.0];
                let mut effect_scale = [1.0, 1.0, 1.0];
                let mut rot_deg = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
                song_lua_apply_overlay_effect(
                    state,
                    effect_time,
                    effect_beat,
                    z as u32,
                    &mut tint,
                    &mut glow,
                    &mut effect_offset,
                    &mut effect_scale,
                    &mut rot_deg,
                );
                let (model, size) = song_lua_projected_sprite_geometry(
                    state,
                    source_size,
                    [x_scale, y_scale],
                    effect_offset,
                    rot_deg,
                    effect_scale,
                )?;
                let actor = song_lua_projected_overlay_actor(
                    Arc::clone(texture_key),
                    tint,
                    overlay_blend,
                    z,
                    model,
                    size,
                    song_lua_overlay_uvs(
                        state,
                        Some(frame_sheet),
                        states,
                        flip_x,
                        flip_y,
                        animation_elapsed,
                        total_elapsed,
                    ),
                    state,
                    flip_x,
                    flip_y,
                    view_proj,
                    projected_mesh_scratch.as_deref_mut(),
                )?;
                return Some(finalize_actor(
                    actor,
                    glow,
                    projected_mesh_scratch.as_deref_mut(),
                ));
            }
            if (state.skew_x.abs() > f32::EPSILON
                || state.skew_y.abs() > f32::EPSILON
                || state.vertex_colors.is_some()
                || state.fadeleft > 0.0
                || state.faderight > 0.0
                || state.fadetop > 0.0
                || state.fadebottom > 0.0)
                && !state.mask_source
                && !state.mask_dest
            {
                let (center, size) = song_lua_overlay_rect(
                    state,
                    source_size,
                    x_scale,
                    y_scale,
                    size_scale_x,
                    size_scale_y,
                )?;
                let mut tint = state.diffuse;
                let mut glow = state.glow;
                let mut effect_offset = [0.0, 0.0, 0.0];
                let mut effect_scale = [1.0, 1.0, 1.0];
                let mut rot_deg = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
                song_lua_apply_overlay_effect(
                    state,
                    effect_time,
                    effect_beat,
                    z as u32,
                    &mut tint,
                    &mut glow,
                    &mut effect_offset,
                    &mut effect_scale,
                    &mut rot_deg,
                );
                let actor = song_lua_flat_skewed_overlay_actor(
                    Arc::clone(texture_key),
                    tint,
                    overlay_blend,
                    z,
                    [
                        effect_offset[0].mul_add(x_scale, center[0]),
                        effect_offset[1].mul_add(y_scale, center[1]),
                    ],
                    [size[0] * effect_scale[0], size[1] * effect_scale[1]],
                    rot_deg,
                    song_lua_overlay_uvs(
                        state,
                        Some(frame_sheet),
                        states,
                        flip_x,
                        flip_y,
                        animation_elapsed,
                        total_elapsed,
                    ),
                    state,
                    flip_x,
                    flip_y,
                    effect_offset[2],
                    projected_mesh_scratch.as_deref_mut(),
                )?;
                return Some(finalize_actor(
                    actor,
                    glow,
                    projected_mesh_scratch.as_deref_mut(),
                ));
            }
            let source = deadlib_present::actors::TextureKeyHandle {
                key: Arc::clone(texture_key),
                handle: binding.handle,
                generation: textures.revision(),
            };
            let mut actor = if let Some([left, top, right, bottom]) = state.stretch_rect {
                deadlib_present::__act_from_builder!((
                    align(0.0, 0.0):
                    xy(left * x_scale, top * y_scale):
                    setsize(
                        (right - left).abs() * x_scale * size_scale_x,
                        (bottom - top).abs() * y_scale * size_scale_y
                    ):
                    z(z)
                ) deadlib_assets::SpriteBuilder::texture(source))
            } else {
                deadlib_present::__act_from_builder!((
                    align(state.halign, state.valign):
                    xy(state.x * x_scale, state.y * y_scale):
                    setsize(
                        source_size[0] * x_scale * size_scale_x,
                        source_size[1] * y_scale * size_scale_y
                    ):
                    z(z)
                ) deadlib_assets::SpriteBuilder::texture(source))
            };
            if let Actor::Sprite {
                tint,
                glow,
                cropleft,
                cropright,
                croptop,
                cropbottom,
                fadeleft,
                faderight,
                fadetop,
                fadebottom,
                blend,
                mask_source,
                mask_dest,
                rot_x_deg,
                rot_y_deg,
                rot_z_deg,
                offset,
                world_z,
                scale,
                uv_rect,
                texcoordvelocity,
                effect: actor_effect,
                flip_x: actor_flip_x,
                flip_y: actor_flip_y,
                visible,
                ..
            } = &mut actor
            {
                let mut effect_tint = state.diffuse;
                let mut effect_glow = state.glow;
                let mut effect_offset = [0.0, 0.0, 0.0];
                let mut effect_scale = [1.0, 1.0, 1.0];
                let mut effect_rot = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
                song_lua_apply_overlay_effect(
                    state,
                    effect_time,
                    effect_beat,
                    z as u32,
                    &mut effect_tint,
                    &mut effect_glow,
                    &mut effect_offset,
                    &mut effect_scale,
                    &mut effect_rot,
                );
                *tint = effect_tint;
                *glow = effect_glow;
                *cropleft = state.cropleft.clamp(0.0, 1.0);
                *cropright = state.cropright.clamp(0.0, 1.0);
                *croptop = state.croptop.clamp(0.0, 1.0);
                *cropbottom = state.cropbottom.clamp(0.0, 1.0);
                *fadeleft = state.fadeleft.clamp(0.0, 1.0);
                *faderight = state.faderight.clamp(0.0, 1.0);
                *fadetop = state.fadetop.clamp(0.0, 1.0);
                *fadebottom = state.fadebottom.clamp(0.0, 1.0);
                *blend = overlay_blend;
                *mask_source = state.mask_source;
                *mask_dest = state.mask_dest;
                *rot_x_deg = effect_rot[0];
                *rot_y_deg = effect_rot[1];
                // Native actor angles use Y-down coordinates; Sprite rotates
                // in the renderer's Y-up space. Mesh paths convert positions.
                *rot_z_deg = -effect_rot[2];
                offset[0] = effect_offset[0].mul_add(x_scale, offset[0]);
                offset[1] = effect_offset[1].mul_add(y_scale, offset[1]);
                *world_z += song_lua_biased_world_z(state, effect_offset[2]);
                scale[0] *= effect_scale[0];
                scale[1] *= effect_scale[1];
                *uv_rect =
                    song_lua_overlay_uv_rect(state, Some(frame_sheet), states, animation_elapsed);
                *texcoordvelocity = state.texcoord_velocity;
                *actor_effect = deadlib_present::anim::EffectState::default();
                *actor_flip_x ^= flip_x;
                *actor_flip_y ^= flip_y;
                *visible = state.draw_visible();
            }
            let glow = if let Actor::Sprite { glow, .. } = &actor {
                *glow
            } else {
                state.glow
            };
            Some(finalize_actor(
                actor,
                glow,
                projected_mesh_scratch.as_deref_mut(),
            ))
        }
        SongLuaOverlayKind::BitmapText {
            font_name,
            text,
            text_changes,
            text_changes_in_seconds,
            stroke_color,
            attributes,
            ..
        } => {
            let text_time = if *text_changes_in_seconds {
                effect_time
            } else {
                effect_beat
            };
            let text_index = text_changes
                .partition_point(|(time, _)| *time <= text_time)
                .checked_sub(1);
            let text = text_index.map_or(text, |index| &text_changes[index].1);
            let content = if state.uppercase {
                projected_mesh_scratch
                    .as_deref_mut()
                    .map_or_else(
                        || TextContent::from(text.to_uppercase()),
                        |scratch| TextContent::from(scratch.uppercase(text, text_index)),
                    )
            } else {
                TextContent::from(text)
            };
            let font = if asset_manager.with_font(font_name, |_| ()).is_some() {
                *font_name
            } else {
                "miso"
            };
            let mut color = state.diffuse;
            let mut glow = state.glow;
            let mut effect_offset = [0.0, 0.0, 0.0];
            let mut effect_scale = [1.0, 1.0, 1.0];
            let mut effect_rot = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
            song_lua_apply_overlay_effect(
                state,
                effect_time,
                effect_beat,
                z as u32,
                &mut color,
                &mut glow,
                &mut effect_offset,
                &mut effect_scale,
                &mut effect_rot,
            );
            song_lua_clamp_float_output_colors(&mut color, &mut glow);
            let diffuse_alpha = color[3];
            let (text_attributes, color) = if state.rainbow_scroll {
                let attributes = projected_mesh_scratch.as_deref_mut().map_or_else(
                    || song_lua_rainbow_scroll_attributes(content.as_str(), draw_time.uptime_seconds).into(),
                    |scratch| scratch.rainbow_attributes(content.as_str(), draw_time.uptime_seconds),
                );
                // BitmapText::DrawPrimitives replaces diffuse RGBA per glyph.
                // The visibility gate still uses the original actor opacity.
                (attributes, [1.0, 1.0, 1.0, if diffuse_alpha == 0.0 { 0.0 } else { 1.0 }])
            } else {
                song_lua_text_attributes_for_diffuse_mode(
                    attributes,
                    color,
                    content.as_str(),
                    state.mult_attrs_with_diffuse,
                    projected_mesh_scratch.as_deref_mut(),
                )
            };
            let mut text_state = state;
            let stroke_color = if state.rainbow_scroll {
                // Native font loading initializes the stroke from the font.
                // Resolve that default before replacing the text's base alpha.
                let mut stroke = stroke_color.unwrap_or_else(|| {
                    asset_manager.with_font(font, |font| font.default_stroke_color)
                        .unwrap_or([0.0; 4])
                });
                stroke[3] *= diffuse_alpha;
                Some(stroke)
            } else {
                *stroke_color
            };
            if state.rainbow_scroll {
                // Stroke and shadow precede the native rainbow diffuse pass.
                text_state.shadow_color[3] *= diffuse_alpha;
            }
            let actor = Actor::Text {
                align: [state.halign, state.valign],
                offset: [
                    effect_offset[0].mul_add(x_scale, state.x * x_scale),
                    effect_offset[1].mul_add(y_scale, state.y * y_scale),
                ],
                local_transform: song_lua_overlay_local_transform(
                    effect_rot,
                    state.skew_x,
                    state.skew_y,
                ),
                color,
                stroke_color,
                glow,
                font,
                content,
                attributes: text_attributes,
                align_text: state.text_align,
                z,
                scale: [
                    size_scale_x * x_scale * effect_scale[0],
                    size_scale_y * y_scale * effect_scale[1],
                ],
                fit_width: state.size.map(|size| size[0] * x_scale),
                fit_height: state.size.map(|size| size[1] * y_scale),
                line_spacing: state
                    .vert_spacing
                    .map(|value| ((value as f32) * y_scale).round() as i32),
                wrap_width_pixels: state
                    .wrap_width_pixels
                    .map(|value| ((value as f32) * x_scale).round() as i32),
                max_width: state.max_width.map(|value| value * x_scale),
                max_height: state.max_height.map(|value| value * y_scale),
                max_w_pre_zoom: state.max_w_pre_zoom && !state.max_dimension_uses_zoom,
                max_h_pre_zoom: state.max_h_pre_zoom && !state.max_dimension_uses_zoom,
                jitter: state.text_jitter,
                distortion: state.text_distortion,
                clip: None,
                mask_dest: state.mask_dest,
                blend: overlay_blend,
                shadow_len: [0.0, 0.0],
                shadow_color: [0.0, 0.0, 0.0, 0.5],
                effect: deadlib_present::anim::EffectState::default(),
            };
            Some(song_lua_finalize_overlay_actor(
                text_state,
                actor,
                glow,
                x_scale,
                y_scale,
                projected_mesh_scratch.as_deref_mut(),
            ))
        }
        SongLuaOverlayKind::ActorMultiVertex {
            vertices,
            texture_key,
            ..
        } => {
            let mut tint = state.diffuse;
            let mut glow = state.glow;
            let mut effect_offset = [0.0, 0.0, 0.0];
            let mut effect_scale = [1.0, 1.0, 1.0];
            let mut effect_rot = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
            song_lua_apply_overlay_effect(
                state,
                effect_time,
                effect_beat,
                z as u32,
                &mut tint,
                &mut glow,
                &mut effect_offset,
                &mut effect_scale,
                &mut effect_rot,
            );
            let texture = if let Some(handle) = texture_handle {
                Some(deadlib_present::actors::MeshTexture::Handle(
                    render_target_sample_handle(handle, !state.texture_filtering),
                ))
            } else if let Some(key) = texture_key {
                if !asset_manager.has_texture_key(key) {
                    return None;
                }
                Some(deadlib_present::actors::MeshTexture::Key(Arc::clone(key)))
            } else {
                None
            };
            if let Some(texture) = texture {
                // AMV positions are native XYZ coordinates. Preserve Z and the
                // homogeneous camera transform until GPU clipping, just as for
                // projected sprites; the menu camera spans +/-1000 units.
                let model = Matrix4::from_scale(Vector3::new(x_scale, y_scale, 1.0))
                    * song_lua_overlay_sprite_matrix(
                        state,
                        [0.0; 2],
                        [
                            state.x + effect_offset[0],
                            state.y + effect_offset[1],
                            state.z + effect_offset[2],
                        ],
                        effect_rot,
                        effect_scale,
                    );
                let view_proj = camera_state
                    .view_proj(overlay_space_width, overlay_space_height)
                    .unwrap_or_else(|| (Matrix4::IDENTITY, song_lua_screen_proj(1000.0)).into());
                let transform = song_lua_projected_local_transform(view_proj, model, state);
                let mesh_actor = if let Some(scratch) = projected_mesh_scratch.as_deref_mut() {
                    let mesh = scratch.update_textured(|out| {
                        append_song_lua_actor_multi_vertex_textured_mesh(out, vertices);
                    });
                    Actor::ReusableTexturedMesh {
                        vertex_color_encoding: deadlib_present::actors::VertexColorEncoding::RageMultiVertex,
                        environment: Some(deadlib_present::actors::MeshEnvironment {
                            sampler: Some(deadlib_render_core::MeshSampler::Override {
                                filter: if state.texture_filtering {
                                    deadlib_render_core::SamplerFilter::Linear
                                } else {
                                    deadlib_render_core::SamplerFilter::Nearest
                                },
                                wrap: if state.texture_wrapping {
                                    deadlib_render_core::SamplerWrap::Repeat
                                } else {
                                    deadlib_render_core::SamplerWrap::Clamp
                                },
                            }),
                            camera: None,
                            transform: Matrix4::IDENTITY,
                            additive_texture: None,
                            additive_uv: [0.0, 0.0, 1.0, 1.0],
                        }),
                        align: [0.0, 0.0],
                        offset: [0.0; 2],
                        world_z: 0.0,
                        size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
                        local_transform: transform,
                        texture: texture.clone(),
                        tint,
                        glow: [1.0, 1.0, 1.0, 0.0],
                        vertices: mesh,
                        geom_cache_key: INVALID_TMESH_CACHE_KEY,
                        uv_scale: [1.0, 1.0],
                        uv_offset: state.texcoord_offset.unwrap_or([0.0; 2]),
                        uv_tex_shift: [0.0, 0.0],
                        depth_test: state.depth_test,
                        depth_write: state.depth_write,
                        depth_test_on_fail: state.depth_test_on_fail,
                        clear_depth: false,
                        clear_depth_after: false,
                        cull_mode: deadlib_render_core::CullMode::None,
                        visible: state.draw_visible(),
                        blend: overlay_blend,
                        z,
                    }
                } else {
                    let mesh = song_lua_actor_multi_vertex_textured_mesh(vertices);
                    Actor::TexturedMesh {
                        vertex_color_encoding: deadlib_present::actors::VertexColorEncoding::RageMultiVertex,
                        environment: Some(deadlib_present::actors::MeshEnvironment {
                            sampler: Some(deadlib_render_core::MeshSampler::Override {
                                filter: if state.texture_filtering {
                                    deadlib_render_core::SamplerFilter::Linear
                                } else {
                                    deadlib_render_core::SamplerFilter::Nearest
                                },
                                wrap: if state.texture_wrapping {
                                    deadlib_render_core::SamplerWrap::Repeat
                                } else {
                                    deadlib_render_core::SamplerWrap::Clamp
                                },
                            }),
                            camera: None,
                            transform: Matrix4::IDENTITY,
                            additive_texture: None,
                            additive_uv: [0.0, 0.0, 1.0, 1.0],
                        }),
                        align: [0.0, 0.0],
                        offset: [0.0; 2],
                        world_z: 0.0,
                        size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
                        local_transform: transform,
                        texture,
                        tint,
                        glow: [1.0, 1.0, 1.0, 0.0],
                        vertices: mesh,
                        geom_cache_key: INVALID_TMESH_CACHE_KEY,
                        uv_scale: [1.0, 1.0],
                        uv_offset: state.texcoord_offset.unwrap_or([0.0; 2]),
                        uv_tex_shift: [0.0, 0.0],
                        depth_test: state.depth_test,
                        depth_write: state.depth_write,
                        depth_test_on_fail: state.depth_test_on_fail,
                        clear_depth: false,
                        clear_depth_after: false,
                        cull_mode: deadlib_render_core::CullMode::None,
                        visible: state.draw_visible(),
                        blend: overlay_blend,
                        z,
                    }
                };
                return Some(finalize_actor(
                    mesh_actor,
                    glow,
                    projected_mesh_scratch.as_deref_mut(),
                ));
            }
            let mesh_actor = if let Some(scratch) = projected_mesh_scratch.as_deref_mut() {
                let mesh = scratch.update_mesh(|out| {
                    append_song_lua_actor_multi_vertex_mesh(
                        out,
                        vertices,
                        x_scale,
                        y_scale,
                        [size_scale_x, size_scale_y],
                        effect_scale,
                        effect_rot[2],
                        [state.skew_x, state.skew_y],
                    );
                });
                Actor::ReusableMesh {
                    vertex_color_encoding: deadlib_present::actors::VertexColorEncoding::RageMultiVertex,
                    align: [0.0, 0.0],
                    offset: [
                        effect_offset[0].mul_add(x_scale, state.x * x_scale),
                        effect_offset[1].mul_add(y_scale, state.y * y_scale),
                    ],
                    size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
                    tint,
                    vertices: mesh,
                    visible: state.draw_visible(),
                    blend: overlay_blend,
                    z,
                }
            } else {
                let mesh = song_lua_actor_multi_vertex_mesh(
                    vertices,
                    x_scale,
                    y_scale,
                    [size_scale_x, size_scale_y],
                    effect_scale,
                    effect_rot[2],
                    [state.skew_x, state.skew_y],
                );
                Actor::Mesh {
                    vertex_color_encoding: deadlib_present::actors::VertexColorEncoding::RageMultiVertex,
                    align: [0.0, 0.0],
                    offset: [
                        effect_offset[0].mul_add(x_scale, state.x * x_scale),
                        effect_offset[1].mul_add(y_scale, state.y * y_scale),
                    ],
                    size: [SizeSpec::Px(0.0), SizeSpec::Px(0.0)],
                    tint,
                    vertices: mesh,
                    visible: state.draw_visible(),
                    blend: overlay_blend,
                    z,
                }
            };
            Some(finalize_actor(
                mesh_actor,
                glow,
                projected_mesh_scratch.as_deref_mut(),
            ))
        }
        SongLuaOverlayKind::Model { layers } => {
            let mut tint = state.diffuse;
            let mut glow = state.glow;
            let mut effect_offset = [0.0, 0.0, 0.0];
            let mut effect_scale = [1.0, 1.0, 1.0];
            let mut effect_rot = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
            song_lua_apply_overlay_effect(
                state,
                effect_time,
                effect_beat,
                z as u32,
                &mut tint,
                &mut glow,
                &mut effect_offset,
                &mut effect_scale,
                &mut effect_rot,
            );
            song_lua_clamp_float_output_colors(&mut tint, &mut glow);
            let mut out = SongLuaActorList::new();
            let passes = projected_mesh_scratch
                .as_deref()
                .and_then(|scratch| scratch.model_passes.as_deref());
            append_song_lua_model_actors(
                &mut out,
                layers,
                state,
                camera_state,
                asset_manager,
                z,
                x_scale,
                y_scale,
                [size_scale_x, size_scale_y],
                effect_scale,
                effect_rot,
                effect_offset,
                tint,
                glow,
                overlay_blend,
                total_elapsed,
                passes,
            )
            .then_some(out)
        }
        SongLuaOverlayKind::NoteskinActor {
            slots,
            texture_samples,
        } => {
            let mut tint = state.diffuse;
            let mut glow = state.glow;
            let mut effect_offset = [0.0, 0.0, 0.0];
            let mut effect_scale = [1.0, 1.0, 1.0];
            let mut effect_rot = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
            song_lua_apply_overlay_effect(
                state,
                effect_time,
                effect_beat,
                z as u32,
                &mut tint,
                &mut glow,
                &mut effect_offset,
                &mut effect_scale,
                &mut effect_rot,
            );
            song_lua_clamp_float_output_colors(&mut tint, &mut glow);
            let mut out = SongLuaActorList::new();
            append_song_lua_noteskin_actors(
                &mut out,
                slots,
                texture_samples,
                state,
                camera_state,
                asset_manager,
                z,
                x_scale,
                y_scale,
                [size_scale_x, size_scale_y],
                effect_scale,
                effect_rot,
                effect_offset,
                tint,
                glow,
                overlay_blend,
                total_elapsed,
                effect_beat,
                projected_mesh_scratch.as_deref_mut(),
            )
            .then_some(out)
        }
        SongLuaOverlayKind::SongMeterDisplay {
            stream_width,
            stream_state,
            music_length_seconds,
        } => {
            let actor = song_lua_song_meter_actor(
                state,
                *stream_state,
                *stream_width,
                *music_length_seconds,
                x_scale,
                y_scale,
                z,
                total_elapsed,
            )?;
            let glow = [
                state.glow[0] + stream_state.glow[0],
                state.glow[1] + stream_state.glow[1],
                state.glow[2] + stream_state.glow[2],
                state.glow[3].max(stream_state.glow[3]),
            ];
            Some(finalize_actor(
                actor,
                glow,
                projected_mesh_scratch.as_deref_mut(),
            ))
        }
        SongLuaOverlayKind::GraphDisplay {
            size,
            body_values,
            body_state,
            line_state,
        } => {
            let actor = song_lua_graph_display_actor(
                state,
                body_values,
                *body_state,
                **line_state,
                *size,
                x_scale,
                y_scale,
                z,
                projected_mesh_scratch.as_deref_mut(),
            )?;
            let glow = [
                state.glow[0] + body_state.glow[0].max(line_state.glow[0]),
                state.glow[1] + body_state.glow[1].max(line_state.glow[1]),
                state.glow[2] + body_state.glow[2].max(line_state.glow[2]),
                state.glow[3].max(body_state.glow[3].max(line_state.glow[3])),
            ];
            Some(finalize_actor(
                actor,
                glow,
                projected_mesh_scratch.as_deref_mut(),
            ))
        }
        SongLuaOverlayKind::Quad => {
            if let Some(view_proj) = sprite_view_proj() {
                let (flip_x, flip_y) = if state.stretch_rect.is_some() {
                    (flip_x, flip_y)
                } else {
                    (false, false)
                };
                let mut tint = state.diffuse;
                let mut glow = state.glow;
                let mut effect_offset = [0.0, 0.0, 0.0];
                let mut effect_scale = [1.0, 1.0, 1.0];
                let mut rot_deg = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
                song_lua_apply_overlay_effect(
                    state,
                    effect_time,
                    effect_beat,
                    z as u32,
                    &mut tint,
                    &mut glow,
                    &mut effect_offset,
                    &mut effect_scale,
                    &mut rot_deg,
                );
                let (model, size) = song_lua_projected_sprite_geometry(
                    state,
                    state.size.unwrap_or([1.0, 1.0]),
                    [x_scale, y_scale],
                    effect_offset,
                    rot_deg,
                    effect_scale,
                )?;
                let actor = song_lua_projected_overlay_actor(
                    white_texture_key(),
                    tint,
                    overlay_blend,
                    z,
                    model,
                    size,
                    song_lua_overlay_uvs(
                        state,
                        None,
                        &[],
                        flip_x,
                        flip_y,
                        total_elapsed,
                        total_elapsed,
                    ),
                    state,
                    flip_x,
                    flip_y,
                    view_proj,
                    projected_mesh_scratch.as_deref_mut(),
                )?;
                return Some(finalize_actor(
                    actor,
                    glow,
                    projected_mesh_scratch.as_deref_mut(),
                ));
            }
            if (state.skew_x.abs() > f32::EPSILON
                || state.skew_y.abs() > f32::EPSILON
                || state.vertex_colors.is_some()
                || state.fadeleft > 0.0
                || state.faderight > 0.0
                || state.fadetop > 0.0
                || state.fadebottom > 0.0)
                && !state.mask_source
                && !state.mask_dest
            {
                let (center, size) = song_lua_overlay_rect(
                    state,
                    state.size.unwrap_or([1.0, 1.0]),
                    x_scale,
                    y_scale,
                    size_scale_x,
                    size_scale_y,
                )?;
                let mut tint = state.diffuse;
                let mut glow = state.glow;
                let mut effect_offset = [0.0, 0.0, 0.0];
                let mut effect_scale = [1.0, 1.0, 1.0];
                let mut rot_deg = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
                song_lua_apply_overlay_effect(
                    state,
                    effect_time,
                    effect_beat,
                    z as u32,
                    &mut tint,
                    &mut glow,
                    &mut effect_offset,
                    &mut effect_scale,
                    &mut rot_deg,
                );
                let actor = song_lua_flat_skewed_overlay_actor(
                    white_texture_key(),
                    tint,
                    overlay_blend,
                    z,
                    [
                        effect_offset[0].mul_add(x_scale, center[0]),
                        effect_offset[1].mul_add(y_scale, center[1]),
                    ],
                    [size[0] * effect_scale[0], size[1] * effect_scale[1]],
                    rot_deg,
                    song_lua_overlay_uvs(
                        state,
                        None,
                        &[],
                        flip_x,
                        flip_y,
                        total_elapsed,
                        total_elapsed,
                    ),
                    state,
                    flip_x,
                    flip_y,
                    effect_offset[2],
                    projected_mesh_scratch.as_deref_mut(),
                )?;
                return Some(finalize_actor(
                    actor,
                    glow,
                    projected_mesh_scratch.as_deref_mut(),
                ));
            }
            let mut actor = if let Some([left, top, right, bottom]) = state.stretch_rect {
                deadlib_present::__act_from_builder!((
                    align(0.0, 0.0):
                    xy(left * x_scale, top * y_scale):
                    zoomto(
                        (right - left).abs() * x_scale * size_scale_x,
                        (bottom - top).abs() * y_scale * size_scale_y
                    ):
                    diffuse(state.diffuse[0], state.diffuse[1], state.diffuse[2], state.diffuse[3]):
                    z(z)
                ) deadlib_assets::SpriteBuilder::solid())
            } else {
                let size = state.size.unwrap_or([1.0, 1.0]);
                deadlib_present::__act_from_builder!((
                    align(state.halign, state.valign):
                    xy(state.x * x_scale, state.y * y_scale):
                    zoomto(
                        size[0] * x_scale * size_scale_x,
                        size[1] * y_scale * size_scale_y
                    ):
                    diffuse(state.diffuse[0], state.diffuse[1], state.diffuse[2], state.diffuse[3]):
                    z(z)
                ) deadlib_assets::SpriteBuilder::solid())
            };
            if let Actor::Sprite {
                visible,
                tint,
                glow,
                cropleft,
                cropright,
                croptop,
                cropbottom,
                fadeleft,
                faderight,
                fadetop,
                fadebottom,
                blend,
                mask_source,
                mask_dest,
                rot_x_deg,
                rot_y_deg,
                rot_z_deg,
                offset,
                world_z,
                scale,
                effect: actor_effect,
                flip_x: actor_flip_x,
                flip_y: actor_flip_y,
                ..
            } = &mut actor
            {
                let mut effect_tint = state.diffuse;
                let mut effect_glow = state.glow;
                let mut effect_offset = [0.0, 0.0, 0.0];
                let mut effect_scale = [1.0, 1.0, 1.0];
                let mut effect_rot = [state.rot_x_deg, state.rot_y_deg, state.rot_z_deg];
                song_lua_apply_overlay_effect(
                    state,
                    effect_time,
                    effect_beat,
                    z as u32,
                    &mut effect_tint,
                    &mut effect_glow,
                    &mut effect_offset,
                    &mut effect_scale,
                    &mut effect_rot,
                );
                *tint = effect_tint;
                *glow = effect_glow;
                *cropleft = state.cropleft.clamp(0.0, 1.0);
                *cropright = state.cropright.clamp(0.0, 1.0);
                *croptop = state.croptop.clamp(0.0, 1.0);
                *cropbottom = state.cropbottom.clamp(0.0, 1.0);
                *fadeleft = state.fadeleft.clamp(0.0, 1.0);
                *faderight = state.faderight.clamp(0.0, 1.0);
                *fadetop = state.fadetop.clamp(0.0, 1.0);
                *fadebottom = state.fadebottom.clamp(0.0, 1.0);
                *blend = overlay_blend;
                *mask_source = state.mask_source;
                *mask_dest = state.mask_dest;
                *rot_x_deg = effect_rot[0];
                *rot_y_deg = effect_rot[1];
                *rot_z_deg = -effect_rot[2];
                offset[0] = effect_offset[0].mul_add(x_scale, offset[0]);
                offset[1] = effect_offset[1].mul_add(y_scale, offset[1]);
                *world_z += song_lua_biased_world_z(state, effect_offset[2]);
                scale[0] *= effect_scale[0];
                scale[1] *= effect_scale[1];
                *actor_effect = deadlib_present::anim::EffectState::default();
                *actor_flip_x ^= flip_x;
                *actor_flip_y ^= flip_y;
                *visible = state.draw_visible();
            }
            let glow = if let Actor::Sprite { glow, .. } = &actor {
                *glow
            } else {
                state.glow
            };
            Some(finalize_actor(
                actor,
                glow,
                projected_mesh_scratch.as_deref_mut(),
            ))
        }
    }
}

#[cfg(any(test, feature = "test-support"))]
fn build_song_lua_overlay_actor<S: NoteskinSlot + Clone>(
    overlay: &SongLuaOverlayActor<S>,
    state: SongLuaOverlayState,
    camera_state: Option<SongLuaOverlayState>,
    asset_manager: &AssetManager,
    z: i16,
    overlay_space_width: f32,
    overlay_space_height: f32,
    effect_time: f32,
    effect_beat: f32,
    total_elapsed: f32,
) -> Option<SongLuaActorList> {
    build_song_lua_overlay_actor_with_scratch(
        overlay,
        state,
        camera_state,
        asset_manager,
        z,
        overlay_space_width,
        overlay_space_height,
        effect_time,
        effect_beat,
        total_elapsed,
        None,
        None,
    )
}

fn song_lua_has_native_sprite_colors(actor: &Actor) -> bool {
    match actor {
        Actor::Sprite {
            vertex_color_encoding,
            ..
        }
        | Actor::TexturedMesh {
            vertex_color_encoding,
            ..
        }
        | Actor::ReusableTexturedMesh {
            vertex_color_encoding,
            ..
        } => *vertex_color_encoding == deadlib_present::actors::VertexColorEncoding::RageVColor,
        Actor::Shadow { child, .. } => song_lua_has_native_sprite_colors(child),
        _ => false,
    }
}

fn song_lua_set_native_sprite_colors(actor: &mut Actor) {
    match actor {
        Actor::Sprite {
            vertex_color_encoding,
            ..
        }
        | Actor::TexturedMesh {
            vertex_color_encoding,
            ..
        }
        | Actor::ReusableTexturedMesh {
            vertex_color_encoding,
            ..
        } => *vertex_color_encoding = deadlib_present::actors::VertexColorEncoding::RageVColor,
        Actor::Shadow { child, .. } => song_lua_set_native_sprite_colors(child),
        _ => (),
    }
}

fn song_lua_wrap_overlay_shadow(
    state: SongLuaOverlayState,
    mut actor: Actor,
    x_scale: f32,
    y_scale: f32,
) -> Actor {
    if state.shadow_len[0].abs() <= f32::EPSILON && state.shadow_len[1].abs() <= f32::EPSILON {
        return actor;
    }
    let len = [state.shadow_len[0] * x_scale, state.shadow_len[1] * y_scale];
    match &mut actor {
        Actor::Sprite {
            shadow_len,
            shadow_color,
            ..
        }
        | Actor::Text {
            shadow_len,
            shadow_color,
            ..
        } if shadow_len[0].abs() <= f32::EPSILON && shadow_len[1].abs() <= f32::EPSILON => {
            *shadow_len = len;
            *shadow_color = state.shadow_color;
            actor
        }
        _ => Actor::Shadow {
            len,
            color: state.shadow_color,
            child: Box::new(actor),
        },
    }
}

fn song_lua_overlay_glow_actor(
    actor: &Actor,
    glow: [f32; 4],
    text_glow_mode: SongLuaTextGlowMode,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> Option<Actor> {
    song_lua_overlay_glow_actor_with_static_vertices(actor, glow, text_glow_mode, scratch, None)
}

fn song_lua_overlay_glow_actor_with_static_vertices(
    actor: &Actor,
    glow: [f32; 4],
    text_glow_mode: SongLuaTextGlowMode,
    mut scratch: Option<&mut SongLuaProjectedMeshScratch>,
    prewarmed_static_vertices: Option<&Arc<[TexturedMeshVertex]>>,
) -> Option<Actor> {
    match actor {
        Actor::Mesh { align, offset, size, visible, blend, z, vertex_color_encoding, .. }
        | Actor::ReusableMesh { align, offset, size, visible, blend, z, vertex_color_encoding, .. } => {
            if *vertex_color_encoding != deadlib_present::actors::VertexColorEncoding::RageMultiVertex
                || glow[3] <= 0.0
            {
                return None;
            }
            let vertices: &[MeshVertex] = match actor {
                Actor::Mesh { vertices, .. } => vertices,
                Actor::ReusableMesh { vertices, .. } => vertices,
                _ => unreachable!(),
            };
            // AMV glow replaces authored vertex bytes with the final glow
            // color. It uses FTOC directly, without byte diffuse modulation.
            Some(if let Some(scratch) = scratch {
                Actor::ReusableMesh {
                    vertex_color_encoding: deadlib_present::actors::VertexColorEncoding::RageVColor,
                    align: *align,
                    offset: *offset,
                    size: *size,
                    tint: glow,
                    vertices: scratch.update_mesh_glow(vertices),
                    visible: *visible,
                    blend: *blend,
                    z: *z,
                }
            } else {
                let vertices = vertices.iter().copied().map(|mut vertex| {
                    vertex.color = [1.0; 4];
                    vertex
                }).collect::<Vec<_>>();
                Actor::Mesh {
                    vertex_color_encoding: deadlib_present::actors::VertexColorEncoding::RageVColor,
                    align: *align,
                    offset: *offset,
                    size: *size,
                    tint: glow,
                    vertices: vertices.into(),
                    visible: *visible,
                    blend: *blend,
                    z: *z,
                }
            })
        }
        Actor::Sprite {
            align,
            vertex_color_encoding,
            offset,
            world_z,
            size,
            source,
            z,
            cell,
            grid,
            uv_rect,
            visible,
            flip_x,
            flip_y,
            cropleft,
            cropright,
            croptop,
            cropbottom,
            fadeleft,
            faderight,
            fadetop,
            fadebottom,
            mask_source,
            mask_dest,
            rot_x_deg,
            rot_y_deg,
            rot_z_deg,
            skew,
            local_offset,
            local_offset_rot_sin_cos,
            texcoordvelocity,
            animate,
            state_delay,
            scale,
            effect,
            blend,
            ..
        } => {
            if glow[3] <= f32::EPSILON {
                return None;
            }
            if *mask_source && !*mask_dest {
                return None;
            }
            Some(Actor::Sprite {
                align: *align,
                vertex_color_encoding: *vertex_color_encoding,
                offset: *offset,
                world_z: *world_z,
                size: *size,
                source: source.clone(),
                // Sprite::DrawTexture uses TextureMode_Glow with the actor's
                // blend mode: whiten through texture alpha, without adding a
                // second texture-modulated diffuse pass.
                tint: [0.0; 4],
                glow,
                z: *z,
                cell: *cell,
                grid: *grid,
                uv_rect: *uv_rect,
                visible: *visible,
                flip_x: *flip_x,
                flip_y: *flip_y,
                cropleft: *cropleft,
                cropright: *cropright,
                croptop: *croptop,
                cropbottom: *cropbottom,
                fadeleft: *fadeleft,
                faderight: *faderight,
                fadetop: *fadetop,
                fadebottom: *fadebottom,
                blend: *blend,
                mask_source: false,
                mask_dest: *mask_dest,
                rot_x_deg: *rot_x_deg,
                rot_y_deg: *rot_y_deg,
                rot_z_deg: *rot_z_deg,
                skew: *skew,
                local_offset: *local_offset,
                local_offset_rot_sin_cos: *local_offset_rot_sin_cos,
                texcoordvelocity: *texcoordvelocity,
                animate: *animate,
                state_delay: *state_delay,
                scale: *scale,
                shadow_len: [0.0, 0.0],
                shadow_color: [0.0, 0.0, 0.0, 0.5],
                effect: *effect,
            })
        }
        Actor::Text {
            align,
            offset,
            local_transform,
            font,
            content,
            attributes: base_attributes,
            align_text,
            z,
            scale,
            fit_width,
            fit_height,
            line_spacing,
            wrap_width_pixels,
            max_width,
            max_height,
            max_w_pre_zoom,
            max_h_pre_zoom,
            jitter: _,
            distortion,
            clip,
            mask_dest,
            effect,
            ..
        } => {
            let has_attr_glow = song_lua_text_attributes_have_glow(base_attributes.as_slice());
            if glow[3] <= f32::EPSILON && !has_attr_glow {
                return None;
            }
            let (attributes, color, stroke_color) = if has_attr_glow {
                let attributes = song_lua_text_glow_attributes(
                    content.as_str(),
                    base_attributes.as_slice(),
                    glow,
                    scratch.as_deref_mut(),
                );
                let stroke_color = (glow[3] > f32::EPSILON
                    && matches!(
                        text_glow_mode,
                        SongLuaTextGlowMode::Stroke | SongLuaTextGlowMode::Both
                    ))
                .then_some(glow);
                (attributes, [1.0, 1.0, 1.0, 1.0], stroke_color)
            } else {
                let mut attributes = base_attributes.clone();
                let (color, stroke_color) = match text_glow_mode {
                    SongLuaTextGlowMode::Inner => (glow, None),
                    SongLuaTextGlowMode::Both => (glow, Some(glow)),
                    SongLuaTextGlowMode::Stroke => {
                        attributes = song_lua_transparent_text_attributes(
                            content.as_str(),
                            scratch.as_deref_mut(),
                        );
                        ([1.0, 1.0, 1.0, 1.0], Some(glow))
                    }
                };
                (attributes, color, stroke_color)
            };
            Some(Actor::Text {
                align: *align,
                offset: *offset,
                local_transform: *local_transform,
                color,
                stroke_color,
                glow: [0.0, 0.0, 0.0, 0.0],
                font,
                content: content.clone(),
                attributes,
                align_text: *align_text,
                z: *z,
                scale: *scale,
                fit_width: *fit_width,
                fit_height: *fit_height,
                line_spacing: *line_spacing,
                wrap_width_pixels: *wrap_width_pixels,
                max_width: *max_width,
                max_height: *max_height,
                max_w_pre_zoom: *max_w_pre_zoom,
                max_h_pre_zoom: *max_h_pre_zoom,
                jitter: false,
                distortion: *distortion,
                clip: *clip,
                mask_dest: *mask_dest,
                blend: BlendMode::Add,
                shadow_len: [0.0, 0.0],
                shadow_color: [0.0, 0.0, 0.0, 0.5],
                effect: *effect,
            })
        }
        Actor::TexturedMesh {
            environment,
            vertex_color_encoding,
            align,
            offset,
            world_z,
            size,
            local_transform,
            texture,
            vertices,
            geom_cache_key,
            uv_scale,
            uv_offset,
            uv_tex_shift,
            depth_test,
            depth_write,
            depth_test_on_fail,
            visible,
            blend,
            z,
            ..
        } => {
            if glow[3] <= f32::EPSILON {
                return None;
            }
            let glow_vertices = scratch
                .as_deref_mut()
                .map(|scratch| scratch.update_textured_glow(vertices.as_ref()));
            let actor = if let Some(vertices) = prewarmed_static_vertices {
                Actor::TexturedMesh {
                    vertex_color_encoding: *vertex_color_encoding,
                    environment: environment
                        .as_ref()
                        .and_then(|environment| environment.sampler)
                        .map(|sampler| deadlib_present::actors::MeshEnvironment {
                            sampler: Some(sampler),
                            camera: None,
                            transform: *local_transform,
                            additive_texture: None,
                            additive_uv: [0.0, 0.0, 1.0, 1.0],
                        }),
                    align: *align,
                    offset: *offset,
                    world_z: *world_z,
                    size: *size,
                    local_transform: *local_transform,
                    texture: texture.clone(),
                    tint: [1.0, 1.0, 1.0, 0.0],
                    glow,
                    vertices: Arc::clone(vertices),
                    geom_cache_key: song_lua_glow_geometry_key(*geom_cache_key),
                    uv_scale: *uv_scale,
                    uv_offset: *uv_offset,
                    uv_tex_shift: *uv_tex_shift,
                    depth_test: *depth_test,
                    depth_write: *depth_write,
                    depth_test_on_fail: *depth_test_on_fail,
                    clear_depth: false,
                    clear_depth_after: false,
                    cull_mode: deadlib_render_core::CullMode::None,
                    visible: *visible,
                    blend: *blend,
                    z: *z,
                }
            } else if let Some(vertices) = glow_vertices {
                Actor::ReusableTexturedMesh {
                    vertex_color_encoding: *vertex_color_encoding,
                    environment: environment
                        .as_ref()
                        .and_then(|environment| environment.sampler)
                        .map(|sampler| deadlib_present::actors::MeshEnvironment {
                            sampler: Some(sampler),
                            camera: None,
                            transform: *local_transform,
                            additive_texture: None,
                            additive_uv: [0.0, 0.0, 1.0, 1.0],
                        }),
                    align: *align,
                    offset: *offset,
                    world_z: *world_z,
                    size: *size,
                    local_transform: *local_transform,
                    texture: texture.clone(),
                    tint: [1.0, 1.0, 1.0, 0.0],
                    glow,
                    vertices,
                    geom_cache_key: INVALID_TMESH_CACHE_KEY,
                    uv_scale: *uv_scale,
                    uv_offset: *uv_offset,
                    uv_tex_shift: *uv_tex_shift,
                    depth_test: *depth_test,
                    depth_write: *depth_write,
                    depth_test_on_fail: *depth_test_on_fail,
                    clear_depth: false,
                    clear_depth_after: false,
                    cull_mode: deadlib_render_core::CullMode::None,
                    visible: *visible,
                    blend: *blend,
                    z: *z,
                }
            } else {
                let mut glow_vertices = vertices.as_ref().to_vec();
                for vertex in &mut glow_vertices {
                    // Native Sprite/ActorMultiVertex glow replaces diffuse RGBA.
                    vertex.color = [1.0; 4];
                }
                Actor::TexturedMesh {
                    vertex_color_encoding: *vertex_color_encoding,
                    environment: environment
                        .as_ref()
                        .and_then(|environment| environment.sampler)
                        .map(|sampler| deadlib_present::actors::MeshEnvironment {
                            sampler: Some(sampler),
                            camera: None,
                            transform: *local_transform,
                            additive_texture: None,
                            additive_uv: [0.0, 0.0, 1.0, 1.0],
                        }),
                    align: *align,
                    offset: *offset,
                    world_z: *world_z,
                    size: *size,
                    local_transform: *local_transform,
                    texture: texture.clone(),
                    tint: [1.0, 1.0, 1.0, 0.0],
                    glow,
                    vertices: Arc::from(glow_vertices.into_boxed_slice()),
                    geom_cache_key: INVALID_TMESH_CACHE_KEY,
                    uv_scale: *uv_scale,
                    uv_offset: *uv_offset,
                    uv_tex_shift: *uv_tex_shift,
                    depth_test: *depth_test,
                    depth_write: *depth_write,
                    depth_test_on_fail: *depth_test_on_fail,
                    clear_depth: false,
                    clear_depth_after: false,
                    cull_mode: deadlib_render_core::CullMode::None,
                    visible: *visible,
                    blend: *blend,
                    z: *z,
                }
            };
            Some(actor)
        }
        Actor::ReusableTexturedMesh {
            align,
            environment,
            vertex_color_encoding,
            offset,
            world_z,
            size,
            local_transform,
            texture,
            vertices,
            uv_scale,
            uv_offset,
            uv_tex_shift,
            depth_test,
            depth_write,
            depth_test_on_fail,
            visible,
            blend,
            z,
            ..
        } => {
            if glow[3] <= f32::EPSILON {
                return None;
            }
            let glow_vertices = scratch.as_deref_mut().map_or_else(
                || {
                    let mut out = Vec::with_capacity(vertices.len());
                    out.extend(vertices.iter().copied().map(|mut vertex| {
                        // Native Sprite/ActorMultiVertex glow replaces diffuse RGBA.
                        vertex.color = [1.0; 4];
                        vertex
                    }));
                    Arc::new(out)
                },
                |scratch| scratch.update_textured_glow(vertices),
            );
            Some(Actor::ReusableTexturedMesh {
                environment: environment
                    .as_ref()
                    .and_then(|environment| environment.sampler)
                    .map(|sampler| deadlib_present::actors::MeshEnvironment {
                        sampler: Some(sampler),
                        camera: None,
                        transform: *local_transform,
                        additive_texture: None,
                        additive_uv: [0.0, 0.0, 1.0, 1.0],
                    }),
                vertex_color_encoding: *vertex_color_encoding,
                align: *align,
                offset: *offset,
                world_z: *world_z,
                size: *size,
                local_transform: *local_transform,
                texture: texture.clone(),
                tint: [1.0, 1.0, 1.0, 0.0],
                glow,
                vertices: glow_vertices,
                geom_cache_key: INVALID_TMESH_CACHE_KEY,
                uv_scale: *uv_scale,
                uv_offset: *uv_offset,
                uv_tex_shift: *uv_tex_shift,
                depth_test: *depth_test,
                depth_write: *depth_write,
                depth_test_on_fail: *depth_test_on_fail,
                clear_depth: false,
                clear_depth_after: false,
                cull_mode: deadlib_render_core::CullMode::None,
                visible: *visible,
                blend: *blend,
                z: *z,
            })
        }
        _ => None,
    }
}

fn song_lua_finalize_overlay_actor(
    state: SongLuaOverlayState,
    mut actor: Actor,
    glow: [f32; 4],
    x_scale: f32,
    y_scale: f32,
    scratch: Option<&mut SongLuaProjectedMeshScratch>,
) -> SongLuaActorList {
    let glow_actor = if let Actor::Sprite {
        glow: actor_glow, ..
    } = &mut actor
    {
        // Sprite composition already emits TextureMode_Glow after diffuse.
        // A separate glow actor would draw that pass a second time.
        *actor_glow = glow;
        None
    } else {
        song_lua_overlay_glow_actor(&actor, glow, state.text_glow_mode, scratch)
    };
    let actor = song_lua_wrap_overlay_shadow(state, actor, x_scale, y_scale);
    let mut out = SmallVec::new();
    out.push(actor);
    if let Some(glow_actor) = glow_actor {
        out.push(glow_actor);
    }
    out
}

#[inline(always)]
fn push_song_lua_capture_actor(
    out: &mut Vec<Actor>,
    actor: Actor,
    tint: [f32; 4],
    blend: Option<BlendMode>,
    z_shift: i16,
) {
    if z_shift == 0 && tint == [1.0; 4] && blend.is_none() {
        out.push(actor);
    } else {
        out.push(song_lua_style_capture_actor(actor, tint, blend, z_shift));
    }
}

#[derive(Clone, Copy, Debug)]
struct PlayerTransformMetrics {
    screen_width: f32,
    screen_height: f32,
    screen_center_y: f32,
}

impl PlayerTransformMetrics {
    #[inline(always)]
    fn current() -> Self {
        Self {
            screen_width: screen_width(),
            screen_height: screen_height(),
            screen_center_y: screen_center_y(),
        }
    }
}

#[inline(always)]
fn song_lua_player_root_camera_with_metrics(
    player_transform: Matrix4,
    metrics: PlayerTransformMetrics,
) -> Matrix4 {
    glam::camera::rh::proj::opengl::orthographic(
        -0.5 * metrics.screen_width,
        0.5 * metrics.screen_width,
        -0.5 * metrics.screen_height,
        0.5 * metrics.screen_height,
        -4096.0,
        4096.0,
    ) * player_transform
}

#[inline(always)]
fn song_lua_player_root_camera(player_transform: Matrix4) -> Matrix4 {
    song_lua_player_root_camera_with_metrics(player_transform, PlayerTransformMetrics::current())
}

#[allow(clippy::too_many_arguments)]
fn append_song_lua_player_transform<F, H>(
    field_actors: F,
    hud_actors: H,
    field_len: usize,
    hud_len: usize,
    field_has_camera: bool,
    out: &mut Vec<Actor>,
    z_shift: i16,
    tint: [f32; 4],
    blend: Option<BlendMode>,
    playfield_center_x: f32,
    target_x: f32,
    target_y: f32,
    rotation_x_deg: f32,
    rotation_z_deg: f32,
    rotation_y_deg: f32,
    skew_x: f32,
    skew_y: f32,
    zoom_x: f32,
    zoom_y: f32,
    zoom_z: f32,
    target_z: f32,
    wrappers: Matrix4,
    field_camera_parts: Option<(Matrix4, Matrix4)>,
) where
    F: IntoIterator<Item = Actor>,
    H: IntoIterator<Item = Actor>,
{
    let Some(player_transform) = song_lua_player_transform_matrix(SongLuaPlayerTransformRequest {
        screen_width: screen_width(),
        screen_height: screen_height(),
        screen_center_y: screen_center_y(),
        playfield_center_x,
        target_x,
        target_y,
        rotation_x_deg,
        rotation_y_deg,
        rotation_z_deg,
        skew_x,
        skew_y,
        zoom_x,
        zoom_y,
        zoom_z,
        target_z,
        wrappers,
    }) else {
        out.reserve(field_len.saturating_add(hud_len));
        for actor in hud_actors {
            push_song_lua_capture_actor(out, actor, [1.0; 4], None, z_shift);
        }
        for actor in field_actors {
            push_song_lua_capture_actor(out, actor, [1.0; 4], None, z_shift);
        }
        return;
    };

    let root_camera = song_lua_player_root_camera(player_transform);
    out.reserve(field_len.saturating_add(hud_len).saturating_add(4));
    if !field_has_camera {
        if field_len + hud_len == 0 {
            return;
        }
        push_song_lua_capture_actor(
            out,
            Actor::CameraPush {
                view_proj: root_camera,
            },
            tint,
            blend,
            z_shift,
        );
        for actor in hud_actors {
            push_song_lua_capture_actor(out, actor, tint, blend, z_shift);
        }
        for actor in field_actors {
            push_song_lua_capture_actor(out, actor, tint, blend, z_shift);
        }
        push_song_lua_capture_actor(out, Actor::CameraPop, tint, blend, z_shift);
        return;
    }

    let mut root_open = hud_len > 0;
    if root_open {
        push_song_lua_capture_actor(
            out,
            Actor::CameraPush {
                view_proj: root_camera,
            },
            tint,
            blend,
            z_shift,
        );
        for actor in hud_actors {
            push_song_lua_capture_actor(out, actor, tint, blend, z_shift);
        }
    }
    let mut field_camera_depth = 0usize;
    for actor in field_actors {
        match actor {
            Actor::Camera {
                view_proj,
                children,
            } => {
                if field_camera_depth == 0 && root_open {
                    push_song_lua_capture_actor(out, Actor::CameraPop, tint, blend, z_shift);
                    root_open = false;
                }
                push_song_lua_capture_actor(
                    out,
                    Actor::CameraPush {
                        view_proj: field_camera_parts.map_or_else(
                            || view_proj * player_transform,
                            |(camera, model)| camera * (player_transform * model),
                        ),
                    },
                    tint,
                    blend,
                    z_shift,
                );
                for child in children {
                    push_song_lua_capture_actor(out, child, tint, blend, z_shift);
                }
                push_song_lua_capture_actor(out, Actor::CameraPop, tint, blend, z_shift);
            }
            Actor::CameraPush { view_proj } => {
                if field_camera_depth == 0 && root_open {
                    push_song_lua_capture_actor(out, Actor::CameraPop, tint, blend, z_shift);
                    root_open = false;
                }
                push_song_lua_capture_actor(
                    out,
                    Actor::CameraPush {
                        view_proj: field_camera_parts.map_or_else(
                            || view_proj * player_transform,
                            |(camera, model)| camera * (player_transform * model),
                        ),
                    },
                    tint,
                    blend,
                    z_shift,
                );
                field_camera_depth = field_camera_depth.saturating_add(1);
            }
            Actor::CameraPop => {
                push_song_lua_capture_actor(out, Actor::CameraPop, tint, blend, z_shift);
                field_camera_depth = field_camera_depth.saturating_sub(1);
            }
            other if field_camera_depth > 0 => {
                push_song_lua_capture_actor(out, other, tint, blend, z_shift);
            }
            other => {
                if !root_open {
                    push_song_lua_capture_actor(
                        out,
                        Actor::CameraPush {
                            view_proj: root_camera,
                        },
                        tint,
                        blend,
                        z_shift,
                    );
                    root_open = true;
                }
                push_song_lua_capture_actor(out, other, tint, blend, z_shift);
            }
        }
    }
    if root_open {
        push_song_lua_capture_actor(out, Actor::CameraPop, tint, blend, z_shift);
    }
}

#[inline(always)]
fn song_lua_player_transform_has_identity_geometry_with_metrics(
    transform: SongLuaCaptureTransform,
    metrics: PlayerTransformMetrics,
) -> bool {
    metrics.screen_width.is_finite()
        && metrics.screen_height.is_finite()
        && metrics.screen_center_y.is_finite()
        && transform.playfield_center_x.is_finite()
        && transform.target_x.is_finite()
        && transform.target_y.is_finite()
        && transform.rotation_x.is_finite()
        && transform.rotation_x.abs() <= f32::EPSILON
        && transform.rotation_z.is_finite()
        && transform.rotation_z.abs() <= f32::EPSILON
        && transform.rotation_y.is_finite()
        && transform.rotation_y.abs() <= f32::EPSILON
        && transform.skew_x.is_finite()
        && transform.skew_x.abs() <= f32::EPSILON
        && transform.skew_y.is_finite()
        && transform.skew_y.abs() <= f32::EPSILON
        && transform.zoom_x.is_finite()
        && (transform.zoom_x - 1.0).abs() <= f32::EPSILON
        && transform.zoom_y.is_finite()
        && (transform.zoom_y - 1.0).abs() <= f32::EPSILON
        && transform.zoom_z.is_finite()
        && (transform.zoom_z - 1.0).abs() <= f32::EPSILON
        && (transform.target_x - transform.playfield_center_x).abs() <= f32::EPSILON
        && (metrics.screen_center_y - transform.target_y).abs() <= f32::EPSILON
        && transform.target_z.abs() <= f32::EPSILON
        && transform.wrappers == Matrix4::IDENTITY
}

#[inline(always)]
fn song_lua_player_transform_has_identity_geometry(transform: SongLuaCaptureTransform) -> bool {
    song_lua_player_transform_has_identity_geometry_with_metrics(
        transform,
        PlayerTransformMetrics::current(),
    )
}

#[inline(always)]
fn song_lua_player_transform_is_direct_identity(transform: SongLuaCaptureTransform) -> bool {
    transform.z_shift == 0
        && transform.tint == [1.0; 4]
        && transform.blend.is_none()
        && song_lua_player_transform_has_identity_geometry(transform)
}

#[inline(always)]
fn song_lua_player_transform_is_direct_proxy(transform: SongLuaCaptureTransform) -> bool {
    transform.tint.into_iter().all(f32::is_finite)
        && transform.playfield_center_x.is_finite()
        && transform.target_x.is_finite()
        && transform.target_y.is_finite()
        && transform.rotation_x.is_finite()
        && transform.rotation_z.is_finite()
        && transform.rotation_y.is_finite()
        && transform.skew_x.is_finite()
        && transform.skew_y.is_finite()
        && transform.zoom_x.is_finite()
        && transform.zoom_y.is_finite()
        && transform.zoom_z.is_finite()
        && transform.target_z.is_finite()
        && transform.wrappers.is_finite()
}

#[inline(always)]
fn song_lua_player_transform_is_direct_hud_proxy(transform: SongLuaCaptureTransform) -> bool {
    song_lua_player_transform_is_direct_proxy(transform)
}

#[cfg(test)]
fn song_lua_direct_field_camera(
    field_camera: Option<Matrix4>,
    transform: SongLuaCaptureTransform,
) -> Option<Matrix4> {
    let player_transform = song_lua_player_camera_suffix(transform);
    song_lua_field_camera_with_player(field_camera, transform.field_camera_parts, player_transform)
}

fn song_lua_field_camera_with_player(
    field_camera: Option<Matrix4>,
    field_camera_parts: Option<(Matrix4, Matrix4)>,
    player_transform: Option<Matrix4>,
) -> Option<Matrix4> {
    match (field_camera, player_transform) {
        (Some(camera), Some(player_transform)) => Some(field_camera_parts.map_or_else(
            || camera * player_transform,
            |(camera, model)| camera * (player_transform * model),
        )),
        (None, Some(player_transform)) => Some(song_lua_player_root_camera(player_transform)),
        (camera, None) => camera,
    }
}

fn song_lua_player_camera_suffix(transform: SongLuaCaptureTransform) -> Option<Matrix4> {
    song_lua_player_transform_matrix(SongLuaPlayerTransformRequest {
        screen_width: screen_width(),
        screen_height: screen_height(),
        screen_center_y: screen_center_y(),
        playfield_center_x: transform.playfield_center_x,
        target_x: transform.target_x,
        target_y: transform.target_y,
        rotation_x_deg: transform.rotation_x,
        rotation_y_deg: transform.rotation_y,
        rotation_z_deg: transform.rotation_z,
        skew_x: transform.skew_x,
        skew_y: transform.skew_y,
        zoom_x: transform.zoom_x,
        zoom_y: transform.zoom_y,
        zoom_z: transform.zoom_z,
        target_z: transform.target_z,
        wrappers: transform.wrappers,
    })
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum PlayerActorAssembly {
    Captured,
    Hidden,
    DirectZ {
        z_shift: i16,
    },
    DirectTransform {
        z_shift: i16,
        tint: [f32; 4],
        blend: Option<BlendMode>,
        root_camera: Matrix4,
        field_camera_suffix: Matrix4,
    },
}

/// Retain the camera/Player/NoteField boundary for both actor and flat draws.
/// Native Actor::Draw enters Player before the child's wrapper states. Keeping
/// the child model on the suffix also supports singular authored field zooms.
fn prepare_player_field_camera(
    assembly: &mut PlayerActorAssembly,
    field_camera: Option<Matrix4>,
    field_camera_parts: Option<(Matrix4, Matrix4)>,
    field_actors: &mut [Actor],
) -> Option<Matrix4> {
    let PlayerActorAssembly::DirectTransform { field_camera_suffix, .. } = assembly else {
        return field_camera;
    };
    let (Some(original), Some((camera, model))) = (field_camera, field_camera_parts) else {
        return field_camera;
    };
    for actor in field_actors {
        if let Actor::Camera { view_proj, .. } | Actor::CameraPush { view_proj } = actor
            && *view_proj == original
        {
            *view_proj = camera;
        }
    }
    *field_camera_suffix *= model;
    Some(camera)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct PlayerActorAssemblyKey {
    requests_player_proxy: bool,
    visible: bool,
    z_shift: i16,
    blend: Option<BlendMode>,
    metrics: [u32; 3],
    tint: [u32; 4],
    geometry: [u32; 12],
    wrappers: [u32; 16],
}

impl PlayerActorAssemblyKey {
    fn new(
        requests_player_proxy: bool,
        visible: bool,
        transform: SongLuaCaptureTransform,
        metrics: PlayerTransformMetrics,
    ) -> Self {
        Self {
            requests_player_proxy,
            visible,
            z_shift: transform.z_shift,
            blend: transform.blend,
            metrics: [
                metrics.screen_width.to_bits(),
                metrics.screen_height.to_bits(),
                metrics.screen_center_y.to_bits(),
            ],
            tint: transform.tint.map(f32::to_bits),
            geometry: [
                transform.playfield_center_x.to_bits(),
                transform.target_x.to_bits(),
                transform.target_y.to_bits(),
                transform.rotation_x.to_bits(),
                transform.rotation_z.to_bits(),
                transform.rotation_y.to_bits(),
                transform.skew_x.to_bits(),
                transform.skew_y.to_bits(),
                transform.zoom_x.to_bits(),
                transform.zoom_y.to_bits(),
                transform.zoom_z.to_bits(),
                transform.target_z.to_bits(),
            ],
            wrappers: transform.wrappers.to_cols_array().map(f32::to_bits),
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
struct PlayerActorAssemblyCacheStats {
    hits: u64,
    rebuilds: u64,
}

/// Per-player transform plan retained by one gameplay screen.
///
/// The gameplay/presentation thread owns the fixed two-entry screen-lifetime
/// storage for non-identity transforms. Exact source-bit or viewport changes
/// rebuild one bounded plan synchronously through the canonical resolver;
/// stable transformed frames copy it. Identity, hidden, and captured players
/// retain their cheaper direct decisions without constructing a key. There is
/// no allocation, synchronization, overflow, pruning, or eviction scan. Screen
/// teardown drops both inline entries, counters expose hit/rebuild behavior,
/// and worst-case frame work is one plan rebuild per active player.
#[derive(Clone, Copy, Debug, Default)]
struct PlayerActorAssemblyCache {
    key: Option<PlayerActorAssemblyKey>,
    assembly: Option<PlayerActorAssembly>,
    stats: PlayerActorAssemblyCacheStats,
}

impl PlayerActorAssemblyCache {
    #[inline(always)]
    fn resolve(
        &mut self,
        requests_player_proxy: bool,
        visible: bool,
        transform: SongLuaCaptureTransform,
    ) -> PlayerActorAssembly {
        let metrics = PlayerTransformMetrics::current();
        if let Some(assembly) =
            direct_player_actor_assembly(requests_player_proxy, visible, transform, metrics)
        {
            return assembly;
        }
        self.resolve_nonidentity(requests_player_proxy, visible, transform, metrics)
    }

    #[cfg(test)]
    fn resolve_with_metrics(
        &mut self,
        requests_player_proxy: bool,
        visible: bool,
        transform: SongLuaCaptureTransform,
        metrics: PlayerTransformMetrics,
    ) -> PlayerActorAssembly {
        if let Some(assembly) =
            direct_player_actor_assembly(requests_player_proxy, visible, transform, metrics)
        {
            return assembly;
        }
        self.resolve_nonidentity(requests_player_proxy, visible, transform, metrics)
    }

    fn resolve_nonidentity(
        &mut self,
        requests_player_proxy: bool,
        visible: bool,
        transform: SongLuaCaptureTransform,
        metrics: PlayerTransformMetrics,
    ) -> PlayerActorAssembly {
        debug_assert!(
            visible
                && !requests_player_proxy
                && !song_lua_player_transform_has_identity_geometry_with_metrics(
                    transform, metrics
                ),
            "only non-identity visible player plans enter retained storage"
        );
        let key = PlayerActorAssemblyKey::new(requests_player_proxy, visible, transform, metrics);
        if self.key == Some(key) {
            self.stats.hits = self.stats.hits.saturating_add(1);
            return self
                .assembly
                .expect("a retained player transform key has an assembly");
        }
        let assembly = player_actor_assembly_for_transform_with_metrics(
            requests_player_proxy,
            visible,
            transform,
            metrics,
        );
        self.key = Some(key);
        self.assembly = Some(assembly);
        self.stats.rebuilds = self.stats.rebuilds.saturating_add(1);
        assembly
    }

    #[cfg(test)]
    const fn stats(&self) -> PlayerActorAssemblyCacheStats {
        self.stats
    }

    const fn generation(&self) -> u64 {
        self.stats.rebuilds
    }
}

#[inline(always)]
fn direct_player_actor_assembly(
    requests_player_proxy: bool,
    visible: bool,
    transform: SongLuaCaptureTransform,
    metrics: PlayerTransformMetrics,
) -> Option<PlayerActorAssembly> {
    if !visible {
        Some(PlayerActorAssembly::Hidden)
    } else if requests_player_proxy {
        Some(PlayerActorAssembly::Captured)
    } else if song_lua_player_transform_has_identity_geometry_with_metrics(transform, metrics) {
        Some(PlayerActorAssembly::DirectZ {
            z_shift: transform.z_shift,
        })
    } else {
        None
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
struct PlayerFieldCameraCacheStats {
    hits: u64,
    rebuilds: u64,
}

/// Final flat-field camera retained from two upstream source generations.
///
/// The gameplay/presentation thread owns exactly one screen-lifetime entry per
/// player. Only non-identity direct transforms enter it. Stable frames compare
/// two `u64` tokens and copy one inline matrix; either upstream rebuild performs
/// one bounded matrix product. There is no allocation, synchronization,
/// overflow, pruning, or eviction scan. Screen teardown drops both entries,
/// counters expose hit/rebuild behavior, and worst-case frame work is one
/// matrix product per active transformed player.
#[derive(Clone, Copy, Debug, Default)]
struct PlayerFieldCameraCache {
    key: Option<(u64, u64)>,
    camera: Option<Matrix4>,
    stats: PlayerFieldCameraCacheStats,
}

impl PlayerFieldCameraCache {
    fn resolve(
        &mut self,
        field_generation: u64,
        transform_generation: u64,
        field_camera: Option<Matrix4>,
        root_camera: Matrix4,
        field_camera_suffix: Matrix4,
    ) -> Matrix4 {
        let key = (field_generation, transform_generation);
        if self.key == Some(key) {
            self.stats.hits = self.stats.hits.saturating_add(1);
            return self
                .camera
                .expect("a retained transformed field-camera key has a matrix");
        }
        let camera = field_camera.map_or(root_camera, |camera| camera * field_camera_suffix);
        self.key = Some(key);
        self.camera = Some(camera);
        self.stats.rebuilds = self.stats.rebuilds.saturating_add(1);
        camera
    }

    #[cfg(test)]
    const fn stats(&self) -> PlayerFieldCameraCacheStats {
        self.stats
    }
}

#[derive(Clone, Copy, Debug)]
struct PlayerActorSegment {
    player: usize,
    assembly: PlayerActorAssembly,
    field_camera: Option<Matrix4>,
    field_screen_projection: Matrix4,
    captured_field_range: Option<[usize; 2]>,
    manual_hud_draw: bool,
    hud_parts: deadsync_notefield::NotefieldHudParts,
}

#[derive(Clone, Copy, Debug)]
struct SongLuaScreenProjectionRange {
    start: usize,
    end: usize,
}

#[derive(Clone, Copy, Debug)]
struct SongLuaScreenCaptureRange {
    start: usize,
    end: usize,
    original_start: usize,
    original_end: usize,
}

#[derive(Default)]
struct SongLuaScreenCaptureOriginals {
    actors: Vec<Actor>,
    ranges: Vec<SongLuaScreenCaptureRange>,
}

#[derive(Clone, Copy, Debug)]
pub struct GameplayActorSegments {
    insert: usize,
    /// End of ScreenGameplay-owned actors. System actors and later application
    /// overlays use the ordinary screen camera instead of chart transforms.
    screen_actor_end: usize,
    players: [Option<PlayerActorSegment>; 2],
    direct_proxy_len: usize,
    underlay_visible: bool,
    screen_projection: Matrix4,
}

impl GameplayActorSegments {
    #[cfg(any(test, feature = "test-support"))]
    pub const fn direct_proxy_count(&self) -> usize {
        self.direct_proxy_len
    }

    #[cfg(any(test, feature = "test-support"))]
    pub fn has_direct_field_proxy(&self, state: &FrameScratch) -> bool {
        self.direct_field_proxy_count(state) != 0
    }

    #[cfg(any(test, feature = "test-support"))]
    pub fn direct_field_proxy_count(&self, state: &FrameScratch) -> usize {
        state
            .song_lua_direct_proxies
            .entries
            .iter()
            .take(self.direct_proxy_len)
            .map(|proxy| {
                usize::from(
                    proxy.draws == SongLuaDirectDraws::Field && proxy.draw_start < proxy.draw_end,
                )
            })
            .sum()
    }

    #[cfg(any(test, feature = "test-support"))]
    pub fn direct_combo_proxy_count(&self, state: &FrameScratch) -> usize {
        state
            .song_lua_direct_proxies
            .entries
            .iter()
            .take(self.direct_proxy_len)
            .filter(|proxy| {
                proxy.draws == SongLuaDirectDraws::Combo && proxy.draw_start < proxy.draw_end
            })
            .count()
    }

    /// # Panics
    ///
    /// Panics if an internal state invariant is violated.
    pub fn segments<'a>(
        &'a self,
        state: &'a FrameScratch,
        actors: &'a [Actor],
    ) -> impl Clone + Iterator<Item = ActorSegment<'a>> + 'a {
        let scratch = state;
        let (actors, system_actors) = actors.split_at(self.screen_actor_end.min(actors.len()));
        GameplayActorSegmentIter {
            owner: self,
            scratch,
            actors,
            phase: 0,
            player: 0,
            underlay_player: 0,
            player_part: 0,
            proxy: 0,
            proxy_draw: false,
            actor_start: self.insert.min(actors.len()),
            pending_actor_start: 0,
            pending_actor_end: 0,
            projection_index: 0,
        }
        .chain((!system_actors.is_empty()).then(|| ActorSegment::new(system_actors)))
    }
}

#[derive(Clone)]
struct GameplayActorSegmentIter<'a> {
    owner: &'a GameplayActorSegments,
    scratch: &'a FrameScratch,
    actors: &'a [Actor],
    phase: u8,
    player: usize,
    underlay_player: usize,
    player_part: u8,
    proxy: usize,
    proxy_draw: bool,
    actor_start: usize,
    pending_actor_start: usize,
    pending_actor_end: usize,
    projection_index: usize,
}

impl<'a> GameplayActorSegmentIter<'a> {
    fn pending_actor_segment(&mut self) -> Option<ActorSegment<'a>> {
        let start = self.pending_actor_start;
        if start >= self.pending_actor_end {
            return None;
        }
        let ranges = &self.scratch.song_lua_screen_projection_ranges;
        while ranges
            .get(self.projection_index)
            .is_some_and(|range| range.end <= start)
        {
            self.projection_index += 1;
        }
        let (end, projection) = match ranges.get(self.projection_index) {
            Some(range) if range.start <= start => {
                (self.pending_actor_end.min(range.end), &Matrix4::IDENTITY)
            }
            Some(range) => (
                self.pending_actor_end.min(range.start),
                &self.owner.screen_projection,
            ),
            None => (self.pending_actor_end, &self.owner.screen_projection),
        };
        self.pending_actor_start = end;
        Some(ActorSegment::new(&self.actors[start..end]).with_projection(projection))
    }

    fn direct_draws(
        &self,
        player: usize,
        draws: SongLuaDirectDraws,
        start: usize,
        end: usize,
    ) -> &'a [FlatDraw] {
        let source = match draws {
            SongLuaDirectDraws::Field => &self.scratch.notefield_flat_draw_scratch[player],
            SongLuaDirectDraws::Judgment | SongLuaDirectDraws::Combo => {
                &self.scratch.notefield_hud_flat_draw_scratch[player]
            }
        };
        source.get(start..end).unwrap_or(&[])
    }

    fn player_segment(
        &self,
        segment: &'a PlayerActorSegment,
        part: u8,
    ) -> Option<ActorSegment<'a>> {
        let player = segment.player;
        if matches!(segment.assembly, PlayerActorAssembly::Hidden) {
            return None;
        }
        if matches!(segment.assembly, PlayerActorAssembly::Captured) {
            debug_assert!(self.scratch.notefield_flat_draw_scratch[player].is_empty());
            debug_assert!(self.scratch.notefield_hud_flat_draw_scratch[player].is_empty());
            let source = self
                .scratch
                .song_lua_proxy_actor_scratch
                .as_ref()
                .and_then(|scratch| scratch.player_source(player, SONG_LUA_PLAYER_PROXY_SOURCE))
                .expect("player proxy capture has song-lifetime backing");
            let source = if let Some([start, end]) = segment.captured_field_range {
                let actors = song_lua_captured_segment_actors(source);
                match part {
                    0 => &actors[..start],
                    1 => &actors[start..end],
                    2 => &actors[end..],
                    _ => return None,
                }
            } else if part == 0 {
                source
            } else {
                return None;
            };
            return Some(ActorSegment::new(source));
        }
        let hud = &self.scratch.notefield_hud_actor_scratch[player];
        let hud_draws = &self.scratch.notefield_hud_flat_draw_scratch[player];
        let (hud, hud_draws) = if part == 0 {
            (
                &hud[..segment.hud_parts.combo_actors],
                &hud_draws[..segment.hud_parts.combo_draws],
            )
        } else {
            (
                &hud[segment.hud_parts.combo_actors..],
                &hud_draws[segment.hud_parts.combo_draws..],
            )
        };
        let assembly_part = if part == 2 { 0 } else { part };
        match (&segment.assembly, assembly_part) {
            (PlayerActorAssembly::DirectZ { z_shift }, 0) => {
                Some(ActorSegment::shifted(hud, *z_shift).with_flat_draws(hud_draws, None))
            }
            (PlayerActorAssembly::DirectZ { z_shift }, 1) => Some(
                ActorSegment::shifted(&self.scratch.notefield_actor_scratch[player], *z_shift)
                    .with_flat_draws(
                        &self.scratch.notefield_flat_draw_scratch[player],
                        segment.field_camera.as_ref(),
                    ),
            ),
            (
                PlayerActorAssembly::DirectTransform {
                    z_shift,
                    tint,
                    blend,
                    root_camera,
                    field_camera_suffix: _,
                },
                0,
            ) => {
                let (hud, camera) = if segment.manual_hud_draw {
                    (ActorSegment::shifted(hud, *z_shift), None)
                } else {
                    (
                        ActorSegment::transformed(
                            hud,
                            *z_shift,
                            tint,
                            *blend,
                            root_camera,
                            &Matrix4::IDENTITY,
                            None,
                        ),
                        Some(root_camera),
                    )
                };
                Some(hud.with_flat_draws(hud_draws, camera))
            }
            (
                PlayerActorAssembly::DirectTransform {
                    z_shift,
                    tint,
                    blend,
                    root_camera,
                    field_camera_suffix,
                },
                1,
            ) => Some(
                ActorSegment::transformed(
                    &self.scratch.notefield_actor_scratch[player],
                    *z_shift,
                    tint,
                    *blend,
                    root_camera,
                    field_camera_suffix,
                    None,
                )
                .with_flat_draws(
                    &self.scratch.notefield_flat_draw_scratch[player],
                    segment.field_camera.as_ref(),
                ),
            ),
            (PlayerActorAssembly::Captured | PlayerActorAssembly::Hidden, _)
            | (PlayerActorAssembly::DirectZ { .. }, _)
            | (PlayerActorAssembly::DirectTransform { .. }, _) => None,
        }
    }
}

impl<'a> Iterator for GameplayActorSegmentIter<'a> {
    type Item = ActorSegment<'a>;

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            if let Some(segment) = self.pending_actor_segment() {
                return Some(segment);
            }
            match self.phase {
                0 => {
                    self.phase = 1;
                    self.pending_actor_start = 0;
                    self.pending_actor_end = self.actor_start;
                    continue;
                }
                1 => {
                    while self.underlay_player < MAX_PLAYERS {
                        let player = self.underlay_player;
                        self.underlay_player += 1;
                        if self.owner.underlay_visible {
                            return Some(
                                ActorSegment::new(&self.scratch.notefield_underlay_actors[player])
                                    .with_flat_draws(
                                        &self.scratch.notefield_underlay_draws[player],
                                        None,
                                    )
                                    .with_projection(&self.owner.screen_projection),
                            );
                        }
                    }
                    while self.player < self.owner.players.len() {
                        let player = self.player;
                        let part = self.player_part;
                        self.player_part += 1;
                        if self.player_part == 3 {
                            self.player += 1;
                            self.player_part = 0;
                        }
                        let Some(segment) = self.owner.players[player].as_ref() else {
                            continue;
                        };
                        if let Some(draw) = self.player_segment(segment, part) {
                            let projection = if part == 1 {
                                &segment.field_screen_projection
                            } else {
                                &self.owner.screen_projection
                            };
                            return Some(draw.with_projection(projection));
                        }
                    }
                    self.phase = 2;
                }
                2 => {
                    debug_assert!(
                        self.owner.direct_proxy_len
                            <= self.scratch.song_lua_direct_proxies.entries.len()
                    );
                    let proxy_len = self
                        .owner
                        .direct_proxy_len
                        .min(self.scratch.song_lua_direct_proxies.entries.len());
                    let proxies = &self.scratch.song_lua_direct_proxies.entries[..proxy_len];
                    let Some(proxy) = proxies.get(self.proxy) else {
                        self.phase = 3;
                        continue;
                    };
                    let actor_insert = proxy
                        .actor_insert
                        .clamp(self.actor_start, self.actors.len());
                    if !self.proxy_draw {
                        self.proxy_draw = true;
                        self.pending_actor_start = self.actor_start;
                        self.pending_actor_end = actor_insert;
                        continue;
                    }
                    self.proxy_draw = false;
                    self.proxy += 1;
                    self.actor_start = actor_insert;
                    let draws = self.direct_draws(
                        proxy.player,
                        proxy.draws,
                        proxy.draw_start,
                        proxy.draw_end,
                    );
                    return Some(
                        ActorSegment::flat_proxy_styled_with_cameras(
                            draws,
                            proxy.offset,
                            proxy.z,
                            &proxy.style,
                            proxy.blend,
                            proxy.enclosing_camera.as_ref(),
                            proxy.camera.as_ref(),
                        )
                        .with_projection(&self.owner.screen_projection),
                    );
                }
                3 => {
                    self.phase = 4;
                    self.pending_actor_start = self.actor_start;
                    self.pending_actor_end = self.actors.len();
                    continue;
                }
                _ => return None,
            }
        }
    }
}

#[inline(always)]
#[cfg(test)]
fn player_actor_assembly_for_transform(
    requests_player_proxy: bool,
    visible: bool,
    transform: SongLuaCaptureTransform,
) -> PlayerActorAssembly {
    player_actor_assembly_for_transform_with_metrics(
        requests_player_proxy,
        visible,
        transform,
        PlayerTransformMetrics::current(),
    )
}

#[inline(always)]
fn player_actor_assembly_for_transform_with_metrics(
    requests_player_proxy: bool,
    visible: bool,
    transform: SongLuaCaptureTransform,
    metrics: PlayerTransformMetrics,
) -> PlayerActorAssembly {
    if let Some(assembly) =
        direct_player_actor_assembly(requests_player_proxy, visible, transform, metrics)
    {
        return assembly;
    }
    let field_camera_suffix = song_lua_player_transform_matrix(SongLuaPlayerTransformRequest {
        screen_width: metrics.screen_width,
        screen_height: metrics.screen_height,
        screen_center_y: metrics.screen_center_y,
        playfield_center_x: transform.playfield_center_x,
        target_x: transform.target_x,
        target_y: transform.target_y,
        rotation_x_deg: transform.rotation_x,
        rotation_y_deg: transform.rotation_y,
        rotation_z_deg: transform.rotation_z,
        skew_x: transform.skew_x,
        skew_y: transform.skew_y,
        zoom_x: transform.zoom_x,
        zoom_y: transform.zoom_y,
        zoom_z: transform.zoom_z,
        target_z: transform.target_z,
        wrappers: transform.wrappers,
    });
    match field_camera_suffix {
        Some(field_camera_suffix) => PlayerActorAssembly::DirectTransform {
            z_shift: transform.z_shift,
            tint: transform.tint,
            blend: transform.blend,
            root_camera: song_lua_player_root_camera_with_metrics(field_camera_suffix, metrics),
            field_camera_suffix,
        },
        None => PlayerActorAssembly::DirectZ {
            z_shift: transform.z_shift,
        },
    }
}

#[inline(always)]
fn clear_player_actor_bundle(
    field_scratch: &mut Vec<Actor>,
    flat_draw_scratch: &mut Vec<FlatDraw>,
    hud_scratch: &mut Vec<Actor>,
    hud_flat_draw_scratch: &mut Vec<FlatDraw>,
) {
    field_scratch.clear();
    flat_draw_scratch.clear();
    hud_scratch.clear();
    hud_flat_draw_scratch.clear();
}

fn song_lua_player_target_x(
    explicit_x: Option<f32>,
    player_state_x: f32,
    layout_center_x: f32,
    notefield_view: ViewOverride,
) -> f32 {
    explicit_x.unwrap_or(if notefield_view.force_center_1player {
        layout_center_x
    } else {
        player_state_x
    })
}

fn prepare_song_lua_layer<S: NoteskinSlot + Clone>(
    out: &mut Vec<Actor>,
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    song_foreground_state: SongLuaOverlayState,
    order_cache: &mut SongLuaOverlayOrderCache,
    order_scratch: &mut Vec<usize>,
    aft_capture_scratch: &mut SongLuaAftCaptureScratch,
    depth: SongLuaLayerDepth,
) -> Option<SongLuaLayerDepth> {
    if overlays.is_empty() || !song_foreground_state.draw_visible() {
        order_scratch.clear();
        return None;
    }
    Some(prepare_active_song_lua_layer(
        out,
        overlays,
        overlay_states,
        order_cache,
        order_scratch,
        aft_capture_scratch,
        depth,
    ))
}

fn prepare_active_song_lua_layer<S: NoteskinSlot + Clone>(
    out: &mut Vec<Actor>,
    overlays: &[SongLuaOverlayActor<S>],
    overlay_states: &[SongLuaOverlayState],
    order_cache: &mut SongLuaOverlayOrderCache,
    order_scratch: &mut Vec<usize>,
    aft_capture_scratch: &mut SongLuaAftCaptureScratch,
    depth: SongLuaLayerDepth,
) -> SongLuaLayerDepth {
    aft_capture_scratch.begin_frame();
    out.reserve(overlays.len());
    song_lua_overlay_order_into(overlays, overlay_states, order_cache, None, order_scratch);
    // Parent Z is composed into each child's geometry. Authored draworder and
    // explicit child Z sorting determine traversal within this screen layer.
    depth
}

/// Foreground::Update advances actors from the FGCHANGE's start, undoing
/// music rate with ITGmania's default RateModsAffectFGChanges=false. Hidden
/// children continue animating; the gameplay-screen lead-in is not actor age.
#[must_use]
pub fn foreground_elapsed(music_second: f32, start_second: f32, music_rate: f32) -> f32 {
    (music_second - start_second).max(0.0) / music_rate
}

fn push_song_lua_layer_actors<S: NoteskinSlot + Clone>(
    out: &mut Vec<Actor>,
    targets: &mut Vec<deadlib_present::actors::RenderTarget>,
    overlays: &[SongLuaOverlayActor<S>],
    order_cache: &mut SongLuaOverlayOrderCache,
    topology_index: &SongLuaOverlayTopologyIndex,
    local_overlay_states: &[SongLuaOverlayState],
    overlay_states: &[SongLuaOverlayState],
    song_foreground_state: SongLuaOverlayState,
    screen_state: Option<SongLuaOverlayState>,
    screen_projections: &mut Vec<SongLuaScreenProjectionRange>,
    mut capture_originals: Option<&mut SongLuaScreenCaptureOriginals>,
    proxy_sources: &SongLuaScreenProxySources<'_>,
    mut direct_proxies: Option<&mut SongLuaDirectProxies>,
    mut proxy_actor_scratch: Option<&mut SongLuaProxyActorScratch>,
    asset_manager: &AssetManager,
    space_width: f32,
    space_height: f32,
    effect_time: f32,
    effect_beat: f32,
    total_elapsed: impl Into<SongLuaDrawTime>,
    order_scratch: &mut Vec<usize>,
    capture_states: &mut Vec<SongLuaOverlayState>,
    capture_order_scratch: &mut Vec<usize>,
    aft_capture_scratch: &mut SongLuaAftCaptureScratch,
    projected_mesh_scratch: &mut [SongLuaProjectedMeshScratch],
    depth: SongLuaLayerDepth,
) {
    let total_elapsed = total_elapsed.into();
    let Some(song_lua_depth) = prepare_song_lua_layer(
        out,
        overlays,
        overlay_states,
        song_foreground_state,
        order_cache,
        order_scratch,
        aft_capture_scratch,
        depth,
    ) else {
        return;
    };
    // Command/update Draw calls precede ordinary DrawPrimitives. Consume each
    // retained submission once, while allowing the same AFT to draw normally.
    let immediate = aft_capture_scratch.manual.take_immediate(effect_time);
    for event in immediate {
        let frame = aft_capture_scratch.manual.immediate_frames[event];
        let count = aft_capture_scratch.manual.frames[frame].owners.len();
        for batch in 0..count {
            let owner = aft_capture_scratch.manual.frames[frame].owners[batch];
            song_lua_draw_owner(
                out,
                targets,
                overlays,
                local_overlay_states,
                topology_index,
                &mut aft_capture_scratch.manual,
                frame,
                owner,
                proxy_sources,
                asset_manager,
                [space_width, space_height],
                [effect_time, effect_beat],
                total_elapsed,
                song_lua_depth.draw_z(0),
            );
        }
    }
    for (draw_idx, idx) in order_scratch.iter().copied().enumerate() {
        let Some(overlay) = overlays.get(idx) else {
            continue;
        };
        if let Some(frame_index) = aft_capture_scratch.manual.frame_at(effect_time)
            && let Some(owner) = aft_capture_scratch.manual.owners[idx]
        {
            if idx == owner {
                song_lua_draw_owner(
                    out,
                    targets,
                    overlays,
                    local_overlay_states,
                    topology_index,
                    &mut aft_capture_scratch.manual,
                    frame_index,
                    owner,
                    proxy_sources,
                    asset_manager,
                    [space_width, space_height],
                    [effect_time, effect_beat],
                    total_elapsed,
                    song_lua_depth.draw_z(draw_idx),
                );
            }
            continue;
        }
        if topology_index
            .aft_ancestors
            .get(idx)
            .copied()
            .and_then(SongLuaOverlayIndex::get)
            .is_some()
        {
            continue;
        }
        // These kinds never build actors; their children are drawn on their own.
        if matches!(
            overlay.kind,
            SongLuaOverlayKind::Actor
                | SongLuaOverlayKind::ActorFrame
                | SongLuaOverlayKind::WrapperState
                | SongLuaOverlayKind::UpdateTracks { .. }
                | SongLuaOverlayKind::Sound { .. }
        ) {
            continue;
        }
        let overlay_state = overlay_states
            .get(idx)
            .copied()
            .unwrap_or_else(SongLuaOverlayState::default);
        let overlay_state = if song_foreground_state == SongLuaOverlayState::default() {
            overlay_state
        } else {
            song_lua_overlay_compose_state(
                &SongLuaOverlayKind::<S>::ActorFrame,
                song_foreground_state,
                overlay_state,
                space_width,
                space_height,
                [effect_time, effect_beat],
            )
        };
        let z = song_lua_depth.draw_z(draw_idx);
        match &overlay.kind {
            SongLuaOverlayKind::ActorProxy { target } => {
                // Effects never change visibility, and hidden proxies draw nothing.
                if !overlay_state.draw_visible() {
                    continue;
                }
                let overlay_state =
                    song_lua_proxy_effect(overlay_state, effect_time, effect_beat, idx as u32);
                if let Some((player_index, sources)) =
                    song_lua_direct_player_proxy_source(target, proxy_sources)
                {
                    if let Some(dest) = direct_proxies.as_deref_mut() {
                        for source in sources {
                            if let Some(proxy) = song_lua_direct_proxy(
                                overlay_state,
                                z,
                                source,
                                player_index,
                                out.len(),
                                space_width,
                                space_height,
                            ) {
                                dest.push(proxy);
                            }
                        }
                    }
                    continue;
                }
                let direct_source = song_lua_direct_proxy_source(target, proxy_sources);
                if let Some((player_index, source)) = direct_source {
                    if let Some(proxy) = song_lua_direct_proxy(
                        overlay_state,
                        z,
                        source,
                        player_index,
                        out.len(),
                        space_width,
                        space_height,
                    ) && let Some(dest) = direct_proxies.as_deref_mut()
                    {
                        dest.push(proxy);
                    }
                    continue;
                }
                if let Some(actor) =
                    song_lua_proxy_source(target, proxy_sources).and_then(|source| {
                        song_lua_build_proxy_actor_with_scratch(
                            overlay_state,
                            z,
                            source,
                            space_width,
                            space_height,
                            proxy_actor_scratch.as_deref_mut(),
                        )
                    })
                {
                    out.push(actor);
                }
            }
            SongLuaOverlayKind::ActorFrameTexture {
                alpha_buffer,
                depth_buffer,
                float_buffer,
                ..
            } => {
                if !overlay_state.draw_visible() {
                    continue;
                }
                let Some(&texture_handle) = topology_index.aft_texture_handles.get(idx) else {
                    continue;
                };
                let Some(size) = song_lua_aft_size(overlay, overlay_state) else {
                    continue;
                };
                let (target_size, viewport) = song_lua_capture_size(size);
                let size = viewport.map(|value| value as f32);
                let Some(capture_scratch) = aft_capture_scratch.overlay(idx) else {
                    continue;
                };
                let Some(children) = capture_scratch.refill([0.0, 0.0], |source| {
                    // RageTextureRenderTarget::BeginRenderingTo resets the
                    // camera to LoadMenuPerspective(0), whose depth is Â±1000.
                    // The default presentation camera clips at Â±1 instead.
                    source.push(Actor::CameraPush {
                        view_proj: glam::camera::rh::proj::opengl::orthographic(
                            -size[0] * 0.5,
                            size[0] * 0.5,
                            -size[1] * 0.5,
                            size[1] * 0.5,
                            -1000.0,
                            1000.0,
                        ),
                    });
                    song_lua_capture_children_into(
                        source,
                        overlays,
                        overlay_states,
                        local_overlay_states,
                        order_cache,
                        topology_index,
                        asset_manager,
                        idx,
                        proxy_sources,
                        proxy_actor_scratch.as_deref_mut(),
                        space_width,
                        space_height,
                        effect_time,
                        effect_beat,
                        total_elapsed,
                        capture_states,
                        capture_order_scratch,
                        projected_mesh_scratch,
                    );
                    source.push(Actor::CameraPop);
                }) else {
                    continue;
                };
                targets.push(deadlib_present::actors::RenderTarget {
                    texture_handle,
                    size: target_size,
                    viewport,
                    logical_size: size,
                    float_color: *float_buffer,
                    alpha: *alpha_buffer,
                    depth: *depth_buffer,
                    preserve: overlay_state.aft_preserve,
                    children,
                });
            }
            SongLuaOverlayKind::AftSprite { .. } => {
                let Some(capture_index) = topology_index
                    .aft_sprite_targets
                    .get(idx)
                    .copied()
                    .and_then(SongLuaOverlayIndex::get)
                else {
                    continue;
                };
                let Some(&texture_handle) = topology_index.aft_texture_handles.get(capture_index)
                else {
                    continue;
                };
                let Some(texture_size) =
                    song_lua_aft_size(&overlays[capture_index], overlay_states[capture_index])
                else {
                    continue;
                };
                if let Some(actors) = build_song_lua_aft_sprite_actor(
                    overlay_state,
                    texture_handle,
                    texture_size,
                    z,
                    space_width,
                    space_height,
                    effect_time,
                    effect_beat,
                    total_elapsed.animation_elapsed,
                    projected_mesh_scratch.get_mut(idx),
                ) {
                    out.extend(actors);
                }
            }
            _ => {
                let start = out.len();
                let camera_state = topology_index
                    .camera_state(overlay_states, idx)
                    .or(screen_state.filter(|screen| screen.fov.is_some()));
                let camera = SongLuaDrawCamera::with_screen(
                    camera_state, screen_state, [effect_time, effect_beat],
                );
                append_song_lua_overlay_output(
                    out,
                    overlay,
                    overlay_state,
                    camera,
                    asset_manager,
                    z,
                    [space_width, space_height],
                    [effect_time, effect_beat],
                    total_elapsed,
                    topology_index.texture_handle(idx),
                    projected_mesh_scratch.get_mut(idx),
                );
                if out.len() > start
                    && camera.world != Matrix4::IDENTITY
                {
                    // These actors already include the screen on their world
                    // stack. Other gameplay fragments keep the outer prefix.
                    if let Some(previous) = screen_projections.last_mut()
                        && previous.end == start
                    {
                        previous.end = out.len();
                    } else {
                        screen_projections.push(SongLuaScreenProjectionRange {
                            start,
                            end: out.len(),
                        });
                    }
                    if let Some(originals) = capture_originals.as_deref_mut() {
                        let original_start = originals.actors.len();
                        append_song_lua_overlay_output(
                            &mut originals.actors, overlay, overlay_state,
                            camera_state.into(), asset_manager, z,
                            [space_width, space_height], [effect_time, effect_beat],
                            total_elapsed, topology_index.texture_handle(idx),
                            projected_mesh_scratch.get_mut(idx),
                        );
                        originals.ranges.push(SongLuaScreenCaptureRange {
                            start,
                            end: out.len(),
                            original_start,
                            original_end: originals.actors.len(),
                        });
                    }
                }
            }
        }
    }
}

/// Song-lifetime playback storage, owned by the game/render frame thread.
///
/// `new` sizes layer caches from the compiled chart and reserves field/proxy
/// buffers before play. Texture and text warmup are explicit separate steps.
/// There is no synchronization, eviction, or scan-pruning; storage is released
/// at the song transition. Existing capture pools and geometry caches document
/// their own capacity, overflow, and instrumentation policies. Frame work scales
/// with active chart actors and requested captures, not the whole song history.
/// Per-player Underlay streams reserve the HUD actor/draw bounds at song entry.
/// Ordinary frames move their prefixes without allocation or capture; requested
/// Underlay proxies materialize them into the existing bounded screen banks.
/// No lookup or eviction occurs. Overflow follows the existing HUD vector policy;
/// allocation regressions check warmed capacities, and work is linear in that
/// frame's emitted HUD. All retained backing is freed at the song transition.
#[derive(Default)]
pub struct FrameScratch {
    song_lua_enabled: bool,
    dynamic_scene: bool,
    render_targets: Vec<deadlib_present::actors::RenderTarget>,
    song_lua_overlay_order: SongLuaOverlayOrderCache,
    song_lua_background_visual_layer_orders: Vec<SongLuaOverlayOrderCache>,
    song_lua_foreground_visual_layer_orders: Vec<SongLuaOverlayOrderCache>,
    song_lua_background_layer_activity: SongLuaLayerActivity,
    song_lua_foreground_layer_activity: SongLuaLayerActivity,
    song_lua_proxy_request_index: SongLuaProxyRequestIndex,
    song_lua_background_overlay_topology_indices: Vec<SongLuaOverlayTopologyIndex>,
    song_lua_foreground_proxy_request_indices: Vec<SongLuaProxyRequestIndex>,
    song_lua_aft_capture_scratch: SongLuaAftCaptureScratch,
    song_lua_background_aft_capture_scratch: Vec<SongLuaAftCaptureScratch>,
    song_lua_foreground_aft_capture_scratch: Vec<SongLuaAftCaptureScratch>,
    song_lua_projected_mesh_scratch: Vec<SongLuaProjectedMeshScratch>,
    song_lua_background_projected_mesh_scratch: Vec<Vec<SongLuaProjectedMeshScratch>>,
    song_lua_foreground_projected_mesh_scratch: Vec<Vec<SongLuaProjectedMeshScratch>>,
    song_lua_message_state_cache: Vec<SongLuaMessageStateCache>,
    song_lua_background_layer_message_state_cache: Vec<Vec<SongLuaMessageStateCache>>,
    song_lua_foreground_layer_message_state_cache: Vec<Vec<SongLuaMessageStateCache>>,
    song_lua_player_message_state_cache: [SongLuaMessageStateCache; MAX_PLAYERS],
    song_lua_player_judgment_message_state_cache: [SongLuaMessageStateCache; MAX_PLAYERS],
    song_lua_player_combo_message_state_cache: [SongLuaMessageStateCache; MAX_PLAYERS],
    song_lua_song_foreground_message_state_cache: SongLuaMessageStateCache,
    screen_layer_caches: [SongLuaMessageStateCache; 4],
    song_lua_background_song_foreground_message_state_cache: Vec<SongLuaMessageStateCache>,
    song_lua_foreground_song_foreground_message_state_cache: Vec<SongLuaMessageStateCache>,
    song_lua_local_state_scratch: Vec<SongLuaOverlayState>,
    song_lua_overlay_state_scratch: Vec<SongLuaOverlayState>,
    song_lua_background_layer_local_state_scratch: Vec<Vec<SongLuaOverlayState>>,
    song_lua_background_layer_state_scratch: Vec<Vec<SongLuaOverlayState>>,
    song_lua_foreground_layer_local_state_scratch: Vec<Vec<SongLuaOverlayState>>,
    song_lua_foreground_layer_state_scratch: Vec<Vec<SongLuaOverlayState>>,
    song_lua_capture_state_scratch: Vec<SongLuaOverlayState>,
    song_lua_order_scratch: Vec<usize>,
    song_lua_capture_order_scratch: Vec<usize>,
    song_lua_capture_visit_scratch: SongLuaCaptureVisitScratch,
    song_lua_proxy_actor_scratch: Option<SongLuaProxyActorScratch>,
    song_lua_direct_proxies: SongLuaDirectProxies,
    song_lua_screen_projection_ranges: Vec<SongLuaScreenProjectionRange>,
    screen_capture_originals: SongLuaScreenCaptureOriginals,
    notefield_actor_scratch: [Vec<Actor>; MAX_PLAYERS],
    notefield_flat_draw_scratch: [Vec<FlatDraw>; MAX_PLAYERS],
    notefield_hud_actor_scratch: [Vec<Actor>; MAX_PLAYERS],
    notefield_hud_flat_draw_scratch: [Vec<FlatDraw>; MAX_PLAYERS],
    notefield_underlay_actors: [Vec<Actor>; MAX_PLAYERS],
    notefield_underlay_draws: [Vec<FlatDraw>; MAX_PLAYERS],
    notefield_camera_cache: [NotefieldCameraCache; MAX_PLAYERS],
    player_actor_assembly_cache: [PlayerActorAssemblyCache; MAX_PLAYERS],
    player_field_camera_cache: [PlayerFieldCameraCache; MAX_PLAYERS],
}

impl FrameScratch {
    #[cfg(any(test, feature = "test-support"))]
    pub const fn uses_song_lua_compositor(&self) -> bool {
        self.song_lua_enabled
    }

    /// Screen-entry-only warmup for a native program or diagnostic live scene. Every prepared actor
    /// may mutate, including ancestors, draw order and camera scope. The exact
    /// lists are reused until a live callback appends a wrapper state.
    pub fn enable_dynamic_scene(&mut self) {
        self.song_lua_enabled = true;
        self.dynamic_scene = true;
        // A foreground can bind or retarget a proxy after screen preparation.
        // Reserve the largest direct source (whole Player: three runs) for
        // every root proxy before any of those live callbacks execute.
        let root_proxies = std::iter::once(&self.song_lua_proxy_request_index)
            .chain(&self.song_lua_foreground_proxy_request_indices)
            .map(|index| {
                index
                    .proxy_indices
                    .iter()
                    .filter(|&&proxy| index.topology.aft_ancestors[proxy].get().is_none())
                    .count()
            })
            .sum::<usize>();
        let capacity = root_proxies.saturating_mul(3);
        let entries = &mut self.song_lua_direct_proxies.entries;
        if entries.capacity() < capacity {
            entries.reserve_exact(capacity.saturating_sub(entries.len()));
        }
        for order in std::iter::once(&mut self.song_lua_overlay_order)
            .chain(&mut self.song_lua_background_visual_layer_orders)
            .chain(&mut self.song_lua_foreground_visual_layer_orders)
        {
            order.enable_dynamic();
        }
        self.song_lua_proxy_request_index
            .topology
            .dynamic_camera_scope = true;
        for topology in &mut self.song_lua_background_overlay_topology_indices {
            topology.dynamic_camera_scope = true;
        }
        for index in &mut self.song_lua_foreground_proxy_request_indices {
            index.topology.dynamic_camera_scope = true;
        }
    }

    pub fn new<P: deadsync_gameplay::GameplayProfileData, S: NoteskinSlot + Clone>(
        gameplay: &GameplayCoreState<P, S>,
    ) -> Self {
        let active_players = gameplay.num_players();
        let notefield_actor_scratch =
            player_scratch(active_players, NOTEFIELD_ACTOR_SCRATCH_CAPACITY);
        let notefield_flat_draw_scratch =
            player_scratch(active_players, NOTEFIELD_ACTOR_SCRATCH_CAPACITY);
        let notefield_hud_actor_scratch =
            player_scratch(active_players, NOTEFIELD_HUD_ACTOR_SCRATCH_CAPACITY);
        let notefield_hud_flat_draw_scratch =
            player_scratch(active_players, NOTEFIELD_HUD_FLAT_DRAW_SCRATCH_CAPACITY);
        let notefield_underlay_actors =
            player_scratch(active_players, NOTEFIELD_HUD_ACTOR_SCRATCH_CAPACITY);
        let notefield_underlay_draws =
            player_scratch(active_players, NOTEFIELD_HUD_FLAT_DRAW_SCRATCH_CAPACITY);
        let song_lua_visuals = gameplay.song_lua_visuals();
        if gameplay.song().background_lua_changes.is_empty()
            && gameplay.song().foreground_lua_changes.is_empty()
            && song_lua_visuals.overlays.is_empty()
            && song_lua_visuals.background_visual_layers.is_empty()
            && song_lua_visuals.foreground_visual_layers.is_empty()
        {
            return Self {
                notefield_actor_scratch,
                notefield_flat_draw_scratch,
                notefield_hud_actor_scratch,
                notefield_hud_flat_draw_scratch,
                notefield_underlay_actors,
                notefield_underlay_draws,
                ..Self::default()
            };
        }
        let song_lua_overlay_order = song_lua_overlay_order_cache_from(
            &song_lua_visuals.overlays,
            &song_lua_visuals.overlay_eases,
        );
        let song_lua_background_visual_layer_orders = song_lua_visuals
            .background_visual_layers
            .iter()
            .map(|layer| song_lua_overlay_order_cache_from(&layer.overlays, &layer.overlay_eases))
            .collect();
        let song_lua_foreground_visual_layer_orders = song_lua_visuals
            .foreground_visual_layers
            .iter()
            .map(|layer| song_lua_overlay_order_cache_from(&layer.overlays, &layer.overlay_eases))
            .collect();
        let mut song_lua_proxy_request_index =
            SongLuaProxyRequestIndex::new(&song_lua_visuals.overlays);
        song_lua_proxy_request_index
            .topology
            .include_camera_eases(&song_lua_visuals.overlays, &song_lua_visuals.overlay_eases);
        let song_lua_background_overlay_topology_indices: Vec<SongLuaOverlayTopologyIndex> =
            song_lua_visuals
                .background_visual_layers
                .iter()
                .map(|layer| {
                    let mut topology = SongLuaOverlayTopologyIndex::new(&layer.overlays);
                    topology.include_camera_eases(&layer.overlays, &layer.overlay_eases);
                    topology
                })
                .collect();
        let song_lua_foreground_proxy_request_indices: Vec<SongLuaProxyRequestIndex> =
            song_lua_visuals
                .foreground_visual_layers
                .iter()
                .map(|layer| {
                    let mut index = SongLuaProxyRequestIndex::new(&layer.overlays);
                    index
                        .topology
                        .include_camera_eases(&layer.overlays, &layer.overlay_eases);
                    index
                })
                .collect();
        let song_lua_direct_proxy_capacity = song_lua_proxy_request_index
            .direct_proxy_capacity(&song_lua_visuals.overlays)
            .saturating_add(
                song_lua_foreground_proxy_request_indices
                    .iter()
                    .zip(song_lua_visuals.foreground_visual_layers.iter())
                    .map(|(index, layer)| index.direct_proxy_capacity(&layer.overlays))
                    .sum::<usize>(),
            );
        let song_lua_aft_capture_scratch = SongLuaAftCaptureScratch::new(
            &song_lua_visuals.overlays,
            &song_lua_proxy_request_index.topology,
        );
        let song_lua_background_aft_capture_scratch: Vec<_> = song_lua_visuals
            .background_visual_layers
            .iter()
            .zip(song_lua_background_overlay_topology_indices.iter())
            .map(|(layer, topology)| SongLuaAftCaptureScratch::new(&layer.overlays, topology))
            .collect();
        let song_lua_foreground_aft_capture_scratch: Vec<_> = song_lua_visuals
            .foreground_visual_layers
            .iter()
            .zip(song_lua_foreground_proxy_request_indices.iter())
            .map(|(layer, index)| SongLuaAftCaptureScratch::new(&layer.overlays, &index.topology))
            .collect();
        let mut proxy_pool_counts =
            song_lua_proxy_pool_counts(&song_lua_visuals.overlays, &song_lua_proxy_request_index);
        for (index, layer) in song_lua_foreground_proxy_request_indices
            .iter()
            .zip(song_lua_visuals.foreground_visual_layers.iter())
        {
            let layer_counts = song_lua_proxy_pool_counts(&layer.overlays, index);
            for class in 0..SONG_LUA_PROXY_POOL_CLASSES {
                proxy_pool_counts[class] =
                    proxy_pool_counts[class].saturating_add(layer_counts[class]);
            }
        }
        let song_lua_proxy_count = proxy_pool_counts.iter().sum::<usize>();
        let song_lua_projected_mesh_scratch =
            song_lua_projected_mesh_scratch_for(&song_lua_visuals.overlays);
        let song_lua_background_projected_mesh_scratch = song_lua_visuals
            .background_visual_layers
            .iter()
            .map(|layer| song_lua_projected_mesh_scratch_for(&layer.overlays))
            .collect();
        let song_lua_foreground_projected_mesh_scratch = song_lua_visuals
            .foreground_visual_layers
            .iter()
            .map(|layer| song_lua_projected_mesh_scratch_for(&layer.overlays))
            .collect();
        let song_lua_message_state_cache =
            vec![SongLuaMessageStateCache::default(); song_lua_visuals.overlays.len()];
        let song_lua_background_layer_message_state_cache = song_lua_visuals
            .background_visual_layers
            .iter()
            .map(|layer| vec![SongLuaMessageStateCache::default(); layer.overlays.len()])
            .collect();
        let song_lua_foreground_layer_message_state_cache = song_lua_visuals
            .foreground_visual_layers
            .iter()
            .map(|layer| vec![SongLuaMessageStateCache::default(); layer.overlays.len()])
            .collect();
        let song_lua_background_song_foreground_message_state_cache = vec![
            SongLuaMessageStateCache::default();
            song_lua_visuals.background_visual_layers.len()
        ];
        let song_lua_foreground_song_foreground_message_state_cache = vec![
            SongLuaMessageStateCache::default();
            song_lua_visuals.foreground_visual_layers.len()
        ];
        let song_lua_max_overlay_count = std::iter::once(song_lua_visuals.overlays.len())
            .chain(
                song_lua_visuals
                    .background_visual_layers
                    .iter()
                    .map(|layer| layer.overlays.len()),
            )
            .chain(
                song_lua_visuals
                    .foreground_visual_layers
                    .iter()
                    .map(|layer| layer.overlays.len()),
            )
            .max()
            .unwrap_or(0);
        let (song_lua_local_state_scratch, song_lua_overlay_state_scratch) =
            song_lua_overlay_initial_state_sets(
                &song_lua_visuals.overlays,
                song_lua_visuals.screen_width,
                song_lua_visuals.screen_height,
            );
        let (
            song_lua_background_layer_local_state_scratch,
            song_lua_background_layer_state_scratch,
        ) = song_lua_visuals
            .background_visual_layers
            .iter()
            .map(|layer| {
                song_lua_overlay_initial_state_sets(
                    &layer.overlays,
                    layer.screen_width,
                    layer.screen_height,
                )
            })
            .unzip();
        let (
            song_lua_foreground_layer_local_state_scratch,
            song_lua_foreground_layer_state_scratch,
        ) = song_lua_visuals
            .foreground_visual_layers
            .iter()
            .map(|layer| {
                song_lua_overlay_initial_state_sets(
                    &layer.overlays,
                    layer.screen_width,
                    layer.screen_height,
                )
            })
            .unzip();
        let song_lua_now = gameplay.current_music_time_display();
        let song_lua_background_layer_activity = SongLuaLayerActivity::new(
            song_lua_visuals
                .background_visual_layers
                .iter()
                .map(|layer| layer.start_second),
            song_lua_now,
        );
        let song_lua_foreground_layer_activity = SongLuaLayerActivity::new(
            song_lua_visuals
                .foreground_visual_layers
                .iter()
                .map(|layer| layer.start_second),
            song_lua_now,
        );
        let target_capacity = std::iter::once(&song_lua_aft_capture_scratch)
            .chain(&song_lua_background_aft_capture_scratch)
            .chain(&song_lua_foreground_aft_capture_scratch)
            .map(|scratch| {
                scratch.slots.iter().filter(|slot| slot.is_some()).count()
                    + scratch
                        .manual
                        .frames
                        .iter()
                        .map(|frame| {
                            frame
                                .ops
                                .iter()
                                .filter(|op| matches!(op, SongLuaDrawOp::Begin { .. }))
                                .count()
                        })
                        .max()
                        .unwrap_or(0)
            })
            .sum();
        let background_overlays = || song_lua_visuals.background_visual_layers.iter()
            .flat_map(|layer| layer.overlays.iter());
        let screen_capture_originals = SongLuaScreenCaptureOriginals {
            actors: Vec::with_capacity(background_overlays().map(|overlay| {
                // Model and noteskin draws can add camera scope markers.
                song_lua_aft_actor_capacity(&overlay.kind).saturating_add(2)
            }).sum()),
            ranges: Vec::with_capacity(background_overlays().count()),
        };
        let frame_scratch = Self {
            song_lua_enabled: true,
            dynamic_scene: false,
            screen_capture_originals,
            render_targets: Vec::with_capacity(target_capacity),
            song_lua_overlay_order,
            song_lua_background_visual_layer_orders,
            song_lua_foreground_visual_layer_orders,
            song_lua_background_layer_activity,
            song_lua_foreground_layer_activity,
            song_lua_proxy_request_index,
            song_lua_background_overlay_topology_indices,
            song_lua_foreground_proxy_request_indices,
            song_lua_aft_capture_scratch,
            song_lua_background_aft_capture_scratch,
            song_lua_foreground_aft_capture_scratch,
            song_lua_projected_mesh_scratch,
            song_lua_background_projected_mesh_scratch,
            song_lua_foreground_projected_mesh_scratch,
            song_lua_message_state_cache,
            song_lua_background_layer_message_state_cache,
            song_lua_foreground_layer_message_state_cache,
            song_lua_player_message_state_cache: [SongLuaMessageStateCache::default(); MAX_PLAYERS],
            song_lua_player_judgment_message_state_cache: [SongLuaMessageStateCache::default();
                MAX_PLAYERS],
            song_lua_player_combo_message_state_cache: [SongLuaMessageStateCache::default();
                MAX_PLAYERS],
            song_lua_song_foreground_message_state_cache: SongLuaMessageStateCache::default(),
            screen_layer_caches: std::array::from_fn(|_| SongLuaMessageStateCache::default()),
            song_lua_background_song_foreground_message_state_cache,
            song_lua_foreground_song_foreground_message_state_cache,
            song_lua_local_state_scratch,
            song_lua_overlay_state_scratch,
            song_lua_background_layer_local_state_scratch,
            song_lua_background_layer_state_scratch,
            song_lua_foreground_layer_local_state_scratch,
            song_lua_foreground_layer_state_scratch,
            song_lua_capture_state_scratch: Vec::with_capacity(song_lua_max_overlay_count),
            song_lua_order_scratch: Vec::with_capacity(song_lua_max_overlay_count),
            song_lua_capture_order_scratch: Vec::with_capacity(song_lua_max_overlay_count),
            song_lua_capture_visit_scratch: SongLuaCaptureVisitScratch::with_capacity(
                song_lua_max_overlay_count,
            ),
            song_lua_proxy_actor_scratch: (song_lua_proxy_count != 0).then(|| {
                SongLuaProxyActorScratch::with_proxy_counts(active_players, proxy_pool_counts)
            }),
            song_lua_direct_proxies: SongLuaDirectProxies::with_capacity(
                song_lua_direct_proxy_capacity,
            ),
            song_lua_screen_projection_ranges: Vec::with_capacity(
                song_lua_visuals.overlays.len()
                    + song_lua_visuals
                        .background_visual_layers
                        .iter()
                        .map(|layer| layer.overlays.len())
                        .sum::<usize>()
                    + song_lua_visuals
                        .foreground_visual_layers
                        .iter()
                        .map(|layer| layer.overlays.len())
                        .sum::<usize>(),
            ),
            notefield_actor_scratch,
            notefield_flat_draw_scratch,
            notefield_hud_actor_scratch,
            notefield_hud_flat_draw_scratch,
            notefield_underlay_actors,
            notefield_underlay_draws,
            notefield_camera_cache: [NotefieldCameraCache::default(); MAX_PLAYERS],
            player_actor_assembly_cache: [PlayerActorAssemblyCache::default(); MAX_PLAYERS],
            player_field_camera_cache: [PlayerFieldCameraCache::default(); MAX_PLAYERS],
        };
        debug_assert_eq!(
            frame_scratch
                .song_lua_background_layer_local_state_scratch
                .len(),
            song_lua_visuals.background_visual_layers.len()
        );
        debug_assert_eq!(
            frame_scratch.song_lua_background_layer_state_scratch.len(),
            song_lua_visuals.background_visual_layers.len()
        );
        debug_assert_eq!(
            frame_scratch
                .song_lua_background_layer_message_state_cache
                .len(),
            song_lua_visuals.background_visual_layers.len()
        );
        debug_assert_eq!(
            frame_scratch
                .song_lua_foreground_layer_local_state_scratch
                .len(),
            song_lua_visuals.foreground_visual_layers.len()
        );
        debug_assert_eq!(
            frame_scratch.song_lua_foreground_layer_state_scratch.len(),
            song_lua_visuals.foreground_visual_layers.len()
        );
        debug_assert_eq!(
            frame_scratch
                .song_lua_foreground_layer_message_state_cache
                .len(),
            song_lua_visuals.foreground_visual_layers.len()
        );
        frame_scratch
    }
    pub fn render_targets(&self) -> &[deadlib_present::actors::RenderTarget] {
        &self.render_targets
    }
}

/// Song-lifetime media schedules advanced by the shell on the game thread.
/// Event lists are built once; frame updates advance cursors and reuse the video
/// list. Seeks rewind those cursors. There is no shared access or eviction.
pub struct SongMedia {
    pub sound_paths: Vec<PathBuf>,
    song_lua_sound_events: Vec<SongLuaSoundEvent>,
    next_song_lua_sound_event_ix: usize,
    active_song_lua_video_paths: Vec<PathBuf>,
    static_song_lua_video_path_count: usize,
    movies: movie::Movies,
    // Authored primary foreground start in the gameplay music clock, resolved
    // once at screen entry. Actor animation must exclude the screen lead-in.
    foreground_start_second: f32,
    foreground_media_initialized: bool,
    next_foreground_change_ix: usize,
    current_foreground_path: Option<PathBuf>,
    current_foreground_key: Option<Arc<str>>,
    song_lua_foreground_owner_index: SongLuaForegroundOwnerIndex,
}
impl SongMedia {
    pub fn new<P: deadsync_gameplay::GameplayProfileData, S: NoteskinSlot + Clone>(
        gameplay: &GameplayCoreState<P, S>,
        sound_paths: Vec<PathBuf>,
    ) -> Self {
        let visuals = gameplay.song_lua_visuals();
        let active_song_lua_video_paths = prepare::song_lua_video_paths(visuals);
        let static_song_lua_video_path_count = active_song_lua_video_paths.len();
        let foreground_start_second = gameplay
            .song()
            .foreground_lua_changes
            .iter()
            .find(|change| change.start_beat <= 0.0 && change.path.is_file())
            .map_or(0.0, |change| {
                gameplay.music_time_for_beat(change.start_beat)
            });
        let mut media = Self {
            sound_paths,
            song_lua_sound_events: prepare::song_lua_sound_events(visuals),
            next_song_lua_sound_event_ix: 0,
            active_song_lua_video_paths,
            static_song_lua_video_path_count,
            movies: movie::Movies::new(visuals),
            foreground_start_second,
            foreground_media_initialized: false,
            next_foreground_change_ix: 0,
            current_foreground_path: None,
            current_foreground_key: None,
            song_lua_foreground_owner_index: SongLuaForegroundOwnerIndex::new(visuals),
        };
        media.refresh_foreground(gameplay);
        media
    }
    pub fn refresh_foreground<
        P: deadsync_gameplay::GameplayProfileData,
        S: NoteskinSlot + Clone,
    >(
        &mut self,
        gameplay: &GameplayCoreState<P, S>,
    ) -> bool {
        let beat = gameplay.current_beat();
        let changes = &gameplay.song().foreground_changes;
        let mut next_ix = self.next_foreground_change_ix.min(changes.len());
        if !self.foreground_media_initialized {
            next_ix = changes.partition_point(|change| change.start_beat <= beat);
        } else {
            while next_ix < changes.len() && changes[next_ix].start_beat <= beat {
                next_ix += 1;
            }
            while next_ix > 0 && changes[next_ix - 1].start_beat > beat {
                next_ix -= 1;
            }
            if next_ix == self.next_foreground_change_ix {
                return false;
            }
        }

        let next_path = next_ix
            .checked_sub(1)
            .and_then(|ix| changes.get(ix))
            .map(|change| &change.path)
            .filter(|path| path.is_file())
            .cloned();
        let changed = next_path != self.current_foreground_path;
        self.foreground_media_initialized = true;
        self.next_foreground_change_ix = next_ix;
        if !changed {
            return false;
        }

        self.current_foreground_key = next_path.as_deref().map(deadlib_assets::media_path_key);
        self.current_foreground_path = next_path;
        self.song_lua_foreground_owner_index
            .select(self.current_foreground_path.as_deref());
        self.active_song_lua_video_paths
            .truncate(self.static_song_lua_video_path_count);
        if let Some(path) = self.current_foreground_path.as_ref()
            && deadlib_assets::dynamic::is_dynamic_video_path(path)
            && !self
                .active_song_lua_video_paths
                .iter()
                .any(|existing| existing == path)
        {
            self.active_song_lua_video_paths.push(path.clone());
        }
        true
    }
    pub fn for_each_sound_event(&mut self, previous: f32, now: f32, mut visit: impl FnMut(&Path)) {
        prepare::visit_scheduled_song_lua_sound_events(
            &self.song_lua_sound_events,
            &mut self.next_song_lua_sound_event_ix,
            previous,
            now,
            &mut visit,
        );
    }

    pub fn video_paths(&self) -> &[PathBuf] {
        &self.active_song_lua_video_paths
    }

    /// Visit movie clocks from actor updates, including paused/invisible movies.
    pub fn for_each_video_position<
        P: deadsync_gameplay::GameplayProfileData,
        S: NoteskinSlot + Clone,
    >(
        &mut self,
        gameplay: &GameplayCoreState<P, S>,
        mut visit: impl FnMut(&Path, f32, bool),
    ) {
        self.movies.sample(gameplay, &mut visit);
        if let Some(path) = self.current_foreground_path.as_deref()
            && crate::is_song_lua_video_path(path)
            && let Some(change) = self
                .next_foreground_change_ix
                .checked_sub(1)
                .and_then(|index| gameplay.song().foreground_changes.get(index))
        {
            let start = gameplay.music_time_for_beat(change.start_beat);
            visit(
                path,
                (gameplay.current_music_time_display() - start).max(0.0),
                true,
            );
        }
    }
}

#[derive(Clone, Copy)]
/// Game/session viewing options, including editor overrides; not theme policy.
pub struct FrameOptions {
    /// Monotonic host draw time, independent of song rate, pauses and layer start.
    pub uptime_seconds: f64,
    pub play_style: deadsync_gameplay::GameplayInputPlayStyle,
    pub player_side: deadsync_gameplay::GameplayInputPlayerSide,
    pub notefield: NotefieldViewOverride,
    pub hide_song_bg: [bool; MAX_PLAYERS],
    pub hide_gameplay_hud: bool,
    pub apply_attacks: bool,
    pub show_song_visuals: bool,
}

/// Fragments retain their original placement around the shared chart layers.
/// Capture visibility and target meanings belong to this compositor.
#[derive(Clone, Copy)]
pub enum ScreenLayer {
    Background,
    ExitPrompt,
    Lobby,
    ExitFade,
    Danger,
    Filter,
    Header,
    Hud,
    Stage,
    Score(usize),
    System,
}

#[derive(Clone, Copy, Default)]
pub struct FieldLayout {
    pub per_player_fields: [(usize, f32); MAX_PLAYERS],
    pub playfield_center_x: f32,
}

pub struct FieldFrame {
    pub player: usize,
    pub placement: FieldPlacement,
    pub judgment_visible: bool,
    pub combo_visible: bool,
    pub judgment_transform: Option<deadsync_notefield::HudActorTransform>,
    pub combo_transform: Option<deadsync_notefield::HudActorTransform>,
    pub capture: ProxyCaptureRequests,
    pub wrapper: Matrix4,
    pub wrapper_visible: bool,
    /// A Lua-moved Player's own position, which centers the field perspective.
    pub player_position: Option<deadsync_notefield::SongLuaPlayerPosition>,
}

fn song_lua_field_wrapper(actor: &crate::SongLuaCapturedActor, clock: [f32; 2]) -> (Matrix4, bool) {
    let (matrix, _, visible) = song_lua_wrapper_chain(&actor.note_field_frames, clock);
    (matrix, visible)
}

/// Sample a baked wrapper chain: its native screen-space matrix (outermost
/// first), the diffuse Actor::Draw hands inward, and whether every wrapper
/// draws (an invisible or transparent wrapper aborts the wrapped draw).
fn song_lua_wrapper_chain(
    frames: &[crate::SongLuaNoteFieldFrame],
    clock: [f32; 2],
) -> (Matrix4, [f32; 4], bool) {
    song_lua_render_chain(frames, clock, false)
}

fn song_lua_render_chain(
    frames: &[crate::SongLuaNoteFieldFrame],
    clock: [f32; 2],
    captured_child: bool,
) -> (Matrix4, [f32; 4], bool) {
    let next = frames.partition_point(|frame| frame.second <= clock[0]);
    let Some(from) = next.checked_sub(1).map(|index| &frames[index]) else {
        return (Matrix4::IDENTITY, [1.0; 4], true);
    };
    let to = frames.get(next).unwrap_or(from);
    let t = if to.second > from.second {
        (clock[0] - from.second) / (to.second - from.second)
    } else {
        0.0
    };
    let mut matrix = Matrix4::IDENTITY;
    let mut tint = [1.0; 4];
    let mut visible = true;
    for (index, &initial) in from.wrappers.iter().enumerate() {
        let mut state = initial;
        if from.wrappers.len() == to.wrappers.len()
            && let Some((_, delta)) =
                crate::overlay_delta_pair_from_states(initial, initial, to.wrappers[index])
        {
            crate::overlay_state_lerp(&mut state, &delta, t);
        }
        visible &= !state.hibernating
            && (state.visible || (captured_child && index + 1 == from.wrappers.len()))
            && state.diffuse[3] > 0.0;
        let (model, diffuse) = song_lua_draw_matrix(state, clock);
        matrix *= model;
        tint = std::array::from_fn(|channel| tint[channel] * diffuse[channel]);
    }
    (matrix, tint, visible)
}

const fn hidden_gameplay_hud_layers(
    hide_gameplay_hud: bool,
    song_lua_hidden_layers: [bool; 2],
    captured_layers: [bool; 2],
) -> [bool; 2] {
    [
        hide_gameplay_hud || (song_lua_hidden_layers[0] && !captured_layers[0]),
        hide_gameplay_hud || (song_lua_hidden_layers[1] && !captured_layers[1]),
    ]
}

/// Compose chart actors around theme fragments using the shared target semantics.
/// The immutable simulation is never advanced here. Keep `frame_scratch` and
/// `actors` alive while consuming the returned segments; reuse both next frame.
/// This state machine deliberately keeps capture ordering and draw ordering in
/// one place, since moving a fragment across a capture boundary changes charts.
pub fn compose_frame<P: deadsync_gameplay::GameplayProfileData, S: NoteskinSlot + Clone>(
    actors: &mut Vec<Actor>,
    state: &GameplayCoreState<P, S>,
    media: &SongMedia,
    frame_scratch: &mut FrameScratch,
    asset_manager: &AssetManager,
    view: FrameOptions,
    mut draw_layer: impl FnMut(ScreenLayer, &mut Vec<Actor>, FieldLayout),
    mut draw_field: impl FnMut(
        FieldFrame,
        &mut [NotefieldCameraCache; MAX_PLAYERS],
        &mut Vec<Actor>,
        &mut Vec<FlatDraw>,
        &mut Vec<Actor>,
        &mut Vec<FlatDraw>,
    ) -> deadsync_notefield::BuiltNotefield,
) -> GameplayActorSegments {
    if !frame_scratch.song_lua_enabled {
        return native::compose_frame(
            actors,
            state,
            media,
            frame_scratch,
            view,
            draw_layer,
            draw_field,
        );
    }
    frame_scratch.refresh_live_wrappers(state.song_lua_visuals());
    let FrameScratch {
        song_lua_enabled: _,
        dynamic_scene: _,
        render_targets,
        song_lua_overlay_order,
        song_lua_background_visual_layer_orders,
        song_lua_foreground_visual_layer_orders,
        song_lua_background_layer_activity,
        song_lua_foreground_layer_activity,
        song_lua_proxy_request_index,
        song_lua_background_overlay_topology_indices,
        song_lua_foreground_proxy_request_indices,
        song_lua_aft_capture_scratch,
        song_lua_background_aft_capture_scratch,
        song_lua_foreground_aft_capture_scratch,
        song_lua_projected_mesh_scratch,
        song_lua_background_projected_mesh_scratch,
        song_lua_foreground_projected_mesh_scratch,
        song_lua_message_state_cache,
        song_lua_background_layer_message_state_cache,
        song_lua_foreground_layer_message_state_cache,
        song_lua_player_message_state_cache,
        song_lua_player_judgment_message_state_cache,
        song_lua_player_combo_message_state_cache,
        song_lua_song_foreground_message_state_cache,
        screen_layer_caches,
        song_lua_background_song_foreground_message_state_cache,
        song_lua_foreground_song_foreground_message_state_cache,
        song_lua_local_state_scratch,
        song_lua_overlay_state_scratch,
        song_lua_background_layer_local_state_scratch,
        song_lua_background_layer_state_scratch,
        song_lua_foreground_layer_local_state_scratch,
        song_lua_foreground_layer_state_scratch,
        song_lua_capture_state_scratch,
        song_lua_order_scratch,
        song_lua_capture_order_scratch,
        song_lua_capture_visit_scratch,
        song_lua_proxy_actor_scratch,
        song_lua_direct_proxies,
        song_lua_screen_projection_ranges,
        screen_capture_originals,
        notefield_actor_scratch,
        notefield_flat_draw_scratch,
        notefield_hud_actor_scratch,
        notefield_hud_flat_draw_scratch,
        notefield_underlay_actors,
        notefield_underlay_draws,
        notefield_camera_cache,
        player_actor_assembly_cache,
        player_field_camera_cache,
    } = frame_scratch;
    render_targets.clear();
    song_lua_direct_proxies.clear();
    song_lua_screen_projection_ranges.clear();
    screen_capture_originals.actors.clear();
    screen_capture_originals.ranges.clear();
    for player in 0..MAX_PLAYERS {
        notefield_underlay_actors[player].clear();
        notefield_underlay_draws[player].clear();
    }

    let notefield_view = view.notefield;
    let hide_gameplay_hud = view.hide_gameplay_hud;
    let apply_attacks = view.apply_attacks;
    let show_song_visuals = view.show_song_visuals;
    actors.reserve(96);
    let play_style = view.play_style;
    let player_side = view.player_side;
    let runtime_player_is_p2 =
        deadsync_gameplay::gameplay_runtime_player_is_p2(play_style, player_side);
    let song_lua_visuals = state.song_lua_visuals();
    let song_lua_space_width = song_lua_overlay_space_width(state);
    let song_lua_space_height = song_lua_overlay_space_height(state);
    let song_lua_now = state.current_music_time_display();
    let screen_layers: [SongLuaOverlayState; 4] = std::array::from_fn(|index| {
        if !show_song_visuals {
            return SongLuaOverlayState::default();
        }
        song_lua_captured_actor_state_from(
            song_lua_now,
            &song_lua_visuals.screen_layers[index],
            Some(&song_lua_visuals.screen_layer_events[index]),
            &mut screen_layer_caches[index],
        )
    });
    let hidden_song_layers = std::array::from_fn(|index| {
        show_song_visuals
            && (!screen_layers[index].draw_visible()
                || screen_layers[index].diffuse[3] <= f32::EPSILON)
    });
    song_lua_overlay_state_sets_from_into(
        song_lua_now,
        &song_lua_visuals.overlays,
        &song_lua_visuals.overlay_events,
        &song_lua_visuals.overlay_eases,
        &song_lua_visuals.overlay_ease_ranges,
        song_lua_visuals.screen_width,
        song_lua_visuals.screen_height,
        song_lua_overlay_order,
        song_lua_message_state_cache,
        song_lua_local_state_scratch,
        song_lua_overlay_state_scratch,
        [song_lua_now, state.current_beat()],
    );
    apply_song_lua_taps(
        &state.display.visual_feedback,
        state.cols_per_player(),
        state.total_elapsed_in_screen(),
        song_lua_now,
        &song_lua_visuals.overlays,
        song_lua_overlay_order,
        song_lua_local_state_scratch,
        song_lua_overlay_state_scratch,
        [
            song_lua_visuals.screen_width,
            song_lua_visuals.screen_height,
        ],
        [song_lua_now, state.current_beat()],
    );
    let song_lua_background_active_layers: &[usize] = if show_song_visuals {
        song_lua_background_layer_activity.sync(song_lua_now)
    } else {
        &[]
    };
    let song_lua_foreground_active_layers: &[usize] = if show_song_visuals {
        song_lua_foreground_layer_activity.sync(song_lua_now)
    } else {
        &[]
    };
    for &layer_idx in song_lua_background_active_layers {
        let layer = &song_lua_visuals.background_visual_layers[layer_idx];
        let local_states = &mut song_lua_background_layer_local_state_scratch[layer_idx];
        let layer_states = &mut song_lua_background_layer_state_scratch[layer_idx];
        let message_caches = &mut song_lua_background_layer_message_state_cache[layer_idx];
        song_lua_overlay_state_sets_from_into(
            song_lua_now,
            &layer.overlays,
            &layer.overlay_events,
            &layer.overlay_eases,
            &layer.overlay_ease_ranges,
            layer.screen_width,
            layer.screen_height,
            &mut song_lua_background_visual_layer_orders[layer_idx],
            message_caches,
            local_states,
            layer_states,
            [song_lua_now, state.current_beat()],
        );
        apply_song_lua_taps(
            &state.display.visual_feedback,
            state.cols_per_player(),
            state.total_elapsed_in_screen(),
            song_lua_now,
            &layer.overlays,
            &mut song_lua_background_visual_layer_orders[layer_idx],
            local_states,
            layer_states,
            [layer.screen_width, layer.screen_height],
            [song_lua_now, state.current_beat()],
        );
    }
    for &layer_idx in song_lua_foreground_active_layers {
        let layer = &song_lua_visuals.foreground_visual_layers[layer_idx];
        let local_states = &mut song_lua_foreground_layer_local_state_scratch[layer_idx];
        let layer_states = &mut song_lua_foreground_layer_state_scratch[layer_idx];
        let message_caches = &mut song_lua_foreground_layer_message_state_cache[layer_idx];
        song_lua_overlay_state_sets_from_into(
            song_lua_now,
            &layer.overlays,
            &layer.overlay_events,
            &layer.overlay_eases,
            &layer.overlay_ease_ranges,
            layer.screen_width,
            layer.screen_height,
            &mut song_lua_foreground_visual_layer_orders[layer_idx],
            message_caches,
            local_states,
            layer_states,
            [song_lua_now, state.current_beat()],
        );
        apply_song_lua_taps(
            &state.display.visual_feedback,
            state.cols_per_player(),
            state.total_elapsed_in_screen(),
            song_lua_now,
            &layer.overlays,
            &mut song_lua_foreground_visual_layer_orders[layer_idx],
            local_states,
            layer_states,
            [layer.screen_width, layer.screen_height],
            [song_lua_now, state.current_beat()],
        );
    }
    let mut proxy_analysis = if show_song_visuals {
        song_lua_proxy_request_analysis_indexed(
            &song_lua_visuals.overlays,
            song_lua_overlay_state_scratch,
            song_lua_proxy_request_index,
            song_lua_capture_visit_scratch,
        )
    } else {
        SongLuaProxyRequestAnalysis::default()
    };
    for &layer_idx in song_lua_foreground_active_layers {
        let layer = &song_lua_visuals.foreground_visual_layers[layer_idx];
        let layer_states = &song_lua_foreground_layer_state_scratch[layer_idx];
        let request_index = &song_lua_foreground_proxy_request_indices[layer_idx];
        song_lua_merge_proxy_analysis(
            &mut proxy_analysis,
            song_lua_proxy_request_analysis_indexed(
                &layer.overlays,
                layer_states,
                request_index,
                song_lua_capture_visit_scratch,
            ),
        );
    }
    let screen_state = song_lua_visuals
        .screen_overlay_index
        .and_then(|index| song_lua_overlay_state_scratch.get(index))
        .filter(|_| show_song_visuals)
        .copied();
    let screen_projection = screen_state.map_or(Matrix4::IDENTITY, |screen| {
        song_lua_screen_projection(
            screen,
            [song_lua_space_width, song_lua_space_height],
            [song_lua_now, state.current_beat()],
        )
    });
    let screen_world = screen_state.map_or(Matrix4::IDENTITY, |screen| {
        deadsync_notefield::song_lua_screen_matrix_to_world(
            song_lua_draw_matrix(screen, [song_lua_now, state.current_beat()]).0,
            screen_width(),
            screen_height(),
        )
    });
    let mut manual_requests = SongLuaScreenProxyRequests::default();
    if show_song_visuals {
        // Release the bank about to be reused before refilling its source
        // buffers. Otherwise our own old captures force Arc replacements.
        song_lua_aft_capture_scratch.manual.release_next();
        manual_requests = song_lua_aft_capture_scratch.manual.requests(song_lua_now);
        for &layer in song_lua_foreground_active_layers {
            song_lua_foreground_aft_capture_scratch[layer]
                .manual
                .release_next();
            let requests = song_lua_foreground_aft_capture_scratch[layer]
                .manual
                .requests(song_lua_now);
            song_lua_merge_proxy_requests(&mut manual_requests, requests);
        }
        song_lua_merge_proxy_requests(&mut proxy_analysis.all, manual_requests);
        song_lua_merge_proxy_requests(&mut proxy_analysis.captured, manual_requests);
    }
    if let Some(scratch) = song_lua_proxy_actor_scratch.as_mut() {
        scratch.begin_frame();
    }
    let proxy_requests = proxy_analysis.all;
    // ActorProxy::DrawPrimitives temporarily makes its target visible. Hidden
    // originals still need populated HUD sources when a proxy draws them.
    let [hide_underlay_hud, hide_overlay_hud] = hidden_gameplay_hud_layers(
        hide_gameplay_hud,
        hidden_song_layers,
        [proxy_requests.underlay, proxy_requests.overlay],
    );
    let mut covering_proxy_requests = if show_song_visuals {
        song_lua_covering_capture_requests(
            &song_lua_visuals.overlays,
            song_lua_local_state_scratch,
            song_lua_overlay_state_scratch,
            song_lua_proxy_request_index,
            song_lua_space_width,
            song_lua_space_height,
            song_lua_capture_visit_scratch,
        )
    } else {
        SongLuaScreenProxyRequests::default()
    };
    for &layer_idx in song_lua_foreground_active_layers {
        let layer = &song_lua_visuals.foreground_visual_layers[layer_idx];
        let layer_states = &song_lua_foreground_layer_state_scratch[layer_idx];
        let request_index = &song_lua_foreground_proxy_request_indices[layer_idx];
        let covering = song_lua_covering_capture_requests(
            &layer.overlays,
            &song_lua_foreground_layer_local_state_scratch[layer_idx],
            layer_states,
            request_index,
            layer.screen_width.max(1.0),
            layer.screen_height.max(1.0),
            song_lua_capture_visit_scratch,
        );
        song_lua_merge_proxy_requests(&mut covering_proxy_requests, covering);
    }
    let retain_underlay_original = !hidden_song_layers[0]
        && !proxy_requests.hide_underlay
        && !covering_proxy_requests.underlay;
    let retain_overlay_original =
        !hidden_song_layers[1] && !proxy_requests.hide_overlay && !covering_proxy_requests.overlay;
    let direct_player_candidates: [bool; MAX_PLAYERS] = std::array::from_fn(|player| {
        proxy_analysis.root_players[player] != 0
            && !proxy_analysis.captured.players[player].player
            && !proxy_analysis.captured.players[player].note_field
            && !proxy_analysis.captured.players[player].judgment
            && !proxy_analysis.captured.players[player].combo
            && !notefield_view.edit_beat_bars
    });
    let direct_note_field_candidates: [bool; MAX_PLAYERS] = std::array::from_fn(|player| {
        proxy_analysis.root_note_fields[player] != 0
            && song_lua_visuals.player_actors[player]
                .note_field_frames
                .is_empty()
            && !proxy_analysis.captured.players[player].note_field
            && (!proxy_requests.players[player].player || direct_player_candidates[player])
    });
    let direct_judgment_candidates: [bool; MAX_PLAYERS] = std::array::from_fn(|player| {
        proxy_analysis.root_judgments[player] != 0
            && song_lua_visuals.player_actors[player]
                .judgment
                .render_frames
                .is_empty()
            && !proxy_analysis.captured.players[player].judgment
            && (!proxy_requests.players[player].player || direct_player_candidates[player])
    });
    let direct_combo_candidates: [bool; MAX_PLAYERS] = std::array::from_fn(|player| {
        proxy_analysis.root_combos[player] != 0
            && song_lua_visuals.player_actors[player]
                .combo
                .render_frames
                .is_empty()
            && !proxy_analysis.captured.players[player].combo
            && (!proxy_requests.players[player].player || direct_player_candidates[player])
    });
    let mut underlay_proxy_source = proxy_requests
        .underlay
        .then_some(SongLuaActorSegments::new());
    let mut overlay_proxy_source = proxy_requests
        .overlay
        .then_some(SongLuaActorSegments::new());
    let mut background_source = proxy_requests
        .background
        .then_some(SongLuaActorSegments::new());
    // --- Background and Filter ---
    // ScreenGameplay is outside the independent song layer trees. Its camera
    // supplies their default projection; an authored inner camera still wins
    // and AFT captures keep their separate orthographic viewport.
    let screen_camera = song_lua_visuals
        .screen_overlay_index
        .and_then(|index| song_lua_overlay_state_scratch.get(index))
        .copied()
        .filter(|_| show_song_visuals);
    let underlay_start = actors.len();
    if show_song_visuals
        && (proxy_requests.background
            || (screen_layers[2].draw_visible() && screen_layers[2].diffuse[3] > f32::EPSILON))
    {
        draw_layer(ScreenLayer::Background, actors, FieldLayout::default());
        for actor in &mut actors[underlay_start..] {
            song_lua_style_capture_actor_in_place(actor, screen_layers[2].diffuse, None, 0);
        }
    }
    for &layer_idx in song_lua_background_active_layers {
        let layer = &song_lua_visuals.background_visual_layers[layer_idx];
        let local_states = &song_lua_background_layer_local_state_scratch[layer_idx];
        let layer_states = &song_lua_background_layer_state_scratch[layer_idx];
        let Some(order_cache) = song_lua_background_visual_layer_orders.get_mut(layer_idx) else {
            continue;
        };
        let Some(topology_index) = song_lua_background_overlay_topology_indices.get_mut(layer_idx)
        else {
            continue;
        };
        let Some(aft_capture_scratch) = song_lua_background_aft_capture_scratch.get_mut(layer_idx)
        else {
            continue;
        };
        let Some(projected_mesh_scratch) =
            song_lua_background_projected_mesh_scratch.get_mut(layer_idx)
        else {
            continue;
        };
        let song_foreground_state = song_lua_song_foreground_state_from(
            song_lua_now,
            &layer.song_foreground,
            layer.song_foreground_events.as_slice(),
            &mut song_lua_background_song_foreground_message_state_cache[layer_idx],
        );
        // Background layers have an independent compiled tree, while the live
        // SongBackground pose is retained on ScreenGameplay. Its transform must
        // precede each layer, including compensation for a moved screen.
        let mut background_parent = screen_layers[2];
        if background_source.is_some() {
            // ActorProxy can draw the hidden target; final capture retention
            // below still uses SongBackground's actual visibility.
            background_parent.visible = true;
            background_parent.hibernating = false;
        }
        let song_foreground_state = song_lua_layer_parent_state::<S>(
            background_parent,
            song_foreground_state,
            [layer.screen_width, layer.screen_height],
            [song_lua_now, state.current_beat()],
        );
        push_song_lua_layer_actors(
            actors,
            render_targets,
            &layer.overlays,
            order_cache,
            topology_index,
            local_states,
            layer_states,
            song_foreground_state,
            screen_camera,
            song_lua_screen_projection_ranges,
            background_source.is_some().then_some(&mut *screen_capture_originals),
            &SongLuaScreenProxySources::default(),
            None,
            None,
            asset_manager,
            layer.screen_width.max(1.0),
            layer.screen_height.max(1.0),
            song_lua_now,
            state.current_beat(),
            SongLuaDrawTime {
                animation_elapsed: state.total_elapsed_in_screen(),
                uptime_seconds: view.uptime_seconds,
            },
            song_lua_order_scratch,
            song_lua_capture_state_scratch,
            song_lua_capture_order_scratch,
            aft_capture_scratch,
            projected_mesh_scratch,
            SONG_LUA_BACKGROUND_DEPTH,
        );
    }
    song_lua_capture_screen_actors(
        &mut background_source,
        actors,
        underlay_start,
        song_lua_proxy_actor_scratch.as_mut(),
        screen_layers[2].draw_visible(),
        song_lua_screen_projection_ranges,
        screen_capture_originals,
    );
    native::push_background_cover(actors, state, view);

    // Native exit prompts participate in the Overlay capture target.
    if !hide_overlay_hud {
        let overlay_start = actors.len();
        draw_layer(ScreenLayer::ExitPrompt, actors, FieldLayout::default());
        for actor in &mut actors[overlay_start..] {
            song_lua_style_capture_actor_in_place(actor, screen_layers[1].diffuse, None, 0);
        }
        song_lua_capture_new_actors(
            &mut overlay_proxy_source,
            actors,
            overlay_start,
            song_lua_proxy_actor_scratch.as_mut(),
            retain_overlay_original,
        );
    }

    if !hide_overlay_hud {
        let overlay_start = actors.len();
        draw_layer(ScreenLayer::Lobby, actors, FieldLayout::default());
        for actor in &mut actors[overlay_start..] {
            song_lua_style_capture_actor_in_place(actor, screen_layers[1].diffuse, None, 0);
        }
        song_lua_capture_new_actors(
            &mut overlay_proxy_source,
            actors,
            overlay_start,
            song_lua_proxy_actor_scratch.as_mut(),
            retain_overlay_original,
        );
    }

    // Exit visuals participate in the Overlay capture target.
    let overlay_start = actors.len();
    draw_layer(ScreenLayer::ExitFade, actors, FieldLayout::default());
    for actor in &mut actors[overlay_start..] {
        song_lua_style_capture_actor_in_place(actor, screen_layers[1].diffuse, None, 0);
    }
    song_lua_capture_new_actors(
        &mut overlay_proxy_source,
        actors,
        overlay_start,
        song_lua_proxy_actor_scratch.as_mut(),
        retain_overlay_original,
    );

    let mut manual_player_sources: [Option<SongLuaManualPlayerSource>; MAX_PLAYERS] =
        std::array::from_fn(|_| None);
    let mut player_hud_parts = [deadsync_notefield::NotefieldHudParts::default(); MAX_PLAYERS];
    let mut player_field_screen_projections = [screen_projection; MAX_PLAYERS];
    let mut captured_player_field_ranges = [None; MAX_PLAYERS];
    let mut build_player_bundle =
        |player_idx: usize, placement: FieldPlacement, requests: SongLuaPlayerProxyRequests| {
            let field_scratch = &mut notefield_actor_scratch[player_idx];
            let flat_draw_scratch = &mut notefield_flat_draw_scratch[player_idx];
            let hud_scratch = &mut notefield_hud_actor_scratch[player_idx];
            let hud_flat_draw_scratch = &mut notefield_hud_flat_draw_scratch[player_idx];
            let player_actor = &song_lua_visuals.player_actors[player_idx];
            let song_lua_now = state.current_music_time_display();
            let song_lua_clock = [song_lua_now, state.current_beat_display()];
            let (field_wrapper, field_wrapper_visible) = if show_song_visuals {
                song_lua_field_wrapper(player_actor, song_lua_clock)
            } else {
                (Matrix4::IDENTITY, true)
            };
            // Player::PushPlayerMatrix centers the field perspective on the
            // Player's own GetX/GetY, so both are needed before the field draws.
            let lua_player_state = show_song_visuals.then(|| {
                song_lua_player_render_state(
                    state,
                    player_idx,
                    &mut song_lua_player_message_state_cache[player_idx],
                )
            });
            let player_transform = if apply_attacks {
                state.song_lua_player_transform(player_idx)
            } else {
                deadsync_gameplay::SongLuaPlayerTransform::default()
            };
            let (player_wrappers, player_wrapper_tint, player_wrappers_visible) =
                if show_song_visuals {
                    song_lua_wrapper_chain(&player_actor.player_wrapper_frames, song_lua_clock)
                } else {
                    (Matrix4::IDENTITY, [1.0; 4], true)
                };
            let player_position = deadsync_notefield::SongLuaPlayerPosition {
                x: player_transform.x.or_else(|| {
                    lua_player_state
                        .filter(|_| !notefield_view.force_center_1player)
                        .map(|player_state| player_state.x)
                }),
                y: player_transform.y.unwrap_or_else(|| {
                    lua_player_state.map_or_else(screen_center_y, |player_state| player_state.y)
                }),
            };
            let ((judgment_transform, judgment_visible), (combo_transform, combo_visible)) =
                if show_song_visuals {
                    let judgment = song_lua_child_render(
                        song_lua_now,
                        song_lua_clock,
                        &player_actor.judgment,
                        &song_lua_visuals.player_judgment_events[player_idx],
                        &mut song_lua_player_judgment_message_state_cache[player_idx],
                        requests.judgment,
                    );
                    let combo = song_lua_child_render(
                        song_lua_now,
                        song_lua_clock,
                        &player_actor.combo,
                        &song_lua_visuals.player_combo_events[player_idx],
                        &mut song_lua_player_combo_message_state_cache[player_idx],
                        requests.combo,
                    );
                    (judgment, combo)
                } else {
                    ((None, true), (None, true))
                };
            let deadsync_notefield::BuiltNotefield {
                layout_center_x,
                field_camera,
                field_camera_generation,
                field_actors,
                field_draw_range,
                judgment_actors,
                mut judgment_draw_range,
                combo_actors,
                mut combo_draw_range,
                hud_parts,
            } = draw_field(
                FieldFrame {
                    wrapper: field_wrapper,
                    wrapper_visible: field_wrapper_visible,
                    player_position: Some(player_position),
                    player: player_idx,
                    placement,
                    judgment_visible,
                    combo_visible,
                    judgment_transform,
                    combo_transform,
                    capture: ProxyCaptureRequests {
                        player: requests.player && !direct_player_candidates[player_idx],
                        // Whole-player captures consume the same field source, so
                        // materialize compact notes into that cold actor capture.
                        note_field: (requests.note_field
                            && !direct_note_field_candidates[player_idx])
                            || (requests.player && !direct_player_candidates[player_idx]),
                        direct_note_field: requests.note_field
                            && direct_note_field_candidates[player_idx],
                        judgment: requests.judgment && !direct_judgment_candidates[player_idx],
                        direct_judgment: requests.judgment
                            && direct_judgment_candidates[player_idx],
                        combo: requests.combo && !direct_combo_candidates[player_idx],
                        direct_combo: requests.combo && direct_combo_candidates[player_idx],
                    },
                },
                notefield_camera_cache,
                field_scratch,
                flat_draw_scratch,
                hud_scratch,
                hud_flat_draw_scratch,
            );
            notefield_underlay_actors[player_idx]
                .extend(hud_scratch.drain(..hud_parts.underlay_actors));
            notefield_underlay_draws[player_idx]
                .extend(hud_flat_draw_scratch.drain(..hud_parts.underlay_draws));
            for range in [&mut judgment_draw_range, &mut combo_draw_range]
                .into_iter()
                .flatten()
            {
                range.start -= hud_parts.underlay_draws;
                range.end -= hud_parts.underlay_draws;
            }
            player_hud_parts[player_idx] = deadsync_notefield::NotefieldHudParts {
                underlay_actors: 0,
                underlay_draws: 0,
                ..hud_parts
            };
            let mut player_state = lua_player_state.unwrap_or(SongLuaOverlayState {
                x: layout_center_x,
                y: screen_center_y(),
                ..SongLuaOverlayState::default()
            });
            // Actor::Draw aborts inside an invisible or transparent wrapper.
            player_state.visible &= player_wrappers_visible;
            let song_lua_active =
                show_song_visuals && !state.song().foreground_lua_changes.is_empty();
            let rotation_x = player_state.rot_x_deg + player_transform.rotation_x;
            let rotation_z = player_state.rot_z_deg + player_transform.rotation_z;
            let rotation_y = player_state.rot_y_deg + player_transform.rotation_y;
            let skew_x = player_transform.skew_x;
            let skew_y = player_transform.skew_y;
            let [player_scale_x, player_scale_y] = song_lua_overlay_axis_scale(player_state);
            let player_scale_z = song_lua_overlay_z_scale(player_state);
            let zoom_x = player_scale_x * player_transform.zoom_x;
            let zoom_y = player_scale_y * player_transform.zoom_y;
            let zoom_z = player_scale_z * player_transform.zoom_z;
            let target_x = song_lua_player_target_x(
                player_transform.x,
                player_state.x,
                layout_center_x,
                notefield_view,
            );
            let target_y = player_transform.y.unwrap_or(player_state.y);
            let z_shift = song_lua_player_layer_z(song_lua_active);
            let player_blend = match player_state.blend {
                SongLuaOverlayBlendMode::NoEffect => Some(BlendMode::NoEffect),
                SongLuaOverlayBlendMode::Alpha => None,
                SongLuaOverlayBlendMode::Add => Some(BlendMode::Add),
                SongLuaOverlayBlendMode::Multiply => Some(BlendMode::Multiply),
                SongLuaOverlayBlendMode::Subtract => Some(BlendMode::Subtract),
            };
            let capture_transform = SongLuaCaptureTransform {
                z_shift,
                // Wrappers pass their diffuse inward as the Player's internal diffuse.
                tint: std::array::from_fn(|channel| {
                    player_state.diffuse[channel] * player_wrapper_tint[channel]
                }),
                blend: player_blend,
                playfield_center_x: layout_center_x,
                target_x,
                target_y,
                rotation_x,
                rotation_z,
                rotation_y,
                skew_x,
                skew_y,
                zoom_x,
                zoom_y,
                zoom_z,
                target_z: player_state.z + player_transform.z,
                wrappers: player_wrappers,
                field_camera_parts: notefield_camera_cache[player_idx].camera_parts(),
            };
            // Player replaces the camera for NoteField while ScreenGameplay's
            // world transform remains on the stack. Use the pure menu camera;
            // the child model can contain a singular authored zoom.
            player_field_screen_projections[player_idx] = capture_transform
                .field_camera_parts
                .map_or(screen_projection, |(camera, _)| {
                    song_lua_camera_world_projection(camera, screen_world)
                });
            let proxy_field_camera = field_camera;
            if manual_requests.players[player_idx].player {
                let scratch = song_lua_proxy_actor_scratch
                    .as_mut()
                    .expect("compiled manual Player draw has song-lifetime capture backing");
                manual_player_sources[player_idx] = Some(capture_manual_player(
                    field_actors.clone(),
                    hud_scratch,
                    hud_parts.combo_actors,
                    [layout_center_x, screen_center_y()],
                    notefield_camera_cache[player_idx],
                    &mut scratch.banks[scratch.active_bank].players[player_idx],
                ));
            }
            let mut assembly = player_actor_assembly_cache[player_idx].resolve(
                requests.player && !direct_player_candidates[player_idx],
                player_state.draw_visible() && !covering_proxy_requests.players[player_idx].player,
                capture_transform,
            );
            let assembly_field_camera = prepare_player_field_camera(
                &mut assembly,
                field_camera,
                capture_transform.field_camera_parts,
                field_scratch,
            );
            let field_camera = match assembly {
                PlayerActorAssembly::DirectTransform {
                    root_camera,
                    field_camera_suffix,
                    ..
                } => Some(player_field_camera_cache[player_idx].resolve(
                    field_camera_generation,
                    player_actor_assembly_cache[player_idx].generation(),
                    assembly_field_camera,
                    root_camera,
                    field_camera_suffix,
                )),
                _ => field_camera,
            };
            let direct_player = direct_player_candidates[player_idx]
                && song_lua_player_transform_is_direct_proxy(capture_transform)
                && field_scratch.is_empty()
                && hud_scratch.is_empty();
            let needs_direct_camera = direct_player
                || direct_note_field_candidates[player_idx]
                || direct_judgment_candidates[player_idx]
                || direct_combo_candidates[player_idx];
            let direct_camera_suffix = needs_direct_camera
                .then(|| song_lua_player_camera_suffix(capture_transform))
                .flatten();
            let direct_hud_camera = direct_camera_suffix.map(song_lua_player_root_camera);
            let direct_field_camera = song_lua_field_camera_with_player(
                proxy_field_camera,
                capture_transform.field_camera_parts,
                direct_camera_suffix,
            );
            let captured_player_source = if requests.player && !direct_player {
                let scratch = song_lua_proxy_actor_scratch
                    .as_mut()
                    .and_then(|scratch| scratch.player(player_idx, SONG_LUA_PLAYER_PROXY_SOURCE))
                    .expect("compiled player proxy has song-lifetime capture backing");
                if direct_player_candidates[player_idx] {
                    capture_flat_player_source(
                        field_scratch,
                        flat_draw_scratch,
                        proxy_field_camera,
                        hud_scratch,
                        hud_flat_draw_scratch,
                        hud_parts.combo_actors + hud_parts.combo_draws,
                        capture_transform,
                        scratch,
                    )
                } else {
                    capture_player_source(
                        field_scratch,
                        hud_scratch,
                        hud_parts.combo_actors,
                        capture_transform,
                        scratch,
                    )
                }
            } else {
                None
            };
            if matches!(assembly, PlayerActorAssembly::Captured)
                && screen_world != Matrix4::IDENTITY
                && let Some(source) = &captured_player_source
            {
                let camera = if song_lua_player_transform_is_direct_identity(capture_transform) {
                    proxy_field_camera
                } else {
                    song_lua_field_camera_with_player(
                        proxy_field_camera,
                        capture_transform.field_camera_parts,
                        song_lua_player_camera_suffix(capture_transform),
                    )
                };
                // Keep the source local for ActorProxy consumers. Only the
                // ordinary Player draw separates its closed field camera scope
                // from the Combo/Judgment spans that retain the screen camera.
                captured_player_field_ranges[player_idx] = camera.and_then(|camera| {
                    song_lua_captured_camera_range(
                        song_lua_captured_segment_actors(&source[0]),
                        camera,
                    )
                });
            }
            let player_source = captured_player_source.map(PreparedProxySource::new);
            let direct_player_source = direct_player
                .then(|| {
                    // Whole-Player capture retains the Player transform in the
                    // source and lets ActorProxy add its authored placement.
                    let target = [0.0, 0.0];
                    let suffix = direct_camera_suffix.unwrap_or(Matrix4::IDENTITY);
                    let root_base = song_lua_player_root_camera(Matrix4::IDENTITY);
                    [
                        SongLuaDirectProxySource {
                            draws: SongLuaDirectDraws::Combo,
                            draw_start: 0,
                            draw_end: hud_parts.combo_draws,
                            target,
                            tint: capture_transform.tint,
                            camera: direct_hud_camera,
                            player_camera: Some(SongLuaDirectPlayerCamera {
                                base: root_base,
                                suffix,
                            }),
                        },
                        SongLuaDirectProxySource {
                            draws: SongLuaDirectDraws::Field,
                            draw_start: 0,
                            draw_end: flat_draw_scratch.len(),
                            target,
                            tint: capture_transform.tint,
                            camera: direct_field_camera,
                            player_camera: Some(SongLuaDirectPlayerCamera {
                                base: capture_transform.field_camera_parts.map_or_else(
                                    || proxy_field_camera.unwrap_or(root_base),
                                    |(camera, _)| camera,
                                ),
                                suffix: capture_transform.field_camera_parts.map_or(
                                    suffix,
                                    |(_, model)| suffix * model,
                                ),
                            }),
                        },
                        SongLuaDirectProxySource {
                            draws: SongLuaDirectDraws::Judgment,
                            draw_start: hud_parts.combo_draws,
                            draw_end: hud_flat_draw_scratch.len(),
                            target,
                            tint: capture_transform.tint,
                            camera: direct_hud_camera,
                            player_camera: Some(SongLuaDirectPlayerCamera {
                                base: root_base,
                                suffix,
                            }),
                        },
                    ]
                })
                .filter(|sources| {
                    sources
                        .iter()
                        .any(|source| source.draw_start < source.draw_end)
                });
            let direct_note_field = direct_note_field_candidates[player_idx]
                && song_lua_player_transform_is_direct_proxy(capture_transform)
                && field_scratch.is_empty();
            let direct_note_field_source = direct_note_field
                .then_some(field_draw_range.as_ref())
                .flatten()
                .map(|range| SongLuaDirectProxySource {
                    draws: SongLuaDirectDraws::Field,
                    draw_start: range.start,
                    draw_end: range.end,
                    target: [capture_transform.target_x, capture_transform.target_y],
                    tint: capture_transform.tint,
                    camera: direct_field_camera,
                    player_camera: None,
                });
            let mut note_field_source = if !player_actor.note_field_frames.is_empty() {
                // ActorProxy draws NoteField in its own local frame, without
                // Player's pose or perspective. Retain the child wrappers.
                field_actors.and_then(|source| {
                    let scratch = song_lua_proxy_actor_scratch
                        .as_mut()?
                        .player(player_idx, SONG_LUA_FIELD_PROXY_SOURCE)?;
                    let local = SongLuaCaptureTransform {
                        z_shift: 0,
                        tint: [1.0; 4],
                        blend: None,
                        playfield_center_x: layout_center_x,
                        target_x: layout_center_x,
                        target_y: screen_center_y(),
                        rotation_x: 0.0,
                        rotation_y: 0.0,
                        rotation_z: 0.0,
                        skew_x: 0.0,
                        skew_y: 0.0,
                        zoom_x: 1.0,
                        zoom_y: 1.0,
                        zoom_z: 1.0,
                        target_z: 0.0,
                        wrappers: Matrix4::IDENTITY,
                        field_camera_parts: None,
                    };
                    prepare_proxy_source(source, ProxyCapturePart::Field, local, scratch)
                })
            } else if direct_note_field_candidates[player_idx] {
                (!direct_note_field)
                    .then(|| {
                        let range = field_draw_range.clone().unwrap_or(0..0);
                        let draws = flat_draw_scratch.get(range).unwrap_or(&[]);
                        (draws, field_scratch)
                    })
                    .and_then(|(draws, actors)| {
                        let scratch = song_lua_proxy_actor_scratch
                            .as_mut()?
                            .player(player_idx, SONG_LUA_FIELD_PROXY_SOURCE)?;
                        prepare_field_proxy_source(
                            actors,
                            draws,
                            proxy_field_camera,
                            capture_transform,
                            scratch,
                        )
                    })
            } else {
                field_actors.and_then(|source| {
                    let scratch = song_lua_proxy_actor_scratch
                        .as_mut()?
                        .player(player_idx, SONG_LUA_FIELD_PROXY_SOURCE)?;
                    prepare_proxy_source(
                        source,
                        ProxyCapturePart::Field,
                        capture_transform,
                        scratch,
                    )
                })
            };
            if !player_actor.note_field_frames.is_empty()
                && let Some(source) = &mut note_field_source
            {
                source.model = notefield_camera_cache[player_idx].wrapper_model();
            }
            let direct_judgment = direct_judgment_candidates[player_idx]
                && song_lua_player_transform_is_direct_hud_proxy(capture_transform);
            let direct_judgment_source = direct_judgment
                .then_some(judgment_draw_range.as_ref())
                .flatten()
                .map(|range| SongLuaDirectProxySource {
                    draws: SongLuaDirectDraws::Judgment,
                    draw_start: range.start,
                    draw_end: range.end,
                    target: [capture_transform.target_x, capture_transform.target_y],
                    tint: capture_transform.tint,
                    camera: direct_hud_camera,
                    player_camera: None,
                });
            let judgment_source = if direct_judgment_candidates[player_idx] {
                (!direct_judgment)
                    .then_some(judgment_draw_range.as_ref())
                    .flatten()
                    .and_then(|range| {
                        let scratch = song_lua_proxy_actor_scratch
                            .as_mut()?
                            .player(player_idx, SONG_LUA_JUDGMENT_PROXY_SOURCE)?;
                        prepare_flat_proxy_source(
                            &hud_flat_draw_scratch[range.clone()],
                            capture_transform,
                            scratch,
                        )
                    })
            } else {
                judgment_actors.and_then(|source| {
                    let scratch = song_lua_proxy_actor_scratch
                        .as_mut()?
                        .player(player_idx, SONG_LUA_JUDGMENT_PROXY_SOURCE)?;
                    prepare_proxy_source(source, ProxyCapturePart::Hud, capture_transform, scratch)
                })
            };
            let direct_combo = direct_combo_candidates[player_idx]
                && song_lua_player_transform_is_direct_hud_proxy(capture_transform);
            let direct_combo_source = direct_combo
                .then_some(combo_draw_range.as_ref())
                .flatten()
                .map(|range| SongLuaDirectProxySource {
                    draws: SongLuaDirectDraws::Combo,
                    draw_start: range.start,
                    draw_end: range.end,
                    target: [capture_transform.target_x, capture_transform.target_y],
                    tint: capture_transform.tint,
                    camera: direct_hud_camera,
                    player_camera: None,
                });
            let combo_source = if direct_combo_candidates[player_idx] {
                (!direct_combo)
                    .then_some(combo_draw_range.as_ref())
                    .flatten()
                    .and_then(|range| {
                        let scratch = song_lua_proxy_actor_scratch
                            .as_mut()?
                            .player(player_idx, SONG_LUA_COMBO_PROXY_SOURCE)?;
                        prepare_flat_proxy_source(
                            &hud_flat_draw_scratch[range.clone()],
                            capture_transform,
                            scratch,
                        )
                    })
            } else {
                combo_actors.and_then(|source| {
                    let scratch = song_lua_proxy_actor_scratch
                        .as_mut()?
                        .player(player_idx, SONG_LUA_COMBO_PROXY_SOURCE)?;
                    prepare_proxy_source(source, ProxyCapturePart::Hud, capture_transform, scratch)
                })
            };
            let proxy_sources = [note_field_source, judgment_source, combo_source];
            (
                layout_center_x,
                player_source,
                direct_player_source,
                proxy_sources,
                direct_note_field_source,
                direct_judgment_source,
                direct_combo_source,
                assembly,
                field_camera,
            )
        };

    let (
        has_p2_actors,
        p1_player_proxy_source,
        p2_player_proxy_source,
        p1_direct_player,
        p2_direct_player,
        p1_proxy_sources,
        p2_proxy_sources,
        p1_direct_note_field,
        p2_direct_note_field,
        p1_direct_judgment,
        p2_direct_judgment,
        p1_direct_combo,
        p2_direct_combo,
        p1_actor_assembly,
        p2_actor_assembly,
        p1_field_camera,
        p2_field_camera,
        playfield_center_x,
        per_player_fields,
    ): (
        bool,
        Option<PreparedProxySource>,
        Option<PreparedProxySource>,
        Option<SongLuaDirectPlayerSource>,
        Option<SongLuaDirectPlayerSource>,
        [Option<PreparedProxySource>; 3],
        [Option<PreparedProxySource>; 3],
        Option<SongLuaDirectProxySource>,
        Option<SongLuaDirectProxySource>,
        Option<SongLuaDirectProxySource>,
        Option<SongLuaDirectProxySource>,
        Option<SongLuaDirectProxySource>,
        Option<SongLuaDirectProxySource>,
        PlayerActorAssembly,
        PlayerActorAssembly,
        Option<Matrix4>,
        Option<Matrix4>,
        f32,
        [(usize, f32); 2],
    ) = match play_style {
        style if style.is_versus() => {
            let (
                p1_x,
                p1_player_source,
                p1_direct_player,
                p1_sources,
                p1_direct_field,
                p1_direct_judgment,
                p1_direct_combo,
                p1_assembly,
                p1_camera,
            ) = build_player_bundle(0, FieldPlacement::P1, proxy_requests.players[0]);
            let (
                p2_x,
                p2_player_source,
                p2_direct_player,
                p2_sources,
                p2_direct_field,
                p2_direct_judgment,
                p2_direct_combo,
                p2_assembly,
                p2_camera,
            ) = build_player_bundle(1, FieldPlacement::P2, proxy_requests.players[1]);
            (
                true,
                p1_player_source,
                p2_player_source,
                p1_direct_player,
                p2_direct_player,
                p1_sources,
                p2_sources,
                p1_direct_field,
                p2_direct_field,
                p1_direct_judgment,
                p2_direct_judgment,
                p1_direct_combo,
                p2_direct_combo,
                p1_assembly,
                p2_assembly,
                p1_camera,
                p2_camera,
                p1_x,
                [(0, p1_x), (1, p2_x)],
            )
        }
        _ => {
            let placement = if runtime_player_is_p2 {
                FieldPlacement::P2
            } else {
                FieldPlacement::P1
            };
            let (
                nf_x,
                nf_player_source,
                nf_direct_player,
                nf_sources,
                nf_direct_field,
                nf_direct_judgment,
                nf_direct_combo,
                nf_assembly,
                nf_camera,
            ) = build_player_bundle(0, placement, proxy_requests.players[0]);
            (
                false,
                nf_player_source,
                None,
                nf_direct_player,
                None,
                nf_sources,
                [None, None, None],
                nf_direct_field,
                None,
                nf_direct_judgment,
                None,
                nf_direct_combo,
                None,
                nf_assembly,
                PlayerActorAssembly::Hidden,
                nf_camera,
                None,
                nf_x,
                [(0, nf_x), (usize::MAX, 0.0)],
            )
        }
    };
    let replacement_proxy_sources = [
        SongLuaPlayerProxySources {
            player: p1_player_proxy_source
                .as_ref()
                .map(PreparedProxySource::view),
            direct_player: p1_direct_player.is_some(),
            note_field: p1_proxy_sources[0].as_ref().map(PreparedProxySource::view),
            direct_note_field: p1_direct_note_field.is_some(),
            judgment: p1_proxy_sources[1].as_ref().map(PreparedProxySource::view),
            combo: p1_proxy_sources[2].as_ref().map(PreparedProxySource::view),
            direct_combo: p1_direct_combo.is_some(),
        },
        SongLuaPlayerProxySources {
            player: p2_player_proxy_source
                .as_ref()
                .map(PreparedProxySource::view),
            direct_player: p2_direct_player.is_some(),
            note_field: p2_proxy_sources[0].as_ref().map(PreparedProxySource::view),
            direct_note_field: p2_direct_note_field.is_some(),
            judgment: p2_proxy_sources[1].as_ref().map(PreparedProxySource::view),
            combo: p2_proxy_sources[2].as_ref().map(PreparedProxySource::view),
            direct_combo: p2_direct_combo.is_some(),
        },
    ];
    let mut replacement_active_players = if show_song_visuals {
        song_lua_replacement_active_players_indexed(
            &song_lua_visuals.overlays,
            song_lua_overlay_state_scratch,
            &replacement_proxy_sources,
            song_lua_proxy_request_index,
            song_lua_capture_visit_scratch,
        )
    } else {
        [false; MAX_PLAYERS]
    };
    for &layer_idx in song_lua_foreground_active_layers {
        let layer_active = song_lua_replacement_active_players_indexed(
            &song_lua_visuals.foreground_visual_layers[layer_idx].overlays,
            &song_lua_foreground_layer_state_scratch[layer_idx],
            &replacement_proxy_sources,
            &song_lua_foreground_proxy_request_indices[layer_idx],
            song_lua_capture_visit_scratch,
        );
        for (active, layer_active) in replacement_active_players.iter_mut().zip(layer_active) {
            *active |= layer_active;
        }
    }

    let layout = FieldLayout {
        per_player_fields,
        playfield_center_x,
    };
    // Danger visuals participate in the Underlay capture target.
    if !hide_underlay_hud {
        let underlay_start = actors.len();
        draw_layer(ScreenLayer::Danger, actors, layout);
        for actor in &mut actors[underlay_start..] {
            song_lua_style_capture_actor_in_place(actor, screen_layers[0].diffuse, None, 0);
        }
        song_lua_capture_new_actors(
            &mut underlay_proxy_source,
            actors,
            underlay_start,
            song_lua_proxy_actor_scratch.as_mut(),
            retain_underlay_original,
        );
    }

    if !hide_underlay_hud {
        // Per-player filtering is part of the Underlay capture target.
        let underlay_start = actors.len();
        draw_layer(ScreenLayer::Filter, actors, layout);
        for actor in &mut actors[underlay_start..] {
            song_lua_style_capture_actor_in_place(actor, screen_layers[0].diffuse, None, 0);
        }
        song_lua_capture_new_actors(
            &mut underlay_proxy_source,
            actors,
            underlay_start,
            song_lua_proxy_actor_scratch.as_mut(),
            retain_underlay_original,
        );
    }

    // Header and HUD fragments belong to Underlay, before foreground Lua.
    if !hide_underlay_hud {
        let underlay_start = actors.len();
        draw_layer(ScreenLayer::Header, actors, layout);
        for actor in &mut actors[underlay_start..] {
            song_lua_style_capture_actor_in_place(actor, screen_layers[0].diffuse, None, 0);
        }
        song_lua_capture_new_actors(
            &mut underlay_proxy_source,
            actors,
            underlay_start,
            song_lua_proxy_actor_scratch.as_mut(),
            retain_underlay_original,
        );
    }

    actors.reserve(48);
    let mut segment_players = [None; 2];
    if has_p2_actors {
        if !replacement_active_players[1] {
            segment_players[0] = Some(PlayerActorSegment {
                player: 1,
                assembly: p2_actor_assembly,
                field_camera: p2_field_camera,
                field_screen_projection: player_field_screen_projections[1],
                captured_field_range: captured_player_field_ranges[1],
                hud_parts: player_hud_parts[1],
                manual_hud_draw: show_song_visuals
                    && song_lua_visuals.player_actors[1].manual_hud_draw,
            });
        } else if p2_direct_player.is_none() && p2_direct_note_field.is_none() {
            clear_player_actor_bundle(
                &mut notefield_actor_scratch[1],
                &mut notefield_flat_draw_scratch[1],
                &mut notefield_hud_actor_scratch[1],
                &mut notefield_hud_flat_draw_scratch[1],
            );
        }
    }
    if !replacement_active_players[0] {
        segment_players[1] = Some(PlayerActorSegment {
            player: 0,
            assembly: p1_actor_assembly,
            field_camera: p1_field_camera,
            field_screen_projection: player_field_screen_projections[0],
            captured_field_range: captured_player_field_ranges[0],
            hud_parts: player_hud_parts[0],
            manual_hud_draw: show_song_visuals && song_lua_visuals.player_actors[0].manual_hud_draw,
        });
    } else if p1_direct_player.is_none() && p1_direct_note_field.is_none() {
        clear_player_actor_bundle(
            &mut notefield_actor_scratch[0],
            &mut notefield_flat_draw_scratch[0],
            &mut notefield_hud_actor_scratch[0],
            &mut notefield_hud_flat_draw_scratch[0],
        );
    }
    if !hide_underlay_hud {
        let underlay_tail_start = actors.len();
        draw_layer(ScreenLayer::Hud, actors, layout);
        for actor in &mut actors[underlay_tail_start..] {
            song_lua_style_capture_actor_in_place(actor, screen_layers[0].diffuse, None, 0);
        }
        song_lua_capture_new_actors(
            &mut underlay_proxy_source,
            actors,
            underlay_tail_start,
            song_lua_proxy_actor_scratch.as_mut(),
            retain_underlay_original,
        );
    }
    if !hide_underlay_hud && underlay_proxy_source.is_some() {
        let start = actors.len();
        for player in 0..MAX_PLAYERS {
            actors.append(&mut notefield_underlay_actors[player]);
            actors.extend(
                notefield_underlay_draws[player]
                    .drain(..)
                    .map(actor_from_flat_draw),
            );
        }
        for actor in &mut actors[start..] {
            song_lua_style_capture_actor_in_place(actor, screen_layers[0].diffuse, None, 0);
        }
        song_lua_capture_new_actors(
            &mut underlay_proxy_source,
            actors,
            start,
            song_lua_proxy_actor_scratch.as_mut(),
            retain_underlay_original,
        );
    }
    let segment_insert = actors.len();
    let song_foreground_state =
        song_lua_song_foreground_state(state, song_lua_song_foreground_message_state_cache);
    let score_sources: [Option<SongLuaActorSegments>; MAX_PLAYERS] =
        std::array::from_fn(|player| {
            if !proxy_requests.scores[player] {
                return None;
            }
            let start = actors.len();
            draw_layer(ScreenLayer::Score(player), actors, layout);
            let mut source = Some(SongLuaActorSegments::new());
            song_lua_capture_new_actors(
                &mut source,
                actors,
                start,
                song_lua_proxy_actor_scratch.as_mut(),
                false,
            );
            source
        });
    let underlay_proxy_slice = underlay_proxy_source.as_deref();
    let overlay_proxy_slice = overlay_proxy_source.as_deref();
    // Simply Love keeps Stage/Event text in the In transition after its
    // lead-in animation finishes. It is a separately drawable screen child,
    // so Underlay/Overlay visibility must not suppress or capture it.
    let stage_start = actors.len();
    let stage_visible = !hide_gameplay_hud
        && screen_layers[3].draw_visible()
        && screen_layers[3].diffuse[3] > f32::EPSILON;
    if stage_visible || proxy_requests.stage {
        draw_layer(ScreenLayer::Stage, actors, layout);
    }
    let mut stage_source = proxy_requests.stage.then_some(SongLuaActorSegments::new());
    song_lua_capture_new_actors(
        &mut stage_source,
        actors,
        stage_start,
        song_lua_proxy_actor_scratch.as_mut(),
        stage_visible,
    );
    let proxy_sources = SongLuaScreenProxySources {
        // The same prepared views the replacement analysis read; the prepared
        // sources are not modified in between.
        players: replacement_proxy_sources,
        manual_players: std::array::from_fn(|player| manual_player_sources[player].as_ref()),
        scores: std::array::from_fn(|player| score_sources[player].as_deref()),
        direct_players: [p1_direct_player, p2_direct_player],
        direct_note_fields: [p1_direct_note_field, p2_direct_note_field],
        direct_judgments: [p1_direct_judgment, p2_direct_judgment],
        direct_combos: [p1_direct_combo, p2_direct_combo],
        underlay: underlay_proxy_slice,
        overlay: overlay_proxy_slice,
        background: background_source.as_deref(),
        stage: stage_source.as_deref(),
    };
    if show_song_visuals {
        push_song_lua_layer_actors(
            actors,
            render_targets,
            &song_lua_visuals.overlays,
            song_lua_overlay_order,
            &mut song_lua_proxy_request_index.topology,
            song_lua_local_state_scratch,
            song_lua_overlay_state_scratch,
            song_foreground_state,
            screen_camera,
            song_lua_screen_projection_ranges,
            None,
            &proxy_sources,
            Some(&mut *song_lua_direct_proxies),
            song_lua_proxy_actor_scratch.as_mut(),
            asset_manager,
            song_lua_space_width,
            song_lua_space_height,
            state.current_music_time_display(),
            state.current_beat(),
            SongLuaDrawTime {
                animation_elapsed: foreground_elapsed(
                    song_lua_now,
                    media.foreground_start_second,
                    state.music_rate(),
                ),
                uptime_seconds: view.uptime_seconds,
            },
            song_lua_order_scratch,
            song_lua_capture_state_scratch,
            song_lua_capture_order_scratch,
            song_lua_aft_capture_scratch,
            song_lua_projected_mesh_scratch,
            SONG_LUA_FOREGROUND_DEPTH,
        );
        if let Some(actor) = build_foreground_media(
            state,
            media,
            song_lua_overlay_state_scratch,
            song_lua_background_layer_state_scratch,
            song_lua_foreground_layer_state_scratch,
        ) {
            actors.push(actor);
        }
    }
    for &layer_idx in song_lua_foreground_active_layers {
        let layer = &song_lua_visuals.foreground_visual_layers[layer_idx];
        let local_states = &song_lua_foreground_layer_local_state_scratch[layer_idx];
        let layer_states = &song_lua_foreground_layer_state_scratch[layer_idx];
        let Some(order_cache) = song_lua_foreground_visual_layer_orders.get_mut(layer_idx) else {
            continue;
        };
        let Some(topology_index) = song_lua_foreground_proxy_request_indices.get_mut(layer_idx)
        else {
            continue;
        };
        let Some(aft_capture_scratch) = song_lua_foreground_aft_capture_scratch.get_mut(layer_idx)
        else {
            continue;
        };
        let Some(projected_mesh_scratch) =
            song_lua_foreground_projected_mesh_scratch.get_mut(layer_idx)
        else {
            continue;
        };
        let layer_parent_state = song_lua_song_foreground_state_from(
            song_lua_now,
            &layer.song_foreground,
            layer.song_foreground_events.as_slice(),
            &mut song_lua_foreground_song_foreground_message_state_cache[layer_idx],
        );
        let layer_parent_state = song_lua_layer_parent_state::<S>(
            song_foreground_state,
            layer_parent_state,
            [layer.screen_width, layer.screen_height],
            [song_lua_now, state.current_beat()],
        );
        push_song_lua_layer_actors(
            actors,
            render_targets,
            &layer.overlays,
            order_cache,
            &mut topology_index.topology,
            local_states,
            layer_states,
            layer_parent_state,
            screen_camera,
            song_lua_screen_projection_ranges,
            None,
            &proxy_sources,
            Some(&mut *song_lua_direct_proxies),
            song_lua_proxy_actor_scratch.as_mut(),
            asset_manager,
            layer.screen_width.max(1.0),
            layer.screen_height.max(1.0),
            song_lua_now,
            state.current_beat(),
            SongLuaDrawTime {
                animation_elapsed: foreground_elapsed(song_lua_now, layer.start_second, state.music_rate()),
                uptime_seconds: view.uptime_seconds,
            },
            song_lua_order_scratch,
            song_lua_capture_state_scratch,
            song_lua_capture_order_scratch,
            aft_capture_scratch,
            projected_mesh_scratch,
            SONG_LUA_FOREGROUND_DEPTH,
        );
    }
    let screen_actor_end = actors.len();
    if !hide_gameplay_hud {
        // ScreenManager draws ScreenSystemLayer and ScreenSyncOverlay after
        // ScreenGameplay. Its Overlay child cannot hide or tint these separate
        // screens. Keep them outside song captures and the gameplay camera,
        // while retaining the explicit application/Practice HUD override.
        draw_layer(ScreenLayer::System, actors, layout);
    }
    let direct_proxy_len = song_lua_direct_proxies.len();
    GameplayActorSegments {
        insert: segment_insert,
        screen_actor_end,
        players: segment_players,
        direct_proxy_len,
        underlay_visible: !hide_underlay_hud && retain_underlay_original,
        screen_projection,
    }
}

fn build_foreground_media<P: deadsync_gameplay::GameplayProfileData, S: NoteskinSlot + Clone>(
    state: &GameplayCoreState<P, S>,
    media: &SongMedia,
    overlay_states: &[SongLuaOverlayState],
    background_layer_states: &[Vec<SongLuaOverlayState>],
    foreground_layer_states: &[Vec<SongLuaOverlayState>],
) -> Option<Actor> {
    let texture_key = media.current_foreground_key.clone()?;
    if media.song_lua_foreground_owner_index.owns(
        state.current_music_time_display(),
        state.song_lua_visuals(),
        overlay_states,
        background_layer_states,
        foreground_layer_states,
    ) {
        return None;
    }
    Some(cover_sprite(
        texture_key,
        screen_center_x(),
        screen_center_y(),
        screen_width(),
        screen_height(),
        1.0,
        1000,
    ))
}

pub fn prewarm_texture_bindings<
    P: deadsync_gameplay::GameplayProfileData,
    S: NoteskinSlot + Clone,
>(
    state: &GameplayCoreState<P, S>,
    scratch: &mut FrameScratch,
    assets: &AssetManager,
) {
    let visuals = state.song_lua_visuals();
    let layers = std::iter::once((
        visuals.overlays.as_slice(),
        scratch.song_lua_projected_mesh_scratch.as_mut_slice(),
    ))
    .chain(
        visuals
            .background_visual_layers
            .iter()
            .zip(
                scratch
                    .song_lua_background_projected_mesh_scratch
                    .iter_mut(),
            )
            .map(|(layer, scratch)| (layer.overlays.as_slice(), scratch.as_mut_slice())),
    )
    .chain(
        visuals
            .foreground_visual_layers
            .iter()
            .zip(
                scratch
                    .song_lua_foreground_projected_mesh_scratch
                    .iter_mut(),
            )
            .map(|(layer, scratch)| (layer.overlays.as_slice(), scratch.as_mut_slice())),
    );
    for (overlays, scratch) in layers {
        for (overlay, scratch) in overlays.iter().zip(scratch) {
            if let SongLuaOverlayKind::Sprite { texture_key, .. } = &overlay.kind {
                scratch.bind_sprite(texture_key, assets.texture_context());
            }
        }
    }
}

pub const NOTEFIELD_ACTOR_SCRATCH_CAPACITY: usize = 384;
pub const NOTEFIELD_HUD_ACTOR_SCRATCH_CAPACITY: usize = 32;
// Worst case: colorful and highlight each emit a background, twelve bands,
// and ten ticks; monochrome emits a background, center, twelve bounds, and
// fifteen ticks; average emits a center plus five ticks; long average adds one.
const ERROR_BAR_HUD_FLAT_DRAW_CAPACITY: usize =
    82 + deadsync_notefield::ERROR_BAR_TEXT_SLOTS_PER_PLAYER as usize;
// Tap plus split overlay and one held-miss plus hold-result sprite per column.
const JUDGMENT_HUD_FLAT_DRAW_CAPACITY: usize = 2 + MAX_COLS * 2;
// One unique active hundred milestone emits four sprites, one unique thousand
// milestone emits two, and the visible combo contributes one prepared digit
// run; gameplay retains at most one milestone of each kind.
const COMBO_HUD_FLAT_DRAW_CAPACITY: usize = 7;
// Five lookahead/current counters, one broken-run counter, one run timer, and
// one mini score indicator.
const ZMOD_HUD_FLAT_DRAW_CAPACITY: usize =
    deadsync_notefield::COUNTER_TEXT_SLOTS_PER_PLAYER as usize + 1;
// One regular cue plus the two legitimate crossover-overlap countdowns.
const CUE_COUNTDOWN_FLAT_DRAW_CAPACITY: usize =
    deadsync_notefield::COLUMN_COUNTDOWN_SLOTS_PER_PLAYER as usize;
const NOTEFIELD_HUD_FLAT_DRAW_SCRATCH_CAPACITY: usize = ERROR_BAR_HUD_FLAT_DRAW_CAPACITY
    + JUDGMENT_HUD_FLAT_DRAW_CAPACITY
    + COMBO_HUD_FLAT_DRAW_CAPACITY
    + ZMOD_HUD_FLAT_DRAW_CAPACITY
    + CUE_COUNTDOWN_FLAT_DRAW_CAPACITY;
pub const PLAYER_ACTOR_SCRATCH_CAPACITY: usize =
    NOTEFIELD_ACTOR_SCRATCH_CAPACITY + NOTEFIELD_HUD_ACTOR_SCRATCH_CAPACITY;
fn white_texture_key() -> Arc<str> {
    static WHITE_TEXTURE_KEY: OnceLock<Arc<str>> = OnceLock::new();
    Arc::clone(WHITE_TEXTURE_KEY.get_or_init(|| Arc::from("__white")))
}

pub fn prewarm_text_layout<P: deadsync_gameplay::GameplayProfileData, S: NoteskinSlot + Clone>(
    cache: &mut TextLayoutCache,
    fonts: &font::FontMap,
    state: &GameplayCoreState<P, S>,
) {
    let visuals = state.song_lua_visuals();
    for overlay in visuals.overlays.iter().chain(
        visuals
            .background_visual_layers
            .iter()
            .chain(&visuals.foreground_visual_layers)
            .flat_map(|layer| &layer.overlays),
    ) {
        if let SongLuaOverlayKind::BitmapText {
            font_name,
            text_changes,
            ..
        } = &overlay.kind
        {
            for (_, text) in text_changes.iter() {
                cache.prewarm_text(fonts, font_name, text, None);
            }
        }
    }
}

/// Access to the production capture paths for differential integration tests.
#[cfg(feature = "test-support")]
#[doc(hidden)]
pub mod actor_capture_test_support {
    use super::*;

    pub const PLAYER_ACTOR_CAPACITY: usize = PLAYER_ACTOR_SCRATCH_CAPACITY;

    pub fn style(actor: Actor, tint: [f32; 4], blend: Option<BlendMode>, z: i16) -> Actor {
        song_lua_style_capture_actor(actor, tint, blend, z)
    }

    pub fn expand(children: &mut Vec<Actor>) {
        song_lua_proxy_expand_retained(children);
    }

    pub fn normalize(children: &mut Vec<Actor>) {
        song_lua_proxy_local_children_in_place(children);
    }
}

#[cfg(feature = "test-support")]
#[path = "playback/actor_conformance.rs"]
pub mod actor_conformance;

#[cfg(test)]
#[path = "playback/screen_projection_tests.rs"]
mod screen_projection_tests;

fn player_scratch<T>(active_players: usize, capacity: usize) -> [Vec<T>; MAX_PLAYERS] {
    std::array::from_fn(|player| {
        if player < active_players {
            Vec::with_capacity(capacity)
        } else {
            Vec::new()
        }
    })
}
