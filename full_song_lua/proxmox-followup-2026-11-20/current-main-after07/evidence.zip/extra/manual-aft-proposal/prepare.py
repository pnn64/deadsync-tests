from pathlib import Path
import datetime, difflib, hashlib, json

root = Path('C:/GitHub/deadsync')
work = root / 'target/song-lua-parity-20261120/manual-aft-proposal'
originals = {}
changes = {}

def load(path):
    raw = (root / path).read_bytes()
    originals[path] = raw
    return raw.decode('utf-8').replace('\r\n', '\n')

def replace(text, old, new):
    assert text.count(old) == 1, (old[:120], text.count(old))
    return text.replace(old, new, 1)

path = 'crates/deadlib-present/src/space.rs'
s = load(path)
s = replace(s, '/// Updates surface pixels without changing the current logical bounds.', '''/// Returns the exact logical bounds installed on the calling thread.
#[inline(always)]
#[must_use]
pub fn current_metrics() -> Metrics {
    CURRENT_METRICS.with(Cell::get)
}

/// Runs a presentation operation in temporary logical bounds, restoring the
/// calling thread's exact previous bounds on return or unwind. Surface pixels
/// and overscan remain independent of this logical camera scope.
pub fn with_current_metrics<R>(metrics: Metrics, operation: impl FnOnce() -> R) -> R {
    struct Restore(Metrics);
    impl Drop for Restore {
        fn drop(&mut self) {
            set_current_metrics(self.0);
        }
    }
    let previous = CURRENT_METRICS.with(|current| current.replace(metrics));
    let _restore = Restore(previous);
    operation()
}

/// Updates surface pixels without changing the current logical bounds.''')
s = replace(s, '    #[test]\n    fn centering_matrix_zero_is_identity()', '''    #[test]
    fn scoped_metrics_restore_exact_bounds_after_nested_return_and_unwind() {
        fn bits(m: Metrics) -> [u32; 4] {
            [m.left, m.right, m.top, m.bottom].map(f32::to_bits)
        }
        let original = Metrics { left: -123.5, right: 730.5, top: 208.25, bottom: -271.75 };
        let target = Metrics::centered(8.0, 6.0);
        let pixels = current_window_px();
        with_current_metrics(original, || {
            let value = with_current_metrics(target, || {
                assert_eq!(bits(current_metrics()), bits(target));
                let panic = std::panic::catch_unwind(|| {
                    with_current_metrics(Metrics::centered(3.0, 2.0), || {
                        panic!("render callback failed");
                    });
                });
                assert!(panic.is_err());
                assert_eq!(bits(current_metrics()), bits(target));
                assert_eq!(current_window_px(), pixels);
                42
            });
            assert_eq!(value, 42);
            assert_eq!(bits(current_metrics()), bits(original));
        });
    }

    #[test]
    fn centering_matrix_zero_is_identity()''')
changes[path] = s

path = 'crates/deadsync-song-lua/src/playback.rs'
s = load(path)
s = replace(s, '''struct SongLuaManualSlot {
    actors: Vec<Actor>,
    capture: SharedActorFrameScratch,
    meshes:''', '''struct SongLuaManualSlot {
    actors: Vec<Actor>,
    capture: SharedActorFrameScratch,
    // Native BeginRenderingTo replaces the camera with the image viewport.
    viewport: [f32; 2],
    // Captured Player/ScreenLayer children retain their original layout basis.
    source_layout: Option<SharedActorFrameScratch>,
    meshes:''')
s = replace(s, '        let mut target_ops = vec![false; peak];', '        let mut target_ops = vec![false; peak];\n        let mut source_layout_ops = vec![false; peak];')
s = replace(s, '                target_ops[op] |= matches!(draw, SongLuaDrawOp::Begin { .. });', '''                target_ops[op] |= matches!(draw, SongLuaDrawOp::Begin { .. });
                source_layout_ops[op] |= matches!(draw, SongLuaDrawOp::Draw {
                    source: SongLuaDrawSource::Player(_) | SongLuaDrawSource::ScreenLayer(_),
                    ..
                });''')
s = replace(s, '                        meshes: sources[op]', '''                        viewport: [0.0; 2],
                        source_layout: source_layout_ops[op]
                            .then(|| SharedActorFrameScratch::with_capacity(capacity)),
                        meshes: sources[op]''')
s = replace(s, '''            slot.actors.clear();
            slot.capture.clear();
''', '''            slot.actors.clear();
            slot.capture.clear();
            if let Some(source_layout) = &mut slot.source_layout {
                source_layout.clear();
            }
''')
s = replace(s, '''    state: Option<SongLuaOverlayState>,
    world: Matrix4,
}''', '''    state: Option<SongLuaOverlayState>,
    world: Matrix4,
    // Explicit ActorFrame FOV always resolves against SCREEN_WIDTH/HEIGHT,
    // including when a smaller render target is the active destination.
    resolved: Option<(Matrix4, Matrix4)>,
}''')
s = replace(s, '        Self { state, world: Matrix4::IDENTITY }', '        Self { state, world: Matrix4::IDENTITY, resolved: None }')
s = replace(s, '''            world: screen.map_or(Matrix4::IDENTITY, |screen| song_lua_draw_matrix(screen, clock).0),
        }''', '''            world: screen.map_or(Matrix4::IDENTITY, |screen| song_lua_draw_matrix(screen, clock).0),
            resolved: None,
        }''')
s = replace(s, '    fn is_active(self) -> bool {', '''    fn resolve_for(mut self, screen: [f32; 2]) -> Self {
        self.resolved = self.state.and_then(|state| {
            song_lua_overlay_view_proj(state, screen[0], screen[1])
        });
        self
    }

    fn explicit_view_proj(self, width: f32, height: f32) -> Option<(Matrix4, Matrix4)> {
        self.resolved.or_else(|| {
            self.state.and_then(|state| song_lua_overlay_view_proj(state, width, height))
        })
    }

    fn is_active(self) -> bool {''')
s = replace(s, '            && self.state.and_then(|camera| song_lua_overlay_view_proj(camera, size[0], size[1])).is_none()', '            && self.explicit_view_proj(size[0], size[1]).is_none()')
s = replace(s, '        let camera = self.state.and_then(|state| song_lua_overlay_view_proj(state, width, height));', '        let camera = self.explicit_view_proj(width, height);')
start = s.index('fn song_lua_manual_mesh<')
end = s.index('\nfn song_lua_capture_size', start)
mesh = s[start:end]
mesh = replace(mesh, '    vertices: &Arc<[TexturedMeshVertex]>,\n', '    vertices: &Arc<[TexturedMeshVertex]>,\n    camera: SongLuaDrawCamera,\n')
mesh = replace(mesh, '        parents,\n        camera,\n', '        parents,\n')
mesh = replace(mesh, '''    let view_proj = camera
        .and_then(|camera| song_lua_overlay_view_proj(camera, screen[0], screen[1]))
        .unwrap_or((Matrix4::IDENTITY, song_lua_screen_proj(1000.0)));''', '''    let view_proj = camera.view_proj(screen[0], screen[1])
        .unwrap_or_else(|| (Matrix4::IDENTITY, song_lua_screen_proj(1000.0)).into());''')
s = s[:start] + mesh + s[end:]

for name, end_name in [('append_manual_player', 'append_manual_screen'), ('append_manual_screen', '// The bounded draw program')]:
    start = s.index('fn ' + name + '(')
    end = s.index('\n' + ('fn ' if not end_name.startswith('//') else '') + end_name, start)
    part = s[start:end]
    part = replace(part, '    camera: Option<SongLuaOverlayState>,\n    screen: [f32; 2],', '''    camera: SongLuaDrawCamera,
    screen: [f32; 2],
    source_metrics: deadlib_present::space::Metrics,
    source_screen: [f32; 2],''')
    part = replace(part, '''    let view_proj = camera
        .and_then(|state| song_lua_overlay_view_proj(state, screen[0], screen[1]))
        .map_or_else(
            || song_lua_screen_proj(1000.0),
            |(view, projection)| projection * view,
        );
    let root = song_lua_proxy_source_view_proj();''', '''    let view_proj = camera.view_proj(screen[0], screen[1]).map_or_else(
        || song_lua_screen_proj(1000.0),
        |camera| camera.projection * camera.view * camera.world,
    );
    let root = song_lua_proxy_source_view_proj();
    let source_root = source_metrics.projection();''')
    part = replace(part, '    let canvas = Matrix4::from_scale(Vector3::new(', '''    let source_canvas = Matrix4::from_scale(Vector3::new(
        (source_metrics.right - source_metrics.left) / source_screen[0],
        (source_metrics.top - source_metrics.bottom) / source_screen[1],
        1.0,
    ));
    let canvas = Matrix4::from_scale(Vector3::new(''')
    part = part.replace('canvas.inverse()', 'source_canvas.inverse()')
    part = replace(part, 'source_view_proj: root,', 'source_view_proj: source_root,')
    if name == 'append_manual_player':
        part = replace(part, '        screen_center_x() - source.origin[0],\n        screen_center_y() - source.origin[1],', '        -source_metrics.left - source.origin[0],\n        source_metrics.top - source.origin[1],')
    else:
        part = replace(part, '    let local = Matrix4::from_translation(Vector3::new(screen_center_x(), screen_center_y(), 0.0))', '    let local = Matrix4::from_translation(Vector3::new(-source_metrics.left, source_metrics.top, 0.0))')
    s = s[:start] + part + s[end:]

start = s.index('fn song_lua_draw_owner<')
end = s.index('\nfn song_lua_aft_actor_capacity', start)
draw = s[start:end]
draw = replace(draw, '    let elapsed = elapsed.into();', '''    let elapsed = elapsed.into();
    let source_metrics = deadlib_present::space::current_metrics();
    let source_size = [source_metrics.right - source_metrics.left,
        source_metrics.top - source_metrics.bottom];''')
draw = replace(draw, '''            SongLuaDrawOp::Begin { .. } => {
                slots[op_index].actors.clear();
                stack.push(op_index);
            }''', '''            SongLuaDrawOp::Begin { capture, .. } => {
                slots[op_index].actors.clear();
                slots[op_index].viewport = song_lua_aft_size(&overlays[*capture], states[*capture])
                    .map(|size| song_lua_capture_size(size).1.map(|value| value as f32))
                    .unwrap_or(source_size);
                stack.push(op_index);
            }''')
draw = replace(draw, '                        children.push(Actor::CameraPush {\n                            view_proj: song_lua_proxy_source_view_proj(),', '''                        children.push(Actor::CameraPush {
                            // Leaf builders cancel this ±1 outer projection
                            // before applying the native ±1000 camera once.
                            view_proj: deadlib_present::space::Metrics::centered(size[0], size[1]).projection(),''')
branch_start = draw.index('                let slot = &mut slots[op_index];\n                slot.actors.clear();')
branch_end = draw.index('                if let Some(&begin) = stack.last() {', branch_start)
branch = draw[branch_start:branch_end]
branch = replace(branch, 'overlays, topology, op, vertices, assets, screen, clock, z,', 'overlays, topology, op, vertices, camera, assets, draw_screen, clock, z,')
branch = branch.replace('screen[0]', 'draw_screen[0]').replace('screen[1]', 'draw_screen[1]')
branch = branch.replace('                        *camera,', '                        camera,')
branch = branch.replace('                            screen,\n', '                            draw_screen,\n                            source_metrics,\n                            screen,\n')
branch = replace(branch, '                slot.actors.clear();', '                slot.actors.clear();\n                slot.viewport = viewport;')
head = '''                let captured = stack.last().copied();
                let viewport = captured.map_or(source_size, |begin| slots[begin].viewport);
                let draw_screen = if captured.is_some() { viewport } else { screen };
                // Resolve native ActorFrame cameras while the original screen
                // metrics are still active; only the default target camera is
                // image-sized. BeginRenderingTo already reset the draw stack.
                let camera = SongLuaDrawCamera::from(*camera).resolve_for(screen);
                let metrics = if captured.is_some() {
                    deadlib_present::space::Metrics::centered(viewport[0], viewport[1])
                } else {
                    source_metrics
                };
                deadlib_present::space::with_current_metrics(metrics, || {
'''
branch = ''.join('    ' + line if line.strip() else line for line in branch.splitlines(keepends=True))
branch = branch.replace('                                    draw_screen,\n                                source_metrics,\n                                screen,', '                                    draw_screen,\n                                    source_metrics,\n                                    screen,')
tail = '''                    if captured.is_some()
                        && matches!(source, SongLuaDrawSource::Player(_) | SongLuaDrawSource::ScreenLayer(_))
                        && let Some(source_layout) = &mut slot.source_layout
                        && let Some(children) = source_layout.refill([0.0; 2], |children| {
                            children.append(&mut slot.actors);
                        })
                    {
                        // Existing shared source actors were authored for the
                        // original screen. Preserve both their layout extent
                        // and world origin under the destination's metrics.
                        slot.actors.push(Actor::SharedFrame {
                            align: [0.0; 2],
                            offset: [source_metrics.left - metrics.left,
                                metrics.top - source_metrics.top],
                            size: source_size.map(SizeSpec::Px),
                            children,
                            background: None,
                            z: 0,
                            tint: [1.0; 4],
                            blend: None,
                        });
                    }
                });
                let slot = &mut slots[op_index];
'''
draw = draw[:branch_start] + head + branch + tail + draw[branch_end:]
s = s[:start] + draw + s[end:]
changes[path] = s

path = 'crates/deadsync-song-lua/src/playback/actor_conformance.rs'
s = load(path)
s = replace(s, '''                let [_, view, space] = song_lua_model_camera(
                    *camera,
                    screen_width() / screen[0].max(1.0),
                    screen_height() / screen[1].max(1.0),
                );
                Some((
                    *overlay,
                    deadlib_present::compose::build_screen_with_texture_context(
                        &self.manual.banks[self.manual.bank][op].actors,
                        [0.0; 4],
                        &deadlib_present::space::Metrics::centered(screen[0], screen[1]),
                        &font::FontMap::default(),
                        seconds,
                        self.assets.texture_context(),
                    ),
                    [matrix_rows(space), matrix_rows(view)],
                ))''', '''                let slot = &self.manual.banks[self.manual.bank][op];
                let viewport = slot.viewport;
                let camera = SongLuaDrawCamera::from(*camera).resolve_for(screen);
                let metrics = deadlib_present::space::Metrics::centered(viewport[0], viewport[1]);
                Some(deadlib_present::space::with_current_metrics(metrics, || {
                    let [_, view, space] = song_lua_model_camera(camera, 1.0, 1.0);
                    (
                        *overlay,
                        deadlib_present::compose::build_screen_with_texture_context(
                            &slot.actors,
                            [0.0; 4],
                            &metrics,
                            &font::FontMap::default(),
                            seconds,
                            self.assets.texture_context(),
                        ),
                        [matrix_rows(space), matrix_rows(view)],
                    )
                }))''')
changes[path] = s

path = 'crates/deadsync-song-lua/tests/playback/native_vertex_colors.rs'
s = load(path)
s = replace(s, '            overlays, &topology, &op, &vertices, assets, [640.0, 480.0], [0.0; 2], 0,', '            overlays, &topology, &op, &vertices, None.into(), assets, [640.0, 480.0], [0.0; 2], 0,')
changes[path] = s

manifest = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'AFT viewport and camera only; inherited color edits owned by sibling',
    'validation': 'proposal generated; no compilation or runtime tests performed', 'files': []}
patch = []
for path, text in changes.items():
    for directory, data in [('base', originals[path]), ('proposed', text.encode('utf-8'))]:
        destination = work / directory / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    before = originals[path].decode('utf-8').replace('\r\n', '\n')
    patch.extend(difflib.unified_diff(before.splitlines(True), text.splitlines(True),
        fromfile='a/' + path, tofile='b/' + path))
    manifest['files'].append({'path': path, 'base_sha256': hashlib.sha256(originals[path]).hexdigest(),
        'proposed_sha256': hashlib.sha256(text.encode('utf-8')).hexdigest()})
(work / 'source.patch').write_text(''.join(patch), encoding='utf-8', newline='\n')
(work / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'files': len(changes), 'patch_bytes': (work / 'source.patch').stat().st_size,
    'patch_sha256': hashlib.sha256((work / 'source.patch').read_bytes()).hexdigest()}))
