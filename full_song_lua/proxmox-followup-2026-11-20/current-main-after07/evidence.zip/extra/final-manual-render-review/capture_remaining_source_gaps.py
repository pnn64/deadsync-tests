from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('C:/GitHub/deadsync')
HARNESS = Path('C:/GitHub/itgmania-harness')
NATIVE = HARNESS / 'vendor/itgmania'
BASE = ROOT / 'target/song-lua-parity-20261120'
OUT = BASE / 'final-manual-render-review'


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def source(path: Path, anchors: list[str]) -> dict:
    return {**identity(path), 'anchors': anchors}


sources = [
    source(ROOT / 'crates/deadsync-song-lua/src/playback.rs', ['3952-4004: external ScreenLayer entry gate and unchanged shared children', '7628-7648: capture tint multiplies existing sprite tint/glow', '14940-14948,15243-15250: requested capture sources remain populated', '16185,16201,16217,16273,16294: Underlay producer applies layer diffuse only']),
    source(ROOT / 'crates/deadsync-song-lua/src/actors.rs', ['2955-2965: invalid scalar returns Ok', '3097-3109: table value is not a float scalar']),
    source(ROOT / 'crates/deadsync-song-lua/src/actors/scalar_methods.rs', ['448-473: scalar forwarding', '475-491: valid actor setter returns self after set_scalar']),
    source(ROOT / 'crates/deadsync-song-lua/tests/playback/manual_color_inheritance.rs', ['539-705: entry/basis-only external source regression', 'external_source_frame: synthetic shared child segments']),
    source(ROOT / 'tests/song_lua_itgmania_semantic_parity/native_gameplay.rs', ['3789-3840: stale actor attempted-call regression', '3844-3903: corrected independent binding-error/encoding-error regression']),
    source(NATIVE / 'src/Actor.cpp', ['641-664: inherited diffuse and independent Screen-combined glow', '1685-1688: Actor.x calls SetX(FArg(1))']),
    source(NATIVE / 'src/ActorFrame.cpp', ['236-248: custom callback bypasses normal child propagation', '251-274: ordinary children receive final diffuse/glow']),
    source(NATIVE / 'src/Player.cpp', ['1810-1843: explicit child draws']),
    source(NATIVE / 'src/LuaManager.h', ['267-271: FArg is luaL_checknumber']),
    source(NATIVE / 'extern/lua-5.1/src/lauxlib.c', ['67-77: type mismatch raises argument error', '184-188: luaL_checknumber rejects nonnumeric values']),
]

cases = []
for name, label in [
    ('typed-aft-uv', 'Typed AFT UV control'),
    ('amv-color', 'AMV color control'),
    ('wrapper-removal', 'Wrapper removal/metrics/geometry control'),
    ('sharkmode', 'Fresh Sharkmode reference'),
    ('pernicious-deed', 'Pernicious Deed reference'),
]:
    directory = BASE / f'{name}-after05'
    report_path = directory / 'report.json'
    execution_path = directory / 'execution.json'
    report = json.loads(report_path.read_text(encoding='utf-8'))
    execution = json.loads(execution_path.read_text(encoding='utf-8'))
    production = report['production_replay']
    assert execution['exit_code'] == 0
    assert report['diagnostic_replay_checks_passed'] is True
    assert report['production_gameplay_checks_passed'] is True
    assert production['production_gameplay_checks_passed'] is True
    assert report['mismatches'] == [] and report['errors'] == []
    assert production['mismatches'] == [] and production['errors'] == []
    assert report['interactive']['draw_mismatches'] == 0
    assert production['interactive']['draw_mismatches'] == 0
    cases.append({
        'case': name, 'label': label,
        'report': identity(report_path), 'execution': identity(execution_path),
        'exit_code': execution['exit_code'],
        'diagnostic_replay_checks_passed': True,
        'production_gameplay_checks_passed': True,
        'diagnostic_frames': report['replayed_frames'],
        'production_frames': production['replayed_frames'],
        'draws_per_path': [report['interactive']['draw_samples_compared'], production['interactive']['draw_samples_compared']],
        'vertices_per_path': [report['interactive']['submitted_vertices_compared'], production['interactive']['submitted_vertices_compared']],
        'draw_mismatches_per_path': [0, 0],
        'whole_song_parity_proven': report['whole_song_parity_proven'],
        'production_parity_proven': report['production_parity_proven'],
        'pixel_parity_proven': report['pixel_parity_proven'],
        'pending_coverage_counts': [len(report['pending_coverage']), len(production['pending_coverage'])],
        'remaining_gap_coverage': 'No dedicated assertion for either remaining gap; incidental exercise is not established by these report fields',
    })

controls = []
for name in ['typed-aft-uv', 'amv-color', 'wrapper-removal']:
    path = HARNESS / f'target/{name}-20261120/input/Songs/{name}/control.lua'
    text = path.read_text(encoding='utf-8')
    assert 'Underlay' not in text
    x_lines = [{'line': index + 1, 'text': line.strip()} for index, line in enumerate(text.splitlines()) if ':x(' in line]
    controls.append({**identity(path), 'underlay_reference': False, 'actor_x_lines': x_lines})
assert 'actor:x(0)' in (HARNESS / 'target/wrapper-removal-20261120/input/Songs/wrapper-removal/control.lua').read_text(encoding='utf-8')

prior_ignored = json.loads((OUT / 'viewport-test-correction/receipt.json').read_text(encoding='utf-8'))['ignored_tests']
for row in prior_ignored:
    declaration = row['declaration']
    path = Path(declaration['path'])
    assert identity(path)['sha256'] == declaration['sha256']
    assert path.read_text(encoding='utf-8').splitlines()[declaration['attribute_line'] - 1] == declaration['attribute']

failure_log = BASE / 'song-lua-regressions-after05/song_lua_itgmania_semantic_parity-attempted_call_encoding_errors_remain_diagnostic_failures.stdout.log'
proof_zip = BASE / 'encoding-test-correction-proof.zip'
assert identity(proof_zip)['sha256'] == '5eb9414e3e3667d02831133049d1eb225ab6a1f1891365e71a6039b90fc37fc7'
proof = BASE / 'encoding-test-correction-proof/proof.json'
proof_data = json.loads(proof.read_text(encoding='utf-8'))
assert proof_data['original_failure']['exit_code'] == 101
assert proof_data['after_source_sha256'] == identity(ROOT / 'tests/song_lua_itgmania_semantic_parity/native_gameplay.rs')['sha256']

rows = '\n'.join(f"| {case['label']} | {case['diagnostic_frames']} / {case['production_frames']} | {case['draws_per_path'][0]} / {case['draws_per_path'][1]} | 0 / 0 |" for case in cases)
ignored_rows = '\n'.join(f"| `{row['test']}` | {row['declared_reason']} |" for row in prior_ignored)
markdown = f'''# Remaining source-identified song-Lua gaps

The five after05 native cases below pass their diagnostic and production gameplay gates with zero compared draw mismatches. Neither remaining gap has dedicated passing native regression coverage in these cases. The source review found no new integration blocker in the accepted viewport/inherited-color work; it does not establish complete ScreenLayer color parity or scalar argument-error parity.

## Underlay child-glow propagation

Native `ActorFrame.cpp:251-274` passes final diffuse and glow to ordinary children. `Actor.cpp:641-664` applies incoming diffuse and Screen-blends incoming glow independently. Production Underlay source preparation currently applies only `screen_layers[0].diffuse` at `playback.rs:16185,16201,16217,16273,16294`. Its helper at `7628-7648` multiplies existing child tint/glow and has no final incoming-glow input.

The corrected external-layer gate (`playback.rs:3952-4004`) can therefore admit a zero-alpha Underlay kept visible by positive wrapper/layer glow while its real shared child segments remain transparent without native inherited glow. This is an existing source-styling limitation, identified from source; no new failure capture was run for this report.

The sixth regression, `manual_external_sources_use_recorded_glow_for_entry_only` (`manual_color_inheritance.rs:539-705` in the current hashed source), covers real PlayerP1/Underlay handles, preparation/live capture, static/GlowShift entry admission, zero-glow rejection, and unchanged supplied source styling/basis. Its composition helper supplies synthetic white child segments, so it does not exercise production Underlay child-glow preparation. Player's entry-only treatment is separately supported by its explicit child draw calls (`Player.cpp:1810-1843`).

## Actor.x table-argument error

Native `Actor.cpp:1685-1688` calls `SetX(FArg(1))`; `LuaManager.h:271` expands FArg to `luaL_checknumber`. The bundled Lua implementation (`lauxlib.c:184-188`, with the type-error path at `67-77`) rejects a table with a Lua argument error before mutation.

Owned `actors.rs:2955-2965` instead returns success when `float_scalar` cannot convert the argument. That converter returns None for tables (`3097-3109`), and the bound setter subsequently returns the actor (`actors/scalar_methods.rs:475-491`). A valid actor's `pcall(function() self:x({{}}) end)` therefore has a source-grounded success/error mismatch. This report makes no broader claim about every invalid scalar input.

The original after05 encoding regression actually exercised owned `self:x(malformed)` and failed its `not ok` assertion. The retained correction proof preserves the original source bytes, failed exit101 receipt, and log. The current corrected regression uses an independently guaranteed empty-owner `RemoveWrapperState(1)` bounds error with an unused malformed extra argument. Its assertions test preservation of the original Lua error, genuine observer encoding diagnostics, absent invented results/tween metadata, and later successful observation. It does not fix or assert Actor.x argument validation. No fresh native invalid-argument control was captured.

## Relationship to the five passing native cases

| Case | Frames, diagnostic / production | Compared draws, diagnostic / production | Draw mismatches |
|---|---:|---:|---:|
{rows}

The three authored controls contain no Underlay reference. Their Actor.x calls, when present, have numeric arguments; the wrapper control's caught stale calls use `x(0)` and exercise receiver lifetime rather than table-argument validation. AMV color coverage concerns ordinary authored ActorFrame children and custom draws, not production Underlay source segments.

The Sharkmode and Pernicious Deed reports establish their sampled replay comparisons. They contain no dedicated assertion proving either remaining trigger. This review did not audit every incidental event or pixel in those real-song traces, so incidental exercise is **not established**, rather than claimed absent. The passing replay gates must not be used to mark either remaining gap covered. The JSON receipt pins those reports and retains their explicit whole-song/production/pixel parity flags and pending-coverage counts.

## Exactly three ignored full-playback tests

| Test | Declared reason |
|---|---|
{ignored_rows}

These names/reasons were verified against both the after05 playback log and current `#[ignore]` source attributes. The original full playback result was 252 passed, 4 failed, 3 ignored; root owns the corrected-test rebuild and subsequent results.

## Evidence boundary

`remaining-source-gaps.json` pins current owned/native source hashes and anchors, all five completed replay report/execution hashes, authored control hashes, the original owned invalid-argument failure evidence, and exact ignored-test declarations. Only ignored evidence files were written for this report. No runtime/test source, fixture, build, guest state, or commit was changed, and no test or replay was launched.
'''

receipt = {
    'schema': 'remaining-source-identified-song-lua-gaps-v1',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'sources': sources,
    'passing_native_cases': cases,
    'authored_control_source_checks': controls,
    'coverage_assessment': {
        'dedicated_native_regression_for_underlay_source_glow': False,
        'dedicated_native_regression_for_valid_actor_x_table_error': False,
        'real_song_incidental_trigger_presence': 'not established; no exhaustive event/pixel audit performed',
        'three_authored_controls': 'no Underlay reference; Actor.x calls found have numeric arguments; wrapper stale calls use x(0)',
        'sixth_test': 'entry/basis handoff with synthetic supplied children; does not prove production Underlay source styling',
        'corrected_encoding_test': 'independent RemoveWrapperState bounds failure plus unused malformed extra argument; observer diagnostics/error preservation only',
        'new_integration_blocker_from_combined_render_patch_identified': False,
    },
    'actor_x_owned_failure_evidence': {
        'failure_log': identity(failure_log),
        'proof': identity(proof),
        'before_test': identity(BASE / 'encoding-test-correction-proof/before-test.rs'),
        'proof_zip': identity(proof_zip),
        'original_failure_exit': 101,
        'fresh_native_invalid_argument_capture': False,
    },
    'ignored_tests': prior_ignored,
    'original_playback_counts': {'passed': 252, 'failed': 4, 'ignored': 3},
    'reviewer_actions': {'runtime_source_changes': 0, 'test_source_changes': 0, 'fixture_changes': 0, 'builds': 0, 'tests': 0, 'replays': 0, 'guest_actions': 0, 'commits': 0},
    'script': identity(Path(__file__)),
}
for row in sources:
    assert identity(Path(row['path']))['sha256'] == row['sha256'], f"Source changed during report capture: {row['path']}"
md_path = OUT / 'remaining-source-gaps.md'
json_path = OUT / 'remaining-source-gaps.json'
assert not md_path.exists() and not json_path.exists()
with md_path.open('x', encoding='utf-8', newline='\n') as handle:
    handle.write(markdown)
receipt['report'] = identity(md_path)
with json_path.open('x', encoding='utf-8', newline='\n') as handle:
    json.dump(receipt, handle, indent=2)
    handle.write('\n')
print(json.dumps({'report': identity(md_path), 'receipt': identity(json_path), 'passing_native_cases': [{key: case[key] for key in ['case', 'diagnostic_frames', 'production_frames', 'draws_per_path']} for case in cases]}))
