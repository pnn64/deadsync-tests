# Viewport regression assertion correction

The original test counted Sprite draw runs and required two runs. The after05 playback log records one run at the assertion, before any clip-coordinate check ran. The compositor is permitted to batch the two compatible Sprite instances into one run, so run count is not the source-geometry contract.

The correction enumerates each run's full instance range while retaining its camera index. It still requires exactly two submitted sprites, checks the smaller sprite's 4x2 extent, retains the Fill source's original 854x480 extent, and preserves the independent native clip checks for the sprite and nested camera mesh. Four composition iterations and the zero-growth/zero-replacement scratch assertions remain intact.

`old.rs` is the exact former test, reconstructed by reversing only this recorded edit and verified against the SHA-256 pinned by the completed after05 build. `new.rs` is the exact revised live test, also verified by SHA-256. `correction.patch` contains their unified diff. The live file was read only while capturing this proof.

`receipt.json` retains the original failure-log identity and excerpt, the exact three ignored test names and declared reasons (verified against their source attributes), and the observed full playback totals: 252 passed, 4 failed, 3 ignored. These are the original after05 totals; this artifact does not claim that the revised test has passed.

The edit was checked with `rustfmt --edition 2024 --check`, exit 0. No Cargo build, runtime test, product-source change, fixture change, or guest action was performed for this correction or proof capture.
