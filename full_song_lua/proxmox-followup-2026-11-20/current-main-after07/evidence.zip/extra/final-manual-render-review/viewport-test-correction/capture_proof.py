from __future__ import annotations

import difflib
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('C:/GitHub/deadsync')
OUT = Path(__file__).resolve().parent
RELATIVE = 'crates/deadsync-song-lua/tests/playback/manual_target_space.rs'
LIVE = ROOT / RELATIVE
LOG = ROOT / 'target/song-lua-parity-20261120/song-lua-regressions-after05/playback.stdout.log'
OLD_SHA = '6ecf908fd62fcb723522ed178a1f9e0509109d1515edcfb9a10620cc6ea39810'
NEW_SHA = '3ad999d18829bf909c341a877a99db89ad8353e4de965c82fc6c5bb21d984e37'
LOG_SHA = '8d2d46e15932aeb8f04b683ef2c5d094d7b725195bc7f7e54ebf89f4c46d0af0'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(data), 'sha256': sha(data)}


new_bytes = LIVE.read_bytes()
log_bytes = LOG.read_bytes()
assert sha(new_bytes) == NEW_SHA, 'Live revised test no longer matches the frozen correction'
assert sha(log_bytes) == LOG_SHA, 'Retained failure log changed'
new_text = new_bytes.decode('utf-8')
line_ending = '\r\n' if '\r\n' in new_text else '\n'
old_text = new_text
reverse_edits = [
    ('''                .flat_map(|run| {
                    let start = run.instance_start as usize;
                    let end = start + run.instance_count as usize;
                    target.sprite_instances[start..end]
                        .iter()
                        .map(move |instance| (run.camera, instance))
                })
''', ''),
    ('''            let (camera, first) = sprites[0];
            assert_eq!(first.size, [4.0, 2.0]);
            let clip = target.cameras[camera as usize]
''', '''            let first = &target.sprite_instances[sprites[0].instance_start as usize];
            let clip = target.cameras[sprites[0].camera as usize]
'''),
    ('            let (_, fill) = sprites[1];\n', '            let fill = &target.sprite_instances[sprites[1].instance_start as usize];\n'),
]
for after, before in reverse_edits:
    after = after.replace('\n', line_ending)
    before = before.replace('\n', line_ending)
    assert old_text.count(after) == 1, 'Recorded edit does not identify exactly one location'
    old_text = old_text.replace(after, before, 1)
old_bytes = old_text.encode('utf-8')
assert sha(old_bytes) == OLD_SHA, 'Reverse of the specific edit did not recover exact old bytes'

patch = ''.join(difflib.unified_diff(
    old_text.splitlines(keepends=True), new_text.splitlines(keepends=True),
    fromfile=f'a/{RELATIVE}', tofile=f'b/{RELATIVE}',
)).encode('utf-8')
lines = log_bytes.decode('utf-8').splitlines()
ignored = []
for number, line in enumerate(lines, 1):
    if line.startswith('test ') and ' ... ignored, ' in line:
        name, reason = line[5:].split(' ... ignored, ', 1)
        ignored.append({'test': name, 'declared_reason': reason, 'log_line': number})
assert len(ignored) == 3
assert [row['declared_reason'] for row in ignored] == [
    'requires ffprobe on PATH or in the runtime bin directory',
    'requires a local Vulkan device and window',
    'requires a Vulkan device and a window system',
]
for row, relative, attr_line in zip(ignored, [
    'crates/deadsync-song-lua/src/playback/movie_metadata_tests.rs',
    'crates/deadsync-song-lua/tests/playback/cases.rs',
    'crates/deadsync-song-lua/tests/playback/cases.rs',
], [4, 179, 6309]):
    source = ROOT / relative
    source_lines = source.read_text(encoding='utf-8').splitlines()
    expected = '#[ignore = "' + row['declared_reason'] + '"]'
    assert source_lines[attr_line - 1] == expected
    row['declaration'] = {**identity(source), 'attribute_line': attr_line, 'attribute': expected}

readme = '''# Viewport regression assertion correction

The original test counted Sprite draw runs and required two runs. The after05 playback log records one run at the assertion, before any clip-coordinate check ran. The compositor is permitted to batch the two compatible Sprite instances into one run, so run count is not the source-geometry contract.

The correction enumerates each run's full instance range while retaining its camera index. It still requires exactly two submitted sprites, checks the smaller sprite's 4x2 extent, retains the Fill source's original 854x480 extent, and preserves the independent native clip checks for the sprite and nested camera mesh. Four composition iterations and the zero-growth/zero-replacement scratch assertions remain intact.

`old.rs` is the exact former test, reconstructed by reversing only this recorded edit and verified against the SHA-256 pinned by the completed after05 build. `new.rs` is the exact revised live test, also verified by SHA-256. `correction.patch` contains their unified diff. The live file was read only while capturing this proof.

`receipt.json` retains the original failure-log identity and excerpt, the exact three ignored test names and declared reasons (verified against their source attributes), and the observed full playback totals: 252 passed, 4 failed, 3 ignored. These are the original after05 totals; this artifact does not claim that the revised test has passed.

The edit was checked with `rustfmt --edition 2024 --check`, exit 0. No Cargo build, runtime test, product-source change, fixture change, or guest action was performed for this correction or proof capture.
'''.encode('utf-8')
outputs = {'old.rs': old_bytes, 'new.rs': new_bytes, 'correction.patch': patch, 'README.md': readme}
assert all(not (OUT / name).exists() for name in list(outputs) + ['receipt.json'])
for name, data in outputs.items():
    with (OUT / name).open('xb') as handle:
        handle.write(data)

receipt = {
    'schema': 'viewport-test-batched-sprite-assertion-correction-v1',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'live_test': identity(LIVE),
    'old_test_sha256': OLD_SHA,
    'new_test_sha256': NEW_SHA,
    'old_recovery': 'Exact inverse of the specific three replacement blocks; recovered bytes match the frozen parent-build SHA-256',
    'original_failure_log': identity(LOG),
    'original_failure_excerpt': [{'line': index + 1, 'text': lines[index]} for index in range(284, 290)],
    'original_playback_summary': lines[298],
    'ignored_tests': ignored,
    'validation': {'rustfmt_check_exit': 0, 'runtime_test_run': False, 'cargo_build_run': False},
    'preserved_assertions': ['exactly two submitted Sprite instances', 'first sprite 4x2 extent', 'Fill 854x480 source extent', 'native sprite clip [5,4,0] in target13x7', 'native nested-camera mesh clip [5,5,0] in target13x7', 'four frames and all scratch-bank growth/replacement checks'],
    'artifacts': {name: identity(OUT / name) for name in outputs},
    'capture_script': identity(Path(__file__)),
}
assert LIVE.read_bytes() == new_bytes
assert LOG.read_bytes() == log_bytes
with (OUT / 'receipt.json').open('x', encoding='utf-8', newline='\n') as handle:
    json.dump(receipt, handle, indent=2)
    handle.write('\n')
print(json.dumps({'receipt': identity(OUT / 'receipt.json'), 'artifacts': receipt['artifacts'], 'ignored_tests': ignored}))
