from __future__ import annotations

import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('C:/GitHub/deadsync')
BASE = ROOT / 'target/song-lua-parity-20261120'
OUT = BASE / 'final-manual-render-review'
COMMIT = 'af6a6c9e045f5dfb13abe38bd4eb58d7326f2e26'
PREFIX = 'current-source-af6a6c9e'


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


head = git('rev-parse', 'HEAD')
branch = git('branch', '--show-current')
status = git('status', '--short')
assert head == COMMIT and branch == 'main' and status == ''
historic_paths = [OUT / name for name in ['remaining-source-gaps.md', 'remaining-source-gaps.json', 'README.md', 'receipt.json']]
historic = [identity(path) for path in historic_paths]
previous = json.loads((OUT / 'remaining-source-gaps.json').read_text(encoding='utf-8'))
previous_sources = {row['path']: row for row in previous['sources']}

execution_path = BASE / 'song-lua-regressions-after07/execution.json'
execution = json.loads(execution_path.read_text(encoding='utf-8'))
compiled = execution['source_identity']['source_files']
compiled_source_matches = []
for relative, expected in compiled.items():
    path = ROOT / relative
    row = identity(path)
    assert row['sha256'] == expected, f'Committed source differs from after07 compiled bytes: {relative}'
    row['git_blob_at_selected_commit'] = git('rev-parse', f'{COMMIT}:{relative}')
    row['matches_after07_compiled_bytes'] = True
    compiled_source_matches.append(row)

summary_regex = re.compile(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;')
totals = [0, 0, 0]
per_test = []
for result in execution['results']:
    assert result['exit_code'] == 0
    path = execution_path.parent / (result['name'] + '.stdout.log')
    matches = summary_regex.findall(path.read_text(encoding='utf-8'))
    assert len(matches) == 1, f'Expected one completed test result: {path}'
    counts = list(map(int, matches[0]))
    totals = [left + right for left, right in zip(totals, counts)]
    per_test.append({'name': result['name'], 'counts': counts, 'stdout': identity(path), 'binary_sha256': result['binary_sha256']})
assert totals == [301, 0, 3], totals
interactive_path = BASE / 'interactive-after07/stdout.log'
interactive_counts = list(map(int, summary_regex.findall(interactive_path.read_text(encoding='utf-8'))[0]))
assert interactive_counts == [26, 0, 0]

selected_name = 'song_lua_itgmania_semantic_parity-attempted_call_encoding_errors_remain_diagnostic_failures'
selected_result = next(row for row in per_test if row['name'] == selected_name)
assert selected_result['counts'] == [1, 0, 0]
test_path = ROOT / 'tests/song_lua_itgmania_semantic_parity/native_gameplay.rs'
test_source = test_path.read_text(encoding='utf-8')
start = test_source.index('    fn attempted_call_encoding_errors_remain_diagnostic_failures()')
end = test_source.index('\n    #[test]', start)
selected_source = test_source[start:end]
for fragment in ['local selected = wrapper.x', 'pcall(selected, wrapper, 0, extra)', 'assert(err == baseline_error)', 'assert_eq!(calls.len(), 3', 'assert_eq!(failed.len(), 1']:
    assert fragment in selected_source

runtime_paths = [
    ROOT / 'crates/deadsync-song-lua/src/playback.rs',
    ROOT / 'crates/deadsync-song-lua/src/actors.rs',
    ROOT / 'crates/deadsync-song-lua/src/actors/scalar_methods.rs',
]
unchanged_gap_sources = []
for path in runtime_paths:
    row = identity(path)
    prior = previous_sources[path.as_posix()]
    assert row['sha256'] == prior['sha256']
    row['anchors'] = prior['anchors']
    row['unchanged_from_historical_gap_review'] = True
    row['git_blob_at_selected_commit'] = git('rev-parse', f'{COMMIT}:{path.relative_to(ROOT).as_posix()}')
    unchanged_gap_sources.append(row)
native_sources = []
for prior in previous['sources']:
    if '/itgmania-harness/vendor/itgmania/' not in prior['path']:
        continue
    assert identity(Path(prior['path']))['sha256'] == prior['sha256']
    native_sources.append(prior)

playback_log = execution_path.parent / 'playback.stdout.log'
ignored = []
for number, line in enumerate(playback_log.read_text(encoding='utf-8').splitlines(), 1):
    if line.startswith('test ') and ' ... ignored, ' in line:
        name, reason = line[5:].split(' ... ignored, ', 1)
        ignored.append({'test': name, 'declared_reason': reason, 'log_line': number})
assert [(row['test'], row['declared_reason']) for row in ignored] == [(row['test'], row['declared_reason']) for row in previous['ignored_tests']]
for row, old_row in zip(ignored, previous['ignored_tests']):
    declaration = old_row['declaration']
    path = Path(declaration['path'])
    assert identity(path)['sha256'] == declaration['sha256']
    assert path.read_text(encoding='utf-8').splitlines()[declaration['attribute_line'] - 1] == declaration['attribute']
    row['declaration'] = declaration

ignored_rows = '\n'.join(f"| `{row['test']}` | {row['declared_reason']} |" for row in ignored)
markdown = f'''# Current source supplement: af6a6c9e

Selected source commit: `{COMMIT}` on `main`. The working tree was clean when this supplement was captured. Every source file recorded by the after07 regression execution matches the committed file bytes. The build ran before the source commit was created; the matching hashes, rather than a rewritten build identity, bind these results to the selected commit.

The after07 regression evidence is green: **301 focused tests plus 26 interactive comparator tests = 327 passed, 0 failed, 3 ignored**. Full playback accounts for 256 passed and all three ignored tests. No tests were launched while preparing this supplement.

## Final selected-wrapper-x encoding regression

`attempted_call_encoding_errors_remain_diagnostic_failures` now passes using the selected `wrapper.x` forward after that wrapper is removed (`native_gameplay.rs:3844-3913`). A baseline `pcall(selected, wrapper, 0, 0)` establishes the receiver-lifetime error. A second call adds a malformed cyclic actor-tag table as an unused extra argument. The binding still produces exactly the baseline Lua error; the observer retains exactly one genuine encoding diagnostic. Assertions also preserve raw Lua fields, reject invented return/tween metadata on failed calls, and verify a later successful `aux(74)` observation.

This final regression supersedes the historical intermediate RemoveWrapperState-extra-argument proposal. It tests observable attempted calls, error preservation, and observer cleanup. The first x argument is numeric and the receiver is already removed, so it does **not** establish argument validation for `x(table)` on a valid actor.

## Two source gaps remain unchanged

- **Production Underlay child glow:** normal native ActorFrame children inherit final glow independently of diffuse (`ActorFrame.cpp:251-274`, `Actor.cpp:641-664`). The production Underlay source producer still applies layer diffuse only (`playback.rs:16185,16201,16217,16273,16294`; helper `7628-7648`). The passing external-source regression covers entry admission and basis preservation using synthetic shared children; it does not prove production Underlay child-glow propagation.
- **Valid Actor.x table-argument errors:** native `Actor.cpp:1685-1688` uses `FArg`, defined as `luaL_checknumber` (`LuaManager.h:271`; bundled `lauxlib.c:184-188`), which rejects a table. Owned scalar handling still returns success when conversion fails (`actors.rs:2955-2965,3097-3109`; bound return at `actors/scalar_methods.rs:475-491`). The selected-wrapper-x regression does not change or cover that separate valid-receiver contract.

The JSON supplement verifies these runtime/native source hashes are unchanged from the retained gap report and records committed blob identities for the owned sources. Earlier reports and correction proofs remain unchanged as historical evidence. Use the coordinator's **final checkpoint summary** for final native replay outcomes and acceptance coverage; this supplement does not publish another native-case status table.

## Exact ignored tests

| Test | Declared reason |
|---|---|
{ignored_rows}

Names and reasons match both the after07 log and current source attributes. The JSON receipt pins the committed source hashes, completed regression logs/receipts, native anchors, historical reports, and this supplement. Only new ignored evidence files were written.
'''

receipt = {
    'schema': 'current-source-limitations-supplement-v1',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'selected_source_commit': COMMIT,
    'observed_branch': branch,
    'observed_status': status,
    'after07_execution': identity(execution_path),
    'build_time_source_head_preserved': execution['source_identity']['git_head'],
    'compiled_source_matches': compiled_source_matches,
    'regressions': {'focused': dict(zip(['passed','failed','ignored'], totals)), 'interactive': dict(zip(['passed','failed','ignored'], interactive_counts)), 'combined': {'passed': 327, 'failed': 0, 'ignored': 3}, 'per_target': per_test, 'interactive_stdout': identity(interactive_path), 'interactive_execution': identity(BASE / 'interactive-after07/execution.json')},
    'final_selected_wrapper_x_regression': {'source': identity(test_path), 'anchors': ['3844-3913'], 'result': selected_result, 'tests_observer_encoding_and_stale_receiver_error': True, 'tests_valid_receiver_x_table_argument_error': False},
    'unchanged_gap_runtime_sources': unchanged_gap_sources,
    'unchanged_native_sources': native_sources,
    'ignored_tests': ignored,
    'historical_evidence_preserved': historic,
    'native_replay_status_authority': 'Coordinator final checkpoint summary; no new native-case status table in this supplement',
    'reviewer_actions': {'code_changes': 0, 'fixture_changes': 0, 'builds': 0, 'tests': 0, 'guest_actions': 0, 'commits': 0},
    'capture_script': identity(Path(__file__)),
}
for path, original in zip(historic_paths, historic):
    assert identity(path) == original
for row in compiled_source_matches:
    assert identity(Path(row['path']))['sha256'] == row['sha256']
md_path, json_path = OUT / f'{PREFIX}.md', OUT / f'{PREFIX}.json'
assert not md_path.exists() and not json_path.exists()
with md_path.open('x', encoding='utf-8', newline='\n') as handle:
    handle.write(markdown)
receipt['supplement'] = identity(md_path)
with json_path.open('x', encoding='utf-8', newline='\n') as handle:
    json.dump(receipt, handle, indent=2)
    handle.write('\n')
print(json.dumps({'supplement': identity(md_path), 'receipt': identity(json_path), 'source_commit': COMMIT, 'regression_counts': receipt['regressions']['combined']}))
