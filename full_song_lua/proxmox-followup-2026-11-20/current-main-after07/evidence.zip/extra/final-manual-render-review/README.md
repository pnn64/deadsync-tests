# Final manual rendering source review

The combined viewport, inherited-color, and external-source entry-gate changes have no newly identified integration or compile blocker in this read-only review. One existing production ScreenLayer styling limitation remains. This review does not claim complete Underlay color parity or new replay acceptance.

## Reviewed result

- AFT draws use the active image viewport. Explicit ActorFrame cameras are resolved against the original screen before target metrics are entered; native `ActorFrame.cpp:208-214` uses `SCREEN_WIDTH` and `SCREEN_HEIGHT`. `RageTextureRenderTarget.cpp:44-69` instead resets the default target camera/world stack and restores them at exit. The scoped metrics guard, per-slot viewport, and separate source/destination bases preserve this distinction.
- Inherited diffuse/glow is recorded separately from the geometric parent stack. Ordinary ActorFrame traversal propagates final colors; custom DrawFunction traversal starts explicit children with fresh internal colors. AFT target entry preserves the active color scope while resetting geometry/camera. These interactions match `ActorFrame.cpp:236-274`, `Actor.cpp:422-450,478-482,641-664`, and `ActorFrameTexture.cpp:80-89`.
- Manual Player composition preserves its original source layout and uses the captured colors for its entry gate. Native `Player.cpp:1810-1843` explicitly draws children without ActorFrame's ordinary internal-color propagation. No additional Player recoloring was required by the inspected source.
- The corner-color, local effect sampling, wrapper entry order, and outer metrics restoration review did not establish another regression introduced by this combined change.

## Remaining ScreenLayer source-styling gap

This is a source-identified existing limitation, not a newly measured failure from the current native controls.

`playback.rs:16185,16201,16217,16273,16294` styles production Underlay child segments using only `screen_layers[0].diffuse`. The helper `song_lua_style_capture_actor_in_place` at `7628-7648` multiplies existing sprite tint and glow by that tint; it accepts no final inherited-glow value. Captured layer requests can keep these sources populated despite a hidden original (`14940-14948`, `15243-15250`).

The corrected `append_manual_screen` gate at `3952-4004` now admits an actor kept partially opaque by positive inherited glow, then preserves the supplied shared source segments. Consequently, a zero-alpha Underlay admitted by positive wrapper/layer glow can still supply transparent child segments without the native inherited glow.

Native `ActorFrame.cpp:251-274` passes both final diffuse and final glow to each ordinary child. Native `Actor.cpp:656-664` Screen-blends the incoming glow independently of diffuse. This is different from Player's explicit child draw path. The existing shared-source styling path therefore does not establish full native Underlay color parity.

The remaining correction belongs in source preparation/style propagation, with a regression that builds the real production Underlay segments and verifies their child glow. Reapplying a color at the final shared-frame boundary without auditing already-applied tint could duplicate styling. No such change or additional capture was made during this review.

## Exact scope of the sixth regression

`manual_color_inheritance.rs:525-690`, `manual_external_sources_use_recorded_glow_for_entry_only`, obtains real PlayerP1 and Underlay runtime handles and tests preparation/live capture with static/GlowShift inherited glow. It proves positive-glow entry admission, the zero-glow rejection case, and preservation of the supplied source's styling and coordinate basis.

Its composition helper (`external_source_frame`, approximately `458-523`) supplies synthetic white child segments. The comparison deliberately holds those segments fixed. The test therefore covers the entry/basis handoff contract; it does not exercise the production Underlay source producer or prove native ScreenLayer child-glow propagation.

## Evidence and validation boundary

`receipt.json` binds the reviewed owned/native source files, exact line anchors, this README, and the parent's completed build receipt to SHA-256 hashes. The reviewed owned files must match the frozen `full-replay-and-manual-render-build-after05/execution.json` identities before the receipt is written. That parent-owned build exited 0 and reports unchanged source; it used `--no-run` and is not a test-pass result.

The reviewer performed source inspection only. No product source, fixture, catalog, VM state, or guest job was changed; no build, test, capture, or replay was launched by this review. Runtime validation and acceptance remain with the parent coordinator.
