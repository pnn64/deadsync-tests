from __future__ import annotations

import difflib
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('C:/GitHub/deadsync')
BASE = ROOT / 'target/song-lua-parity-20261120'
OUT = Path(__file__).resolve().parent
RELATIVE = 'crates/deadsync-song-lua/tests/playback/manual_target_space.rs'
NATIVE = Path('C:/GitHub/itgmania-harness/vendor/itgmania/src')


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


old_path = OUT.parent / 'viewport-test-correction/new.rs'
new_path = ROOT / RELATIVE
old = old_path.read_bytes()
new = new_path.read_bytes()
assert hashlib.sha256(old).hexdigest() == '3ad999d18829bf909c341a877a99db89ad8353e4de965c82fc6c5bb21d984e37'
assert hashlib.sha256(new).hexdigest() == '52ee0b755a757d89c05012c14df77af366b91ed5656a85caf61931b270ebec47'
old_text = old.decode('utf-8')
new_text = new.decode('utf-8')
old_helper = old_text.split('fn source_children(', 1)[1].split('\n#[test]', 1)[0]
expected_helper = old_helper.replace('        Actor::SharedCamera {', '        // A composable source camera preserves layout and SharedTransform remapping.\n        // Retained SharedCamera deliberately bypasses both for absolute replay.\n        Actor::Camera {', 1).replace('children: Arc::from([Actor::Mesh {', 'children: vec![Actor::Mesh {', 1).replace('            }]),', '            }],', 1)
assert old_text.replace(old_helper, expected_helper, 1) == new_text, 'Change exceeds the approved synthetic camera correction'
patch = ''.join(difflib.unified_diff(old_text.splitlines(keepends=True), new_text.splitlines(keepends=True), fromfile=f'a/{RELATIVE}', tofile=f'b/{RELATIVE}')).encode('utf-8')

run_path = BASE / 'song-lua-regressions-after06/execution.json'
log_path = BASE / 'song-lua-regressions-after06/playback.stdout.log'
run = json.loads(run_path.read_text(encoding='utf-8'))
playback_result = next(item for item in run['results'] if item['name'] == 'playback')
assert playback_result['exit_code'] == 101
assert run['source_identity']['source_files'][RELATIVE] == hashlib.sha256(old).hexdigest()
log_lines = log_path.read_text(encoding='utf-8').splitlines()
failure = [dict(line=index + 1, text=line) for index, line in enumerate(log_lines) if index >= 264]
assert any('Vec4(-0.008196721, -0.0020833334' in row['text'] for row in failure)

anchors = [
    (ROOT / 'crates/deadlib-present/src/actors.rs', ['544-546: SharedTransform remaps source cameras', '573-584: ordinary Camera versus absolute retained SharedCamera']),
    (ROOT / 'crates/deadlib-present/src/compose.rs', ['7452-7478: Camera retains parent and camera_prefix', '7482-7521: SharedTransform source-root remapping', '7535-7566: SharedCamera deliberately clears parent layout and prefix']),
    (ROOT / 'crates/deadsync-song-lua/src/playback.rs', ['3872-4004: separate original source and target bases', '4276-4296: source layout extent/origin preservation']),
    (NATIVE / 'Actor.cpp', ['668-704: BeginDraw pushes and premultiplies existing world transform']),
    (NATIVE / 'ActorFrame.cpp', ['208-214: Actor BeginDraw precedes camera push/replacement']),
    (NATIVE / 'RageDisplay.cpp', ['534-541: CameraPush/Pop preserve world stack']),
]
source_rows = [{**identity(path), 'anchors': ranges} for path, ranges in anchors]

readme = '''# Composable source-camera regression correction

The after06 full playback result was 255 passed, 1 failed, 3 ignored. The remaining failure came from the nested camera assertion in `manual_target_space_player_and_screen_sources_keep_original_layout_and_camera`, after the Sprite instance count, first sprite clip, and original Fill extent assertions had passed. The failing expected Y value identifies the `[5,5]` nested mesh assertion; the preceding `[5,4]` sprite assertion has a different expected Y.

The synthetic source incorrectly used `Actor::SharedCamera`. Its documented contract is absolute retained replay: parent layout and camera remapping do not alter the recorded matrix (`deadlib-present/actors.rs:580-584`). The composer intentionally resets the parent rectangle to the current target extent and clears the source camera prefix (`compose.rs:7535-7566`).

This independently derives the failure. The first source mesh vertex is `[3,4]`. Under the 13x7 target's reset layout, its centered world coordinate is `[3-6.5,3.5-4]=[-3.5,-0.5]`. The stored 854x480 projection then gives `[-7/854,-1/480]=[-0.0081967213,-0.0020833333]`, matching the observed output. The recorded `[2,1]` placement and source-layout remapping were intentionally bypassed by the wrong actor variant.

The approved correction uses ordinary `Actor::Camera` with Vec children. That variant preserves the enclosing source layout and applies `SharedTransform`'s camera prefix (`compose.rs:7452-7478,7482-7521`). Here the supplied camera is the original source-root basis, so its remapping composes the source's `[3,4]` point with the recorded `[2,1]` placement. The target point remains `[5,5]`, whose independent native orthographic clip is `[-3/13,-3/7]=[-0.2307692308,-0.4285714286]`. The expected value was not changed to the observed output.

Native ActorFrame camera entry first applies Actor::BeginDraw, retaining the world transform, and only then replaces the camera; CameraPush/Pop do not reset the world stack (`ActorFrame.cpp:208-214`, `Actor.cpp:668-704`, `RageDisplay.cpp:534-541`). This supports the composable-camera choice for this test. The separate explicit-FOV0/45 test continues to cover the native original-screen dimension rule; this synthetic source-root camera is not a new authored FOV override.

Only the helper's camera variant/child container and its explanatory comment changed. Both Player/ScreenLayer loops, 13x7 target, batched-instance enumeration, 4x2 sprite extent, 854x480 Fill extent, native clip expectations, four-frame reuse, and zero scratch growth/replacement assertions remain intact.

The exact old/new files, patch, original after06 failure excerpt, source hashes and anchors are retained in this folder. `rustfmt --edition 2024 --check` passed. No production code, fixtures, builds, extra test execution, or guest actions were performed. The parent coordinator owns the rebuild and passing result.
'''.encode('utf-8')
outputs = {'old.rs': old, 'new.rs': new, 'correction.patch': patch, 'README.md': readme}
assert all(not (OUT / name).exists() for name in [*outputs, 'receipt.json'])
for name, content in outputs.items():
    with (OUT / name).open('xb') as handle:
        handle.write(content)
receipt = {
    'schema': 'composable-source-camera-test-correction-v1',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'approved_scope': 'test-only source_children Camera/Vec correction; native target expectation unchanged',
    'old_file': identity(old_path),
    'new_live_file': identity(new_path),
    'only_approved_helper_changed': True,
    'original_after06_execution': identity(run_path),
    'original_playback_result': playback_result,
    'original_after06_log': identity(log_path),
    'failure_excerpt': failure,
    'source_anchors': source_rows,
    'independent_derivation': {
        'retained_absolute_shared_camera_world': [-3.5, -0.5],
        'retained_absolute_shared_camera_clip_xy': [-7 / 854, -1 / 480],
        'composable_source_camera_target_point': [5, 5],
        'unchanged_native_target_clip_xy': [-3 / 13, -3 / 7],
    },
    'validation': {'rustfmt_check_exit': 0, 'runtime_test_run_by_reviewer': False, 'build_run_by_reviewer': False, 'production_source_changes': 0, 'fixture_changes': 0, 'guest_actions': 0},
    'artifacts': {name: identity(OUT / name) for name in outputs},
    'capture_script': identity(Path(__file__)),
}
assert identity(new_path)['sha256'] == receipt['new_live_file']['sha256']
with (OUT / 'receipt.json').open('x', encoding='utf-8', newline='\n') as handle:
    json.dump(receipt, handle, indent=2)
    handle.write('\n')
print(json.dumps({'receipt': identity(OUT / 'receipt.json'), 'patch': receipt['artifacts']['correction.patch'], 'readme': receipt['artifacts']['README.md'], 'new_live_file': receipt['new_live_file']}))
