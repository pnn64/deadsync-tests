# Composable source-camera regression correction

The after06 full playback result was 255 passed, 1 failed, 3 ignored. The remaining failure came from the nested camera assertion in `manual_target_space_player_and_screen_sources_keep_original_layout_and_camera`, after the Sprite instance count, first sprite clip, and original Fill extent assertions had passed. The failing expected Y value identifies the `[5,5]` nested mesh assertion; the preceding `[5,4]` sprite assertion has a different expected Y.

The synthetic source incorrectly used `Actor::SharedCamera`. Its documented contract is absolute retained replay: parent layout and camera remapping do not alter the recorded matrix (`deadlib-present/actors.rs:580-584`). The composer intentionally resets the parent rectangle to the current target extent and clears the source camera prefix (`compose.rs:7535-7566`).

This independently derives the failure. The first source mesh vertex is `[3,4]`. Under the 13x7 target's reset layout, its centered world coordinate is `[3-6.5,3.5-4]=[-3.5,-0.5]`. The stored 854x480 projection then gives `[-7/854,-1/480]=[-0.0081967213,-0.0020833333]`, matching the observed output. The recorded `[2,1]` placement and source-layout remapping were intentionally bypassed by the wrong actor variant.

The approved correction uses ordinary `Actor::Camera` with Vec children. That variant preserves the enclosing source layout and applies `SharedTransform`'s camera prefix (`compose.rs:7452-7478,7482-7521`). Here the supplied camera is the original source-root basis, so its remapping composes the source's `[3,4]` point with the recorded `[2,1]` placement. The target point remains `[5,5]`, whose independent native orthographic clip is `[-3/13,-3/7]=[-0.2307692308,-0.4285714286]`. The expected value was not changed to the observed output.

Native ActorFrame camera entry first applies Actor::BeginDraw, retaining the world transform, and only then replaces the camera; CameraPush/Pop do not reset the world stack (`ActorFrame.cpp:208-214`, `Actor.cpp:668-704`, `RageDisplay.cpp:534-541`). This supports the composable-camera choice for this test. The separate explicit-FOV0/45 test continues to cover the native original-screen dimension rule; this synthetic source-root camera is not a new authored FOV override.

Only the helper's camera variant/child container and its explanatory comment changed. Both Player/ScreenLayer loops, 13x7 target, batched-instance enumeration, 4x2 sprite extent, 854x480 Fill extent, native clip expectations, four-frame reuse, and zero scratch growth/replacement assertions remain intact.

The exact old/new files, patch, original after06 failure excerpt, source hashes and anchors are retained in this folder. `rustfmt --edition 2024 --check` passed. No production code, fixtures, builds, extra test execution, or guest actions were performed. The parent coordinator owns the rebuild and passing result.
