# Remaining source-identified song-Lua gaps

The five after05 native cases below pass their diagnostic and production gameplay gates with zero compared draw mismatches. Neither remaining gap has dedicated passing native regression coverage in these cases. The source review found no new integration blocker in the accepted viewport/inherited-color work; it does not establish complete ScreenLayer color parity or scalar argument-error parity.

## Underlay child-glow propagation

Native `ActorFrame.cpp:251-274` passes final diffuse and glow to ordinary children. `Actor.cpp:641-664` applies incoming diffuse and Screen-blends incoming glow independently. Production Underlay source preparation currently applies only `screen_layers[0].diffuse` at `playback.rs:16185,16201,16217,16273,16294`. Its helper at `7628-7648` multiplies existing child tint/glow and has no final incoming-glow input.

The corrected external-layer gate (`playback.rs:3952-4004`) can therefore admit a zero-alpha Underlay kept visible by positive wrapper/layer glow while its real shared child segments remain transparent without native inherited glow. This is an existing source-styling limitation, identified from source; no new failure capture was run for this report.

The sixth regression, `manual_external_sources_use_recorded_glow_for_entry_only` (`manual_color_inheritance.rs:539-705` in the current hashed source), covers real PlayerP1/Underlay handles, preparation/live capture, static/GlowShift entry admission, zero-glow rejection, and unchanged supplied source styling/basis. Its composition helper supplies synthetic white child segments, so it does not exercise production Underlay child-glow preparation. Player's entry-only treatment is separately supported by its explicit child draw calls (`Player.cpp:1810-1843`).

## Actor.x table-argument error

Native `Actor.cpp:1685-1688` calls `SetX(FArg(1))`; `LuaManager.h:271` expands FArg to `luaL_checknumber`. The bundled Lua implementation (`lauxlib.c:184-188`, with the type-error path at `67-77`) rejects a table with a Lua argument error before mutation.

Owned `actors.rs:2955-2965` instead returns success when `float_scalar` cannot convert the argument. That converter returns None for tables (`3097-3109`), and the bound setter subsequently returns the actor (`actors/scalar_methods.rs:475-491`). A valid actor's `pcall(function() self:x({}) end)` therefore has a source-grounded success/error mismatch. This report makes no broader claim about every invalid scalar input.

The original after05 encoding regression actually exercised owned `self:x(malformed)` and failed its `not ok` assertion. The retained correction proof preserves the original source bytes, failed exit101 receipt, and log. The current corrected regression uses an independently guaranteed empty-owner `RemoveWrapperState(1)` bounds error with an unused malformed extra argument. Its assertions test preservation of the original Lua error, genuine observer encoding diagnostics, absent invented results/tween metadata, and later successful observation. It does not fix or assert Actor.x argument validation. No fresh native invalid-argument control was captured.

## Relationship to the five passing native cases

| Case | Frames, diagnostic / production | Compared draws, diagnostic / production | Draw mismatches |
|---|---:|---:|---:|
| Typed AFT UV control | 537 / 537 | 450 / 450 | 0 / 0 |
| AMV color control | 559 / 559 | 2380 / 2380 | 0 / 0 |
| Wrapper removal/metrics/geometry control | 581 / 581 | 1300 / 1300 | 0 / 0 |
| Fresh Sharkmode reference | 2258 / 2258 | 5190 / 5190 | 0 / 0 |
| Pernicious Deed reference | 7447 / 7447 | 224479 / 224479 | 0 / 0 |

The three authored controls contain no Underlay reference. Their Actor.x calls, when present, have numeric arguments; the wrapper control's caught stale calls use `x(0)` and exercise receiver lifetime rather than table-argument validation. AMV color coverage concerns ordinary authored ActorFrame children and custom draws, not production Underlay source segments.

The Sharkmode and Pernicious Deed reports establish their sampled replay comparisons. They contain no dedicated assertion proving either remaining trigger. This review did not audit every incidental event or pixel in those real-song traces, so incidental exercise is **not established**, rather than claimed absent. The passing replay gates must not be used to mark either remaining gap covered. The JSON receipt pins those reports and retains their explicit whole-song/production/pixel parity flags and pending-coverage counts.

## Exactly three ignored full-playback tests

| Test | Declared reason |
|---|---|
| `playback::actor_conformance::movie_metadata_tests::movie_source_dimensions_preserve_fullscreen_and_cropped_geometry` | requires ffprobe on PATH or in the runtime bin directory |
| `playback::tests::manual_player_draws_keep_recorded_pixels` | requires a local Vulkan device and window |
| `playback::tests::song_lua_preloaded_aft_chain_preserves_pixels` | requires a Vulkan device and a window system |

These names/reasons were verified against both the after05 playback log and current `#[ignore]` source attributes. The original full playback result was 252 passed, 4 failed, 3 ignored; root owns the corrected-test rebuild and subsequent results.

## Evidence boundary

`remaining-source-gaps.json` pins current owned/native source hashes and anchors, all five completed replay report/execution hashes, authored control hashes, the original owned invalid-argument failure evidence, and exact ignored-test declarations. Only ignored evidence files were written for this report. No runtime/test source, fixture, build, guest state, or commit was changed, and no test or replay was launched.
