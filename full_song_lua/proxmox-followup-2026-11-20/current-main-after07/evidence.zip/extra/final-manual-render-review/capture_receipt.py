from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('C:/GitHub/deadsync')
HARNESS = Path('C:/GitHub/itgmania-harness')
NATIVE = HARNESS / 'vendor/itgmania'
OUT = ROOT / 'target/song-lua-parity-20261120/final-manual-render-review'
BUILD = ROOT / 'target/song-lua-parity-20261120/full-replay-and-manual-render-build-after05/execution.json'


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


owned_anchors = {
    'crates/deadlib-present/src/space.rs': ['current_metrics', 'with_current_metrics'],
    'crates/deadsync-song-lua/src/actors/draw.rs': ['80-115: target color preservation and scope restore', '163-248: local color evaluation and direct-wrapper gates', '269-400: custom callback reset and normal child traversal'],
    'crates/deadsync-song-lua/src/draw_commands.rs': ['50-92: independent geometry/color context and native partial-opacity gate'],
    'crates/deadsync-song-lua/src/playback.rs': ['3658-3832: resolved camera and manual mesh', '3872-4004: Player and ScreenLayer entry gates/source bases', '4096-4290: active target viewport and preserved source layout', '7628-7648: source styling has tint but no incoming glow', '7931-8004: shared local/inherited color evaluation', '14940-14948,15243-15250: captured layer source visibility', '16185,16201,16217,16273,16294: Underlay producer diffuse-only styling'],
    'crates/deadsync-song-lua/src/playback/actor_conformance.rs': ['render_recorded_index: per-slot viewport and scoped metrics'],
    'crates/deadsync-song-lua/tests/playback/manual_target_space.rs': ['five target-space regressions: native clip coordinates, nested targets, explicit FOV, depth, external source basis'],
    'crates/deadsync-song-lua/tests/playback/manual_color_inheritance.rs': ['35-199: normal/custom AMV colors and byte expectations', '259-449: nested callbacks, wrappers, effect clocks, AFT color scope', '458-523: synthetic shared-source composition helper', '525-690: sixth regression, entry/basis-only source handoff'],
}
native_anchors = {
    'src/Actor.cpp': ['386-475: Actor::Draw wrapper/owner traversal', '478-482: internal-color reset', '641-664: base alpha, inherited diffuse, independent Screen-blended glow'],
    'src/ActorFrame.cpp': ['208-214: explicit FOV uses original screen dimensions', '236-248: DrawFunction returns before ordinary child color propagation', '251-274: normal child diffuse/glow propagation'],
    'src/ActorFrameTexture.cpp': ['80-89: target begin, normal ActorFrame draw, target finish'],
    'src/RageTextureRenderTarget.cpp': ['44-69: target-sized default camera, identity world, nested restoration'],
    'src/Player.cpp': ['1810-1843: explicit child drawing without ordinary Frame color propagation'],
}

build_data = json.loads(BUILD.read_text(encoding='utf-8'))
assert build_data['exit_code'] == 0
assert build_data['source_unchanged_during_command'] is True
assert '--no-run' in build_data['command']
owned = []
for relative, anchors in owned_anchors.items():
    row = identity(ROOT / relative)
    expected = build_data['source_identity']['source_files'][relative]
    assert row['sha256'] == expected, f'Reviewed source changed after frozen build: {relative}'
    row['anchors'] = anchors
    row['matches_parent_build_source'] = True
    owned.append(row)
native = []
for relative, anchors in native_anchors.items():
    row = identity(NATIVE / relative)
    row['anchors'] = anchors
    native.append(row)

receipt = {
    'schema': 'deadsync-final-manual-render-source-review-v1',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'reviewer': '/root/harness_audit',
    'review_mode': 'read-only product/native source inspection; ignored evidence files only',
    'repository_heads': {
        'deadsync': git(ROOT, 'rev-parse', 'HEAD'),
        'deadsync_branch': git(ROOT, 'branch', '--show-current'),
        'itgmania_harness': git(HARNESS, 'rev-parse', 'HEAD'),
        'native_itgmania': git(NATIVE, 'rev-parse', 'HEAD'),
    },
    'reviewed_sources': owned,
    'native_sources': native,
    'parent_build': {
        **identity(BUILD),
        'exit_code': build_data['exit_code'],
        'source_unchanged_during_command': build_data['source_unchanged_during_command'],
        'no_run': True,
        'does_not_claim_tests_passed': True,
    },
    'conclusions': {
        'new_integration_blocker_identified': False,
        'new_compile_blocker_identified': False,
        'supported_interactions': [
            'Target-sized default camera with original-screen resolved explicit FOV',
            'Scoped metrics restoration and separate original-source/destination bases',
            'Independent inherited color metadata and geometric parent stack',
            'Normal Frame color propagation, custom callback reset, and AFT color preservation',
            'Player entry-only color gate with unchanged explicit child source styling',
        ],
        'remaining_limitations': [{
            'id': 'screen-layer-source-style-missing-inherited-glow',
            'status': 'pre-existing source-identified limitation; no new reproducer or replay run',
            'trigger': 'Underlay with zero final diffuse alpha and positive final wrapper/layer glow',
            'native_behavior': 'ActorFrame passes final glow to ordinary children; Actor PreDraw Screen-blends it independently of diffuse',
            'owned_gap': 'Production Underlay source preparation applies screen layer diffuse only; current source style helper has no incoming glow input',
            'impact': 'The corrected entry gate can admit the layer while real shared source child segments remain transparent without native inherited glow',
            'not_claimed': 'Full Underlay or general ScreenLayer color parity',
            'next_validation': 'Build real production Underlay source segments and assert resulting child glow, including already-applied tint behavior',
        }],
        'sixth_regression_scope': {
            'name': 'manual_external_sources_use_recorded_glow_for_entry_only',
            'covers': ['real PlayerP1/Underlay runtime handles', 'preparation and live capture', 'static and GlowShift inherited-glow entry', 'zero-glow rejection', 'unchanged supplied synthetic source styling and coordinate basis'],
            'does_not_cover': ['real production Underlay source preparation', 'native ScreenLayer child-glow propagation'],
        },
    },
    'reviewer_actions': {'product_source_writes': 0, 'fixture_writes': 0, 'builds': 0, 'tests': 0, 'replays': 0, 'guest_actions': 0},
    'artifacts': {'readme': identity(OUT / 'README.md'), 'receipt_capture_script': identity(Path(__file__))},
}

for row in owned + native:
    assert identity(Path(row['path']))['sha256'] == row['sha256'], f"Source changed during receipt capture: {row['path']}"
destination = OUT / 'receipt.json'
with destination.open('x', encoding='utf-8', newline='\n') as handle:
    json.dump(receipt, handle, indent=2, ensure_ascii=False)
    handle.write('\n')
print(json.dumps({'receipt': identity(destination), 'readme': receipt['artifacts']['readme'], 'source_files': len(owned) + len(native), 'all_owned_sources_match_frozen_parent_build': True}))
