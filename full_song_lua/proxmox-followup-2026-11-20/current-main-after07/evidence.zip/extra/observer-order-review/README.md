# Native observer ordering review

The preexisting owned observer emitted a completed selected call only after invoking the binding. The stale-call fix correctly moved argument capture before invocation, but still emitted the event afterward. This can reorder visible callbacks for a real selected native method.

Concrete source path: `GameState.SetCurrentSteps` uses `m_pCurSteps[pn].Set(...)` (native GameState.cpp 2765-2775). BroadcastOnChangePtr::Set assigns and synchronously broadcasts (MessageManager.h 273-277), and MessageManager::Broadcast immediately invokes subscribers (MessageManager.cpp 192-207). The owned implementation has the same synchronous path in managers/game_state/selection.rs 111-145 and 192-204, then actors/messages.rs 238-251 and actors.rs 1605-1618. The latter emits command.begin/end even while the observer's native binding depth is nonzero.

Native `probe_theme/SongLuaTrace.lua` appends the attempted event and sequence before the binding (954-974), then adds results/tween detail to that same event (975-991). Nested events remain in entry order. `native_method_depth` defers flushing (25-26 and 993-995); it does not suppress nested authored observations. Native command/callback wrappers restore their prior context and depth on return/error (480-522).

The narrow correction reserves an owned JSON event before entering a binding, records nested command observations behind that reservation, fills successful results/tween detail afterward, and drains the completed batch in entry order. Argument-stack preparation finishes before reservation, so a failed push cannot strand a pending event. Once reserved, every protected-call result reaches completion, including binding errors and encoding diagnostics.

The existing internal-binding suppression remains. A nested selected call is observed only when its `song_callback_depth` exceeds the callback depth saved on entry to the active binding. This admits the actual authored message callback invoked by SetCurrentSteps without exposing the same binding's implementation calls. Binding entry/exit now restores both depth fields exactly, including during trace installation.

Stack review: argument encoding resets the native stack to the original count before calling the binding. Results are read from the original result range; option-path and tween helper temporary values are removed by restoring result_top before finish. The protected binding Error is returned unchanged. Diagnostic encoding failures remain trace-error events. This implementation does not relax the observer's argument/result encoding checks.

The new end-to-end regression invokes SetCurrentSteps from OnCommand, reenters it from CurrentStepsP1ChangedMessageCommand, and records selected aux/getter operations on both callback levels. It asserts exact entry order, nil getter tuples, successful fluent returns, failed setter arguments with no invented results, valid tween detail, and later successful observations after the caught error. The existing stale-actor and encoding-error cases remain required.

Files changed: `crates/deadsync-song-lua/src/actors/live_trace.rs` and `tests/song_lua_itgmania_semantic_parity/native_gameplay.rs` only. No guest commands, builds, or commits were performed by this worker for this correction.
