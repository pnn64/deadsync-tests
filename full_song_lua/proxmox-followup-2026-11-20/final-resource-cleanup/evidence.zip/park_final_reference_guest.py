"""Inspect and gracefully park the completed task's idle guests; keep all disks."""
import argparse
import concurrent.futures
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess

TASK = Path('/root/deadsync-lua-20261119')
OUT = Path('/root/deadsync-lua-20261120/final-reference-guest-parking')
INSPECTION = OUT / 'inspection.json'
ROLE = TASK / 'resource-retry-roles/9458d11fa29552a3ce70c276ba44e6b80fa0896374ecdd370af1962674baf924'
VMIDS = [1503]
GUEST = r'''
import json,os,pathlib,subprocess
busy=[]
names={'itgmania','full_song_lua','cargo','rustc','cmake','ninja','make','zstd','tar','scp','rsync'}
for path in pathlib.Path('/proc').iterdir():
 if not path.name.isdigit() or int(path.name)==os.getpid(): continue
 try:
  comm=(path/'comm').read_text().strip()
  args=(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace').strip()
 except (FileNotFoundError,PermissionError,ProcessLookupError): continue
 if comm.lower() in names or comm.lower().startswith(('itgmania-harne','full_song_lua')) or (comm.startswith('python') and '/opt/song-lua-audit/' in args):
  busy.append({'pid':int(path.name),'comm':comm,'args':args[:600]})
units=subprocess.check_output(['systemctl','list-units','--type=service','--state=running','--no-legend','--plain'],text=True)
task_units=[line.strip() for line in units.splitlines() if any(term in line.lower() for term in ('deadsync','itgmania','song-lua','capture','replay'))]
who=subprocess.check_output(['who'],text=True)
print(json.dumps({'busy_processes':busy,'running_task_services':task_units,'logged_in_users':who.strip()}))
'''

def run(argv, timeout=45):
    p=subprocess.run(argv,capture_output=True,text=True,timeout=timeout)
    if p.returncode: raise RuntimeError({'argv':argv[:5],'exit':p.returncode,'stderr':p.stderr})
    return p.stdout

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def gate():
    state=json.loads((ROLE/'state.json').read_text())
    assert state['phase']=='all-original-roles-restored',state['phase']
    assert (ROLE/'completed-host-role-marker.json').is_file()
    return {'state_sha256':digest(ROLE/'state.json'),'completed_marker_sha256':digest(ROLE/'completed-host-role-marker.json')}

def inspect(vmid):
    config={line.split(': ',1)[0]:line.split(': ',1)[1] for line in run(['qm','config',str(vmid)]).splitlines() if ': ' in line}
    expected=f'deadsync-lua-20261119-{vmid-1500:02}' if vmid<1516 else 'deadsync-lua-20261119-build'
    assert config['name']==expected,(vmid,config['name'])
    assert int(config['memory'])==(16384 if vmid==1516 else 8192),(vmid,config['memory'])
    status=run(['qm','status',str(vmid)]).strip()
    data={'vmid':vmid,'name':config['name'],'status':status,'memory_mib':int(config['memory']),
          'retained_disks':{key:value for key,value in config.items() if key.startswith(('scsi','virtio','sata','ide')) and key not in ('scsihw',)}}
    if status=='status: running':
        reply=json.loads(run(['qm','guest','exec',str(vmid),'--timeout','30','--','python3','-c',GUEST],40))
        assert reply.get('exited')==1 and reply.get('exitcode')==0,(vmid,reply)
        data['guest']=json.loads(reply['out-data'])
        # The first inspection found only the task's unused virtual display.
        # Keep its identity in the receipt; any other running task service blocks.
        infrastructure = {'deadsync-lua-pass4-xvfb.service'}
        data['idle_infrastructure'] = [line for line in data['guest']['running_task_services']
                                       if line.split()[0] in infrastructure]
        data['idle'] = (not data['guest']['busy_processes']
                        and not data['guest']['logged_in_users']
                        and all(line.split()[0] in infrastructure
                                for line in data['guest']['running_task_services']))
    else:
        assert status=='status: stopped',data
        data['idle']=True
    return data

def save(path,data):
    with path.open('x') as stream: json.dump(data,stream,indent=2);stream.write('\n')

parser=argparse.ArgumentParser()
parser.add_argument('action',choices=['inspect','park'])
parser.add_argument('--inspection-sha256')
args=parser.parse_args()
OUT.mkdir(exist_ok=True)
receipt={'utc':dt.datetime.now(dt.timezone.utc).isoformat(),'gate':gate(),
         'final_b_snapshot_sha256':'546c9b576e4a90023530d0be5deeb2fe52ef8667f95d8375508ec7a100010e35',
         'kept_running_for_fresh_native_controls':[],'template_backing_retained':1500}
if args.action=='inspect':
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        receipt['guests']=list(pool.map(inspect,VMIDS))
    receipt['meminfo']=Path('/proc/meminfo').read_text()
    save(INSPECTION,receipt)
    print(json.dumps({'path':str(INSPECTION),'sha256':digest(INSPECTION),
                      'guests':[{'vmid':g['vmid'],'idle':g['idle'],'guest':g.get('guest')} for g in receipt['guests']]}),flush=True)
else:
    old=INSPECTION
    assert args.inspection_sha256 and digest(old)==args.inspection_sha256
    previous=json.loads(old.read_text())
    assert previous['gate']==receipt['gate']
    assert all(guest['idle'] for guest in previous['guests'])
    assert not (OUT/'completed.json').exists()
    receipt['inspection_sha256']=digest(old)
    receipt['guests']=[]
    for vmid in VMIDS:
        guest=inspect(vmid)
        assert guest['idle'],guest
        if guest['status']=='status: running':
            guest['shutdown_output']=run(['qm','shutdown',str(vmid),'--timeout','60'],70)
        guest['final_status']=run(['qm','status',str(vmid)]).strip()
        assert guest['final_status']=='status: stopped',guest
        receipt['guests'].append(guest)
        save(OUT/f'parked-{vmid}.json',guest)
        print(json.dumps({'vmid':vmid,'final_status':guest['final_status']}),flush=True)
    receipt['finished_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
    receipt['meminfo']=Path('/proc/meminfo').read_text()
    receipt['remaining_vms']=run(['qm','list'])
    save(OUT/'completed.json',receipt)
    print(json.dumps({'path':str(OUT/'completed.json'),'sha256':digest(OUT/'completed.json'),
                      'guests_parked':len(receipt['guests']),
                      'configured_memory_mib_released':sum(g['memory_mib'] for g in receipt['guests'])}),flush=True)
