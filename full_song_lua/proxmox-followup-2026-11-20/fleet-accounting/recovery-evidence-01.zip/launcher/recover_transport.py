#!/usr/bin/env python3
"""Reconcile observed fleet transport after the owned role's DHCP interruption.

Inspection performs reads only. Execution creates append-only custody receipts,
starts only the three exactly owned parked workers, verifies all live identities,
replaces each transport file atomically under the orchestration lock, and requests
the unchanged frozen restore once. It never submits a test queue or changes a key.
"""
from __future__ import annotations

import argparse
import base64
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import traceback

sys.dont_write_bytecode = True
ROLE = '9458d11fa29552a3ce70c276ba44e6b80fa0896374ecdd370af1962674baf924'
HOST = Path('/root/deadsync-lua-20261119')
DIRECTORY = HOST / 'resource-retry-roles' / ROLE
FROZEN = DIRECTORY / 'resource_retry_roles.py'
RECOVERY = DIRECTORY / 'transport-recoveries' / 'dhcp-stale-20261120-01'
START_VMIDS = (1508, 1511, 1513)
ALL_VMIDS = tuple(range(1501, 1516))
PINS = {
    'resource_retry_roles.py': 'a2ae17784929e8fea6b1931f86620f38564484e01d8bfd0651b50a46951126ab',
    'manifest.json': '24ff6e4eef5d61af5d880a1f65c54d9a344c7849aa6bfecaecc912a7bc6972b4',
    'state.json': '22cfd219299cc1a4180e5de8af367fc33b46ab77e46d418e2b294c023301e8d9',
    'failure-1795134502230441176.json': 'b20d93c4a8297361f2828de37775e303da27dcef0ddc2cadc639791a88bc0a6f',
}
TRANSPORT_PINS = {
    'fleet.json': '83773dc223debc44a423fc6b392624ec05210a4c7b85a218cf28c06d6788f67b',
    'fleet-known-hosts': 'd9c30a8e91c84f77cac043bfbc6efca3f87d5ce711a50a6aa410978020d10eb8',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def append_raw(name, raw):
    path = RECOVERY / name
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}


def append_json(name, value):
    return append_raw(name, json.dumps(value, ensure_ascii=False, indent=2).encode() + b'\n')


def frozen_helper():
    require(digest(FROZEN.read_bytes()) == PINS[FROZEN.name], 'Frozen helper bytes changed')
    spec = importlib.util.spec_from_file_location('frozen_retry_role', FROZEN)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    return helper


def validate_inputs(helper):
    for name, expected in PINS.items():
        require(digest((DIRECTORY / name).read_bytes()) == expected, 'Pinned input changed: ' + name)
    directory, manifest, contract, _ = helper.load_role(ROLE)
    require(directory == DIRECTORY, 'Unexpected role directory')
    state = helper.read(DIRECTORY / 'state.json')
    require(state['phase'] == 'restarting-completed-parked-worker', 'Unexpected interrupted phase')
    require(state['events'][-1]['vmid'] == 1507, 'Unexpected interrupted worker')
    require(helper.read(helper.TASK / 'active-role.json') == {'role_id': ROLE, 'candidate': contract['candidate']['id']},
            'Original role no longer owns the task')
    unit = 'deadsync-lua-pass4-resource-roles-' + ROLE[:16] + '.service'
    properties = helper.run(['systemctl', 'show', unit, '--property=LoadState,ActiveState,SubState,MainPID'], timeout=10).stdout
    properties = dict(line.split('=', 1) for line in properties.splitlines() if '=' in line)
    require(properties.get('ActiveState') not in ('active', 'activating', 'deactivating', 'reloading'), 'Restore unit is active')
    require(properties.get('MainPID') in ('0', None), 'Restore unit still owns a process')
    before = {}
    for name, expected in TRANSPORT_PINS.items():
        path = HOST / name
        require(path.is_file() and not path.is_symlink(), 'Transport is not a regular owned file: ' + name)
        before[name] = path.read_bytes()
        require(digest(before[name]) == expected, 'Transport changed since review: ' + name)
    rows = json.loads(before['fleet.json'])
    require(len(rows) == 15 and sorted(row['vmid'] for row in rows) == list(ALL_VMIDS), 'Fleet identities are not exactly all15')
    require(len({tuple(helper.public_key(row['host_key'])) for row in rows}) == 15, 'Preserved guest keys are not unique')
    roles = {role['vmid']: role for role in [*contract['roles'], *contract['parked_workers']]}
    require(all(state['roles'][str(role['vmid'])].get('restored') for role in contract['roles']), 'A retry role is not restored')
    require(state['parked']['1502'].get('restored'), 'Previously restored1502 receipt is absent')
    for row in rows:
        if row['vmid'] in roles:
            require(helper.public_key(row['host_key']) == helper.public_key(roles[row['vmid']]['host_key']), 'Frozen guest key differs')
    observations = []
    for row in rows:
        vmid = row['vmid']
        if vmid in roles:
            live, config, raw = helper.require_config(roles[vmid], [8192])
        else:
            live, config, raw = helper.current_vm(vmid)
            require(int(config['memory']) == 8192, 'Ordinary worker no longer has8GiB')
        expected_status = 'stopped' if vmid in START_VMIDS else 'running'
        require(live['status'] == expected_status, 'Unexpected current VM state: ' + str(vmid))
        observations.append({'vmid': vmid, 'status': live['status'], 'status_source': live['status_source'],
                             'configuration_sha256': digest(raw), 'memory_mib': int(config['memory'])})
    owned_starts = []
    for vmid in START_VMIDS:
        role = roles[vmid]
        info = state['parked'][str(vmid)]
        require(role['original_status'] == 'running' and role['original_memory_mib'] == 8192, 'Unexpected original parked profile')
        require(digest(base64.b64decode(role['original_config_base64'])) == role['original_config_sha256'], 'Frozen original config digest differs')
        expected = {'role_id': ROLE, 'vmid': vmid, 'original_status': 'running',
                    'original_config_sha256': role['original_config_sha256']}
        require(info.get('stop_intent') == expected, 'Exact owned stop intent is absent')
        require(info['stopped']['observed_status'] == 'stopped' and info['stopped']['configuration_sha256'] == role['original_config_sha256'],
                'Exact owned stopped receipt differs')
        setup = info['setup']
        require(setup['role_id'] == ROLE and setup['vmid'] == vmid, 'Setup is owned by another role or VM')
        hold = setup['completed_queue_hold']
        require(hold['kind'] == 'completed-original-queue' and hold['phase'] == 'completed-queue-held'
                and hold['relaunch_required'] is False and hold['progress']['finished_at']
                and hold['progress']['completed'] == hold['progress']['total'], 'Parked original queue is not proved complete')
        for journal in setup['host_journals']:
            path = Path(journal['host_path']).resolve()
            require(path.is_relative_to(DIRECTORY / 'journal-evidence' / str(vmid)), 'Journal escaped owned custody')
            require(helper.sha(path) == journal['host_sha256'], 'Preserved pre-stop journal changed')
        owned_starts.append({'vmid': vmid, 'stop_intent': expected, 'completed_jobs': hold['progress']['completed'],
                             'journal_count': len(setup['host_journals'])})
    resources = helper.host_resources(additional_bytes=len(START_VMIDS) * 8192 * 1024**2)
    return contract, state, rows, roles, before, {
        'observed_at': now(), 'role_id': ROLE, 'frozen_helper': str(FROZEN), 'input_pins': PINS,
        'transport_pins': TRANSPORT_PINS, 'unit': properties, 'direct_vm_starts': list(START_VMIDS),
        'owned_starts': owned_starts, 'worker_configurations': observations, 'host_resources': resources,
        'builder_original_status': contract['builder']['original_status'],
        'builder_original_memory_mib': contract['builder']['original_memory_mib'],
        'frozen_restore_may_restore_original_builder': bool(state.get('builder_stopped') or state.get('builder_stop_intent')),
        'mutations_executed': False, 'recovery_directory': str(RECOVERY),
    }


def inspect(script_sha):
    helper = frozen_helper()
    with (helper.TASK / 'orchestration.lock').open('rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        *_, plan = validate_inputs(helper)
        plan['script_sha256'] = script_sha
        return plan


def rewrite_known_hosts(helper, before, rows, observed):
    expected = {tuple(helper.public_key(row['host_key'])): row for row in rows}
    matched = set()
    lines = []
    for line in before.decode().splitlines(keepends=True):
        parts = line.split()
        if len(parts) >= 3 and tuple(parts[1:3]) in expected:
            row = expected[tuple(parts[1:3])]
            require(parts[0] == row['ip'], 'Known-host entry differs from the preserved receipt')
            require(row['vmid'] not in matched, 'Duplicate known-host entry for one guest')
            matched.add(row['vmid'])
            line = observed[row['vmid']]['ip'] + line[len(parts[0]):]
        lines.append(line)
    require(matched == set(ALL_VMIDS), 'Known-hosts does not preserve all15 exact guest keys')
    return ''.join(lines).encode()


def atomic_replace(name, expected, replacement):
    path = HOST / name
    require(path.read_bytes() == expected, 'Transport changed before atomic replacement: ' + name)
    metadata = path.stat()
    temporary = path.with_name(path.name + '.dhcp-recovery-20261120-01.tmp')
    with temporary.open('xb') as stream:
        os.fchmod(stream.fileno(), stat.S_IMODE(metadata.st_mode))
        os.fchown(stream.fileno(), metadata.st_uid, metadata.st_gid)
        stream.write(replacement)
        stream.flush()
        os.fsync(stream.fileno())
    require(path.read_bytes() == expected, 'Transport changed while preparing replacement: ' + name)
    os.replace(temporary, path)
    descriptor = os.open(HOST, os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def execute(script_sha):
    helper = frozen_helper()
    created = False
    try:
        with (helper.TASK / 'orchestration.lock').open('rb') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            contract, state, rows, roles, before, plan = validate_inputs(helper)
            RECOVERY.mkdir(parents=True, exist_ok=False)
            created = True
            plan['script_sha256'] = script_sha
            append_json('plan.json', plan)
            append_raw('state.before.json', (DIRECTORY / 'state.json').read_bytes())
            for name, raw in before.items():
                append_raw(name + '.before', raw)
            append_raw('original-failure.json', (DIRECTORY / 'failure-1795134502230441176.json').read_bytes())
            for vmid in START_VMIDS:
                live, _, raw = helper.require_config(roles[vmid], [8192])
                require(live['status'] == 'stopped', 'Owned parked VM changed before start')
                resources = helper.host_resources(additional_bytes=8192 * 1024**2)
                append_json('start-' + str(vmid) + '-intent.json', {'at': now(), 'vmid': vmid,
                    'stop_intent': state['parked'][str(vmid)]['stop_intent'], 'configuration_sha256': digest(raw), 'resources': resources})
                result = helper.run(['qm', 'start', vmid], timeout=90)
                identity = helper.qga_address(roles[vmid])
                live, _, _ = helper.require_config(roles[vmid], [8192])
                require(live['status'] == 'running', 'Owned VM did not start')
                append_json('start-' + str(vmid) + '-complete.json', {'at': now(), 'vmid': vmid,
                    'stdout': result.stdout, 'stderr': result.stderr, 'qga_ip': identity['ip'], 'host_key': identity['host_key']})
            observed = {}
            for row in rows:
                vmid = row['vmid']
                identity = helper.qga_address({**row, 'host_key': row['host_key']})
                require(helper.public_key(identity['host_key']) == helper.public_key(row['host_key']), 'Live QGA key differs')
                live, _, _ = helper.current_vm(vmid)
                require(live['status'] == 'running', 'A live identity is not running')
                observed[vmid] = {'ip': identity['ip'], 'host_key': identity['host_key']}
            require(len({row['ip'] for row in observed.values()}) == 15, 'Live QGA addresses are not unique')
            append_json('all15-observed-identities.json', {'at': now(), 'identities': observed, 'unique_addresses': True})
            after_rows = [{**row, 'ip': observed[row['vmid']]['ip']} for row in rows]
            after = {'fleet.json': json.dumps(after_rows, ensure_ascii=False, indent=2).encode() + b'\n',
                     'fleet-known-hosts': rewrite_known_hosts(helper, before['fleet-known-hosts'], rows, observed)}
            for name, raw in after.items():
                append_raw(name + '.after', raw)
            require(all((HOST / name).read_bytes() == raw for name, raw in before.items()), 'Transport changed during QGA reads')
            append_json('transport-transaction-intent.json', {'at': now(), 'orchestration_lock_held': True,
                'before': {name: digest(raw) for name, raw in before.items()},
                'after': {name: digest(raw) for name, raw in after.items()},
                'changed_ips': [{'vmid': row['vmid'], 'before': row['ip'], 'after': observed[row['vmid']]['ip']}
                                for row in rows if row['ip'] != observed[row['vmid']]['ip']],
                'atomicity': 'Each file uses fsync and atomic rename under the existing orchestration lock; retained before/after bytes permit exact interrupted-transaction recovery.'})
            for name in ['fleet.json', 'fleet-known-hosts']:
                atomic_replace(name, before[name], after[name])
                append_json(name + '.applied.json', {'at': now(), 'sha256': digest((HOST / name).read_bytes())})
            require(all((HOST / name).read_bytes() == raw for name, raw in after.items()), 'Transport transaction is incomplete')
            append_json('transport-transaction-complete.json', {'at': now(), 'after': {name: digest(raw) for name, raw in after.items()}})
            require(helper.sha(FROZEN) == PINS[FROZEN.name], 'Frozen helper changed during recovery')
            require(digest((DIRECTORY / 'state.json').read_bytes()) == PINS['state.json'], 'Role state changed during recovery')
            append_json('restore-launch-intent.json', {'at': now(), 'role_id': ROLE,
                'operation': 'restore', 'frozen_helper_sha256': PINS[FROZEN.name], 'launch_attempts_allowed': 1})
        # The unchanged helper acquires this same nonblocking lock in its child.
        # Release our lock before launching; its own active-unit guard still applies.
        launched = helper.launch_phase(ROLE, 'restore')
        receipt = append_json('restore-launch-result.json', {'at': now(), **launched})
        return {'recovery_directory': str(RECOVERY), 'launch_receipt': receipt,
                'transport_reconciled': True, 'restore_requested_once': True, 'restoration_complete': False}
    except BaseException as error:
        if created:
            append_json('failure.json', {'at': now(), 'error': str(error), 'traceback': traceback.format_exc(),
                'automatic_retry': False, 'note': 'Inspect retained receipts before any recovery; this helper refuses reuse of its execution directory.'})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--inspect', action='store_true')
    mode.add_argument('--execute', action='store_true')
    parser.add_argument('--expected-script-sha256', required=True)
    args = parser.parse_args()
    script_sha = digest(Path(__file__).read_bytes())
    require(script_sha == args.expected_script_sha256, 'Recovery script differs from the reviewed bytes')
    print(json.dumps(inspect(script_sha) if args.inspect else execute(script_sha), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
