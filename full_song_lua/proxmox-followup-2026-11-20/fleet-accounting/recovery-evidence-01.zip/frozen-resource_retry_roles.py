#!/usr/bin/env python3
"""Freeze and operate explicit reversible retry roles on existing task guests.

Freeze performs proof reads and writes only owned receipts. Activate, retry and
restore are separate explicit invocations. No source/binary deployment happens
here: final rollout and any independent capture profile must already be proved.
"""
from __future__ import annotations
import argparse
import base64
import concurrent.futures
import datetime
import gzip
import hashlib
import io
import ipaddress
import json
import os
import pathlib
import re
import shutil
import subprocess
import tarfile
import time
import traceback

HOST = pathlib.Path('/root/deadsync-lua-20261119')
TASK = HOST / 'resource-retry-roles'
GUEST = pathlib.PurePosixPath('/opt/song-lua-audit/pass4')
GIB = 1024 ** 3
WORKER_SHA = '4155f85dc78eaee40189d8ee5e2a9b177be8b8ad36093b6a4706a098ec9b0e72'
NAMES = {'completed_queue_hold.py': 'completed_queue_hold_v2.py',
         'resource_retry_coordinator.py': 'resource_retry_coordinator_v3.py', 'resource_retry_guest.py': 'resource_retry_guest_v4.py',
         'retry_runtime_readiness.py': 'retry_runtime_readiness.py',
         'worker.py': 'worker_candidate.py', 'replay_only.py': 'replay_only.py', 'rollout_runner.py': 'rollout_runner.py'}


def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
def sha(path):
    with pathlib.Path(path).open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
def read(path): return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))
def save(path, value):
    path = pathlib.Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp.' + str(os.getpid()))
    with temporary.open('wb') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2).encode() + b'\n'); stream.flush(); os.fsync(stream.fileno())
    temporary.replace(path)
def stable(path, raw):
    path = pathlib.Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink(): raise ValueError('owned input path is symlinked')
    if path.exists():
        if path.read_bytes() != raw: raise ValueError('frozen owned input differs: ' + str(path))
    else: path.write_bytes(raw)
def run(args, **kwargs): return subprocess.run(list(map(str, args)), check=True, capture_output=True, text=True, **kwargs)
def api(*args): return json.loads(run(['pvesh', 'get', *args, '--output-format', 'json']).stdout)
def valid_sha(value): return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None
def public_key(value):
    parts = value.strip().split()
    if len(parts) < 2 or parts[0] != 'ssh-ed25519': raise ValueError('expected an exact ED25519 public host key')
    return parts[:2]


def memory_config(original, target_mib):
    text = original.decode('utf-8')
    replaced, count = re.subn(r'(?m)^memory: [0-9]+$', 'memory: ' + str(target_mib), text)
    if count != 1: raise ValueError('VM configuration has no unique memory field')
    return replaced.encode('utf-8')


def current_vm(vmid):
    values = api('/cluster/resources', '--type', 'vm')
    selected = [row for row in values if row['vmid'] == vmid]
    if len(selected) != 1: raise ValueError('task VM is absent or ambiguous')
    live = selected[0]; config = api('/nodes/' + live['node'] + '/qemu/' + str(vmid) + '/config')
    if config.get('tags') != 'deadsync-lua-20261119' or not config.get('name', '').startswith('deadsync-lua-20261119-'):
        raise ValueError('live VM is outside the exact task family')
    pending = api('/nodes/' + live['node'] + '/qemu/' + str(vmid) + '/pending')
    if any('pending' in row or row.get('delete') for row in pending): raise ValueError('task VM has an unowned pending configuration change')
    raw = pathlib.Path('/etc/pve/qemu-server', str(vmid) + '.conf').read_bytes()
    # Cluster status is published periodically; lifecycle decisions need the node's current state.
    status_path = '/nodes/' + live['node'] + '/qemu/' + str(vmid) + '/status/current'
    observed = api(status_path)
    if not isinstance(observed, dict) or type(observed.get('vmid')) is not int or observed['vmid'] != vmid:
        raise ValueError('node status does not identify the selected task VM')
    if observed.get('name') != config.get('name'):
        raise ValueError('node status name differs from the selected task configuration')
    status = observed.get('status')
    if status not in {'running', 'stopped'} or observed.get('qmpstatus') != status:
        raise ValueError('node process and QMP status are not an unambiguous running or stopped state')
    live = {**live, 'cluster_status': live['status'], 'status': status,
            'qmpstatus': observed['qmpstatus'], 'status_source': status_path}
    return live, config, raw


def require_config(role, allowed_memory):
    live, config, raw = current_vm(role['vmid']); original = base64.b64decode(role['original_config_base64'])
    allowed = {memory_config(original, size) for size in allowed_memory}
    if raw not in allowed: raise ValueError('VM configuration differs outside its exact owned memory transition')
    if int(config.get('onboot', 0)) != 0 or int(config.get('balloon', 0)) != 0:
        raise ValueError('temporary retry role requires the preserved onboot0/balloon0 task profile')
    return live, config, raw


def host_resources(additional_bytes=0):
    memory = {line.split(':', 1)[0]: int(line.split(':', 1)[1].split()[0]) * 1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines()
              if line.split(':', 1)[0] in {'MemTotal', 'MemAvailable'}}
    rows = api('/cluster/resources', '--type', 'vm')
    configured = sum(row.get('maxmem', 0) for row in rows if row.get('status') == 'running')
    free = shutil.disk_usage('/waves/deadsync-lua-audit').free
    if configured + additional_bytes + 12 * GIB > memory['MemTotal']:
        raise ValueError('configured VM memory would cross the12GiB host reserve')
    if memory['MemAvailable'] < 12 * GIB: raise ValueError('host available memory is below its reserved headroom')
    if free < 64 * GIB: raise ValueError('task backing storage is below its64GiB reserve')
    return {'memory': memory, 'running_configured_bytes': configured, 'waves_available_bytes': free}


def transport(row):
    if ipaddress.ip_address(row['ip']) not in ipaddress.ip_network('192.168.1.0/24'): raise ValueError('guest IP escapes the task subnet')
    public_key(row['host_key'])
    known = HOST / ('build-worker-known-hosts' if row['vmid'] == 1516 else 'fleet-known-hosts')
    return ['ssh', '-i', '/root/deadsync-pass3-20261116/transfer-key', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
            '-o', 'StrictHostKeyChecking=yes', '-o', 'UserKnownHostsFile=' + str(known), '-o', 'ServerAliveInterval=15',
            '-o', 'ServerAliveCountMax=3', 'parity@' + row['ip']]


def guest_call(row, request, files, timeout=900):
    hashes = {name: hashlib.sha256(base64.b64decode(raw)).hexdigest() for name, raw in files.items()}
    recipe_id = hashlib.sha256(canonical(hashes)).hexdigest()
    code = r'''
import base64,hashlib,importlib.util,json,pathlib,sys
directory=pathlib.Path('/opt/song-lua-audit/pass4/retries/recipes')/recipe_id;directory.mkdir(parents=True,exist_ok=True)
for name,encoded in files.items():
 raw=base64.b64decode(encoded);assert hashlib.sha256(raw).hexdigest()==hashes[name]
 path=directory/name
 if path.exists():assert path.is_file() and not path.is_symlink() and path.read_bytes()==raw
 else:path.write_bytes(raw)
sys.path.insert(0,str(directory))
import resource_retry_guest
print(json.dumps(resource_retry_guest.action(request)))
'''
    values = {'recipe_id': recipe_id, 'files': files, 'hashes': hashes, 'request': request}
    process = run(transport(row) + ['python3', '-'], input='\n'.join(key + '=' + repr(value) for key, value in values.items()) + '\n' + code, timeout=timeout)
    return json.loads(process.stdout)


def copy_from_guest(row, source, expected_sha, destination):
    source = str(source)
    if not re.fullmatch(r'/opt/song-lua-audit/pass4/(results|retries)/[A-Za-z0-9_./-]+', source) or '..' in pathlib.PurePosixPath(source).parts:
        raise ValueError('remote artifact path is outside an exact ordinary task output')
    destination = pathlib.Path(destination); destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if sha(destination) != expected_sha: raise ValueError('cached original artifact differs')
        return destination
    temporary = destination.with_name(destination.name + '.partial')
    if temporary.exists(): temporary.rename(temporary.with_name(temporary.name + '.' + str(time.time_ns())))
    connection = transport(row)
    run(['scp', *connection[1:-1], connection[-1] + ':' + source, str(temporary)], timeout=900)
    if sha(temporary) != expected_sha: raise ValueError('downloaded original artifact hash differs; partial is retained')
    temporary.replace(destination); return destination


def put_file(row, source, destination, expected_sha):
    destination = str(destination)
    if not re.fullmatch(r'/opt/song-lua-audit/pass4/retries/[A-Za-z0-9_./-]+', destination) or '..' in pathlib.PurePosixPath(destination).parts:
        raise ValueError('retry upload escapes the owned task output')
    if sha(source) != expected_sha: raise ValueError('upload source changed')
    temporary = destination + '.incoming.' + expected_sha[:16]
    probe = r'''
import hashlib,json,pathlib,shutil,time
path=pathlib.Path(destination);path.parent.mkdir(parents=True,exist_ok=True)
assert path.resolve()==path and not path.is_symlink()
if path.exists():
 with path.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected
else:
 if shutil.disk_usage(path.parent).free < upload_bytes+20*1024**3:raise ValueError('upload would cross the guest scratch reserve')
 partial=pathlib.Path(temporary)
 if partial.exists():
  assert partial.is_file() and not partial.is_symlink() and partial.resolve()==partial
  partial.rename(partial.with_name(partial.name+'.interrupted.'+str(time.time_ns())))
print(json.dumps({'present':path.exists()}))
'''
    result = run(transport(row) + ['python3', '-'], input='destination=' + repr(destination) + '\nexpected=' + repr(expected_sha)
                 + '\ntemporary=' + repr(temporary) + '\nupload_bytes=' + repr(pathlib.Path(source).stat().st_size) + '\n' + probe, timeout=30)
    if json.loads(result.stdout)['present']: return
    connection = transport(row)
    run(['scp', *connection[1:-1], str(source), connection[-1] + ':' + temporary], timeout=900)
    publish = r'''
import hashlib,pathlib
source=pathlib.Path(temporary);target=pathlib.Path(destination)
assert source.resolve()==source and target.resolve()==target and not source.is_symlink() and not target.exists()
with source.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected
source.rename(target)
'''
    run(connection + ['python3', '-'], input='temporary=' + repr(temporary) + '\ndestination=' + repr(destination) + '\nexpected=' + repr(expected_sha) + '\n' + publish, timeout=30)


def link_same_guest_archive(row, retained, destination):
    """Bind an original closed archive to this role without duplicating its bytes."""
    code = r'''
import hashlib,json,os,pathlib
root=pathlib.Path('/opt/song-lua-audit/pass4')
source=pathlib.Path(retained['path']);target=pathlib.Path(destination)
assert source.is_relative_to(root/'results') and target.is_relative_to(root/'retries')
assert source.resolve()==source and target.resolve()==target and not source.is_symlink() and not target.is_symlink()
assert source.is_file() and source.stat().st_size==retained['bytes']
with source.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==retained['sha256']
target.parent.mkdir(parents=True,exist_ok=True)
if target.exists():assert os.path.samefile(source,target)
else:os.link(source,target)
print(json.dumps({'path':str(target),'sha256':retained['sha256'],'new_compressed_archive_bytes':0,'samefile':os.path.samefile(source,target)}))
'''
    return json.loads(run(transport(row) + ['python3', '-'], input='retained=' + repr(retained)
                          + '\ndestination=' + repr(str(destination)) + '\n' + code, timeout=180).stdout)


PARKING_POLICY='completed-worker-parking-v1'
HOLD_V2_SHA='8db1a387f4074263e877b5fdb9e96884870f2ceee26032e49d7122029ab3b2d9'


def parking_plan_members(plan, request):
    if plan.get('parking_policy') != PARKING_POLICY or (request['guest_memory_mib'],request['stage_memory_gib']) != (16384,12):
        raise ValueError('parking requires its explicit reviewed16/12GiB plan')
    groups=[]
    for key in ['roles','parked_workers']:
        rows=plan.get(key)
        if not isinstance(rows,list) or not rows:raise ValueError('retry and parked sets must both be explicit and nonempty')
        ids=[row['vmid'] for row in rows]
        if any(type(v)is not int or v not in range(1501,1516) for v in ids) or len(set(ids))!=len(ids):
            raise ValueError('invalid or duplicate explicit parking member')
        groups.append(sorted(ids))
        for row in rows:
            proof=row.get('completed_queue_hold',{})
            if (proof.get('kind')!='completed-original-queue' or proof.get('phase')!='completed-queue-held'
                    or proof.get('vmid')!=row['vmid'] or proof.get('relaunch_required')is not False
                    or proof.get('original_jobs_sha256')!=row['original_assigned_jobs_sha256']):
                raise ValueError('parking plan lacks a truthful exact completed queue hold')
    if set(groups[0])&set(groups[1]):raise ValueError('retry and parked sets overlap')
    if plan['memory'].get('host_reserve_bytes')!=12*GIB or plan['memory'].get('guest_memory_mib')!=16384 or plan['memory'].get('stage_memory_gib')!=12:
        raise ValueError('parking plan changed the fixed host/stage reserve')
    for row in plan['parked_workers']:
        if (row.get('original_status')!='running' or row.get('original_memory_mib')!=8192
                or row.get('expected_config_field_changes')!={} or row.get('relaunch_required')is not False):
            raise ValueError('parked member must preserve exact original8GiB configuration and completed state')
    return groups


def parking_memory_projection(resources, roles, parked, builder):
    if not parked or not roles:raise ValueError('explicit retry and parking sets are required')
    if builder.get('original_status') not in {'running','stopped'}:raise ValueError('builder original running state is unknown')
    if any(row['original_memory_mib']!=8192 or row['target_memory_mib']!=16384 for row in roles):
        raise ValueError('unreviewed retry memory profile')
    if any(row['original_memory_mib']!=8192 or row['target_memory_mib']!=8192 or row.get('original_status')!='running' for row in parked):
        raise ValueError('parking may credit only proved-running ordinary8GiB guests')
    builder_credit=builder['original_memory_mib']*1024**2 if builder['original_status']=='running' else 0
    parked_credit=sum(row['original_memory_mib']*1024**2 for row in parked)
    increase=sum((row['target_memory_mib']-row['original_memory_mib'])*1024**2 for row in roles)
    total=resources['running_configured_bytes']+increase-builder_credit-parked_credit
    if total<0 or total+12*GIB>resources['memory']['MemTotal']:
        raise ValueError('explicit parking still exceeds the unchanged12GiB host reserve')
    return {'projected_configured_bytes':total,'builder_credit_bytes':builder_credit,'parked_credit_bytes':parked_credit,
            'retry_increase_bytes':increase,'host_reserve_bytes':12*GIB,'credit_requires_observed_stopped_before_start':True}


def parked_dependencies(contract):
    parked={row['vmid'] for row in contract['parked_workers']}; result=[]
    for role in contract['roles']:
        for entry in role['entries']:
            if entry['vmid'] not in parked:continue
            artifacts=[]
            for key,name in [('failure','failure.original.json'),('capture_result','capture-result.original.json')]:
                source=pathlib.PurePosixPath(entry[key+'_path'])
                if not source.is_absolute():source=GUEST/source
                if not source.is_relative_to(GUEST/'results') or '..' in source.parts:raise ValueError('parked source receipt escapes original results')
                artifacts.append({'name':name,'source_path':str(source),'sha256':entry[key+'_sha256'],
                                  'cache_relative':'original-attempts/'+str(entry['vmid'])+'/'+entry['id']+'/'+name})
            if entry['operation']=='replay-only':
                retained=entry['retained_candidate'];name=retained['sha256']+'.tar.zst';source=pathlib.PurePosixPath(retained['path'])
                if not source.is_relative_to(GUEST/'results') or '..' in source.parts:raise ValueError('parked archive escapes original results')
                artifacts.append({'name':name,'source_path':str(source),'sha256':retained['sha256'],'bytes':retained['bytes'],
                                  'decoded_sha256':retained['uncompressed_sha256'],'cache_relative':'compressed-inputs/'+name})
            result.append({'retry_vmid':role['vmid'],'source_vmid':entry['vmid'],'id':entry['id'],
                           'entry_sha256':hashlib.sha256(canonical(entry)).hexdigest(),'artifacts':artifacts})
    return result


def checked_cached_input(directory, relative, expected_sha, expected_bytes=None):
    path=directory/relative
    if (path.resolve()!=path or not path.is_relative_to(directory) or path.is_symlink() or not path.is_file()
            or sha(path)!=expected_sha or expected_bytes is not None and path.stat().st_size!=expected_bytes):
        raise ValueError('parked-source cache is absent/changed; an offline source must not be contacted')
    return path


def verify_parked_export_receipt(directory, manifest, proposed_value=None):
    contract=manifest['contract'];specs=parked_dependencies(contract);path=directory/'parked-source-exports.json'
    if proposed_value is None:
        if path.is_symlink() or not path.is_file():raise ValueError('parked sources have no completed export/import receipt')
        value=read(path)
    else:value=proposed_value
    if (value.get('passed')is not True or value.get('role_id')!=manifest['id'] or value.get('specifications')!=specs
            or value.get('specifications_sha256')!=hashlib.sha256(canonical(specs)).hexdigest()):
        raise ValueError('parked export/import receipt differs from the exact frozen dependencies')
    for spec in specs:
        for artifact in spec['artifacts']:
            checked_cached_input(directory,artifact['cache_relative'],artifact['sha256'],artifact.get('bytes'))
    expected_targets={spec['retry_vmid'] for spec in specs}
    if {int(key) for key in value.get('imports',{})}!=expected_targets:raise ValueError('parked import targets are incomplete or extra')
    for role in contract['roles']:
        selected=[entry for entry in role['entries'] if any(s['id']==entry['id'] and s['retry_vmid']==role['vmid'] for s in specs)]
        if not selected:continue
        proof=value['imports'][str(role['vmid'])]
        if proof.get('passed')is not True or proof.get('role_id')!=manifest['id'] or proof.get('vmid')!=role['vmid']:
            raise ValueError('parked import proof belongs to another role/target')
        rows=proof.get('inputs',[])
        if len(rows)!=len(selected):raise ValueError('parked import proof does not cover every selected dependency')
        for entry,row in zip(selected,rows):
            if any(row.get(key)!=expected for key,expected in [('id',entry['id']),('source_vmid',entry['vmid']),
                    ('entry_sha256',hashlib.sha256(canonical(entry)).hexdigest()),('failure_sha256',entry['failure_sha256']),
                    ('capture_result_sha256',entry['capture_result_sha256'])]):
                raise ValueError('parked import changed original attempt identity')
            if entry['operation']=='replay-only':
                retained=entry['retained_candidate'];archive=row.get('archive') or {}
                if (archive.get('bytes')!=retained['bytes'] or archive.get('compressed_sha256')!=retained['sha256']
                        or archive.get('decoded_sha256')!=retained['uncompressed_sha256'] or type(archive.get('decoded_bytes'))is not int
                        or archive['decoded_bytes']<=0):raise ValueError('parked archive lacks exact compressed+decoded import proof')
            elif row.get('archive')is not None:raise ValueError('new-native retry may not invent an original complete archive')
    digest=sha(path) if proposed_value is None else hashlib.sha256(json.dumps(value,ensure_ascii=False,indent=2).encode()+b'\n').hexdigest()
    return {'path':str(path),'sha256':digest,'dependency_count':len(specs),'passed':True}


def prepare_parked_exports(directory, manifest, files, rows):
    path=directory/'parked-source-exports.json'
    if path.exists():return verify_parked_export_receipt(directory,manifest)
    if path.is_symlink():raise ValueError('unknown parked export receipt symlink')
    contract=manifest['contract'];specs=parked_dependencies(contract);parked={r['vmid']:r for r in contract['parked_workers']}
    records=[]
    for spec in specs:
        source=rows[spec['source_vmid']];target=rows[spec['retry_vmid']]
        live,_,_=require_config(parked[spec['source_vmid']],[8192])
        if live['status']!='running':raise ValueError('parked source stopped before verified exports/imports completed')
        incoming=GUEST/'retries/roles'/manifest['id']/str(spec['retry_vmid'])/'imports'/spec['id']
        for item in spec['artifacts']:
            destination=directory/item['cache_relative']
            if not destination.exists() and shutil.disk_usage(directory).free < item.get('bytes',16*1024**2)+64*GIB:
                raise ValueError('parked-source export would cross the unchanged host cache reserve')
            local=copy_from_guest(source,item['source_path'],item['sha256'],destination)
            checked_cached_input(directory,item['cache_relative'],item['sha256'],item.get('bytes'))
            put_file(target,local,str(incoming/item['name']),item['sha256'])
            records.append({'retry_vmid':spec['retry_vmid'],'source_vmid':spec['source_vmid'],'id':spec['id'],
                            'artifact':item,'host_path':str(local),'bytes':local.stat().st_size})
            save(directory/'parked-export-progress.json',{'role_id':manifest['id'],'records':records,'complete':False})
    imports={}
    for vmid in sorted({row['retry_vmid'] for row in specs}):
        imports[str(vmid)]=guest_call(rows[vmid],{'action':'verify_parked_inputs','contract':str(GUEST/'retries/roles'/manifest['id']/str(vmid)/'contract.json'),'vmid':vmid},files)
    value={'passed':True,'role_id':manifest['id'],'specifications':specs,'specifications_sha256':hashlib.sha256(canonical(specs)).hexdigest(),
           'exports':records,'imports':imports,'finished_at_ns':time.time_ns(),'all_sources_still_required_reachable_until_this_receipt':True}
    verify_parked_export_receipt(directory,manifest,proposed_value=value)
    save(path,value)
    return verify_parked_export_receipt(directory,manifest)


def park_completed_workers(directory, manifest, files, rows, state, event):
    contract=manifest['contract'];proved=prepare_parked_exports(directory,manifest,files,rows)
    if state.get('parked_exports') and state['parked_exports']!=proved:raise ValueError('owned parked export receipt changed')
    state['parked_exports']=proved;event('parked-source-imports-proved')
    for role in contract['parked_workers']:
        info=state['parked'][str(role['vmid'])];live,_,_=require_config(role,[8192])
        intent={'role_id':manifest['id'],'vmid':role['vmid'],'original_status':'running','original_config_sha256':role['original_config_sha256']}
        if info.get('stop_intent') and info['stop_intent']!=intent:raise ValueError('parked shutdown intent differs')
        if info.get('stopped'):
            if live['status']!='stopped':raise ValueError('parked guest resumed outside its owned restoration')
            continue
        if live['status']=='running':
            proof=guest_call(rows[role['vmid']],{'action':'parking_stop_ready','contract':str(GUEST/'retries/roles'/manifest['id']/str(role['vmid'])/'contract.json'),'vmid':role['vmid']},files)
            if proof.get('passed')is not True or proof.get('completed_queue_hold')!=role['completed_queue_hold']:
                raise ValueError('parked shutdown lacks its exact current completed-owner proof')
            info['stop_ready']=proof
        elif not info.get('stop_intent'):raise ValueError('unowned stopped parked guest cannot be adopted')
        info['stop_intent']=intent;event('stopping-completed-worker',vmid=role['vmid'])
        stop_gracefully(role,[8192]);observed,_,raw=require_config(role,[8192])
        if observed['status']!='stopped':raise ValueError('completed parked worker is not stopped')
        info['stopped']={'observed_status':'stopped','source':observed['status_source'],'configuration_sha256':hashlib.sha256(raw).hexdigest()}
        event('completed-worker-parked',vmid=role['vmid'])


def require_parked_stopped(contract, state):
    for role in contract['parked_workers']:
        info=state.get('parked',{}).get(str(role['vmid']),{})
        expected={'role_id':state['role_id'],'vmid':role['vmid'],'original_status':'running','original_config_sha256':role['original_config_sha256']}
        observed=info.get('stopped') or {}
        if (info.get('stop_intent')!=expected or observed.get('observed_status')!='stopped'
                or observed.get('configuration_sha256')!=role['original_config_sha256']):
            raise ValueError('parking credit has no exact owned stopped proof')
        live,_,_=require_config(role,[8192])
        if live['status']!='stopped':raise ValueError('parking credit is unavailable because the guest is running')


def restore_parked_workers(directory, manifest, files, rows, state, event):
    contract=manifest['contract']
    for role in contract['roles']:
        live,_,_=require_config(role,[8192])
        if live['status']!='running' or not state['roles'].get(str(role['vmid']),{}).get('restored'):
            raise ValueError('every retry role must return to ordinary8GiB before parked guests restart')
    for role in contract['parked_workers']:
        info=state['parked'].setdefault(str(role['vmid']),{})
        live,_,_=require_config(role,[8192]);row=rows[role['vmid']]
        if info.get('restored'):
            if live['status']!='running':raise ValueError('previously restored completed worker is no longer running')
            continue
        if not info.get('setup'):
            if live['status']!='running':raise ValueError('an unprepared parked guest may not have been stopped')
            setup=guest_call(row,{'action':'setup','manifest':manifest,'vmid':role['vmid'],'files':files},files)
            setup['host_journals']=preserve_journals(row,setup['journals'],directory);info['setup']=setup
            event('preserved-unactivated-completed-hold-for-release',vmid=role['vmid'])
        if live['status']=='stopped':
            expected={'role_id':manifest['id'],'vmid':role['vmid'],'original_status':'running','original_config_sha256':role['original_config_sha256']}
            if info.get('stop_intent')!=expected:raise ValueError('parked restart has no exact durable owned stop intent')
            for item in info['setup']['host_journals']:
                if sha(item['host_path'])!=item['host_sha256']:raise ValueError('parked pre-shutdown journal evidence changed')
            host_resources(additional_bytes=8192*1024**2);event('restarting-completed-parked-worker',vmid=role['vmid'])
            run(['qm','start',role['vmid']],timeout=90)
        address=qga_address(role);row=update_transport(row,{**address,'memory_mib':8192},directory);rows[role['vmid']]=row
        require_config(role,[8192]);path=str(GUEST/'retries/roles'/manifest['id']/str(role['vmid'])/'contract.json')
        if not info.get('restore_prepared'):
            prepared=guest_call(row,{'action':'prepare_restore','contract':path,'vmid':role['vmid']},files)
            prepared['host_journals']=preserve_journals(row,prepared['journals'],directory);info['restore_prepared']=prepared
            event('parked-completion-prepared-for-release',vmid=role['vmid'])
        info['restored']=guest_call(row,{'action':'resume_original','contract':path,'vmid':role['vmid']},files)
        if info['restored'].get('original_queue_relaunched')is not False or not info['restored'].get('original_queue_remains_complete'):
            raise ValueError('parked completion restore attempted to relaunch an already finished queue')
        event('parked-worker-restored-without-queue-launch',vmid=role['vmid'])


def freeze(request):
    if (TASK / 'active-role.json').exists() or (TASK / 'active-role.json').is_symlink(): raise ValueError('another retry role still owns guest resources')
    plan_raw = base64.b64decode(request['role_plan']); plan = json.loads(gzip.decompress(plan_raw))
    if hashlib.sha256(plan_raw).hexdigest() != request['role_plan_sha256'] or plan.get('executed') is not False:
        raise ValueError('role plan identity or unexecuted status differs')
    candidate_id = request['candidate']; bundle_sha = request['bundle_sha256']
    bundle = read(HOST / 'runner-bundles' / candidate_id / (bundle_sha + '.json'))
    if bundle['candidate'] != candidate_id or bundle['sha256'] != bundle_sha or sha(bundle['host_path']) != bundle_sha:
        raise ValueError('host has no exact final candidate bundle')
    with tarfile.open(bundle['host_path'], 'r:gz') as archive:
        bundled = json.load(archive.extractfile('bundle-manifest.json'))
    if bundled['contract'] != bundle['contract'] or hashlib.sha256(canonical(bundled['contract'])).hexdigest() != bundled['id']:
        raise ValueError('candidate bundle manifest differs from its host receipt')
    expected = bundle['contract']
    candidate = {'id': candidate_id, 'bundle_sha256': bundle_sha, 'bundle_host_path': bundle['host_path'],
                 'runner_sha256': expected['runner_sha256'], 'source_proof_sha256': expected['source_proof_sha256'],
                 'build_proof_sha256': expected['build_proof_sha256']}
    hashes = {name: hashlib.sha256(base64.b64decode(raw)).hexdigest() for name, raw in request['files'].items()}
    if hashes['worker.py'] != WORKER_SHA or hashes['worker.py'] != expected['files']['worker.py']['sha256']:
        raise ValueError('final rollout does not pin the accepted worker4155')
    for name in ['replay_only.py', 'rollout_runner.py']:
        if hashes[name] != expected['files'][name]['sha256']: raise ValueError('retry wrapper/rollout helper differs from final bundle')
    fleet = {row['vmid']: row for row in read(HOST / 'fleet.json')}; builder = read(HOST / 'build-worker.json')
    if set(fleet) != set(range(1501, 1516)) or builder['vmid'] != 1516: raise ValueError('task fleet identity differs')
    selected, parked_ids = parking_plan_members(plan,request)
    if hashes.get('completed_queue_hold.py') != HOLD_V2_SHA: raise ValueError('future parking requires the corrected completed hold source')
    originals = {row['vmid']: row for row in plan['observed']['rows']}
    observations = {}; roles = []; parked = []; profiles = None; journal_authorities = {}
    if set(originals) != set(selected+parked_ids+[1516]): raise ValueError('parking plan observations omit or add a member')
    # The final binary/proof must already be on every worker before1516can stop.
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(guest_call, row, {'action': 'inspect', 'vmid': vmid, 'candidate': candidate, 'only_candidate': True}, request['files']): vmid
                   for vmid, row in fleet.items()}
        for future in concurrent.futures.as_completed(futures): observations[futures[future]] = future.result()
    for vmid in [*selected, *parked_ids, 1516]:
        live, config, raw = current_vm(vmid)
        if (live['status'] != originals[vmid]['original_status'] or live.get('cluster_status') != live['status']
                or vmid != 1516 and live['status'] != 'running'
                or sha(pathlib.Path('/etc/pve/qemu-server', str(vmid) + '.conf')) != originals[vmid]['config_file_sha256']):
            raise ValueError('planned VM configuration changed before final role freeze')
        row = builder if vmid == 1516 else fleet[vmid]
        if vmid == 1516:
            # PVE can serialize numeric settings as canonical decimal strings.
            if (config['name'] != 'deadsync-lua-20261119-build' or
                    any(type(config[key]) not in (int, str) or str(config[key]) != str(expected)
                        for key, expected in [('memory', 16384), ('cores', 8)])):
                raise ValueError('build VM no longer matches its exact task configuration')
            if live['status'] == 'running':
                observations[vmid] = guest_call(row, {'action':'inspect','vmid':vmid,'candidate':candidate},request['files'])
            else:
                observations[vmid] = {'observed_stopped':True,'guest_queried':False,'status_source':live['status_source']}
            builder_record = {**row, 'original_config_base64': base64.b64encode(raw).decode(), 'original_config_sha256': hashlib.sha256(raw).hexdigest(),
                              'original_memory_mib': int(config['memory']), 'original_status':live['status']}
            continue
        if (config.get('name') != 'deadsync-lua-20261119-'+str(vmid-1500).zfill(2)
                or any(type(config.get(key)) not in (int,str) or str(config[key])!=str(expected)
                       for key,expected in [('memory',8192),('cores',2),('balloon',0),('onboot',0)])):
            raise ValueError('parking member differs from its exact ordinary task configuration')
        original = next(item for item in [*plan['roles'],*plan['parked_workers']] if item['vmid'] == vmid)
        if original['original_config_sha256'] != hashlib.sha256(raw).hexdigest(): raise ValueError('parking member configuration differs from its planned identity')
        probe = guest_call(row, {'action': 'inspect', 'vmid': vmid, 'candidate': candidate,
                                'original_jobs_sha256': original['original_assigned_jobs_sha256'],
                                'capture_profile': request.get('capture_profile'), 'parked_only':vmid in parked_ids}, request['files'])
        readiness = probe.get('runtime_readiness', {})
        if readiness.get('passed') is not True or readiness.get('policy_sha256') != hashes['retry_runtime_readiness.py']:
            raise ValueError('selected retry worker lacks the frozen persistent-service readiness proof')
        if probe.get('completed_queue_hold') != original['completed_queue_hold'] or 'drain' in probe:
            raise ValueError('parking freeze changed its exact completed queue owner')
        if vmid in parked_ids:
            parked.append({**row,'role_kind':'parked-completed-worker','original_status':'running',
                           'original_config_base64':base64.b64encode(raw).decode(),'original_config_sha256':hashlib.sha256(raw).hexdigest(),
                           'original_memory_mib':8192,'target_memory_mib':8192,'entries':[],
                           'original_jobs_sha256':probe['jobs_sha256'],'completed_queue_hold':probe['completed_queue_hold'],
                           'original_results':probe['original_results'],'original_queue_base64':probe['original_queue_base64'],
                           'runtime_readiness_preflight':readiness,'relaunch_required':False})
            continue
        if profiles is None: profiles = probe['profiles']
        elif profiles != probe['profiles']: raise ValueError('selected workers have different proved capture/replay profiles')
        entries = json.loads(base64.b64decode(request['attempts'][str(vmid)]))
        if hashlib.sha256(base64.b64decode(request['attempts'][str(vmid)])).hexdigest() != original['attempts_sha256']:
            raise ValueError('per-worker retry attempt selection differs from accepted role plan')
        jobs_raw=base64.b64decode(request['jobs'][str(vmid)])
        if hashlib.sha256(jobs_raw).hexdigest()!=original['jobs_sha256'] or canonical(json.loads(jobs_raw))!=canonical([entry['retry_job'] for entry in entries]):
            raise ValueError('per-worker exact jobs bytes disagree with its ordered frozen attempts')
        for entry in entries:
            authority = entry['oom_authority']
            if entry['vmid'] not in fleet or entry['operation'] not in {'replay-only', 'capture-archive-replay'}:
                raise ValueError('retry attempt is outside the task fleet or supported operations')
            if entry['original_job']['id'] != entry['id'] or not valid_sha(entry['failure_sha256']) or not valid_sha(entry['capture_result_sha256']):
                raise ValueError('retry attempt lacks exact original job/receipt identities')
            if authority['kind'] == 'durable-stage-receipt':
                stage = authority['stage']
                if stage.get('service_result') != 'oom-kill' or stage.get('memory_limit') != '6G' or not stage.get('exit'):
                    raise ValueError('higher-memory retry requires a proved original6GiB OOM')
                expected_status = 'replay_resource_limit' if entry['operation'] == 'replay-only' else 'capture_resource_limit'
                if entry['original_status'] != expected_status: raise ValueError('retry stage/status contradicts its OOM authority')
            elif authority['kind'] == 'separate-preserved-systemd-journal':
                source = pathlib.Path(authority['path'])
                if (not source.is_relative_to(HOST) or source.resolve() != source or not valid_sha(authority['sha256'])
                        or sha(source) != authority['sha256'] or entry['operation'] != 'capture-archive-replay'
                        or not authority.get('original_status_unchanged')):
                    raise ValueError('journal-only OOM lacks its exact independent host evidence')
                journal_authorities[authority['sha256']] = {'source_path': str(source), 'bytes': source.stat().st_size, 'sha256': authority['sha256']}
            else: raise ValueError('unknown resource retry authority')
            if (canonical(entry['retry_job'])!=canonical({**entry['original_job'],'stage_memory':'12G'})
                    or entry['original_job'].get('stage_memory')!='6G' or type(entry.get('retry_vmid'))is not int or entry['retry_vmid']!=vmid):
                raise ValueError('parking retry must preserve its exact original inputs and planned target with only6G to12G memory change')
            mode='same-guest-hardlink' if entry['vmid']==vmid and entry['operation']=='replay-only' else 'verified-compressed-transfer' if entry['operation']=='replay-only' else 'new-native-capture'
            if entry.get('archive_import')!=mode:raise ValueError('parking retry changed its exact planned import locality')
        if 'completed_queue_hold' in probe:
            if 'drain' in probe: raise ValueError('completed queue cannot also claim an active coordinator drain')
            queue_owner = {'completed_queue_hold':probe['completed_queue_hold']}
        else:
            queue_owner = {'drain_sha256':probe['drain']['marker_sha256'], 'drain_state_sha256':probe['drain']['state_sha256']}
        roles.append({**row, 'role_kind':'retry', 'original_status':'running', 'original_config_base64': base64.b64encode(raw).decode(), 'original_config_sha256': hashlib.sha256(raw).hexdigest(),
                      'original_memory_mib': 8192, 'target_memory_mib': request['guest_memory_mib'],
                      'stage_memory': str(request['stage_memory_gib']) + 'G', 'stage_memory_bytes': request['stage_memory_gib'] * GIB,
                      'original_jobs_sha256': probe['jobs_sha256'], **queue_owner, 'original_results': probe['original_results'],
                      'original_queue_base64': probe['original_queue_base64'], 'entries': entries,
                      'runtime_readiness_preflight': readiness})
    if request['stage_memory_gib'] == 6 and profiles['capture'] == profiles['replay'] and any(row['operation'] != 'replay-only' for role in roles for row in role['entries']):
        raise ValueError('same-limit native retry requires a separately proved capture-profile improvement')
    need_builder_stop = builder_record['original_status']=='running'
    resources=host_resources();projection=parking_memory_projection(resources,roles,parked,builder_record)
    contract = {'schema_version': 1, 'role_plan_sha256': request['role_plan_sha256'], 'candidate': candidate, 'helpers': hashes,
                'host_helper_sha256': request['host_helper_sha256'], 'roles': roles, 'parked_workers':parked, 'parking_policy':PARKING_POLICY, 'builder': builder_record,
                'parking_memory_projection':projection,
                'profiles': profiles, 'builder_stop_required': need_builder_stop, 'source_snapshot_sha256': plan['source_snapshot_sha256'],
                'journal_authorities': journal_authorities,
                'frozen_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'resource_observation': resources,
                'all15_final_candidate_proved': observations}
    contract['parked_source_dependencies']=parked_dependencies(contract)
    identifier = hashlib.sha256(canonical(contract)).hexdigest(); directory = TASK / identifier
    directory.mkdir(parents=True, exist_ok=False)
    manifest = {'id': identifier, 'contract': contract}
    save(directory / 'manifest.json', manifest); stable(directory / 'source-role-plan.json.gz', plan_raw)
    for name, raw in request['files'].items(): stable(directory / 'helpers' / name, base64.b64decode(raw))
    for digest, item in journal_authorities.items(): stable(directory / 'source-journal-authorities' / (digest + '.json'), pathlib.Path(item['source_path']).read_bytes())
    stable(directory / 'resource_retry_roles.py', base64.b64decode(request['host_helper']))
    save(directory / 'state.json', {'role_id': identifier, 'phase': 'frozen', 'vm_actions_performed': 0, 'events': []})
    return {'role_id': identifier, 'directory': str(directory), 'manifest': manifest, 'manifest_sha256': sha(directory / 'manifest.json'),
            'candidate': candidate, 'vm_actions_performed': 0}


def load_role(identifier):
    if not valid_sha(identifier): raise ValueError('exact role ID is required')
    directory = TASK / identifier; manifest = read(directory / 'manifest.json'); contract = manifest['contract']
    if manifest['id'] != identifier or hashlib.sha256(canonical(contract)).hexdigest() != identifier or sha(__file__) != contract['host_helper_sha256']:
        raise ValueError('frozen role/helper identity differs')
    files = {}
    for name, expected in contract['helpers'].items():
        path = directory / 'helpers' / name
        if sha(path) != expected: raise ValueError('frozen guest helper changed')
        files[name] = base64.b64encode(path.read_bytes()).decode()
    if sha(contract['candidate']['bundle_host_path']) != contract['candidate']['bundle_sha256']:
        raise ValueError('host final candidate artifact is absent or changed')
    for digest in contract.get('journal_authorities', {}):
        if sha(directory / 'source-journal-authorities' / (digest + '.json')) != digest:
            raise ValueError('preserved independent OOM journal authority changed')
    return directory, manifest, contract, files


def qga_address(role):
    for attempt in range(90):
        try:
            networks = json.loads(run(['qm', 'guest', 'cmd', role['vmid'], 'network-get-interfaces'], timeout=15).stdout)
            addresses = [item['ip-address'] for interface in networks for item in interface.get('ip-addresses', [])
                         if item.get('ip-address-type') == 'ipv4' and ipaddress.ip_address(item['ip-address']) in ipaddress.ip_network('192.168.1.0/24')]
            if len(addresses) == 1:
                key = json.loads(run(['qm', 'guest', 'exec', role['vmid'], '--', 'cat', '/etc/ssh/ssh_host_ed25519_key.pub'], timeout=15).stdout)
                if key.get('exitcode') == 0:
                    observed = key['out-data'].strip()
                    if public_key(observed) != public_key(role['host_key']): raise ValueError('guest public host key changed after reboot')
                    return {**role, 'ip': addresses[0], 'host_key': observed, 'status': 'running'}
        except subprocess.CalledProcessError: pass
        time.sleep(2)
    raise TimeoutError('guest did not return a unique QGA-verified address/key')


def update_transport(before, after, directory):
    receipt_path = HOST / ('build-worker.json' if after['vmid'] == 1516 else 'fleet.json')
    known_path = HOST / ('build-worker-known-hosts' if after['vmid'] == 1516 else 'fleet-known-hosts')
    transition_id = hashlib.sha256(canonical({key: after[key] for key in ['vmid', 'ip', 'host_key', 'memory_mib']})).hexdigest()
    history = directory / 'transport-transitions' / transition_id
    intent_path = history / 'intent.json'
    if intent_path.exists():
        intent = read(intent_path)
        if intent.get('vmid') != after['vmid'] or intent.get('target') != {key: after[key] for key in ['ip', 'host_key', 'memory_mib']}:
            raise ValueError('transport transition intent belongs to another guest state')
        for path, prefix in [(receipt_path, 'receipt'), (known_path, 'known-hosts')]:
            old = (history / (prefix + '.before')).read_bytes(); new = (history / (prefix + '.after')).read_bytes()
            if sha(history / (prefix + '.before')) != intent[prefix + '_before_sha256'] or sha(history / (prefix + '.after')) != intent[prefix + '_after_sha256']:
                raise ValueError('preserved transport transition changed')
            if path.read_bytes() not in {old, new}: raise ValueError('unknown transport edits block interrupted transition recovery')
        for path, prefix in [(receipt_path, 'receipt'), (known_path, 'known-hosts')]:
            new = (history / (prefix + '.after')).read_bytes()
            if path.read_bytes() != new:
                temporary = path.with_name(path.name + '.retry-role-' + transition_id[:16] + '.tmp')
                stable(temporary, new); temporary.replace(path)
        save(history / 'completed.json', {'completed': True, 'at_ns': time.time_ns(), 'intent_sha256': sha(intent_path)})
        return {**after, 'transport_receipt_sha256': sha(receipt_path), 'known_hosts_sha256': sha(known_path)}
    receipt_raw = receipt_path.read_bytes(); known_raw = known_path.read_bytes()
    rows = json.loads(receipt_raw)
    values = [rows] if after['vmid'] == 1516 else rows
    row = next(row for row in values if row['vmid'] == after['vmid'])
    if public_key(row['host_key']) != public_key(before['host_key']): raise ValueError('fleet transport receipt changed outside this role')
    if any(item['vmid'] != after['vmid'] and item.get('ip') == after['ip'] for item in values): raise ValueError('QGA IP conflicts with another task guest')
    old_ip = row['ip']; row.update(ip=after['ip'], host_key=after['host_key'], status='running', memory_mib=after['memory_mib'])
    lines = known_raw.decode().splitlines(); changed = False
    for index, line in enumerate(lines):
        parts = line.split()
        if parts and parts[0] == old_ip and parts[1:3] == public_key(before['host_key']):
            lines[index] = after['ip'] + ' ' + after['host_key']; changed = True
    if not changed: raise ValueError('known-hosts file lacks the exact preserved guest key')
    if receipt_path.read_bytes() != receipt_raw or known_path.read_bytes() != known_raw: raise ValueError('fleet transport changed concurrently')
    new_receipt = json.dumps(values[0] if after['vmid'] == 1516 else values, ensure_ascii=False, indent=2).encode() + b'\n'
    new_known = ('\n'.join(lines) + '\n').encode()
    history.mkdir(parents=True, exist_ok=True)
    for name, raw in [('receipt.before', receipt_raw), ('receipt.after', new_receipt), ('known-hosts.before', known_raw), ('known-hosts.after', new_known)]:
        stable(history / name, raw)
    intent = {'vmid': after['vmid'], 'target': {key: after[key] for key in ['ip', 'host_key', 'memory_mib']},
              **{name.replace('.', '_') + '_sha256': hashlib.sha256(raw).hexdigest()
                 for name, raw in [('receipt.before', receipt_raw), ('receipt.after', new_receipt), ('known-hosts.before', known_raw), ('known-hosts.after', new_known)]}}
    save(intent_path, intent)
    return update_transport(before, after, directory)


def stop_gracefully(role, allowed_memory):
    live, config, _ = require_config(role, allowed_memory)
    if live['status'] == 'stopped': return
    if live['status'] != 'running': raise ValueError('guest is neither running nor safely stopped')
    run(['qm', 'shutdown', role['vmid'], '--timeout', '90'], timeout=105)
    if current_vm(role['vmid'])[0]['status'] != 'stopped': raise ValueError('graceful guest shutdown did not complete; force-stop is forbidden')


def change_memory_and_start(role, target_mib):
    live, config, raw = require_config(role, [role['original_memory_mib'], role['target_memory_mib']])
    if live['status'] == 'running':
        if int(config['memory']) != target_mib: raise ValueError('refusing a live memory change')
        return qga_address(role)
    if live['status'] != 'stopped': raise ValueError('memory transition requires a stopped guest')
    if int(config['memory']) != target_mib:
        run(['qm', 'set', role['vmid'], '--memory', target_mib], timeout=30)
    require_config(role, [target_mib]); host_resources(additional_bytes=target_mib * 1024 ** 2)
    run(['qm', 'start', role['vmid']], timeout=90)
    return qga_address(role)


def preserve_journals(row, journals, directory):
    records = []
    for journal in journals:
        target = directory / 'journal-evidence' / str(row['vmid']) / (journal['sha256'] + '.jsonl.gz')
        copy_from_guest(row, journal['path'], journal['sha256'], target)
        records.append({**journal, 'host_path': str(target), 'host_sha256': sha(target)})
    return records


def phase(identifier, operation, resume_interrupted=False, cancel_pending=False):
    import fcntl
    directory, manifest, contract, files = load_role(identifier)
    with (TASK / 'orchestration.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state = read(directory / 'state.json'); state.setdefault('events', []); state.setdefault('roles', {}); state.setdefault('parked', {})
        owner_path = TASK / 'active-role.json'
        owner = {'role_id': identifier, 'candidate': contract['candidate']['id']}
        if owner_path.exists() and read(owner_path) != owner:
            raise ValueError('another temporary role owns guest resources')
        if operation == 'activate':
            if state.get('phase') == 'all-original-roles-restored': raise ValueError('a restored immutable role cannot be reactivated')
            if not owner_path.exists(): save(owner_path, owner)
        elif not owner_path.exists() and state.get('phase') != 'all-original-roles-restored':
            raise ValueError('temporary role has not acquired its host resource ownership')
        def event(name, **values):
            state['phase'] = name; state['events'].append({'phase': name, 'at_ns': time.time_ns(), **values}); save(directory / 'state.json', state)
        rows = {row['vmid']: row for row in read(HOST / 'fleet.json')}
        if operation == 'activate':
            for role in [*contract['roles'],*contract['parked_workers']]:
                group=state['parked'] if role['role_kind']=='parked-completed-worker' else state['roles']
                info = group.setdefault(str(role['vmid']), {})
                if info.get('ready'): continue
                if not info.get('setup'):
                    require_config(role, [role['original_memory_mib']]); event('preserving-original-queue', vmid=role['vmid'])
                    setup = guest_call(rows[role['vmid']], {'action': 'setup', 'manifest': manifest, 'vmid': role['vmid'], 'files': files}, files)
                    setup['host_journals'] = preserve_journals(rows[role['vmid']], setup['journals'], directory)
                    info['setup'] = setup; save(directory / 'state.json', state)
            if contract['builder_stop_required'] and not state.get('builder_stopped'):
                builder = contract['builder']; current_builder = read(HOST / 'build-worker.json')
                require_config(builder, [builder['original_memory_mib']])
                if not state.get('builder_journals'):
                    data = guest_call(current_builder, {'action': 'builder_journals', 'vmid': 1516, 'candidate': contract['candidate'], 'role_id': identifier}, files)
                    state['builder_journals'] = preserve_journals(current_builder, data['journals'], directory); save(directory / 'state.json', state)
                state['builder_stop_intent'] = {'vmid': 1516, 'original_config_sha256': builder['original_config_sha256'],
                                                'original_status': 'running', 'at_ns': time.time_ns()}
                event('stopping-idle-builder'); stop_gracefully(builder, [builder['original_memory_mib']])
                state['builder_stopped'] = True; event('builder-stopped')
            park_completed_workers(directory,manifest,files,rows,state,event)
            require_parked_stopped(contract,state)
            if contract['builder']['original_status']=='stopped' and require_config(contract['builder'],[16384])[0]['status']!='stopped':
                raise ValueError('originally stopped builder was started outside the parking contract')
            for role in contract['roles']:
                info = state['roles'][str(role['vmid'])]
                if info.get('ready'): continue
                row = rows[role['vmid']]
                if role['target_memory_mib'] != role['original_memory_mib']:
                    event('changing-guest-memory', vmid=role['vmid'])
                    stop_gracefully(role, [role['original_memory_mib'], role['target_memory_mib']])
                    address = change_memory_and_start(role, role['target_memory_mib'])
                    row = update_transport(row, {**address, 'memory_mib': role['target_memory_mib']}, directory)
                    rows[role['vmid']] = row
                else: require_config(role, [role['original_memory_mib']])
                request = {'action': 'after_boot', 'contract': str(GUEST / 'retries/roles' / identifier / str(role['vmid']) / 'contract.json'), 'vmid': role['vmid']}
                info['ready'] = guest_call(row, request, files); event('retry-role-ready', vmid=role['vmid'])
            event('all-retry-roles-ready'); return state
        if operation == 'retry':
            if not all(state['roles'].get(str(role['vmid']), {}).get('ready') for role in contract['roles']): raise ValueError('retry roles are not all ready')
            require_parked_stopped(contract,state); verify_parked_export_receipt(directory,manifest)
            event('retry-queue-running')
            def queue(role):
                target = rows[role['vmid']]; role_root = GUEST / 'retries/roles' / identifier / str(role['vmid'])
                contract_path = str(role_root / 'contract.json'); outputs = []
                for entry in role['entries']:
                    host_resources(); require_config(role, [role['target_memory_mib']])
                    source = rows[entry['vmid']]
                    incoming = role_root / 'imports' / entry['id']
                    origin = directory / 'original-attempts' / str(entry['vmid']) / entry['id']
                    for key, name in [('failure', 'failure.original.json'), ('capture_result', 'capture-result.original.json')]:
                        source_path = pathlib.PurePosixPath(entry[key + '_path'])
                        if not source_path.is_absolute(): source_path = GUEST / source_path
                        if source['vmid'] in {row['vmid'] for row in contract['parked_workers']}:
                            local=checked_cached_input(directory,str((origin/name).relative_to(directory)),entry[key+'_sha256'])
                        else:local = copy_from_guest(source, str(source_path), entry[key + '_sha256'], origin / name)
                        put_file(target, local, str(incoming / name), entry[key + '_sha256'])
                    if entry['operation'] == 'replay-only':
                        retained = entry['retained_candidate']; name = retained['sha256'] + '.tar.zst'
                        if source['vmid'] == target['vmid']:
                            link_same_guest_archive(target, retained, incoming / name)
                        else:
                            if source['vmid'] in {row['vmid'] for row in contract['parked_workers']}:
                                local=checked_cached_input(directory,'compressed-inputs/'+name,retained['sha256'],retained['bytes'])
                            else:
                                if shutil.disk_usage(directory).free < retained['bytes'] + 64 * GIB:
                                    raise ValueError('retained input transfer would cross the host cache reserve')
                                local = copy_from_guest(source, retained['path'], retained['sha256'], directory / 'compressed-inputs' / name)
                            put_file(target, local, str(incoming / name), retained['sha256'])
                    launched = guest_call(target, {'action': 'launch_case', 'contract': contract_path, 'vmid': role['vmid'], 'id': entry['id'],
                                                   'resume_interrupted': resume_interrupted}, files)
                    deadline = time.monotonic() + launched.get('timeout_seconds', 6000) + 90
                    while True:
                        observed = guest_call(target, {'action': 'status', 'contract': contract_path, 'vmid': role['vmid'], 'id': entry['id']}, files, timeout=60)
                        match = next((item for item in observed['outcomes'] if item.get('data', {}).get('id') == entry['id']), None)
                        if match:
                            outputs.append(match); save(directory / ('retry-progress-' + str(role['vmid']) + '.json'), outputs)
                            if match['data']['status'] == 'retry_resource_guard_stop': raise ValueError('retry resource guard stopped its case; preserve and review before continuing')
                            break
                        try: host_resources()
                        except ValueError as error:
                            guest_call(target, {'action': 'abort', 'contract': contract_path, 'vmid': role['vmid'], 'reason': str(error)}, files)
                            raise
                        if time.monotonic() > deadline: raise TimeoutError('retry coordinator exceeded its declared case budget; no original stage is signalled')
                        if not any(launched['unit'] in line for line in observed['active_units']):
                            raise ValueError('retry coordinator ended without a durable outcome; stage receipts and originals are preserved')
                        time.sleep(3)
                return {'vmid': role['vmid'], 'completed': len(outputs), 'assigned': len(role['entries'])}
            results = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(contract['roles'])) as pool:
                futures = {pool.submit(queue, role): role['vmid'] for role in contract['roles']}
                for future in concurrent.futures.as_completed(futures):
                    try: results.append(future.result())
                    except Exception as error: results.append({'vmid': futures[future], 'error': str(error), 'completed': False})
            state['retry_results'] = results; event('retry-queues-finished'); return state
        if operation == 'restore':
            for role in contract['roles']:
                info = state['roles'].setdefault(str(role['vmid']), {})
                if info.get('restored'): continue
                if not info.get('setup'):
                    live,_,_=require_config(role,[8192])
                    if live['status']!='running':raise ValueError('unprepared completed retry guest cannot be stopped')
                    setup=guest_call(rows[role['vmid']],{'action':'setup','manifest':manifest,'vmid':role['vmid'],'files':files},files)
                    setup['host_journals']=preserve_journals(rows[role['vmid']],setup['journals'],directory);info['setup']=setup
                    event('preserved-unactivated-retry-hold-for-release',vmid=role['vmid'])
                row = rows[role['vmid']]; path = str(GUEST / 'retries/roles' / identifier / str(role['vmid']) / 'contract.json')
                live, config, _ = require_config(role, [role['original_memory_mib'], role['target_memory_mib']])
                if live['status']=='running' and int(config['memory'])==role['original_memory_mib'] and not info.get('memory_restored'):
                    info['memory_restored']={'memory_mib':8192,'already_original':True,'at_ns':time.time_ns()}
                    event('already-original-memory-proved',vmid=role['vmid'])
                if live['status'] == 'stopped' and not info.get('restore_prepared'):
                    if not cancel_pending: raise ValueError('interrupted activation recovery requires explicit cancel-pending')
                    # Setup copied the exact queue, completed drain and journals
                    # before this owned shutdown. Boot at the original size so
                    # the guest can recheck its unchanged outputs before resume.
                    for record in info['setup']['host_journals']:
                        if sha(record['host_path']) != record['host_sha256']: raise ValueError('pre-shutdown journal evidence changed')
                    address = change_memory_and_start(role, role['original_memory_mib'])
                    row = update_transport(row, {**address, 'memory_mib': role['original_memory_mib']}, directory); rows[role['vmid']] = row
                    info['memory_restored'] = {'at_ns': time.time_ns(), 'memory_mib': role['original_memory_mib'], 'interrupted_activation_recovery': True}
                    event('original-memory-recovered-before-restore-inspection', vmid=role['vmid'])
                if not info.get('restore_prepared'):
                    prepared = guest_call(row, {'action': 'prepare_restore', 'contract': path, 'vmid': role['vmid'], 'cancel_pending': cancel_pending}, files)
                    prepared['host_journals'] = preserve_journals(row, prepared['journals'], directory)
                    info['restore_prepared'] = prepared; event('retry-role-prepared-for-restore', vmid=role['vmid'])
                if not info.get('memory_restored'):
                    if role['target_memory_mib'] != role['original_memory_mib']:
                        stop_gracefully(role, [role['original_memory_mib'], role['target_memory_mib']])
                        address = change_memory_and_start(role, role['original_memory_mib'])
                        row = update_transport(row, {**address, 'memory_mib': role['original_memory_mib']}, directory); rows[role['vmid']] = row
                    info['memory_restored'] = {'at_ns': time.time_ns(), 'memory_mib': role['original_memory_mib']}
                    event('original-memory-restored-before-queue-launch', vmid=role['vmid'])
                require_config(role, [role['original_memory_mib']])
                info['restored'] = guest_call(row, {'action': 'resume_original', 'contract': path, 'vmid': role['vmid']}, files)
                event('original-queue-restored', vmid=role['vmid'])
            restore_parked_workers(directory,manifest,files,rows,state,event)
            if contract['builder']['original_status']=='stopped':
                if state.get('builder_stopped') or state.get('builder_stop_intent') or require_config(contract['builder'],[16384])[0]['status']!='stopped':
                    raise ValueError('originally stopped builder state changed outside this role')
                state['builder_original_stopped_preserved']=True
            owned_builder_stop = state.get('builder_stopped') or state.get('builder_stop_intent')
            if owned_builder_stop and not state.get('builder_restarted'):
                builder = contract['builder']; live, config, _ = require_config(builder, [builder['original_memory_mib']])
                intent = state.get('builder_stop_intent')
                if intent and (intent.get('vmid') != 1516 or intent.get('original_status') != 'running'
                               or intent.get('original_config_sha256') != builder['original_config_sha256']):
                    raise ValueError('builder restoration lacks its exact owned pre-shutdown intent')
                if live['status'] == 'stopped':
                    host_resources(additional_bytes=builder['original_memory_mib'] * 1024 ** 2)
                    run(['qm', 'start', 1516], timeout=90)
                address = qga_address(builder)
                state['builder_restarted'] = update_transport(read(HOST / 'build-worker.json'), {**address, 'memory_mib': builder['original_memory_mib']}, directory)
            event('all-original-roles-restored')
            if owner_path.exists(): owner_path.rename(directory / 'completed-host-role-marker.json')
            return state
        raise ValueError('unknown role lifecycle phase')


def launch_phase(identifier, operation, **flags):
    directory, manifest, contract, _ = load_role(identifier)
    unit = 'deadsync-lua-pass4-resource-roles-' + identifier[:16]
    if subprocess.run(['systemctl', 'is-active', '--quiet', unit]).returncode == 0:
        raise ValueError('a role lifecycle phase is already active')
    command = ['python3', str(directory / 'resource_retry_roles.py'), '--host-phase', operation, '--role-id', identifier]
    for key, enabled in flags.items():
        if enabled: command.append('--' + key.replace('_', '-'))
    run(['systemd-run', '--collect', '--unit=' + unit, '--property=MemoryMax=2G', '--property=MemorySwapMax=0',
         '--property=Nice=10', '--property=RuntimeMaxSec=172800', '--property=StandardOutput=append:' + str(directory / 'lifecycle.log'),
         '--property=StandardError=append:' + str(directory / 'lifecycle.log'), *command], timeout=30)
    return {'launched': True, 'role_id': identifier, 'operation': operation, 'unit': unit, 'directory': str(directory)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(); modes.add_argument('--freeze', action='store_true'); modes.add_argument('--activate', action='store_true')
    modes.add_argument('--retry', action='store_true'); modes.add_argument('--restore', action='store_true'); modes.add_argument('--status', action='store_true')
    modes.add_argument('--collect', action='store_true')
    parser.add_argument('--role-plan', type=pathlib.Path); parser.add_argument('--candidate'); parser.add_argument('--bundle-sha256'); parser.add_argument('--role-id')
    parser.add_argument('--guest-memory-mib', type=int, default=16384); parser.add_argument('--stage-memory-gib', type=int, default=12)
    parser.add_argument('--capture-profile', type=pathlib.Path); parser.add_argument('--resume-interrupted', action='store_true'); parser.add_argument('--cancel-pending', action='store_true')
    parser.add_argument('--host-phase', choices=['activate', 'retry', 'restore'], help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.host_phase:
        try: value = phase(args.role_id, args.host_phase, args.resume_interrupted, args.cancel_pending)
        except BaseException as error:
            directory = TASK / args.role_id
            save(directory / ('failure-' + str(time.time_ns()) + '.json'), {'operation': args.host_phase, 'error': str(error), 'traceback': traceback.format_exc()})
            raise
        print(json.dumps({'role_id': args.role_id, 'phase': value['phase']})); return
    here = pathlib.Path(__file__).resolve().parent; raw = pathlib.Path(__file__).read_bytes()
    request = {'host_helper_sha256': hashlib.sha256(raw).hexdigest(), 'host_helper': base64.b64encode(raw).decode()}
    if args.freeze:
        if not args.role_plan or not valid_sha(args.candidate) or not valid_sha(args.bundle_sha256): parser.error('freeze requires role plan and exact candidate/bundle identities')
        if (args.guest_memory_mib, args.stage_memory_gib)!=(16384,12): parser.error('parking supports only the reviewed16/12GiB profile')
        plan_raw = args.role_plan.read_bytes(); plan = json.loads(gzip.decompress(plan_raw))
        request.update(action='freeze', role_plan=base64.b64encode(plan_raw).decode(), role_plan_sha256=hashlib.sha256(plan_raw).hexdigest(),
                       candidate=args.candidate, bundle_sha256=args.bundle_sha256, guest_memory_mib=args.guest_memory_mib, stage_memory_gib=args.stage_memory_gib,
                       files={name: base64.b64encode((here / source).read_bytes()).decode() for name, source in NAMES.items()},
                       attempts={str(row['vmid']): base64.b64encode((args.role_plan.parent / ('vm-' + str(row['vmid']) + '-retry-attempts.json')).read_bytes()).decode() for row in plan['roles']},
                       jobs={str(row['vmid']):base64.b64encode((args.role_plan.parent/('vm-'+str(row['vmid'])+'-retry-jobs.json')).read_bytes()).decode() for row in plan['roles']},
                       capture_profile=read(args.capture_profile) if args.capture_profile else None)
    else:
        if not valid_sha(args.role_id): parser.error('an exact frozen role ID is required')
        request.update(role_id=args.role_id, action='activate' if args.activate else 'retry' if args.retry else 'restore' if args.restore else 'collect' if args.collect else 'status',
                       resume_interrupted=args.resume_interrupted, cancel_pending=args.cancel_pending)
    bootstrap = r'''
import base64,hashlib,importlib.util,json,pathlib
root=pathlib.Path('/root/deadsync-lua-20261119/resource-retry-roles');recipes=root/'recipes';recipes.mkdir(parents=True,exist_ok=True)
raw=base64.b64decode(request['host_helper']);assert hashlib.sha256(raw).hexdigest()==request['host_helper_sha256']
path=recipes/(request['host_helper_sha256']+'.py')
if path.exists():assert path.read_bytes()==raw
else:path.write_bytes(raw)
spec=importlib.util.spec_from_file_location('bound_retry_roles',path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
if request['action']=='freeze':value=helper.freeze(request)
elif request['action'] in ['activate','retry','restore']:
 directory,manifest,contract,files=helper.load_role(request['role_id'])
 value=helper.launch_phase(request['role_id'],request['action'],resume_interrupted=request['resume_interrupted'],cancel_pending=request['cancel_pending'])
else:
 directory,manifest,contract,files=helper.load_role(request['role_id'])
 value={'role_id':request['role_id'],'state':helper.read(directory/'state.json')}
 if request['action']=='collect':
  fleet={row['vmid']:row for row in helper.read(helper.HOST/'fleet.json')}
  value['guests']=[helper.guest_call(fleet[role['vmid']],{'action':'status','contract':str(helper.GUEST/'retries/roles'/request['role_id']/str(role['vmid'])/'contract.json'),'vmid':role['vmid'],'full':True},files) for role in contract['roles']]
 value['active']=helper.subprocess.run(['systemctl','is-active','--quiet','deadsync-lua-pass4-resource-roles-'+request['role_id'][:16]]).returncode==0
print(json.dumps(value))
'''
    import remote
    try: response = remote.run('request=' + repr(request) + '\n' + bootstrap, capture_output=True, timeout=2400 if args.freeze else 180)
    except subprocess.CalledProcessError as error: print(error.stderr[-7000:]); raise
    value = json.loads(response.stdout)
    identifier = value['role_id']; directory = here / 'resource-retry-contracts' / identifier; directory.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(json.dumps(value, ensure_ascii=False, indent=2).encode() + b'\n')
    path = directory / (request['action'] + '-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.json.gz'); path.write_bytes(packed)
    if args.freeze:
        stable(directory / 'manifest.json', json.dumps(value['manifest'], ensure_ascii=False, indent=2).encode() + b'\n')
        stable(directory / 'resource_retry_roles.py', raw)
    print(json.dumps({'role_id': identifier, 'action': request['action'], 'receipt': str(path), 'sha256': sha(path),
                      **{key: value[key] for key in ['launched', 'operation', 'unit', 'directory', 'active', 'vm_actions_performed'] if key in value},
                      'phase': value.get('state', {}).get('phase')}))


if __name__ == '__main__': main()
