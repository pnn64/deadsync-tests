"""Historical pass4 baseline replay, not acceptance on current DeadSync main."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import guest_capture as capture

root = Path(__file__).resolve().parent
directory = root / 'historical-baseline-replay'
directory.mkdir()
runner = Path('/opt/song-lua-audit/pass4/bin/full_song_lua')
proof_path = Path('/opt/song-lua-audit/pass4/proof/build-proof.json')
source_path = Path('/opt/song-lua-audit/pass4/proof/source-proof.json')
proof = json.loads(proof_path.read_text())
assert proof['passed'] is True
assert capture.digest(runner) == proof['binaries']['runner']['sha256'] == '90abd15f5e2f6e15a23b33faacc83ec81bde13a2f709f095576a10ce0c8405e4'
assert capture.digest(source_path) == proof['source_proof_sha256']
shutil.copyfile(proof_path, directory / 'build-proof.json')
shutil.copyfile(source_path, directory / 'source-proof.json')
candidate = root / 'candidate/11064b28f2572ca8a90e532e1639f30b416794ae886e7adf7e286c0c91324ac0.tar'
assert capture.digest(candidate) == candidate.stem
report_path = directory / 'report.json'
command = [str(runner), '--archive', str(candidate), '--report', str(report_path), '--production']
environment = {'TMPDIR': str(root / 'tmp'), 'DISPLAY': ':99', 'LIBGL_ALWAYS_SOFTWARE': '1',
               'GALLIUM_DRIVER': 'llvmpipe', 'LP_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1'}
spec = {'started_at': capture.now(), 'command': command, 'environment': environment,
        'working_directory': '/opt/song-lua-audit/deadsync-pass4', 'memory_max_bytes': 6*1024**3,
        'cpu_quota_percent': 200, 'timeout_seconds': 180,
        'runner_sha256': capture.digest(runner), 'candidate_sha256': candidate.stem,
        'runner_source_proof_sha256': capture.digest(source_path),
        'runner_label': 'historical-pass4-be576a51-not-current-main', 'accepted_fixture': False}
token = hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:16]
unit = 'deadsync-typed-aft-baseline-' + token
spec['unit'] = unit
spec_path = directory / 'spec.json'
capture.write(spec_path, spec)
log = directory / 'output.log'
launch = ['sudo','-n','systemd-run','--quiet','--wait','--collect','--unit='+unit,
          '--property=MemoryMax=6G','--property=MemorySwapMax=0','--property=CPUQuota=200%',
          '--property=OOMPolicy=kill','--property=RuntimeMaxSec=180','--property=TimeoutStopSec=15',
          '--property=KillMode=control-group','--property=User=parity','--property=Group=parity',
          '--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),
          '--property=ExecStopPost=/usr/bin/python3 '+str(root/'guest_capture.py')+' finished '+str(spec_path),
          '--working-directory='+spec['working_directory']]
launch += ['--setenv='+key+'='+value for key,value in environment.items()]
result = subprocess.run(launch+command,capture_output=True,text=True)
capture.write(directory/'launch.json',{'command':launch+command,'exit':result.returncode,
                                     'stdout':result.stdout,'stderr':result.stderr})
summary = {'baseline_only': True, 'exit': result.returncode,
           'runner_sha256': spec['runner_sha256'], 'report_path': str(report_path),
           'receipt': json.loads((directory/'receipt.json').read_text())}
if report_path.is_file():
    report = json.loads(report_path.read_text())
    summary['report'] = {key:report.get(key) for key in ['archive_accepted','execution_path','native_frames',
        'replayed_frames','mismatch_count','error_count','diagnostic_replay_checks_passed',
        'production_preparation_exercised','production_gameplay_checks_passed','errors','mismatches']}
capture.write(directory/'summary.json',summary)
shown = dict(summary)
if 'report' in shown:
    shown['report'] = dict(shown['report'])
    shown['report']['mismatches'] = shown['report']['mismatches'][:3] if shown['report']['mismatches'] else []
print(json.dumps(shown),flush=True)
