-- Authored inputs and public observations only; no expected native results.
local root, stage, stats, players
local active_write
local armed = false
local serial = 0
local seen_judgment = {'none', 'none'}
local score_pending = {}
local triggered = {}
local natural_count = {0, 0}

local function player_index(player)
    if player == PLAYER_1 then return 1 end
    if player == PLAYER_2 then return 2 end
end

local function observe(phase, player, meter, extra)
    serial = serial + 1
    local state = stats[player]
    local steps = stage:GetStepsSeconds()
    local history = state:GetLifeRecord(steps, 5)
    local row = {
        serial = serial, phase = phase, player = player,
        seconds = GAMESTATE:GetCurMusicSeconds(), steps_seconds = steps,
        current_life = state:GetCurrentLife(), history = history,
        score = state:GetScore(), current_max_score = state:GetCurMaxScore(),
        actual_dance_points = state:GetActualDancePoints(),
        failed = state:GetFailed(), judgment = seen_judgment[player],
    }
    if meter then row.meter = meter:GetLife() end
    if extra then for key, value in pairs(extra) do row[key] = value end end
    local text = string.format('%02d %s P%d L=%.9g S=%s M=%s F=%s',
        serial, phase, player, row.current_life, row.score,
        row.current_max_score, tostring(row.failed))
    local parts = {}
    for _, value in ipairs(history) do parts[#parts + 1] = string.format('%.9g', value) end
    text = text .. ' H=' .. table.concat(parts, ',')
    if row.meter then text = text .. ' meter=' .. string.format('%.9g', row.meter) end
    local label = root:GetChild('Observation' .. serial)
    assert(label, 'life callback control exceeded its observation slots')
    label:settext(text)
    MESSAGEMAN:Broadcast('LifeEventScoreObservation', row)
    return row
end

local function write_life(label, player, life)
    active_write = label
    local before = observe('before:' .. label, player)
    players[player]:SetLife(life)
    observe('after:' .. label, player)
    active_write = nil
    return before
end

root = Def.ActorFrame {
    Name = 'LifeEventScoreControl',
    OnCommand = function(self)
        root = self
        self:sleep(30)
        local screen = SCREENMAN:GetTopScreen()
        stage = STATSMAN:GetCurStageStats()
        stats = {stage:GetPlayerStageStats(PLAYER_1), stage:GetPlayerStageStats(PLAYER_2)}
        players = {screen:GetChild('PlayerP1'), screen:GetChild('PlayerP2')}
        assert(players[1] and players[2], 'control requires versus players')
        -- A direct gameplay launch skips the song wheel's normal chart-change
        -- setup. Populate the theme's density cache from native chart queries
        -- before its TrackFailTime actor observes HealthState_Dead.
        ParseChartInfo(GAMESTATE:GetCurrentSteps(PLAYER_1), 'P1')
        ParseChartInfo(GAMESTATE:GetCurrentSteps(PLAYER_2), 'P2')
        armed = true
        local early_p1, early_p2, failed_p1, failed_p2, summary
        self:SetUpdateFunction(function()
            local seconds = GAMESTATE:GetCurMusicSeconds()
            if not early_p1 and seconds >= 0.25 then
                early_p1 = true
                stats[1]:SetScore(17)
                stats[1]:SetCurMaxScore(29)
                write_life('P1-early', 1, 0.25)
            end
            if not early_p2 and seconds >= 0.5 then
                early_p2 = true
                stats[2]:SetScore(31)
                stats[2]:SetCurMaxScore(41)
                write_life('P2-early', 2, 0.75)
            end
            for player = 1, 2 do
                local pending = score_pending[player]
                if pending and stats[player]:GetScore() ~= pending.before_score then
                    observe('post-score:' .. pending.label, player, nil,
                        {before_score = pending.before_score,
                         before_max_score = pending.before_max_score})
                    score_pending[player] = nil
                end
            end
            -- Normal drain may recover a small amount after W1/Held. These
            -- distinct later writes exercise committed failure explicitly.
            if not failed_p2 and triggered[2] and not score_pending[2] and seconds >= 2.5 then
                failed_p2 = true
                write_life('P2-later-failure', 2, 0)
            end
            if not failed_p1 and triggered[1] and not score_pending[1] and seconds >= 3.25 then
                failed_p1 = true
                write_life('P1-later-failure', 1, 0)
            end
            if not summary and seconds >= 3.5 then
                summary = true
                observe('final:P1', 1, nil, {natural_events = natural_count[1]})
                observe('final:P2', 2, nil, {natural_events = natural_count[2]})
            end
        end)
    end,
    JudgmentMessageCommand = function(self, params)
        if not armed then return end
        local player = player_index(params.Player)
        if not player then return end
        local judgment = params.HoldNoteScore or params.TapNoteScore
        seen_judgment[player] = judgment or 'none'
        observe('judgment', player, nil, {first_track = params.FirstTrack or -1})
        local label
        if player == 2 and params.HoldNoteScore == 'HoldNoteScore_Held' and not triggered[2] then
            label = 'P2-held'
        elseif player == 1 and not params.HoldNoteScore
            and params.TapNoteScore == 'TapNoteScore_W1'
            and GAMESTATE:GetCurMusicSeconds() >= 2.8 and not triggered[1] then
            label = 'P1-W1-row'
        end
        if label then
            triggered[player] = true
            local before = write_life(label, player, 0)
            score_pending[player] = {label = label, before_score = before.score,
                before_max_score = before.current_max_score}
        end
    end,
    LifeChangedMessageCommand = function(self, params)
        if not armed then return end
        local player = player_index(params.Player)
        if not player then return end
        if active_write then
            observe('inside:' .. active_write, player, params.LifeMeter)
        else
            natural_count[player] = natural_count[player] + 1
            observe('natural', player, params.LifeMeter)
        end
    end,
}
for index = 1, 64 do
    local number = index
    root[#root + 1] = LoadFont('Common Normal') .. {
        Name = 'Observation' .. number,
        InitCommand = function(self)
            self:halign(0):valign(0):xy(4, 4 + (number - 1) * 7):zoom(0.08):settext('')
        end,
    }
end
return root
