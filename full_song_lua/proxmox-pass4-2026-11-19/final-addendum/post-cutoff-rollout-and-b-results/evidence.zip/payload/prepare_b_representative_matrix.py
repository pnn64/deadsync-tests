"""Read the root-frozen collection only; no fleet access, replay or source edits."""
import collections
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
SOURCE = TASK / "collected/20261119T060837.263748Z-full.json.gz"
SOURCE_SHA = "94f36e050bc0b62f5c36b83a06cab2deeee525752f55432b10a5755330d1f7a5"
SUMMARY = TASK / "collected/20261119T060837.263748Z-B-summary.json"
SUMMARY_SHA = "942a50262b109ce06c6117c1e3ef0c460de6e9da847318cc22a462ab385fefa3"
BASE = "100d005699815a5ab6ad67692bb547c3b44049630050688cc977e42a9338f26b"
B = "90abd15f5e2f6e15a23b33faacc83ec81bde13a2f709f095576a10ce0c8405e4"
BUILD = "610be24222fac61761ca70c5f18f986840ff971566d52417b9bde14726963d1e"
PROOF = "18f5fe495952a649abaf758df3a20deb62abc8cf49411e1acc3de9affb03e717"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def family(source):
    value = source.casefold()
    for name, token in [("Circles", "circles/"), ("Door Open", "dooropen"), ("Flowers", "flowers"), ("VANITY ANGEL", "vanity angel"), ("Cold", "cold/"), ("Vtubers", "vtubers"), ("MODULO", "modulo"), ("Genshin", "genshin")]:
        if token in value:
            return name
    return None


def identity():
    result = {}
    for label, path in [("product", ROOT), ("fixtures", ROOT / "tests/fixtures")]:
        result[label] = {"head": subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"]).decode().strip(), "status": subprocess.check_output(["git", "-C", str(path), "status", "--porcelain", "--untracked-files=no"]).decode()}
    assert result["product"]["head"] == "81c18c105ad9e70e1d6d9a84c610e3a2de477899" and not result["product"]["status"]
    assert result["fixtures"]["head"] == "11f6edff529423df9ffef9458e93f7726183a646" and not result["fixtures"]["status"]
    return result


def concise(item, vmid):
    data = item["data"]
    return {"vmid": vmid, "kind": item["kind"], "path": item["path"], "sha256": item["sha256"], "bytes": item["bytes"], "status": data["status"], "started_at": data.get("started_at"), "finished_at": data.get("finished_at"), "capture_result": data.get("capture_result"), "pins": data.get("pins", {}), "comparison": data.get("comparison"), "reason": data.get("reason", data.get("error")), "artifacts": data.get("artifacts", []), "retained_candidate": data.get("retained_candidate"), "candidate_sha256": data.get("candidate_sha256"), "candidate_path": data.get("candidate_path")}


def main():
    before = identity()
    raw = SOURCE.read_bytes()
    assert sha(raw) == SOURCE_SHA and sha(SUMMARY.read_bytes()) == SUMMARY_SHA
    snapshot = json.loads(gzip.decompress(raw))
    assert snapshot["mode"] == "full" and len(snapshot["guests"]) == 15 and not snapshot["errors"]
    assert all(g["connected"] and g["payload"]["read_complete"] and not g["payload"]["errors"] for g in snapshot["guests"])
    jobs = {j["id"]: j for j in snapshot["host_all_jobs"]["records"] if family(j["source_simfile"])}
    rows = {key: {"job": job, "family": family(job["source_simfile"]), "captures": [], "baseline": [], "candidate_b": [], "other_runners": []} for key, job in jobs.items()}
    selected = []; door_reads = []
    for guest in snapshot["guests"]:
        for item in guest["payload"]["files"]:
            if item["kind"] not in ("capture_result", "replay_result") or item["data"].get("id") not in rows:
                continue
            data = item["data"]; row = rows[data["id"]]
            assert data.get("job", data.get("binding", {}).get("job", {}))["source_simfile"] == row["job"]["source_simfile"]
            selected.append({"vmid": guest["vmid"], "ip": guest["ip"], "item": item})
            record = concise(item, guest["vmid"])
            if item["kind"] == "capture_result":
                row["captures"].append(record)
                if data["id"] in ("c8d9fd94d9f121bc-c0001", "5e1b59e6d321839b-c0001"):
                    door_reads.append({"vmid": guest["vmid"], "ip": guest["ip"], "id": data["id"], "capture_result": record, "archive_entry": data.get("archive_entry")})
                continue
            runner = data.get("pins", {}).get("runner_sha256")
            if runner == B:
                assert data["pins"]["binary_proof_sha256"] == BUILD and data["pins"]["source_proof_sha256"] == PROOF
                assert data["pins"]["replay_execution_path"] == "production-and-diagnostic-live-lua"
                if data.get("comparison"):
                    assert data["comparison"]["execution_path"] == "production-and-diagnostic-live-lua" and data["comparison"]["production_preparation_exercised"] is True
                row["candidate_b"].append(record)
            elif runner == BASE:
                row["baseline"].append(record)
            else:
                row["other_runners"].append(record)
    for row in rows.values():
        for record in row["candidate_b"]:
            path = record["capture_result"]
            matching = [x for x in row["baseline"] if x["capture_result"] == path]
            record["baseline_same_capture_sha256"] = [x["sha256"] for x in matching]
            if record.get("comparison"):
                assert all((x.get("comparison") or {}).get("fixture_sha256") in (None, record["comparison"]["fixture_sha256"]) for x in matching)
        row["candidate_b_state"] = "pending: no final-B replay receipt in this snapshot" if not row["candidate_b"] else "; ".join(x["status"] for x in row["candidate_b"])
    aggregate = {}
    for name in sorted({x["family"] for x in rows.values()}):
        values = [x for x in rows.values() if x["family"] == name]
        aggregate[name] = {"jobs": len(values), "candidate_b": dict(collections.Counter(x["candidate_b_state"] for x in values))}
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    out = TASK / ("b-representative-matrix-" + stamp); out.mkdir()
    result = {"schema_version": 1, "created_at": stamp, "scope": "Read-only comparison of exact root-frozen collection; no new collection, replay or edit", "snapshot": {"path": str(SOURCE), "bytes": len(raw), "sha256": SOURCE_SHA, "finished_at": snapshot["finished_at"]}, "root_summary": {"path": str(SUMMARY), "sha256": SUMMARY_SHA}, "baseline_runner_sha256": BASE, "candidate_b_runner_sha256": B, "candidate_b_build_proof_sha256": BUILD, "candidate_b_source_proof_sha256": PROOF, "aggregate": aggregate, "rows": sorted(rows.values(), key=lambda x: (x["family"], x["job"]["source_simfile"], x["job"]["chart_index"])), "limits": ["Baseline pass is diagnostic-only; B uses both diagnostic and production paths.", "Door Open's two B mismatch rows are the same sampled frame observed by two paths, not two new defect sites.", "The retained Circles mismatch-example counts can be capped and do not measure all unique failures.", "No B receipt, running, native setup failure and unsupported coverage are never relabeled as resolved.", "The independently retained Cold Linux B control is a separate successful builder replay; this fleet matrix keeps its still-pending fleet row.", "All original pending-coverage and whole-song parity flags remain unchanged."], "before": before, "after": identity()}
    assert result["before"] == result["after"]
    for name, doc in [("matrix.json", result), ("door-read-selection.json", {"source_snapshot_sha256": SOURCE_SHA, "cases": door_reads})]:
        (out / name).write_text(json.dumps(doc, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    selected_raw = (json.dumps({"source_snapshot_sha256": SOURCE_SHA, "scope": "Selected original receipt data, not original file byte serialization", "records": selected}, ensure_ascii=False) + "\n").encode()
    (out / "selected-receipt-data.json.gz").write_bytes(gzip.compress(selected_raw, mtime=0))
    lines = ["# Baseline to final-B representative results", "", "Root-frozen snapshot: " + SOURCE.name + "; SHA-256 " + SOURCE_SHA + ".", "", "| Case | Chart | Baseline | Final B at this snapshot |", "|---|---:|---|---|"]
    for row in result["rows"]:
        old = "; ".join(x["status"] + (" " + json.dumps(x["comparison"]["mismatch_fields"], sort_keys=True) if (x.get("comparison") or {}).get("mismatch_fields") else "") for x in row["baseline"]) or "; ".join(x["status"] for x in row["captures"]) or "not observed"
        new = "; ".join(x["status"] + (" " + json.dumps(x["comparison"]["mismatch_fields"], sort_keys=True) if (x.get("comparison") or {}).get("mismatch_fields") else "") for x in row["candidate_b"]) or "pending"
        lines.append(f"| {row['job']['source_simfile']} | {row['job']['chart_index']} | {old} | {new} |")
    lines += ["", *["- " + x for x in result["limits"]], ""]
    (out / "matrix.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")
    manifest = {"scope": result["scope"], "files": [{"path": p.name, "bytes": p.stat().st_size, "sha256": sha(p.read_bytes())} for p in sorted(out.iterdir())]}
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"directory": str(out), "matrix_sha256": sha((out / "matrix.json").read_bytes()), "manifest_sha256": sha((out / "manifest.json").read_bytes()), "aggregate": aggregate, "door_archives": [{"id": x["id"], "retained_candidate": x["capture_result"]["retained_candidate"]} for x in door_reads]}, indent=2))


if __name__ == "__main__":
    main()
