# Baseline to final-B representative results

Root-frozen snapshot: 20261119T060837.263748Z-full.json.gz; SHA-256 94f36e050bc0b62f5c36b83a06cab2deeee525752f55432b10a5755330d1f7a5.

| Case | Chart | Baseline | Final B at this snapshot |
|---|---:|---|---|
| Circles/Circles.sm | 1 | parity_failure {"command_query_event": 12} | pending |
| Circles/Circles.ssc | 1 | pass | pending |
| __variants__/debug-pack/Cringle Culmination/Circles/Circles.sm | 1 | parity_failure {"draw_shape_resource_or_depth": 100} | pending |
| __variants__/debug-pack/Cringle Culmination/Circles/Circles.ssc | 1 | parity_failure {"command_query_event": 18, "draw_shape_resource_or_depth": 100} | parity_failure {"command_query_event": 18} |
| Cold/Cold.ssc | 1 | replay_error | pending |
| LeaveTheDoorOpen [Cringle Desolation]/DoorOpen.sm | 1 | parity_failure {"draw_shape_resource_or_depth": 1} | parity_failure {"draw_shape_resource_or_depth": 2} |
| LeaveTheDoorOpen [Cringle Desolation]/DoorOpen.ssc | 1 | parity_failure {"draw_shape_resource_or_depth": 1} | parity_failure {"draw_shape_resource_or_depth": 2} |
| LeaveTheDoorOpen [R.I.G.H.T.S]/DoorOpen.sm | 1 | pass | pending |
| LeaveTheDoorOpen [R.I.G.H.T.S]/DoorOpen.ssc | 1 | pass | pending |
| Flowers [Cringle Desolation]/Flowers.ssc | 1 | parity_failure {"draw_shape_resource_or_depth": 20, "submitted_clip_uv_color_or_topology": 80} | pending |
| __variants__/debug-pack/Cringle Culmination/Flowers/Flowers.ssc | 1 | native_lua_or_setup_error | pending |
| flowers/flowers.ssc | 1 | parity_failure {"draw_shape_resource_or_depth": 100} | pending |
| Genshin Quiz/Megaquiz.ssc | 1 | replay_error | pending |
| Genshin Quiz/Megaquiz.ssc | 2 | replay_error | pending |
| Genshin Quiz/Megaquiz.ssc | 3 | replay_error | pending |
| Genshin Quiz/Megaquiz.ssc | 4 | replay_error | pending |
| MODULO/modulo.ssc | 1 | replay_error | pending |
| MODULO/modulo.ssc | 2 | pass | pending |
| MODULO/modulo.ssc | 3 | pass | pending |
| MODULO/modulo.ssc | 4 | pass | pending |
| MODULO/modulo.ssc | 5 | pass | pending |
| MODULO/modulo.ssc | 6 | pass | pending |
| MODULO/modulo.ssc | 7 | pass | pending |
| MODULO/modulo.ssc | 8 | pass | pending |
| MODULO/modulo.ssc | 9 | pass | pending |
| MODULO/modulo.ssc | 10 | pass | pending |
| MODULO/modulo.ssc | 11 | pass | pending |
| __variants__/debug-pack/rosewood/VANITY ANGEL/vanityangel-fakemines.ssc | 1 | replay_error | pending |
| __variants__/debug-pack/rosewood/VANITY ANGEL/vanityangel-fakemines.ssc | 2 | replay_error | pending |
| Vtubers Never Die! [Gpop]/Vtubers Never Die!.ssc | 1 | pass | pass |
| Vtubers Never Die! [Gpop]/Vtubers Never Die!.ssc | 2 | pass | pass |
| Vtubers Never Die! [Gpop]/Vtubers Never Die!.ssc | 3 | pass | running |
| Vtubers Never Die! [Gpop]/Vtubers Never Die!.ssc | 4 | pass | pass |
| Vtubers Never Die! [Gpop]/Vtubers Never Die!.ssc | 5 | pass | pass |
| Vtubers Never Die! [Gpop]/Vtubers Never Die!.ssc | 6 | parity_failure {"failed": 2} | pass |

- Baseline pass is diagnostic-only; B uses both diagnostic and production paths.
- Door Open's two B mismatch rows are the same sampled frame observed by two paths, not two new defect sites.
- The retained Circles mismatch-example counts can be capped and do not measure all unique failures.
- No B receipt, running, native setup failure and unsupported coverage are never relabeled as resolved.
- The independently retained Cold Linux B control is a separate successful builder replay; this fleet matrix keeps its still-pending fleet row.
- All original pending-coverage and whole-song parity flags remain unchanged.
