"""Exact committed fixture changes over the proved, intentionally partial support tree."""
from __future__ import annotations
import hashlib
import io
import json
import os
import pathlib
import shutil
import subprocess
import tarfile
import time

FIXTURE_PATH = 'tests/fixtures'
BASE = 'fdf26ec30d7c3edcd624b82aae24eea4fe3765c7'


def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
def sha(path):
    with pathlib.Path(path).open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
def read(path): return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))
def write(path, value):
    path = pathlib.Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp.' + str(os.getpid()))
    temporary.write_bytes(json.dumps(value, indent=2, ensure_ascii=False).encode() + b'\n'); temporary.replace(path)
def git(repository, *args): return subprocess.check_output(['git', '-C', str(repository), *args])
def relative(root, name):
    path = pathlib.PurePosixPath(name)
    if path.is_absolute() or not path.parts or '..' in path.parts or '.git' in path.parts:
        raise ValueError('invalid fixture path: ' + name)
    result = pathlib.Path(root) / path
    if result.is_symlink() or not result.resolve().is_relative_to(pathlib.Path(root).resolve()):
        raise ValueError('fixture path escapes its owned root: ' + name)
    return result


def tree(repository, revision):
    result = {}
    for raw in git(repository, 'ls-tree', '-r', '-l', '-z', '--full-tree', revision).decode().split('\0'):
        if not raw: continue
        metadata, name = raw.split('\t', 1)
        mode, kind, oid, size = metadata.split()
        if mode not in {'100644', '100755'} or kind != 'blob':
            raise ValueError('fixture overlay supports only regular committed files: ' + name)
        relative(repository, name)
        result[name] = {'path': name, 'mode': mode, 'git_blob': oid, 'bytes': int(size)}
    return result


def data_row(name, data, mode, origin, git_blob=None):
    result = {'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': mode,
              'verify_mode': True, 'origin': origin}
    if git_blob: result['git_blob'] = git_blob
    return result


def support_requirements(repository, target, target_git, request_path):
    """Validate an explicit target-blob closure before creating any payload."""
    if request_path is None: return None, {}
    request_path = pathlib.Path(request_path)
    if request_path.is_symlink() or not request_path.is_file():
        raise ValueError('fixture requirements must be an existing regular file')
    raw = request_path.read_bytes()
    def unique_keys(pairs):
        result = {}
        for key, value in pairs:
            if key in result: raise ValueError('duplicate fixture requirements key: ' + key)
            result[key] = value
        return result
    request = json.loads(raw, object_pairs_hook=unique_keys)
    if (not isinstance(request, dict) or request.get('schema_version') != 1
            or request.get('kind') != 'explicit-test-support-requirements'
            or request.get('fixture_revision') != target
            or not isinstance(request.get('files'), list) or not request['files']):
        raise ValueError('fixture requirements schema/revision/files differ from the explicit target')
    declared = {}
    for item in request['files']:
        name = item.get('path') if isinstance(item, dict) else None
        if (not isinstance(name, str) or not name or '\\' in name or ':' in name or '\0' in name
                or pathlib.PurePosixPath(name).as_posix() != name):
            raise ValueError('fixture requirement is not a canonical relative Git path')
        relative(repository, name)
        if name in declared: raise ValueError('duplicate fixture requirement path: ' + name)
        expected = target_git.get(name)
        if expected is None or any(item.get(key) != expected[key] for key in ['git_blob', 'mode', 'bytes']):
            raise ValueError('fixture requirement differs from the committed target entry: ' + name)
        if type(item.get('bytes')) is not int:
            raise ValueError('fixture requirement length must be an integer: ' + name)
        data = git(repository, 'cat-file', 'blob', expected['git_blob'])
        if data.startswith(b'version https://git-lfs.github.com/spec/v1'):
            raise ValueError('required fixture is an unresolved Git LFS pointer: ' + name)
        if len(data) != expected['bytes'] or hashlib.sha256(data).hexdigest() != item.get('sha256'):
            raise ValueError('fixture requirement bytes/hash differ from its committed blob: ' + name)
        declared[name] = (item, data)
    return {'input_sha256': hashlib.sha256(raw).hexdigest(), 'document': request}, declared


def materialized(rows):
    return {row['path']: row for row in rows}


def same_bytes(a, b):
    if a is None or b is None: return a is b
    return a['bytes'] == b['bytes'] and a['sha256'] == b['sha256'] and a.get('mode') == b.get('mode')


def files(root):
    root = pathlib.Path(root)
    result = set()
    for path in root.rglob('*'):
        if path.is_symlink(): raise ValueError('unexpected symlink in materialized fixtures: ' + str(path))
        if path.is_file(): result.add(path.relative_to(root).as_posix())
    return result


def matches(root, row):
    path = relative(root, row['path'])
    if not path.is_file() or path.stat().st_size != row['bytes'] or sha(path) != row['sha256']: return False
    return (os.name == 'nt' or not row.get('verify_mode') or
            path.stat().st_mode & 0o777 == (0o755 if row['mode'] == '100755' else 0o644))


def verify_tree(root, rows):
    rows = materialized(rows) if isinstance(rows, list) else rows
    observed = files(root)
    if observed != set(rows):
        raise ValueError('materialized fixture paths differ: ' + repr({'missing': sorted(set(rows)-observed)[:20], 'extra': sorted(observed-set(rows))[:20]}))
    for row in rows.values():
        if not matches(root, row): raise ValueError('materialized fixture bytes differ: ' + row['path'])


def copy_owned(stream, path, row, history):
    """Recover only an exact prefix of our planned generated copy; preserve it."""
    path, history = pathlib.Path(path), pathlib.Path(history)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink(): raise ValueError('owned fixture copy is an unexpected symlink')
    def recover(part):
        if not part.exists(): return
        if part.is_symlink() or part.stat().st_size >= row['bytes']:
            raise ValueError('owned fixture copy has unknown bytes: ' + str(part))
        stream.seek(0)
        with part.open('rb') as existing:
            while chunk := existing.read(4 * 1024 ** 2):
                if stream.read(len(chunk)) != chunk:
                    raise ValueError('owned fixture copy is not an exact interrupted prefix: ' + str(part))
        history.mkdir(parents=True, exist_ok=True)
        preserved = history / (str(time.time_ns()) + '.partial')
        record = {'original_path': str(part), 'preserved_path': str(preserved), 'bytes': part.stat().st_size,
                  'sha256': sha(part), 'expected_sha256': row['sha256'], 'reason': 'exact interrupted copy prefix'}
        part.replace(preserved); write(preserved.with_suffix('.json'), record)
    if path.exists() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256']:
        if row.get('verify_mode'): path.chmod(0o755 if row['mode'] == '100755' else 0o644)
        return
    recover(path)
    temporary = path.with_name(path.name + '.writing')
    if temporary.is_symlink(): raise ValueError('owned fixture temporary copy is an unexpected symlink')
    if temporary.exists() and temporary.stat().st_size == row['bytes'] and sha(temporary) == row['sha256']:
        if row.get('verify_mode'): temporary.chmod(0o755 if row['mode'] == '100755' else 0o644)
        temporary.replace(path)
        return
    recover(temporary)
    stream.seek(0)
    with temporary.open('xb') as output: shutil.copyfileobj(stream, output, 4 * 1024 ** 2)
    if temporary.stat().st_size != row['bytes'] or sha(temporary) != row['sha256']:
        raise ValueError('generated fixture copy differs from the frozen content')
    if row.get('verify_mode'): temporary.chmod(0o755 if row['mode'] == '100755' else 0o644)
    temporary.replace(path)


def freeze(repository, target, work, directory, parent_descriptor=None, parent_directory=None, requirements_path=None):
    """Read committed new blobs; preserve the actual baseline support byte hashes."""
    repository, work, directory = map(pathlib.Path, [repository, work, directory])
    if git(repository, 'rev-parse', 'HEAD').decode().strip() != target:
        raise ValueError('fixture checkout HEAD differs from explicit committed target')
    if git(repository, 'status', '--porcelain', '--untracked-files=all').strip():
        raise ValueError('fixture target must be a clean committed checkout')
    git(repository, 'merge-base', '--is-ancestor', BASE, target)
    support_path = work / 'fixture-support-manifest.json'; receipt_path = work / 'fixture-support-receipt.json'
    support, receipt = read(support_path), read(receipt_path)
    if receipt['revision'] != BASE or receipt['files'] != len(support) or receipt['lfs_pointers']:
        raise ValueError('baseline support receipt differs')
    baseline_git, target_git = tree(repository, BASE), tree(repository, target)
    requirements, declared = support_requirements(repository, target, target_git, requirements_path)
    baseline = {}
    for item in support:
        name = item['path']
        if name not in baseline_git or name in baseline: raise ValueError('support manifest is not a unique baseline Git path subset')
        baseline[name] = {**item, 'mode': baseline_git[name]['mode'], 'verify_mode': False,
                          'origin': 'proved-hydrated-baseline-support',
                          'base_git_blob': baseline_git[name]['git_blob']}
    selected = dict(baseline)
    committed_changes = []
    changed_data = {}
    for name in sorted(set(baseline_git) | set(target_git)):
        before, after = baseline_git.get(name), target_git.get(name)
        if before == after: continue
        committed_changes.append({'path': name, 'base': before, 'target': after,
                                  'baseline_materialized': name in baseline})
        if after is None:
            selected.pop(name, None)
        else:
            raw = git(repository, 'cat-file', 'blob', after['git_blob'])
            if raw.startswith(b'version https://git-lfs.github.com/spec/v1'):
                raise ValueError('changed fixture is an unresolved Git LFS pointer: ' + name)
            assert len(raw) == after['bytes']
            selected[name] = data_row(name, raw, after['mode'], 'exact-committed-target-blob', after['git_blob'])
            changed_data[name] = raw
    required_files = []
    for name, (item, raw) in sorted(declared.items()):
        if name not in selected:
            selected[name] = data_row(name, raw, item['mode'], 'exact-committed-required-support-blob', item['git_blob'])
            changed_data[name] = raw
        # Existing hydrated support may have CRLF bytes or archive modes. Keep
        # that proved materialization separate from the logical Git requirement.
        required_files.append({key: item[key] for key in ['path', 'git_blob', 'mode', 'bytes', 'sha256']} |
                              {'materialized_origin': selected[name]['origin'],
                               'materialized_bytes': selected[name]['bytes'],
                               'materialized_sha256': selected[name]['sha256']})
    if parent_descriptor:
        parent = read(pathlib.Path(parent_directory) / parent_descriptor['manifest'])
        if sha(pathlib.Path(parent_directory) / parent_descriptor['manifest']) != parent_descriptor['manifest_sha256']:
            raise ValueError('parent fixture manifest changed')
        omitted_requirements = {row['path'] for row in parent.get('required_support_files', [])} - set(declared)
        if omitted_requirements:
            raise ValueError('parent required support paths cannot be silently omitted: ' + repr(sorted(omitted_requirements)))
        previous = materialized(parent['target_materialized_files'])
    else:
        previous = baseline
    payload_names = {name for name, row in selected.items() if not same_bytes(previous.get(name), row)}
    restore = payload_names - set(changed_data)
    if restore:
        # Untouched support files retain their raw archive mode without a Git
        # mode claim. A restoration is an explicit new write, so its selected
        # target mode must also be installed and verified (including mode-only
        # transitions back from an earlier committed overlay).
        for name in restore:
            selected[name] = {**selected[name], 'verify_mode': True,
                              'mode_origin': 'restored-support-bytes-with-committed-target-mode'}
        archive_path = work / receipt['archive']
        if sha(archive_path) != receipt['sha256']: raise ValueError('baseline restoration archive differs')
        import zstandard
        with archive_path.open('rb') as packed, zstandard.ZstdDecompressor().stream_reader(packed) as decoded:
            with tarfile.open(fileobj=decoded, mode='r|') as archive:
                for member in archive:
                    if member.name in restore:
                        if not member.isfile(): raise ValueError('baseline restoration is not a regular file')
                        raw = archive.extractfile(member).read()
                        if hashlib.sha256(raw).hexdigest() != selected[member.name]['sha256']:
                            raise ValueError('baseline restoration bytes differ')
                        changed_data[member.name] = raw
        if not payload_names <= set(changed_data): raise ValueError('baseline restoration payload is incomplete')
    directory.mkdir(parents=True, exist_ok=True)
    payload_path = directory / 'fixtures-payload.tar'
    with tarfile.open(payload_path, 'w', format=tarfile.PAX_FORMAT) as archive:
        for name in sorted(payload_names):
            raw = changed_data[name]
            if hashlib.sha256(raw).hexdigest() != selected[name]['sha256']: raise ValueError('fixture payload differs')
            info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o755 if selected[name]['mode'] == '100755' else 0o644
            info.mtime = 0; archive.addfile(info, io.BytesIO(raw))
    omitted = [target_git[name] for name in sorted(set(target_git) - set(selected))]
    value = {'schema_version': 1, 'kind': 'verified-partial-support-with-committed-overlay',
             'fixture_path': FIXTURE_PATH, 'base_revision': BASE, 'target_revision': target,
             'base_git_tree': git(repository, 'rev-parse', BASE + '^{tree}').decode().strip(),
             'target_git_tree': git(repository, 'rev-parse', target + '^{tree}').decode().strip(),
             'full_git_tree_materialized': False,
             'baseline_support_manifest_sha256': sha(support_path), 'baseline_support_receipt': receipt,
             'baseline_support_receipt_sha256': sha(receipt_path),
             'baseline_materialized_files': list(baseline.values()),
             'previous_materialized_files': list(previous.values()),
             'target_materialized_files': [selected[name] for name in sorted(selected)],
             'committed_changes': committed_changes, 'omitted_unchanged_git_paths': omitted,
             'support_requirements': requirements, 'required_support_files': required_files,
             'payload_paths': sorted(payload_names), 'payload_sha256': sha(payload_path), 'payload_bytes': payload_path.stat().st_size,
             'parent_manifest_sha256': parent_descriptor['manifest_sha256'] if parent_descriptor else None}
    manifest_path = directory / 'fixtures-overlay.json'; write(manifest_path, value)
    if git(repository, 'rev-parse', 'HEAD').decode().strip() != target or git(repository, 'status', '--porcelain', '--untracked-files=all').strip():
        raise ValueError('fixture checkout changed during export')
    return {'manifest': manifest_path.name, 'manifest_sha256': sha(manifest_path),
            'payload': payload_path.name, 'payload_sha256': sha(payload_path), 'payload_bytes': payload_path.stat().st_size,
            'base_revision': BASE, 'target_revision': target, 'target_git_tree': value['target_git_tree'],
            'baseline_support_manifest_sha256': value['baseline_support_manifest_sha256'],
            'support_requirements_sha256': hashlib.sha256(canonical(requirements)).hexdigest() if requirements else None,
            'required_support_file_count': len(required_files),
            'materialized_file_count': len(selected), 'omitted_unchanged_file_count': len(omitted),
            'full_git_tree_materialized': False}


def checked(directory, descriptor):
    directory = pathlib.Path(directory)
    path = directory / descriptor['manifest']
    if sha(path) != descriptor['manifest_sha256']: raise ValueError('frozen fixture manifest differs')
    value = read(path)
    if (value['target_revision'] != descriptor['target_revision'] or value['base_revision'] != BASE
            or value['payload_sha256'] != descriptor['payload_sha256']
            or sha(directory / descriptor['payload']) != descriptor['payload_sha256']):
        raise ValueError('frozen fixture payload/commit identity differs')
    return value


def verify(root, directory, descriptor):
    value = checked(directory, descriptor)
    verify_tree(pathlib.Path(root) / FIXTURE_PATH, value['target_materialized_files'])
    return value


def apply(source_root, task_root, directory, descriptor):
    source_root, task_root, directory = map(pathlib.Path, [source_root, task_root, directory])
    value = checked(directory, descriptor)
    fixture = source_root / FIXTURE_PATH
    if (fixture / '.git').exists(): raise ValueError('fixture overlay expects the proved flat support materialization, not a Git checkout')
    before, after = materialized(value['previous_materialized_files']), materialized(value['target_materialized_files'])
    changed = {name for name in set(before) | set(after) if not same_bytes(before.get(name), after.get(name))}
    transition_path = directory / 'fixture-transition.json'
    if transition_path.exists():
        state = read(transition_path)
        if state['manifest_sha256'] != descriptor['manifest_sha256']:
            raise ValueError('another fixture transition already owns this candidate')
        observed = files(fixture)
        if observed - set(before) - set(after): raise ValueError('unexpected fixture file appeared during transition')
        for name in set(before) | set(after):
            options = [row for row in [before.get(name), after.get(name)] if row]
            path = relative(fixture, name)
            if not path.exists() and (before.get(name) is None or after.get(name) is None): continue
            if not any(matches(fixture, row) for row in options): raise ValueError('fixture transition contains unknown bytes: ' + name)
    else:
        verify_tree(fixture, before)
        support = read(task_root / 'proof/fixture-support.json')
        expected = value['baseline_support_receipt']
        if (support['revision'] != BASE or support['sha256'] != expected['sha256'] or support['files'] != expected['files']
                or support['input_receipt_sha256'] != value['baseline_support_receipt_sha256']):
            raise ValueError('guest fixture support foundation differs from the proved archive receipt')
        state = {'manifest_sha256': descriptor['manifest_sha256'], 'phase': 'prepared'}
    staged = directory / 'fixture-staged'; staged.mkdir(exist_ok=True)
    with tarfile.open(directory / descriptor['payload'], 'r') as archive:
        members = archive.getmembers()
        if len(members) != len(value['payload_paths']) or {item.name for item in members} != set(value['payload_paths']):
            raise ValueError('fixture archive has duplicate or undeclared entries')
        for item in members:
            if not item.isfile() or item.size != after[item.name]['bytes']: raise ValueError('fixture payload entry differs')
            path = relative(staged, item.name); path.parent.mkdir(parents=True, exist_ok=True)
            with archive.extractfile(item) as stream:
                copy_owned(stream, path, after[item.name], directory / 'fixture-copy-recovery')
            if not matches(staged, after[item.name]): raise ValueError('staged fixture payload hash differs')
    prior = directory / 'fixture-prior'
    if not transition_path.exists():
        for name in sorted(changed & set(before)):
            source = relative(fixture, name); preserved = relative(prior, name); preserved.parent.mkdir(parents=True, exist_ok=True)
            with source.open('rb') as stream:
                copy_owned(stream, preserved, before[name], directory / 'fixture-copy-recovery')
            shutil.copystat(source, preserved)
        write(transition_path, state)
    for name in sorted(changed):
        target = relative(fixture, name)
        if name in before and not matches(prior, before[name]): raise ValueError('prior fixture bytes were not preserved before mutation')
        if name not in after:
            if target.exists():
                if not matches(fixture, before[name]): raise ValueError('fixture deletion would remove unknown bytes')
                target.unlink()
        elif not matches(fixture, after[name]):
            if target.exists() and (name not in before or not matches(fixture, before[name])):
                raise ValueError('fixture replacement would overwrite unknown bytes')
            target.parent.mkdir(parents=True, exist_ok=True)
            # Publish from the candidate-owned staging tree. A process crash
            # cannot leave an extra sibling inside the fixture support tree.
            temporary = relative(directory / 'fixture-publish', name)
            temporary.parent.mkdir(parents=True, exist_ok=True)
            with relative(staged, name).open('rb') as stream:
                copy_owned(stream, temporary, after[name], directory / 'fixture-copy-recovery')
            temporary.chmod(0o755 if after[name]['mode'] == '100755' else 0o644); temporary.replace(target)
    verify_tree(fixture, after)
    binding = {'kind': value['kind'], 'base_revision': BASE, 'logical_target_revision': value['target_revision'],
               'target_git_tree': value['target_git_tree'], 'full_git_tree_materialized': False,
               'baseline_support_manifest_sha256': value['baseline_support_manifest_sha256'],
               'target_materialized_manifest_sha256': hashlib.sha256(canonical(value['target_materialized_files'])).hexdigest(),
               'materialized_file_count': len(after), 'omitted_unchanged_file_count': len(value['omitted_unchanged_git_paths']),
               'omitted_unchanged_paths_sha256': hashlib.sha256(canonical(value['omitted_unchanged_git_paths'])).hexdigest(),
               'manifest_path': str(directory / descriptor['manifest']), 'manifest_sha256': descriptor['manifest_sha256'],
               'parent_index_gitlink_changed': False}
    write(task_root / 'proof/fixture-overlay-current.json', {'binding': binding, 'descriptor': descriptor, 'candidate_directory': str(directory)})
    state.update(phase='complete', completed_at_ns=time.time_ns(), binding=binding); write(transition_path, state)
    return binding


def current(source_root, task_root):
    path = pathlib.Path(task_root) / 'proof/fixture-overlay-current.json'
    if not path.exists(): return None
    receipt = read(path); directory = pathlib.Path(receipt['candidate_directory'])
    if not directory.resolve().is_relative_to(pathlib.Path(task_root).resolve() / 'candidates'):
        raise ValueError('current fixture receipt escapes candidate evidence')
    verify(source_root, directory, receipt['descriptor'])
    return receipt['binding']
