#!/usr/bin/env python3
"""Freeze, build and publish one exact DeadSync candidate on the proved builder.

Freeze is local/read-only to the source tree. Deploy must be explicitly requested
with the frozen candidate ID and the final baseline build-proof SHA256.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import time
import traceback

BASE = '2da5562bb050d155a90498fd075279a0249ae479'
ROOT = pathlib.Path('/opt/song-lua-audit/pass4')
DEADSYNC = pathlib.Path('/opt/song-lua-audit/deadsync-pass4')
UNIT = 'deadsync-lua-pass4-candidate'
DIFF = ['diff', '--binary', '--full-index', '--no-ext-diff', '--no-textconv', '--no-renames',
        '--no-color', '--diff-algorithm=myers', '--no-indent-heuristic', 'HEAD']
FIXTURE_EXCLUSION = ['--', '.', ':(exclude)tests/fixtures']
EXTRA_NAMES = {'fixture_overlay.py', 'fixtures-overlay.json', 'fixtures-payload.tar', 'candidate-full.patch'}


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def load(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))


def save(path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp.' + str(os.getpid()))
    temporary.write_bytes(json.dumps(value, ensure_ascii=False, indent=2).encode() + b'\n')
    temporary.replace(path)


def stable(path, data):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError('refusing to overwrite another frozen candidate file: ' + str(path))
    else:
        path.write_bytes(data)


def git(repository, *arguments, **kwargs):
    return subprocess.check_output(['git', '-C', str(repository), *arguments], **kwargs)


def relative_file(repository, relative):
    value = pathlib.PurePosixPath(relative)
    if value.is_absolute() or '..' in value.parts or not value.parts:
        raise ValueError('invalid candidate source path: ' + relative)
    return pathlib.Path(repository) / value


def frozen_file_names(contract):
    if set(contract.get('extra_files', {})) - EXTRA_NAMES:
        raise ValueError('unknown frozen candidate companion file')
    return ['candidate.patch', 'manifest.json', 'candidate_runner.py', *contract.get('extra_files', {})]


def fixture_module(directory, contract=None):
    directory = pathlib.Path(directory)
    if contract:
        frozen_file_names(contract)
        for name, record in contract.get('extra_files', {}).items():
            path = directory / name
            if not path.is_file() or path.is_symlink() or path.stat().st_size != record['bytes'] or sha(path) != record['sha256']:
                raise ValueError('frozen candidate companion differs: ' + name)
    path = directory / 'fixture_overlay.py'
    spec = importlib.util.spec_from_file_location('bound_fixture_overlay', path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


def source_diff(manifest):
    return git(DEADSYNC, *DIFF, *(FIXTURE_EXCLUSION if manifest['contract'].get('fixture_overlay') else []))


def apply_fixture(manifest, directory):
    descriptor = manifest['contract'].get('fixture_overlay')
    if descriptor:
        return fixture_module(directory, manifest['contract']).apply(DEADSYNC, ROOT, directory, descriptor)


def freeze(args):
    work = pathlib.Path(__file__).resolve().parent
    repository = work.parent.parent
    source_head = git(repository, 'rev-parse', 'HEAD').decode().strip()
    requested_base = getattr(args, 'base_revision', None)
    base = requested_base or source_head
    if base != BASE:
        raise ValueError('candidate base differs from the proved guest base; pass --base-revision ' + BASE + ' for a cumulative candidate after local commits')
    if requested_base:
        git(repository, 'merge-base', '--is-ancestor', base, source_head)
    full_diff_arguments = [*DIFF[:-1], base]
    full_patch = git(repository, *full_diff_arguments)
    fixture_revision = getattr(args, 'fixtures_revision', None)
    requirements_path = getattr(args, 'fixture_requirements', None)
    if requirements_path and not fixture_revision:
        raise ValueError('--fixture-requirements requires the exact --fixtures-revision')
    parent_directory = work / 'candidates' / args.parent_candidate if getattr(args, 'parent_candidate', None) else None
    parent_manifest = load(parent_directory / 'manifest.json') if parent_directory else None
    if parent_manifest and (parent_manifest['id'] != args.parent_candidate or hashlib.sha256(canonical(parent_manifest['contract'])).hexdigest() != args.parent_candidate):
        raise ValueError('local parent candidate identity differs')
    parent_fixture = parent_manifest['contract'].get('fixture_overlay') if parent_manifest else None
    fixture_entry = git(repository, 'ls-tree', base, '--', 'tests/fixtures').decode().strip()
    baseline_fixture = fixture_entry.split()[2] if fixture_entry else None
    current_fixture = (git(repository / 'tests/fixtures', 'rev-parse', 'HEAD').decode().strip()
                       if baseline_fixture else None)
    if (current_fixture != baseline_fixture or parent_fixture) and not fixture_revision:
        raise ValueError('changed fixture gitlink/content requires --fixtures-revision with the exact clean committed target')
    if fixture_revision and fixture_revision != current_fixture:
        raise ValueError('--fixtures-revision differs from the clean local fixture checkout')
    diff_arguments = [*full_diff_arguments, *(FIXTURE_EXCLUSION if fixture_revision else [])]
    untracked = git(repository, 'ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
    if any(untracked):
        raise ValueError('untracked sources are absent from git diff; mark intended new files with git add -N first: ' + repr([x for x in untracked if x]))
    patch = git(repository, *diff_arguments)
    if not patch and not fixture_revision:
        raise ValueError('candidate has no source changes')
    tokens = git(repository, 'diff', '--name-status', '--no-renames', '-z', base,
                 *(FIXTURE_EXCLUSION if fixture_revision else [])).decode().split('\0')
    changed = []
    object_format = git(repository, 'rev-parse', '--show-object-format').decode().strip()
    for index in range(0, len(tokens) - 1, 2):
        status, relative = tokens[index:index + 2]
        if status not in {'A', 'M', 'D', 'T'}:
            raise ValueError('unsupported candidate change: ' + status)
        path = relative_file(repository, relative)
        row = {'path': relative, 'status': status}
        if status == 'D':
            row['deleted'] = True
        else:
            if not path.is_file() or path.is_symlink():
                raise ValueError('candidate must contain regular source files: ' + relative)
            raw = path.read_bytes()
            expected_blob = git(repository, 'hash-object', '--path=' + relative, relative).decode().strip()
            normalized = None
            for normalization, data in [('none', raw), ('git-text-crlf-to-lf', raw.replace(b'\r\n', b'\n'))]:
                blob = hashlib.new(object_format, b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
                if blob == expected_blob:
                    normalized = data
                    row.update(worktree_sha256=hashlib.sha256(raw).hexdigest(), worktree_bytes=len(raw),
                               applied_sha256=hashlib.sha256(data).hexdigest(), applied_bytes=len(data),
                               git_blob=blob, git_normalization=normalization)
                    break
            if normalized is None:
                raise ValueError('unsupported Git clean filter; exact applied bytes need review: ' + relative)
        changed.append(row)
    tests = []
    for value in args.test:
        if not value or value.startswith('-'):
            raise ValueError('test filter must be explicit')
        tests.append(['cargo', 'test', '--locked', '--release', '--test', args.test_target,
                      value, '-j', str(args.jobs), '--', '--test-threads=1', '--nocapture'])
    for value in args.unit_test:
        package, separator, value = value.partition(':')
        if not package or package.startswith('-') or separator and (not value or value.startswith('-')):
            raise ValueError('--unit-test requires PACKAGE or PACKAGE:FILTER')
        tests.append(['cargo', 'test', '--locked', '--release', '-p', package, '--lib',
                      *([value] if separator else []), '-j', str(args.jobs), '--', '--test-threads=1', '--nocapture'])
    for value in getattr(args, 'integration_test', []):
        target, separator, selected = value.partition(':')
        if not target or target.startswith('-') or separator and (not selected or selected.startswith('-')):
            raise ValueError('--integration-test requires [PACKAGE/]TARGET[:FILTER]')
        package, slash, name = target.partition('/')
        if slash:
            if not package or not name or '/' in name or name.startswith('-'): raise ValueError('invalid integration package/target')
            target = name
        features = getattr(args, 'integration_features', None)
        if features and features.startswith('-'): raise ValueError('invalid integration features')
        tests.append(['cargo', 'test', '--locked', '--release', *(['-p', package] if slash else []),
                      *(['--features', features] if features else []), '--test', target,
                      *([selected] if separator else []), '-j', str(args.jobs), '--', '--test-threads=1', '--nocapture'])
    if not tests:
        raise ValueError('at least one focused test filter must be frozen with the candidate')
    extras = {}
    fixture_descriptor = None
    if fixture_revision:
        staging = work / 'candidate-fixture-staging' / str(time.time_ns())
        fixture_descriptor = fixture_module(work).freeze(repository / 'tests/fixtures', fixture_revision, work,
                                                         staging, parent_fixture, parent_directory, requirements_path)
        stable(staging / 'fixture_overlay.py', (work / 'fixture_overlay.py').read_bytes())
        stable(staging / 'candidate-full.patch', full_patch)
        for name in EXTRA_NAMES:
            path = staging / name
            extras[name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    if (git(repository, *diff_arguments) != patch or git(repository, *full_diff_arguments) != full_patch
            or git(repository, 'rev-parse', 'HEAD').decode().strip() != source_head):
        raise ValueError('source changed during freeze; no candidate was exported')
    for row in changed:
        if not row.get('deleted') and sha(repository / row['path']) != row['worktree_sha256']:
            raise ValueError('source bytes changed during freeze: ' + row['path'])
    contract = {'base_revision': base, 'source_head_revision': source_head, 'patch_sha256': hashlib.sha256(patch).hexdigest(),
                'patch_bytes': len(patch), 'changed_files': changed, 'tests': tests,
                'toolchain': '1.100.0', 'parallel_jobs': args.jobs, 'helper_sha256': sha(__file__),
                'parent_candidate': getattr(args, 'parent_candidate', None)}
    if fixture_descriptor:
        contract.update(fixture_overlay=fixture_descriptor, extra_files=extras,
                        local_full_diff_sha256=hashlib.sha256(full_patch).hexdigest(),
                        patch_scope='regular source files; tests/fixtures committed overlay is bound separately')
    identifier = hashlib.sha256(canonical(contract)).hexdigest()
    directory = work / 'candidates' / identifier
    manifest_path = directory / 'manifest.json'
    if manifest_path.exists():
        existing = load(manifest_path)
        if existing['contract'] != contract or existing['id'] != identifier:
            raise ValueError('frozen candidate manifest identity differs')
    else:
        save(manifest_path, {'schema_version': 1, 'id': identifier, 'frozen_at': now(),
                            'source_workspace': str(repository), 'contract': contract})
    stable(directory / 'candidate.patch', patch)
    stable(directory / 'candidate_runner.py', pathlib.Path(__file__).read_bytes())
    for name in extras:
        stable(directory / name, (staging / name).read_bytes())
    print(json.dumps({'frozen': True, 'candidate': identifier, 'directory': str(directory),
                      'files': len(changed), 'tests': len(tests), 'patch_sha256': contract['patch_sha256']}))


def verify_source(manifest):
    contract = manifest['contract']
    if git(DEADSYNC, 'diff', '--cached', '--name-only', 'HEAD').strip():
        raise ValueError('guest index contains changes beyond this helper\'s intent-to-add markers')
    if git(DEADSYNC, 'ls-files', '--others', '--exclude-standard', '-z').strip(b'\0'):
        raise ValueError('guest source contains untracked files outside the frozen candidate')
    if git(DEADSYNC, 'rev-parse', 'HEAD').decode().strip() != contract['base_revision']:
        raise ValueError('guest source HEAD differs from the frozen base')
    if hashlib.sha256(source_diff(manifest)).hexdigest() != contract['patch_sha256']:
        raise ValueError('guest working diff differs from the exact frozen candidate')
    for row in contract['changed_files']:
        path = relative_file(DEADSYNC, row['path'])
        if row.get('deleted'):
            if path.exists():
                raise ValueError('deleted candidate file remains: ' + row['path'])
        elif not path.is_file() or path.is_symlink() or sha(path) != row['applied_sha256']:
            raise ValueError('guest candidate file differs: ' + row['path'])
    if contract.get('fixture_overlay'):
        directory = ROOT / 'candidates' / manifest['id']
        fixture_module(directory, contract).verify(DEADSYNC, directory, contract['fixture_overlay'])


def exact_candidate_bytes(manifest):
    """Recognize a completed apply even if a crash preceded new-file markers."""
    rows = manifest['contract']['changed_files']
    expected = {row['path'] for row in rows}
    new = {row['path'] for row in rows if row['status'] == 'A'}
    untracked = set(filter(None, git(DEADSYNC, 'ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')))
    changed = set(filter(None, git(DEADSYNC, 'diff', '--name-only', '-z', 'HEAD',
                                  *(FIXTURE_EXCLUSION if manifest['contract'].get('fixture_overlay') else [])).decode().split('\0')))
    if untracked - new or changed | untracked != expected:
        return False
    for row in rows:
        path = relative_file(DEADSYNC, row['path'])
        if row.get('deleted'):
            if path.exists(): return False
        elif not path.is_file() or path.is_symlink() or sha(path) != row['applied_sha256']:
            return False
    return True


def apply_candidate(manifest, directory):
    contract = manifest['contract']
    identifier = manifest['id']
    parent = contract.get('parent_candidate')
    patch = directory / 'candidate.patch'
    if git(DEADSYNC, 'rev-parse', 'HEAD').decode().strip() != BASE:
        raise ValueError('guest source is not based on the required clean base')
    if git(DEADSYNC, 'diff', '--cached', '--name-only', 'HEAD').strip():
        raise ValueError('refusing unrelated staged/index changes')
    transition_path = directory / 'transition.json'
    if transition_path.is_file():
        recorded = load(transition_path)
        if recorded.get('parent') != parent or recorded.get('candidate') != identifier:
            raise ValueError('existing transition receipt belongs to another source transition')
    parent_manifest = None
    if parent:
        parent_directory = ROOT / 'candidates' / parent
        parent_manifest = load(parent_directory / 'manifest.json')
        if (parent_manifest['id'] != parent or hashlib.sha256(canonical(parent_manifest['contract'])).hexdigest() != parent
                or parent_manifest['contract']['base_revision'] != BASE
                or sha(parent_directory / 'candidate.patch') != parent_manifest['contract']['patch_sha256']):
            raise ValueError('explicit parent candidate identity is unverified')
    if exact_candidate_bytes(manifest):
        if parent and not transition_path.exists():
            # A new candidate may change only gates/metadata. Prove its parent
            # before adopting those already-identical source bytes.
            verify_source(parent_manifest)
            save(transition_path, {'parent': parent, 'candidate': identifier, 'phase': 'identical-source', 'at': now()})
        if patch.stat().st_size: git(DEADSYNC, 'apply', '--reverse', '--check', str(patch))
        new = [row['path'] for row in contract['changed_files'] if row['status'] == 'A']
        if new: git(DEADSYNC, 'add', '--intent-to-add', '--', *new)
        apply_fixture(manifest, directory)
        verify_source(manifest)
        return 'adopted-already-applied-exact-candidate'
    difference = source_diff(parent_manifest or manifest)
    if parent and difference:
        verify_source(parent_manifest)
        parent_patch = ROOT / 'candidates' / parent / 'candidate.patch'
        # Check B against the untouched base in a private index before reversing
        # A. This does not reset, clean, checkout or overwrite any working file.
        index = directory / ('preflight-index-' + str(time.time_ns()))
        environment = dict(os.environ, GIT_INDEX_FILE=str(index))
        git(DEADSYNC, 'read-tree', BASE, env=environment)
        if patch.stat().st_size: git(DEADSYNC, 'apply', '--check', '--cached', str(patch), env=environment)
        if parent_patch.stat().st_size: git(DEADSYNC, 'apply', '--reverse', '--check', str(parent_patch))
        transition = {'parent': parent, 'candidate': identifier, 'phase': 'preflight', 'at': now(),
                      'parent_patch_sha256': parent_manifest['contract']['patch_sha256'],
                      'candidate_patch_sha256': contract['patch_sha256'],
                      'parent_manifest_sha256': sha(ROOT / 'candidates' / parent / 'manifest.json'),
                      'private_index': str(index)}
        save(transition_path, transition)
        if parent_patch.stat().st_size: git(DEADSYNC, 'apply', '--reverse', str(parent_patch))
        own_markers = [row['path'] for row in parent_manifest['contract']['changed_files'] if row['status'] == 'A']
        if own_markers: git(DEADSYNC, 'update-index', '--force-remove', '--', *own_markers)
        if source_diff(manifest) or git(DEADSYNC, 'diff', '--cached', '--name-only', 'HEAD').strip():
            raise ValueError('verified parent reverse did not restore the exact clean base')
        transition.update(phase='parent-reversed', reversed_at=now()); save(transition_path, transition)
    elif difference:
        raise ValueError('guest has another candidate or unknown source changes; --parent-candidate is required')
    elif parent:
        if not transition_path.is_file():
            # A proved parent may contain only fixture changes and an empty
            # regular-source patch. Verify that exact state before advancing.
            if parent_manifest['contract']['patch_bytes'] != 0:
                raise ValueError('parent source is absent without this candidate\'s verified transition receipt')
            verify_source(parent_manifest)
            save(transition_path, {'parent': parent, 'candidate': identifier, 'phase': 'parent-reversed', 'at': now()})
        transition = load(transition_path)
        if transition.get('parent') != parent or transition.get('candidate') != identifier or transition.get('phase') not in {'preflight', 'parent-reversed'}:
            raise ValueError('clean-base transition receipt does not match the explicit parent/candidate')
    if git(DEADSYNC, 'ls-files', '--others', '--exclude-standard', '-z').strip(b'\0'):
        raise ValueError('guest contains untracked sources before candidate apply')
    if patch.stat().st_size:
        git(DEADSYNC, 'apply', '--check', str(patch))
        git(DEADSYNC, 'apply', str(patch))
    new = [row['path'] for row in contract['changed_files'] if row['status'] == 'A']
    if new: git(DEADSYNC, 'add', '--intent-to-add', '--', *new)
    apply_fixture(manifest, directory)
    verify_source(manifest)
    if parent:
        transition = load(transition_path)
        transition.update(phase='candidate-applied', applied_at=now()); save(transition_path, transition)
    return 'applied-once-after-verified-parent' if parent else 'applied-once'


def source_snapshot(repository):
    files, links, deleted = {}, {}, []
    for entry in git(repository, 'ls-files', '--stage', '-z').decode().split('\0'):
        if not entry:
            continue
        metadata, relative = entry.split('\t', 1)
        mode, object_id, _ = metadata.split()
        path = repository / relative
        if mode == '160000': links[relative] = object_id
        elif path.is_symlink(): files[relative] = {'symlink': os.readlink(path)}
        elif path.is_file(): files[relative] = sha(path)
        else: deleted.append(relative)
    value = {'path': str(repository), 'revision': git(repository, 'rev-parse', 'HEAD').decode().strip(),
            'tracked_status': git(repository, 'status', '--porcelain', '--untracked-files=no', '--ignore-submodules=all').decode().strip(),
            'files_sha256': files, 'gitlinks': links, 'deleted_files': deleted,
            'working_diff_sha256': hashlib.sha256(git(repository, *DIFF)).hexdigest()}
    current = ROOT / 'proof/fixture-overlay-current.json'
    if current.exists() and pathlib.Path(repository).resolve() == DEADSYNC.resolve():
        receipt = load(current)
        directory = pathlib.Path(receipt['candidate_directory'])
        if not directory.resolve().is_relative_to(ROOT.resolve() / 'candidates'):
            raise ValueError('current fixture receipt escapes candidate evidence')
        bound = load(directory / 'manifest.json')
        if bound['id'] != directory.name or hashlib.sha256(canonical(bound['contract'])).hexdigest() != directory.name:
            raise ValueError('current fixture candidate manifest differs')
        value['fixture_materialization'] = fixture_module(directory, bound['contract']).current(DEADSYNC, ROOT)
        value['working_diff_sha256'] = hashlib.sha256(git(repository, *DIFF, *FIXTURE_EXCLUSION)).hexdigest()
        value['working_diff_scope'] = 'regular source files; actual parent index gitlinks are recorded unchanged'
    return value


def run_step(directory, name, command, environment, candidate):
    path = directory / (name + '.json')
    log = directory / (name + '.log')
    if path.is_file() and log.is_file():
        previous = load(path)
        artifact = previous.get('artifact')
        if (previous.get('exit') == 0 and previous.get('candidate') == candidate
                and previous.get('command') == command and previous.get('log_sha256') == sha(log)
                and (not artifact or pathlib.Path(artifact['path']).is_file() and sha(artifact['path']) == artifact['sha256'])):
            return previous
    if path.exists() or log.exists():
        history = directory / 'attempt-history' / (name + '-' + str(time.time_ns()))
        history.mkdir(parents=True)
        if path.exists(): shutil.copy2(path, history / 'receipt.json')
        if log.exists(): shutil.copy2(log, history / 'output.log')
    record = {'candidate': candidate, 'command': command, 'cwd': str(DEADSYNC), 'started_at': now(), 'log': str(log)}
    started = time.monotonic()
    with log.open('w') as output:
        result = subprocess.run(command, cwd=DEADSYNC, env=environment, stdout=output, stderr=subprocess.STDOUT)
    record.update(exit=result.returncode, finished_at=now(), elapsed_seconds=round(time.monotonic() - started, 3), log_sha256=sha(log))
    save(path, record)
    if result.returncode:
        raise RuntimeError(name + ' failed; preserved log: ' + str(log))
    return record


def guest_build(identifier):
    import fcntl
    lock = (ROOT / 'candidate-runner.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fleet_lock = (ROOT / 'fleet-orchestration.lock').open('a')
    fcntl.flock(fleet_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    directory = ROOT / 'candidates' / identifier
    manifest = load(directory / 'manifest.json')
    contract = manifest['contract']
    if manifest['id'] != identifier or hashlib.sha256(canonical(contract)).hexdigest() != identifier:
        raise ValueError('candidate manifest identity differs')
    if sha(directory / 'candidate.patch') != contract['patch_sha256'] or sha(__file__) != contract['helper_sha256']:
        raise ValueError('candidate patch/helper differs from its frozen manifest')
    proof = ROOT / 'proof'
    prior = directory / 'prior'
    prior.mkdir(exist_ok=True)
    if (directory / 'state.json').exists():
        history = directory / 'attempt-history' / ('state-' + str(time.time_ns()) + '.json')
        history.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(directory / 'state.json', history)
    state = {'candidate': identifier, 'started_at': now(), 'passed': False, 'stage': 'prepare'}
    try:
        for unit in ['deadsync-lua-pass4-pilot', 'deadsync-lua-pass4-drain-pilot', 'deadsync-lua-pass4-build', 'deadsync-lua-pass4-capture-refresh']:
            if subprocess.run(['systemctl', 'is-active', '--quiet', unit]).returncode == 0:
                raise ValueError('source/binary mutation blocked by active unit: ' + unit)
        launch = load(directory / 'launch.json')
        if launch.get('parent_candidate') != contract.get('parent_candidate'):
            raise ValueError('candidate launch parent differs from its frozen contract')
        for name in ['source-proof.json', 'build-proof.json', 'capture-binaries.json']:
            source = pathlib.Path(launch['baseline_source_path'] if name == 'source-proof.json'
                                  else launch['baseline_build_path'] if name == 'build-proof.json' else proof / name)
            if source.is_file() and not (prior / name).exists(): shutil.copy2(source, prior / name)
        if not (prior / 'published-build-proof-before-candidate.json').exists():
            shutil.copy2(proof / 'build-proof.json', prior / 'published-build-proof-before-candidate.json')
        baseline = load(prior / 'build-proof.json')
        baseline_source = load(prior / 'source-proof.json')
        if baseline.get('passed') is not True or baseline['source_proof_sha256'] != sha(prior / 'source-proof.json'):
            raise ValueError('candidate requires a passed, source-bound baseline')
        if launch['expected_build_proof_sha256'] != sha(prior / 'build-proof.json'):
            raise ValueError('candidate launch refers to another final baseline')
        for name in ['harness', 'native']:
            binary = baseline['binaries'][name]
            if sha(binary['path']) != binary['sha256']:
                raise ValueError('proved native executable changed: ' + name)
        runner = ROOT / 'bin/full_song_lua'
        if not (prior / 'full_song_lua').exists():
            if sha(runner) != baseline['binaries']['runner']['sha256']:
                raise ValueError('previous runner differs before preservation')
            shutil.copy2(runner, prior / 'full_song_lua')
        if sha(prior / 'full_song_lua') != baseline['binaries']['runner']['sha256']:
            raise ValueError('preserved previous runner differs from baseline')
        save(directory / 'state.json', state)
        save(proof / 'build-proof.json', {'passed': False, 'candidate': identifier, 'stage': 'candidate-build',
             'previous_build_proof': str(prior / 'build-proof.json'), 'previous_build_proof_sha256': sha(prior / 'build-proof.json')})
        applied = apply_candidate(manifest, directory)
        if not (directory / 'applied.json').exists():
            save(directory / 'applied.json', {'candidate': identifier, 'action': applied, 'at': now(),
                                            'patch_sha256': contract['patch_sha256'], 'changed_files': contract['changed_files']})
        environment = dict(os.environ, CARGO_HOME='/home/parity/.cargo', RUSTUP_HOME='/home/parity/.rustup',
                           RUSTUP_TOOLCHAIN=contract['toolchain'], CARGO_TARGET_DIR='/opt/song-lua-audit/deadsync/target',
                           CARGO_PROFILE_RELEASE_LTO='false', CARGO_PROFILE_RELEASE_CODEGEN_UNITS='16',
                           CARGO_PROFILE_RELEASE_DEBUG='0', CARGO_PROFILE_RELEASE_STRIP='none',
                           LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='1', OMP_NUM_THREADS='1')
        rustup = '/home/parity/.cargo/bin/rustup'
        tool = lambda name: subprocess.check_output([rustup, 'which', '--toolchain', contract['toolchain'], name], env=environment, text=True).strip()
        cargo = tool('cargo'); environment['RUSTC'] = tool('rustc'); environment['RUSTDOC'] = tool('rustdoc')
        rust = subprocess.check_output([environment['RUSTC'], '-Vv'], env=environment, text=True)
        state['stage'] = 'compile'; save(directory / 'state.json', state)
        build = run_step(directory, 'runner-build', [cargo, 'test', '--locked', '--release', '--test', 'full_song_lua',
            '--no-run', '-j', str(contract['parallel_jobs']), '--message-format=json-render-diagnostics'], environment, identifier)
        executables = set()
        with (directory / 'runner-build.log').open() as log:
            for line in log:
                try: item = json.loads(line)
                except json.JSONDecodeError: continue
                if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'full_song_lua' and item.get('executable'):
                    executables.add(item['executable'])
        if len(executables) != 1:
            raise ValueError('Cargo did not identify exactly one current full_song_lua executable')
        executable = pathlib.Path(executables.pop())
        built = {'path': str(executable), 'sha256': sha(executable), 'bytes': executable.stat().st_size}
        build['artifact'] = built; save(directory / 'runner-build.json', build)
        tests = []
        state['stage'] = 'focused-tests'; save(directory / 'state.json', state)
        for index, command in enumerate(contract['tests'], 1):
            if command[0] != 'cargo' or command[1] != 'test' or '--release' not in command or '--locked' not in command:
                raise ValueError('invalid frozen focused test command')
            name = 'test-' + f'{index:02d}'
            record = run_step(directory, name, [cargo, *command[1:]], environment, identifier)
            text = pathlib.Path(record['log']).read_text(errors='replace')
            passed = sum(int(value) for value in re.findall(r'test result: ok\. (\d+) passed;', text))
            if not passed:
                raise ValueError(name + ' matched no passing tests; refusing a false validation gate')
            record['passed_tests'] = passed; save(directory / (name + '.json'), record); tests.append(record)
        verify_source(manifest)
        if sha(executable) != built['sha256']:
            raise ValueError('Cargo runner changed during focused validation')
        for name in ['harness', 'native']:
            if sha(baseline['binaries'][name]['path']) != baseline['binaries'][name]['sha256']:
                raise ValueError('native executable changed during candidate build')
        source = dict(baseline_source)
        source['created_at'] = now(); source['repositories'] = dict(source['repositories'])
        source['repositories']['deadsync'] = source_snapshot(DEADSYNC)
        if contract.get('fixture_overlay'):
            source['pins'] = dict(source['pins'])
            source['pins']['fixtures'] = contract['fixture_overlay']['target_revision']
        source['candidate'] = {'id': identifier, 'manifest_sha256': sha(directory / 'manifest.json'),
                               'patch_sha256': contract['patch_sha256'], 'base_revision': BASE,
                               'parent_candidate': contract.get('parent_candidate'),
                               'prior_source_proof_sha256': sha(prior / 'source-proof.json')}
        if contract.get('fixture_overlay'):
            source['candidate']['fixture_overlay'] = contract['fixture_overlay']
        save(directory / 'source-proof.json', source)
        replacement = runner.with_name('.full_song_lua.' + identifier)
        shutil.copy2(executable, replacement)
        if sha(replacement) != built['sha256']:
            raise ValueError('candidate runner copy differs before atomic installation')
        state['stage'] = 'install'; state['candidate_binary'] = built; save(directory / 'state.json', state)
        replacement.replace(runner)
        final = dict(baseline)
        final.update(passed=True, started_at=state['started_at'], finished_at=now(), candidate=source['candidate'], pins=source['pins'],
                     source_proof_sha256=sha(directory / 'source-proof.json'), rustc=rust,
                     previous_build_proof_sha256=sha(prior / 'build-proof.json'), focused_tests=tests,
                     runner_build=build, helper_sha256=contract['helper_sha256'])
        final['binaries'] = dict(baseline['binaries'])
        final['binaries']['runner'] = {**built, 'path': str(runner)}
        save(directory / 'build-proof.json', final)
        save(proof / 'source-proof.json', source)
        save(proof / 'build-proof.json', final)
        state.update(passed=True, stage='complete', finished_at=now(), runner=final['binaries']['runner'],
                     source_proof_sha256=final['source_proof_sha256'], build_proof_sha256=sha(proof / 'build-proof.json'))
        save(directory / 'state.json', state)
        print(json.dumps(state), flush=True)
    except BaseException as error:
        state.update(passed=False, stage='failed', failed_at=now(), error=str(error), traceback=traceback.format_exc())
        save(directory / 'state.json', state)
        raise


GUEST_TRANSPORT = r'''
import base64,hashlib,json,pathlib,subprocess
root=pathlib.Path('/opt/song-lua-audit/pass4')
proof=root/'proof/build-proof.json'
active=lambda unit:subprocess.run(['systemctl','is-active','--quiet',unit]).returncode==0
if request['action']=='status':
 out={'candidate_active':active('deadsync-lua-pass4-candidate'),'pilot_active':active('deadsync-lua-pass4-pilot'),
      'capture_refresh_active':active('deadsync-lua-pass4-capture-refresh')}
 if proof.is_file():
  value=json.loads(proof.read_text());out['build_proof']={k:value[k] for k in ['passed','candidate','finished_at'] if k in value}
  out['build_proof']['sha256']=hashlib.sha256(proof.read_bytes()).hexdigest()
 if request.get('candidate'):
  state=root/'candidates'/request['candidate']/'state.json'
  if state.is_file():out['candidate_state']=json.loads(state.read_text())
 print(json.dumps(out))
else:
 identifier=request['candidate'];directory=root/'candidates'/identifier
 parent=request.get('parent_candidate')
 if active('deadsync-lua-pass4-candidate') or active('deadsync-lua-pass4-pilot') or active('deadsync-lua-pass4-drain-pilot') or active('deadsync-lua-pass4-build') or active('deadsync-lua-pass4-capture-refresh'):
  raise RuntimeError('candidate deployment requires baseline build and pilot units to be inactive')
 current=json.loads(proof.read_text())
 if current.get('passed') is True and current.get('candidate',{}).get('id')==identifier:
  runner=current['binaries']['runner']
  if hashlib.sha256(pathlib.Path(runner['path']).read_bytes()).hexdigest()!=runner['sha256']:raise RuntimeError('installed candidate executable differs')
  if hashlib.sha256((root/'proof/source-proof.json').read_bytes()).hexdigest()!=current['source_proof_sha256']:raise RuntimeError('installed candidate source proof differs')
  print(json.dumps({'launched':False,'already_installed':True,'candidate':identifier}))
 else:
  prior=directory/'prior/build-proof.json'
  baseline_source=root/'proof/source-proof.json'
  if prior.is_file():
   baseline=prior;baseline_source=directory/'prior/source-proof.json'
  elif parent:
   current_candidate=current.get('candidate')
   current_id=current_candidate.get('id') if isinstance(current_candidate,dict) else current_candidate
   if current_id!=parent:raise RuntimeError('published source/build state does not match explicit parent candidate')
   if current.get('passed') is True:baseline=proof
   else:
    baseline=root/'candidates'/parent/'prior/build-proof.json'
    baseline_source=root/'candidates'/parent/'prior/source-proof.json'
    if current.get('previous_build_proof_sha256')!=hashlib.sha256(baseline.read_bytes()).hexdigest():raise RuntimeError('failed parent baseline provenance differs')
  else:
   if current.get('candidate'):raise RuntimeError('current candidate requires explicit --parent-candidate')
   baseline=proof
  if hashlib.sha256(baseline.read_bytes()).hexdigest()!=request['expected_build_proof_sha256']:
   raise RuntimeError('explicit final baseline build proof SHA differs')
  if json.loads(baseline.read_text()).get('passed') is not True:
   raise RuntimeError('baseline does not have passed native/build controls')
  directory.mkdir(parents=True,exist_ok=True)
  for name,encoded in request['files'].items():
   assert name in ['candidate.patch','manifest.json','candidate_runner.py','fixture_overlay.py','fixtures-overlay.json','fixtures-payload.tar','candidate-full.patch']
   data=base64.b64decode(encoded);target=directory/name
   if target.exists() and target.read_bytes()!=data:raise RuntimeError('frozen guest candidate file differs: '+name)
   if not target.exists():target.write_bytes(data)
  launch=directory/'launch.json'
  value={'candidate':identifier,'parent_candidate':parent,'expected_build_proof_sha256':request['expected_build_proof_sha256'],
         'baseline_build_path':str(baseline),'baseline_source_path':str(baseline_source)}
  if launch.exists():
   previous=json.loads(launch.read_text())
   if any(previous.get(key)!=value.get(key) for key in ['candidate','parent_candidate','expected_build_proof_sha256']):raise RuntimeError('candidate launch binding differs')
  else:launch.write_text(json.dumps(value,indent=2)+'\n')
  command=['sudo','systemd-run','--collect','--unit=deadsync-lua-pass4-candidate',
   '--property=User=parity','--property=Group=parity','--property=MemoryMax='+('12G' if request.get('build_worker') else '28G'),'--property=MemorySwapMax=0',
   '--property=OOMPolicy=kill','--property=RuntimeMaxSec=14400','--property=StandardOutput=append:'+str(directory/'launch.log'),
   '--property=StandardError=append:'+str(directory/'launch.log'),'python3',str(directory/'candidate_runner.py'),'--guest-build',identifier]
  subprocess.run(command,check=True,capture_output=True)
  print(json.dumps({'launched':True,'candidate':identifier,'state':str(directory/'state.json')}))
'''


def remote_action(request):
    if not request.get('build_worker'):
        raise ValueError('builder1500 is retired and its former IP belongs to a capture worker; --build-worker is required')
    import remote
    host = r'''
import ipaddress,json,pathlib,subprocess
work=pathlib.Path('/root/deadsync-lua-20261119')
if request.get('build_worker'):
 builder=json.loads((work/'build-worker.json').read_text())
 tags=builder['tags'] if isinstance(builder['tags'],list) else builder['tags'].split(';')
 assert builder['vmid']==1516 and builder['name']=='deadsync-lua-20261119-build'
 assert tags==['deadsync-lua-20261119'] and builder['cpus']==8 and builder['memory_mib']==16384
 assert builder['template_vmid']==1500 and builder.get('verified_at') and builder.get('host_key')
 assert ipaddress.ip_address(builder['ip']) in ipaddress.ip_network('192.168.1.0/24')
 known_hosts=work/'build-worker-known-hosts'
else:raise RuntimeError('the original builder1500 transport is retired')
ssh=['ssh','-i','/root/deadsync-pass3-20261116/transfer-key','-o','BatchMode=yes','-o','ConnectTimeout=10',
 '-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(known_hosts),'parity@'+builder['ip'],'python3','-']
result=subprocess.run(ssh,input='request='+repr(request)+'\n'+guest_source,text=True,capture_output=True,timeout=45)
if result.returncode:raise RuntimeError(result.stderr[-6000:]+'\n'+result.stdout[-1000:])
print(result.stdout,end='')
'''
    result = remote.run('request=' + repr(request) + '\nguest_source=' + repr(GUEST_TRANSPORT) + '\n' + host,
                        capture_output=True, timeout=60)
    print(result.stdout, end='')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--freeze', action='store_true')
    modes.add_argument('--deploy', action='store_true')
    modes.add_argument('--status', action='store_true')
    modes.add_argument('--guest-build', help=argparse.SUPPRESS)
    parser.add_argument('--candidate')
    parser.add_argument('--base-revision', help='Explicit proved guest base for a cumulative diff after local commits; must remain ' + BASE)
    parser.add_argument('--parent-candidate', help='Exact proved/applied parent candidate for a verified source transition')
    parser.add_argument('--fixtures-revision', help='Exact clean committed fixture target; materialize only the proved support subset plus committed changes')
    parser.add_argument('--fixture-requirements', help='Explicit revision/blob/hash-bound JSON support requirements, included in the frozen fixture overlay')
    parser.add_argument('--build-worker', action='store_true', help='Use only the verified task build-worker1516 receipt and its pinned SSH host key')
    parser.add_argument('--expected-build-proof-sha256')
    parser.add_argument('--test', action='append', default=[], help='Focused semantic parity test name/filter')
    parser.add_argument('--test-target', default='song_lua_itgmania_semantic_parity')
    parser.add_argument('--unit-test', action='append', default=[], help='All PACKAGE library tests, or focused PACKAGE:FILTER')
    parser.add_argument('--integration-test', action='append', default=[], help='All [PACKAGE/]TARGET integration tests, or [PACKAGE/]TARGET:FILTER')
    parser.add_argument('--integration-features', help='Explicit features for the --integration-test gates only')
    parser.add_argument('--jobs', type=int, default=6)
    args = parser.parse_args()
    if not 1 <= args.jobs <= 8: raise ValueError('build parallel jobs must be between 1 and 8')
    identifier = args.guest_build or args.candidate
    if identifier and not re.fullmatch('[0-9a-f]{64}', identifier): raise ValueError('candidate ID must be a frozen SHA256')
    if args.parent_candidate and not re.fullmatch('[0-9a-f]{64}', args.parent_candidate): raise ValueError('parent candidate ID must be a frozen SHA256')
    if args.base_revision and not re.fullmatch('[0-9a-f]{40}', args.base_revision): raise ValueError('base revision must be an exact Git commit')
    if args.fixtures_revision and not re.fullmatch('[0-9a-f]{40}', args.fixtures_revision): raise ValueError('fixture revision must be an exact Git commit')
    if args.guest_build:
        guest_build(args.guest_build)
    elif args.freeze:
        freeze(args)
    else:
        request = {'action': 'deploy' if args.deploy else 'status', 'candidate': args.candidate,
                   'parent_candidate': args.parent_candidate, 'build_worker': args.build_worker}
        if args.deploy:
            if not identifier or not re.fullmatch('[0-9a-f]{64}', args.expected_build_proof_sha256 or ''):
                raise ValueError('deploy requires exact --candidate and --expected-build-proof-sha256')
            directory = pathlib.Path(__file__).resolve().parent / 'candidates' / identifier
            manifest = load(directory / 'manifest.json')
            if manifest['id'] != identifier or sha(directory / 'candidate_runner.py') != manifest['contract']['helper_sha256']:
                raise ValueError('local frozen helper/manifest differs')
            if manifest['contract'].get('parent_candidate') != args.parent_candidate:
                raise ValueError('--parent-candidate must match the frozen candidate contract')
            request['expected_build_proof_sha256'] = args.expected_build_proof_sha256
            request['files'] = {name: base64.b64encode((directory/name).read_bytes()).decode()
                                for name in frozen_file_names(manifest['contract'])}
        remote_action(request)


if __name__ == '__main__':
    main()
