"""Inspect the exact unexecuted two-worker role proposal; write only its handoff."""
import gzip, hashlib, json
from pathlib import Path
HERE = Path(__file__).resolve().parent
TASK = HERE.parent.parent
def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()
def read(path): return json.loads(Path(path).read_bytes())
def require(path, expected):
    if sha(path) != expected: raise ValueError("Exact retained input changed: " + str(path))
    return read(path)
plan_path = HERE / "plan.json.gz"
if sha(plan_path) != "93cfc8b5b22573b7b1ba078812e38083e5f86fda4b27934c27f0550544ffe8d5": raise ValueError("Role plan changed")
plan = json.loads(gzip.decompress(plan_path.read_bytes()))
selected = require(HERE.parent / "selected-attempts.json", "440812f176e792d687d5d522a8ca25ca2eab80dbef6ac9f5dc89f485c00773fe")
authority_receipt_path = HERE.parent / "publication-receipt-20261119T055515.664801Z.json"
publication = require(authority_receipt_path, "953e968aea648452bc5ab8e8f9bc2472853aeeeaf51c901c962d84f4a29b63ce")
if publication.get("published") is not True or publication["host_result"]["sha256"] != "0627ea2ef5b79d0aba3b5f7eb8d8ad8b2d9811d3f76d91efaadee7ab600ef4d7": raise ValueError("Authority publication differs")
if plan["executed"] is not False or plan["final_candidate_bound"] is not False or [row["vmid"] for row in plan["roles"]] != [1503, 1505]: raise ValueError("Role scope differs")
expected = {row["id"]: row for row in selected}
if len(expected) != 54 or len(selected) != 54: raise ValueError("Selection count differs")
seen = set(); roles = []
for row in plan["roles"]:
    vmid = row["vmid"]
    entries = require(HERE / ("vm-" + str(vmid) + "-retry-attempts.json"), row["attempts_sha256"])
    jobs = require(HERE / ("vm-" + str(vmid) + "-retry-jobs.json"), row["jobs_sha256"])
    if jobs != [entry["retry_job"] for entry in entries] or len(entries) != 27: raise ValueError("Role jobs differ")
    for entry in entries:
        key = entry["id"]
        if key in seen or key not in expected or entry["retry_vmid"] != vmid or entry["archive_import"] != "new-native-capture": raise ValueError("Duplicate or altered role assignment")
        if {name:value for name,value in entry.items() if name not in ("retry_vmid","archive_import")} != expected[key]: raise ValueError("Original selected attempt changed")
        if entry["operation"] != "capture-archive-replay" or entry["retry_job"]["stage_memory"] != "12G": raise ValueError("Retry profile changed")
        seen.add(key)
    if sha(HERE / ("vm-" + str(vmid) + "-before.conf")) != row["original_config_sha256"]: raise ValueError("Original config changed")
    if sha(HERE / ("vm-" + str(vmid) + "-original-jobs.json")) != row["original_assigned_jobs_sha256"]: raise ValueError("Original queue changed")
    roles.append({key:row[key] for key in ("vmid","retry_cases","native_capture_retries","replay_only_retries","original_config_sha256","original_assigned_jobs_sha256","jobs_sha256","attempts_sha256","expected_config_field_changes")})
if seen != set(expected): raise ValueError("Role union does not cover the exact selected54")
memory = plan["memory"]
if memory["guest_memory_mib"] != 16384 or memory["stage_memory_gib"] != 12 or memory["stage_swap_bytes"] != 0 or memory["unassigned_host_bytes_after"] < memory["host_reserve_bytes"]: raise ValueError("Memory proposal differs or reserve fails")
result = {"schema_version":1,"planning_only":True,"lifecycle_executed":False,"role_plan":{"path":str(plan_path),"sha256":sha(plan_path)},
    "source_retry_plan_sha256":plan["retry_plan_sha256"],"selected_attempts_sha256":sha(HERE.parent/"selected-attempts.json"),
    "assignment_verified":{"exact_unique_cases":54,"native_capture_retries":54,"replay_only_retries":0,"source_rows_preserved":True,"original_configs_and_queues_preserved":True},
    "roles":roles,"resource_observed_at":plan["observed"]["observed_at"],"memory":memory,
    "supplement_authority_publication":{"receipt_path":str(authority_receipt_path),"receipt_sha256":sha(authority_receipt_path),"receipt_read_and_hashed":True,"host_result":publication["host_result"],"original_proposal_pending_bytes_preserved":True,"independent_host_reread_performed":False},
    "final_candidate_bound":False,"accepted_role_planner_sha256":sha(TASK/"plan_retry_roles.py"),
    "required_before_role_freeze":["Completed B installation on all15 workers; exact rollout bundle/proofs.","1503 and1505 completed drain receipts, original assignments and idle native stages.","Separately verified streaming profile transport installed on1503/1505.","Builder1516 controls inactive, artifacts/proofs and journals preserved before any shutdown.","Fresh configured/available memory and disk checks by accepted role lifecycle helper."],
    "scope":"Read-only host/guest planning plus local exact partition verification. No role freeze, install, queue change, guest shutdown, memory change or retry has been invoked by this proposal."}
out = HERE / "read-only-role-handoff.json"
with out.open("xb") as stream: stream.write((json.dumps(result,indent=2,ensure_ascii=False)+"\n").encode())
print(json.dumps({"handoff":str(out),"sha256":sha(out),"cases":54,"vmids":[1503,1505],"executed":False}))
