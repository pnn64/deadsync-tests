#!/usr/bin/env python3
"""Create a local, planning-only capture selection from a complete fleet snapshot.

This does not select OOMs, run the retry planner, contact a guest, or update any
receipt. The original gzip is retained verbatim. Only replay_result entries are
removed from the derived document; all other source data and ordering survive.
Multiple capture attempts for one job are refused because the unchanged planner
does not determine whether an older failure was superseded by a newer capture.
"""
from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re


TASK = Path(__file__).resolve().parent
VMIDS = list(range(1501, 1516))
ROOT = "/opt/song-lua-audit/pass4"
POLICY = "capture-only-resource-retry-selection-v1"
MARKER = "planning_projection"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def check(condition, message):
    if not condition:
        raise ValueError(message)


def valid_sha(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            check(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result

    def constant(value):
        raise ValueError("non-finite JSON number: " + value)

    value = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                       parse_constant=constant)
    canonical(value)  # Reject numeric overflow to infinity as well.
    return value


def indexed_rows(rows, label):
    check(isinstance(rows, list), label + " is not an array")
    result = {}
    for row in rows:
        check(isinstance(row, dict) and isinstance(row.get("id"), str)
              and row["id"], label + " has an invalid job identity")
        check(row["id"] not in result, label + " has a duplicate job identity")
        result[row["id"]] = row
    return result


def validate_source(source):
    check(isinstance(source, dict), "source is not a collection object")
    check(MARKER not in source, "source is already a planning projection")
    check(type(source.get("schema_version")) is int and source["schema_version"] == 2,
          "source is not the full fleet collector schema")
    check(source.get("mode") == "full" and source.get("expected_vmids") == VMIDS,
          "source is not a full collection of the exact 15-worker fleet")
    check(source.get("host") == "192.168.1.79" and source.get("errors") == [],
          "source host differs or collection reports host errors")
    check(source.get("started_at") and source.get("finished_at"),
          "source collection has no completed time interval")
    check(valid_sha(source.get("fleet_sha256")), "source lacks a fleet file hash")
    fleet = source.get("fleet")
    check(isinstance(fleet, list) and len(fleet) == len(VMIDS)
          and all(isinstance(row, dict) and type(row.get("vmid")) is int for row in fleet),
          "source fleet declaration is incomplete")
    check(sorted(row["vmid"] for row in fleet) == VMIDS,
          "source fleet declaration has missing or duplicate VM IDs")
    fleet_by_id = {row["vmid"]: row for row in fleet}
    host_jobs = source.get("host_all_jobs", {})
    check(host_jobs.get("present") is True and host_jobs.get("read") is True
          and valid_sha(host_jobs.get("sha256")), "source lacks the full host job assignment")
    global_jobs = indexed_rows(host_jobs.get("records"), "host jobs")
    check(bool(global_jobs), "source host job assignment is empty")
    guests = source.get("guests")
    check(isinstance(guests, list) and len(guests) == len(VMIDS)
          and all(isinstance(row, dict) and type(row.get("vmid")) is int for row in guests),
          "source guest collection is incomplete")
    check(sorted(row["vmid"] for row in guests) == VMIDS,
          "source guest collection has missing or duplicate VM IDs")
    assigned = {}
    capture_ids = set()
    counts = collections.Counter()
    for guest in guests:
        vmid = guest["vmid"]
        check(guest.get("connected") is True and type(guest.get("ssh_exit")) is int
              and guest["ssh_exit"] == 0 and not guest.get("error"),
              f"guest {vmid} transport collection is incomplete")
        check(guest.get("ip") == fleet_by_id[vmid].get("ip")
              and isinstance(guest.get("ip"), str) and guest["ip"],
              f"guest {vmid} address differs from the collected fleet")
        payload = guest.get("payload", {})
        check(payload.get("schema_version") == 1 and payload.get("mode") == "full"
              and payload.get("root") == ROOT and payload.get("read_complete") is True
              and payload.get("errors") == [] and payload.get("finished_at"),
              f"guest {vmid} file collection is incomplete")
        check(not payload.get("runtime_error")
              and not payload.get("runtime", {}).get("systemd_query_error"),
              f"guest {vmid} runtime collection reported an error")
        assignments = payload.get("assignments", {})
        for name in ("discovery", "jobs"):
            item = assignments.get(name, {})
            check(item.get("present") is True and item.get("read") is True
                  and valid_sha(item.get("sha256")), f"guest {vmid} lacks {name} assignments")
            rows = indexed_rows(item.get("records"), f"guest {vmid} {name}")
            check(type(item.get("count")) is int and item["count"] == len(rows),
                  f"guest {vmid} {name} assignment count differs")
            if name == "jobs":
                for identifier, row in rows.items():
                    check(identifier not in assigned, "job is assigned to multiple workers")
                    check(global_jobs.get(identifier) == row,
                          "guest job assignment differs from the host assignment")
                    assigned[identifier] = vmid
        files = payload.get("files")
        check(isinstance(files, list), f"guest {vmid} file collection is missing")
        paths = set()
        for entry in files:
            check(isinstance(entry, dict) and isinstance(entry.get("kind"), str)
                  and isinstance(entry.get("path"), str), "malformed collected file entry")
            path = PurePosixPath(entry["path"])
            check(entry["path"] and not path.is_absolute() and ".." not in path.parts
                  and path.as_posix() == entry["path"] and "\\" not in entry["path"],
                  "collected file path is not a canonical guest-relative path")
            check(entry["path"] not in paths, "duplicate collected file path")
            paths.add(entry["path"])
            check(valid_sha(entry.get("sha256")) and type(entry.get("bytes")) is int
                  and entry["bytes"] >= 0 and "data" in entry,
                  "collected file lacks its receipt identity or data")
            counts[entry["kind"]] += 1
            if entry["kind"] in {"capture_result", "replay_result"}:
                data = entry["data"]
                check(isinstance(data, dict) and isinstance(data.get("id"), str)
                      and data["id"] in global_jobs and isinstance(data.get("status"), str),
                      "capture/replay receipt lacks its assigned identity or status")
                check(assigned.get(data["id"]) == vmid,
                      "capture/replay receipt belongs to another guest assignment")
                if entry["kind"] == "capture_result":
                    check(data["id"] not in capture_ids,
                          "multiple capture attempts for one job require explicit review; no latest attempt is inferred")
                    capture_ids.add(data["id"])
    check(set(assigned) == set(global_jobs), "full guest assignments do not cover the host job set")
    check(counts["capture_result"] > 0, "source has no capture entries")
    return {"guest_count": len(guests), "assigned_jobs": len(assigned),
            "source_entry_counts": dict(sorted(counts.items())),
            "unique_capture_jobs": len(capture_ids)}


def filtered_source(source):
    return {**source, "guests": [
        {**guest, "payload": {**guest["payload"], "files": [
            entry for entry in guest["payload"]["files"] if entry["kind"] != "replay_result"]}}
        for guest in source["guests"]]}


def removed_entries(source):
    rows = []
    for guest_index, guest in enumerate(source["guests"]):
        for file_index, entry in enumerate(guest["payload"]["files"]):
            if entry["kind"] != "replay_result":
                continue
            data = entry["data"]
            rows.append({"guest_index": guest_index, "file_index": file_index,
                         "vmid": guest["vmid"], "path": entry["path"], "kind": entry["kind"],
                         "id": data["id"], "status": data["status"],
                         "runner_sha256": data.get("pins", {}).get("runner_sha256"),
                         "original_receipt_sha256": entry["sha256"], "original_receipt_bytes": entry["bytes"],
                         "entry_canonical_sha256": sha(canonical(entry)),
                         "data_canonical_sha256": sha(canonical(data))})
    return rows


def capture_fingerprint(source):
    return sha(canonical([[guest["vmid"], entry] for guest in source["guests"]
                          for entry in guest["payload"]["files"] if entry["kind"] == "capture_result"]))


def write_new(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    check(path.read_bytes() == raw, "written artifact differs: " + path.name)


def project(snapshot, expected_sha256, out):
    check(valid_sha(expected_sha256), "an exact original compressed SHA256 is required")
    snapshot = Path(snapshot).resolve(strict=True)
    check(snapshot.is_file() and snapshot.is_relative_to(TASK), "source must be a local task artifact")
    raw = snapshot.read_bytes()
    check(sha(raw) == expected_sha256, "original snapshot SHA256 differs")
    decoded = gzip.decompress(raw)
    source = strict_json(decoded)
    summary = validate_source(source)
    removed = removed_entries(source)
    removed_raw = canonical({"schema_version": 1, "planning_only": True,
                             "source_snapshot_sha256": expected_sha256, "entries": removed}) + b"\n"
    helper_raw = Path(__file__).read_bytes()
    marker = {"policy": POLICY, "planning_only": True, "is_new_collection": False,
              "source_snapshot_sha256": expected_sha256,
              "source_decoded_sha256": sha(decoded), "helper_sha256": sha(helper_raw),
              "removed_replay_entries_sha256": sha(removed_raw),
              "removed_replay_entries": len(removed),
              "scope": "Retry selection input only; not a coverage report or current runner verdict."}
    projected = {**filtered_source(source), MARKER: marker}
    projected_raw = gzip.compress(canonical(projected), compresslevel=6, mtime=0)
    observed = strict_json(gzip.decompress(projected_raw))
    check(observed.pop(MARKER) == marker, "planning marker did not round-trip")
    check(canonical(observed) == canonical(filtered_source(source)),
          "projection changed data outside the removed replay_result entries")
    check(capture_fingerprint(observed) == capture_fingerprint(source),
          "projection changed a retained capture entry")
    out = Path(out)
    out = out.parent.resolve(strict=True) / out.name
    check(out.is_relative_to(TASK) and out != TASK and not out.exists() and not out.is_symlink(),
          "output must be a new directory within the task; overwrite is forbidden")
    out.mkdir()  # Exclusive creation; partial failed runs are never reused.
    artifacts = {"source-full.json.gz": raw, "removed-replay-entries.json": removed_raw,
                 "capture-only-planning.json.gz": projected_raw}
    for name, data in artifacts.items():
        write_new(out / name, data)
    check(snapshot.read_bytes() == raw and Path(__file__).read_bytes() == helper_raw,
          "original snapshot or projection helper changed during preparation")
    manifest = {"schema_version": 1, "policy": POLICY, "planning_only": True,
                "source_path": str(snapshot), "source_snapshot_sha256": expected_sha256,
                "source_decoded_sha256": sha(decoded), "helper_sha256": sha(helper_raw),
                "projected_snapshot_sha256": sha(projected_raw),
                "preserved_capture_data_sha256": capture_fingerprint(source),
                "removed_replay_entries": len(removed),
                "removed_statuses": dict(sorted(collections.Counter(row["status"] for row in removed).items())),
                "validation": {**summary, "all_non_replay_data_equal": True,
                               "all_capture_entries_equal": True, "source_gzip_preserved_verbatim": True,
                               "original_requested_runner_unchanged": True,
                               "collection_complete_is_not_workload_complete": True},
                "limits": ["Original receipt SHAs are preserved collected claims; downstream helpers must still verify live receipt bytes.",
                           "No OOM selection, latest-attempt inference, planner, guest action, or current-runner acceptance is performed."],
                "artifacts": [{"path": name, "bytes": len(data), "sha256": sha(data)}
                              for name, data in artifacts.items()]}
    write_new(out / "projection-manifest.json", canonical(manifest) + b"\n")
    return {"out": str(out), "manifest_sha256": sha((out / "projection-manifest.json").read_bytes()), **manifest}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = project(args.snapshot, args.source_sha256, args.out)
    print(json.dumps({key: result[key] for key in ["out", "manifest_sha256", "source_snapshot_sha256",
                                                   "projected_snapshot_sha256", "removed_replay_entries", "validation"]}, indent=2))


if __name__ == "__main__":
    main()
