"""Prepare one reviewed journal-only OOM supplement locally; never publish or retry."""
import argparse
import base64
import copy
import datetime
import gzip
import hashlib
import json
import pathlib
import re

HERE = pathlib.Path(__file__).resolve().parent
BASE_PLAN_SHA = "b4e3ef6948f0db99df79b679d6eabedabaafad98d972d7abbacb699e0d8115fe"
FULL_SNAPSHOT_SHA = "d1cfd6e88b6ce95e9fc12c378c2d09651efd4d4c5cfdb9d336bcdd2e62d8d915"
PROJECTION_SHA = "fcab8412bd2640ff4a7cdaa11dbe56f69a2a033946a8225398340431002665a4"
EVIDENCE_SHA = "4ef3a2288d5f8ed1255960459de13a4d8121af884d859aa8100ae4653efb246f"
RESULT_SHA = "d21a1ba39e9d4aec9d1af3a96b5dfc8b6bd8c02a6dd1cd2c5abe43bff37a9d32"
JOB = "33094275d983528c-c0003"
ATTEMPT = "capture-bf480552aa7b55ac7fd8-001"
UNIT = "song-lua-pass4-capture-41f6bb473b71babb0511"
RELATIVE_RESULT = f"results/{JOB}/{ATTEMPT}/capture-result.json"
HOST = pathlib.PurePosixPath("/root/deadsync-lua-20261119")
GUEST = pathlib.PurePosixPath("/opt/song-lua-audit/pass4")


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def decode(data):
    def invalid(value):
        raise ValueError("nonfinite JSON value: " + value)
    return json.loads(data, object_pairs_hook=pairs, parse_constant=invalid)


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def record_bytes(record):
    raw = base64.b64decode(record["base64"], validate=True)
    need(len(raw) == record["bytes"] and sha(raw) == record["sha256"], "record bytes/hash differ")
    return raw


def query_bytes(query):
    need(query["exit"] == 0, "journal query did not succeed")
    raw = base64.b64decode(query["stdout_base64"], validate=True)
    need(len(raw) == query["stdout_bytes"] and sha(raw) == query["stdout_sha256"], "journal bytes/hash differ")
    return raw


def timestamps(row):
    return int(row["__REALTIME_TIMESTAMP"]) / 1e6


def validate_facts(entry, result, spec, launch, collected, service, kernel):
    need(entry["kind"] == "capture_result" and entry["path"] == RELATIVE_RESULT and entry["sha256"] == RESULT_SHA,
         "wrong original snapshot entry")
    need(result == entry["data"], "raw result differs from snapshot data")
    need(result["id"] == JOB and result["worker"] == "1515", "wrong original job/worker")
    need(result["status"] == "capture_validation_or_infrastructure_error" and result["stages"] == {},
         "original status/stages changed")
    need(collected["vmid"] == 1515 and collected["job"] == JOB and collected["attempt"] == ATTEMPT
         and collected["unit"] == UNIT + ".service", "collected attempt identity differs")
    need(collected["stage_receipt_exists"] is False and collected["result_sha256_after"] == RESULT_SHA,
         "missing-receipt/result stability evidence differs")
    job = result["job"]
    need(job["id"] == JOB and job["source_simfile"] == "mawaru6/mawaru6.sm" and job["chart_index"] == 3,
         "authored selector differs")
    native_job = {key: value for key, value in job.items() if key not in {"replay_timeout", "stage_memory", "archive_timeout", "pack_timeout"}}
    need(native_job == result["binding"]["job"] and spec["binding"] == result["binding"], "native binding differs")
    need(result["binding"]["headless"] is True and result["binding"]["drawable_samples"] is True, "native profile differs")
    need(job["stage_memory"] == "6G" and spec["memory_limit"] == "6G", "original memory cap differs")
    need(spec["unit"] == UNIT and spec["fingerprint"].startswith(UNIT.rsplit("-", 1)[1]), "spec unit/fingerprint differs")
    need(spec["timeout_seconds"] == job["capture_timeout"] + 90 == 1290, "original timeouts differ")
    command = launch["command"]
    for expected in ("--unit=" + UNIT, "--property=MemoryMax=6G", "--property=MemorySwapMax=0",
                     "--property=OOMPolicy=kill", "--property=RuntimeMaxSec=1290"):
        need(command.count(expected) == 1, "original launch limit/unit differs")
    need(command[-len(spec["command"]):] == spec["command"], "spec/launch native command differs")
    stop = '--property=ExecStopPost="/usr/bin/python3" "/opt/song-lua-audit/pass4/worker.py" "__stage_finished" "' + str(GUEST / RELATIVE_RESULT).removesuffix("capture-result.json") + 'stages/capture/spec.json"'
    need(command.count(stop) == 1 and launch["exit"] != 0, "stop hook/launch outcome differs")
    start = datetime.datetime.fromisoformat(result["started_at"]).timestamp()
    finish = datetime.datetime.fromisoformat(result["finished_at"]).timestamp()
    unit = UNIT + ".service"
    failures = [row for row in service if row.get("UNIT") == unit and row.get("UNIT_RESULT") == "oom-kill"
                and row.get("MESSAGE") == unit + ": Failed with result 'oom-kill'."]
    need(len(failures) == 1, "exact systemd OOM result absent or ambiguous")
    failure = failures[0]
    need(failure.get("_PID") == "1" and failure.get("_COMM") == "systemd", "OOM result is not systemd authority")
    need(failure.get("_HOSTNAME") == "deadsync-lua-20261119-15", "journal belongs to wrong guest")
    need(start <= timestamps(failure) <= finish + 1, "OOM result lies outside original attempt")
    need(timestamps(failure) - start < spec["timeout_seconds"], "failure does not precede original timeout")
    messages = {str(row.get("MESSAGE")) for row in service}
    need(unit + ": Main process exited, code=killed, status=9/KILL" in messages, "main SIGKILL evidence absent")
    need(unit + ": Control process exited, code=killed, status=9/KILL" in messages, "control SIGKILL evidence absent")
    need(any(text.startswith(unit + ": Consumed ") and "6.0G memory peak, 0B memory swap peak." in text for text in messages),
         "historical six-GiB/no-swap peak absent")
    cgroup = "/system.slice/" + unit
    oom = [row for row in kernel if row.get("_TRANSPORT") == "kernel"
           and "oom-kill:constraint=CONSTRAINT_MEMCG," in str(row.get("MESSAGE"))
           and "oom_memcg=" + cgroup + "," in str(row.get("MESSAGE"))
           and "task_memcg=" + cgroup + "," in str(row.get("MESSAGE"))]
    need(len(oom) == 1, "exact kernel memory-cgroup OOM absent or ambiguous")
    event = oom[0]
    need(event.get("_BOOT_ID") == failure.get("_BOOT_ID") and event.get("_MACHINE_ID") == failure.get("_MACHINE_ID")
         and event.get("_HOSTNAME") == failure.get("_HOSTNAME"), "kernel/service identity mismatch")
    need(start <= timestamps(event) <= timestamps(failure) and timestamps(failure) - timestamps(event) <= 2,
         "kernel OOM is not contemporaneous with service failure")
    match = re.search(r",task=ITGmania-harnes,pid=(\d+),uid=1000$", event["MESSAGE"])
    need(match is not None, "kernel OOM is not the original native process")
    same_boot = [row for row in kernel if row.get("_BOOT_ID") == event["_BOOT_ID"]
                 and row.get("_MACHINE_ID") == event["_MACHINE_ID"] and abs(timestamps(row) - timestamps(event)) <= 2]
    need(any(str(row.get("MESSAGE", "")).startswith("memory: usage 6291456kB, limit 6291456kB,") for row in same_boot),
         "kernel does not establish the original six-GiB limit")
    killed = "Memory cgroup out of memory: Killed process " + match[1] + " (ITGmania-harnes) "
    need(any(str(row.get("MESSAGE", "")).startswith(killed) for row in same_boot), "native PID kill evidence absent")
    return {"service_failure_cursor": failure["__CURSOR"], "kernel_oom_cursor": event["__CURSOR"],
            "boot_id": event["_BOOT_ID"], "machine_id": event["_MACHINE_ID"], "native_pid": int(match[1]),
            "source_limit_bytes": 6 * 1024**3, "result_status_rewritten": False}


def publish_script(raw, digest):
    # This artifact is prepared only. The local preparer never runs it or imports a transport.
    return ("import base64,hashlib,json,os,pathlib\n"
            "raw=base64.b64decode(" + repr(base64.b64encode(raw).decode()) + ",validate=True)\n"
            "expected=" + repr(digest) + "\n"
            "assert hashlib.sha256(raw).hexdigest()==expected\n"
            "root=pathlib.Path('/root/deadsync-lua-20261119')\n"
            "assert root.is_dir() and root.resolve()==root\n"
            "directory=root/'supplemental-journal-authorities'\n"
            "assert directory.resolve()==directory\n"
            "directory.mkdir(exist_ok=True)\n"
            "assert directory.is_dir() and directory.resolve()==directory\n"
            "path=directory/(expected+'.json')\n"
            "assert path.resolve()==path and not path.is_symlink()\n"
            "if path.exists():\n"
            "    assert path.is_file() and path.read_bytes()==raw\n"
            "    outcome='already-present-identical'\n"
            "else:\n"
            "    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o444)\n"
            "    with os.fdopen(fd,'wb') as stream:\n"
            "        stream.write(raw);stream.flush();os.fsync(stream.fileno())\n"
            "    directory_fd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY)\n"
            "    try:os.fsync(directory_fd)\n"
            "    finally:os.close(directory_fd)\n"
            "    outcome='created'\n"
            "assert path.read_bytes()==raw\n"
            "print(json.dumps({'path':str(path),'sha256':expected,'bytes':len(raw),'publication':outcome,'guest_action':False}))\n").encode()


def prepare(base_path, evidence_path, out):
    need(not out.exists(), "output already exists; preserve the prior proposal")
    need(out.resolve().is_relative_to(HERE) and out.resolve() != HERE, "output must be a new task directory")
    base_raw = base_path.read_bytes(); need(sha(base_raw) == BASE_PLAN_SHA, "base plan changed")
    plan = decode(base_raw); need(plan["executed"] is False, "base plan was executed")
    base_files = {"plan.json": base_raw}
    for name, key in (("selected-attempts.json", "selected_attempts_sha256"), ("capture-jobs.json", "capture_jobs_sha256"),
                      ("replay-jobs.json", "replay_jobs_sha256"), ("resources.json", "resource_observation_sha256"),
                      ("missing-stage-receipts.json", "journal_sha256")):
        data = (base_path.parent / name).read_bytes(); need(sha(data) == plan[key], "base companion changed: " + name)
        base_files[name] = data
    selected = decode(base_files["selected-attempts.json"])
    need(len(selected) == 53 and len({row["id"] for row in selected}) == 53 and all(row["id"] != JOB for row in selected),
         "base selection count/uniqueness differs or target already included")
    need(decode(base_files["capture-jobs.json"]) == [row["retry_job"] for row in selected] and decode(base_files["replay-jobs.json"]) == [],
         "base jobs do not match capture-only selection")
    need(plan["counts"] == {"capture_stage_receipt_oom":51,"capture_journal_only_oom":2,"replay_only_oom":0,"all_jobs":53},
         "base counts differ")
    projection_raw = pathlib.Path(plan["source_snapshot"]).read_bytes()
    need(sha(projection_raw) == plan["source_snapshot_sha256"] == PROJECTION_SHA, "base projection changed")
    projection = decode(gzip.decompress(projection_raw))
    full_raw = (HERE / "collected/20261119T054020.048384Z-full.json.gz").read_bytes()
    need(sha(full_raw) == FULL_SNAPSHOT_SHA, "original full collection changed")
    full = decode(gzip.decompress(full_raw))
    def entry_from(snapshot):
        need(snapshot["mode"] == "full", "source is not a full collection")
        guests = [row for row in snapshot["guests"] if row["vmid"] == 1515]
        need(len(guests) == 1 and guests[0]["connected"], "original guest missing")
        entries = [row for row in guests[0]["payload"]["files"] if row["kind"] == "capture_result" and row["data"].get("id") == JOB]
        need(len(entries) == 1, "original attempt missing or duplicated")
        return entries[0]
    entry = entry_from(full); need(entry == entry_from(projection), "projection changed the original capture entry")
    compressed = (evidence_path / "remote-evidence.json.gz").read_bytes()
    need(sha(compressed) == EVIDENCE_SHA, "collected primary evidence changed")
    authority_raw = gzip.decompress(compressed); authority = decode(authority_raw)
    collected = authority["guest"]
    need(authority["worker_identity"]["vmid"] == 1515 and authority["worker_identity"]["ip"] == "192.168.1.40", "host fleet identity differs")
    result_raw = record_bytes(collected["original_result"]); need(sha(result_raw) == RESULT_SHA, "original result bytes differ")
    stage_files = {row["name"]: row for row in collected["stage_files"]}
    need(len(stage_files) == len(collected["stage_files"]), "duplicate stage file")
    spec_raw = record_bytes(stage_files["stages/capture/spec.json"])
    launch_raw = record_bytes(stage_files["stages/capture/launch.json"])
    service_raw = query_bytes(collected["queries"]["service_journal"])
    kernel_raw = query_bytes(collected["queries"]["kernel_journal_0"])
    service = [decode(line) for line in service_raw.splitlines() if line]
    kernel = [decode(line) for line in kernel_raw.splitlines() if line]
    result, spec, launch = decode(result_raw), decode(spec_raw), decode(launch_raw)
    proof = validate_facts(entry, result, spec, launch, collected, service, kernel)
    authority_sha = sha(authority_raw)
    host_path = str(HOST / "supplemental-journal-authorities" / (authority_sha + ".json"))
    job = result["job"]; retry_job = {**job, "stage_memory":"12G"}
    need({key for key in set(job) | set(retry_job) if job.get(key) != retry_job.get(key)} == {"stage_memory"}, "retry changes exceed memory")
    supplemental = {"vmid":1515,"id":JOB,"operation":"capture-archive-replay","source_simfile":job["source_simfile"],
        "chart_index":job["chart_index"],"original_status":result["status"],"failure_path":entry["path"],"failure_sha256":RESULT_SHA,
        "capture_result_path":entry["path"],"capture_result_sha256":RESULT_SHA,"original_capture_binding":result["binding"],
        "original_job":job,"retry_job":retry_job,"retained_candidate":None,"native_frames":None,"original_capture_result":result,
        "oom_authority":{"kind":"separate-preserved-systemd-journal","path":host_path,"sha256":authority_sha,"unit":UNIT,
                         "original_status_unchanged":True}}
    derived = sorted([*selected, supplemental], key=lambda row:(row["operation"] != "replay-only",row["vmid"],row["id"]))
    need([row for row in derived if row["id"] != JOB] == selected, "base selected rows changed")
    files = {"selected-attempts.json":encode(derived),"capture-jobs.json":encode([row["retry_job"] for row in derived]),
             "replay-jobs.json":base_files["replay-jobs.json"],"resources.json":base_files["resources.json"],
             "missing-stage-receipts.json":base_files["missing-stage-receipts.json"],
             "supplemental-journal-authority.json":authority_raw,"original-result.json":result_raw,
             "publish-host-authority.py":publish_script(authority_raw,authority_sha)}
    updated = copy.deepcopy(plan)
    updated["counts"] = {"capture_stage_receipt_oom":51,"capture_journal_only_oom":3,"replay_only_oom":0,"all_jobs":54}
    for name,key in (("selected-attempts.json","selected_attempts_sha256"),("capture-jobs.json","capture_jobs_sha256"),("replay-jobs.json","replay_jobs_sha256")):
        updated[key] = sha(files[name])
    updated["selection_scope"] = "Original immutable 53-case capture-only plan plus one exact separately journal/kernel-proved missing-receipt attempt; later failures require another reviewed plan."
    updated["supplement_provenance"] = {"base_plan_path":str(base_path.resolve()),"base_plan_sha256":BASE_PLAN_SHA,
        "base_selected_attempts_sha256":plan["selected_attempts_sha256"],"base_rows_unchanged":53,
        "original_full_snapshot_sha256":FULL_SNAPSHOT_SHA,"source_projection_sha256":PROJECTION_SHA,
        "original_result_sha256":RESULT_SHA,"added_job":JOB,"added_attempt":ATTEMPT,
        "primary_evidence_gzip_sha256":EVIDENCE_SHA,"primary_authority_sha256":authority_sha,
        "spec_sha256":sha(spec_raw),"launch_sha256":sha(launch_raw),"service_journal_sha256":sha(service_raw),
        "kernel_journal_sha256":sha(kernel_raw),"validated_facts":proof,"host_authority_path":host_path,
        "host_authority_published":False,"legacy_journal_sha256_scope":"Unchanged original two-case authority; the third case uses its separate authority.",
        "resource_observations_inherited":True,"live_resource_revalidation_still_required":True,
        "preparer_sha256":sha(pathlib.Path(__file__).read_bytes())}
    files["plan.json"] = encode(updated)
    publication = {"executed":False,"local_authority":"supplemental-journal-authority.json","authority_bytes":len(authority_raw),
                   "authority_sha256":authority_sha,"host_path":host_path,"script":"publish-host-authority.py",
                   "script_sha256":sha(files["publish-host-authority.py"]),"requires_reviewed_root_invocation":True,
                   "invocation":["python","-X","utf8",str(HERE/"remote.py"),str(out.resolve()/"publish-host-authority.py")],
                   "scope":"Publish only an immutable content-addressed authority on the known host. No guest, VM, role, queue, capture or replay action."}
    files["publication-pending.json"] = encode(publication)
    out.mkdir(parents=True,exist_ok=False)
    (out/"base-plan").mkdir()
    for name,data in base_files.items(): (out/"base-plan"/name).write_bytes(data)
    for name,data in files.items(): (out/name).write_bytes(data)
    manifest = {"executed":False,"planning_only":True,"base_plan_sha256":BASE_PLAN_SHA,"plan_sha256":sha(files["plan.json"]),
                "counts":updated["counts"],"publication_pending":publication,"files":[{"path":name,"bytes":len(data),"sha256":sha(data)} for name,data in sorted(files.items())],
                "preserved_base_files":[{"path":"base-plan/"+name,"bytes":len(data),"sha256":sha(data)} for name,data in sorted(base_files.items())]}
    (out/"manifest.json").write_bytes(encode(manifest))
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-plan",type=pathlib.Path,default=HERE/"resource-retry-capture-plan-20261119T054020.048384Z/plan.json")
    parser.add_argument("--evidence",type=pathlib.Path,default=HERE/"missing-stage-33094275-evidence-20261119T054428.425746Z")
    parser.add_argument("--out",type=pathlib.Path,required=True)
    args = parser.parse_args()
    answer = prepare(args.base_plan,args.evidence,args.out)
    print(json.dumps({"executed":False,"planning_only":True,"out":str(args.out.resolve()),"plan_sha256":answer["plan_sha256"],"counts":answer["counts"],"publication_pending":True}))
