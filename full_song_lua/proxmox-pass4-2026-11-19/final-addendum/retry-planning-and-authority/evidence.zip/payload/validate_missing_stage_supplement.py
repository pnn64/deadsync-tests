"""Local semantic counterexamples for the single-attempt OOM supplement; no network."""
import base64
import copy
import datetime
import gzip
import hashlib
import json
import pathlib
import subprocess
import sys

sys.dont_write_bytecode = True
import prepare_missing_stage_supplement as module

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[1]
EVIDENCE = HERE / "missing-stage-33094275-evidence-20261119T054428.425746Z"
BASE = HERE / "resource-retry-capture-plan-20261119T054020.048384Z/plan.json"
PROPOSAL = HERE / "resource-retry-capture-supplement-33094275-proposal"
out = HERE / ("missing-stage-supplement-validation-" + datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ"))
out.mkdir()
results = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity():
    return {"head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT).decode().strip(),
            "status":subprocess.check_output(["git","status","--porcelain"],cwd=ROOT).decode(),
            "fixture_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT/"tests/fixtures").decode().strip(),
            "fixture_status":subprocess.check_output(["git","status","--porcelain"],cwd=ROOT/"tests/fixtures").decode(),
            "accepted_helpers":{name:sha((HERE/name).read_bytes()) for name in ("prepare_resource_retry.py","plan_retry_roles.py","resource_retry_roles.py","resource_retry_guest.py","resource_retry_coordinator.py","project_capture_retry_snapshot.py")}}


before = identity()
payload = module.decode(gzip.decompress((EVIDENCE/"remote-evidence.json.gz").read_bytes()))
collected = payload["guest"]
result = module.decode(module.record_bytes(collected["original_result"]))
stage_files = {row["name"]:row for row in collected["stage_files"]}
spec = module.decode(module.record_bytes(stage_files["stages/capture/spec.json"]))
launch = module.decode(module.record_bytes(stage_files["stages/capture/launch.json"]))
service = [module.decode(line) for line in module.query_bytes(collected["queries"]["service_journal"]).splitlines() if line]
kernel = [module.decode(line) for line in module.query_bytes(collected["queries"]["kernel_journal_0"]).splitlines() if line]
entry = module.decode((EVIDENCE/"selection.json").read_bytes())["entry"]
original = [entry,result,spec,launch,collected,service,kernel]
proof = module.validate_facts(*original)
results.append({"name":"real primary evidence establishes exact attempt OOM","passed":True,"proof":proof})


def reject(name, mutate, message, sync_result=False):
    values = copy.deepcopy(original)
    mutate(values)
    if sync_result: values[0]["data"] = copy.deepcopy(values[1])
    try:
        module.validate_facts(*values)
    except ValueError as error:
        if message not in str(error): raise AssertionError((name,"wrong refusal",str(error)))
        results.append({"name":name,"passed":True,"refusal":str(error)})
    else:
        raise AssertionError((name,"invalid evidence accepted"))


def failed_record(values):
    return next(row for row in values[5] if row.get("UNIT_RESULT") == "oom-kill")


def oom_record(values):
    return next(row for row in values[6] if str(row.get("MESSAGE","")).startswith("oom-kill:"))


reject("wrong snapshot receipt hash",lambda v:v[0].update(sha256="0"*64),"snapshot entry")
reject("wrong result worker",lambda v:v[1].update(worker="1501"),"job/worker",True)
reject("original status rewritten",lambda v:v[1].update(status="capture_resource_limit"),"status/stages",True)
reject("invented stage receipt",lambda v:v[1].update(stages={"capture":{"service_result":"oom-kill"}}),"status/stages",True)
reject("wrong collected attempt",lambda v:v[4].update(attempt="capture-other"),"attempt identity")
reject("receipt exists despite missing-receipt claim",lambda v:v[4].update(stage_receipt_exists=True),"receipt/result stability")
reject("original result changed during inspection",lambda v:v[4].update(result_sha256_after="0"*64),"receipt/result stability")
reject("wrong spec unit",lambda v:v[2].update(unit="song-lua-pass4-capture-other"),"unit/fingerprint")
reject("wrong original spec memory",lambda v:v[2].update(memory_limit="4G"),"memory cap")
reject("wrong original runtime timeout",lambda v:v[2].update(timeout_seconds=900),"timeouts")
reject("wrong native binding",lambda v:v[2]["binding"].update(drawable_samples=False),"binding")
reject("launch memory cap removed",lambda v:v[3]["command"].remove("--property=MemoryMax=6G"),"limit/unit")
reject("launch allows swap",lambda v:v[3]["command"].remove("--property=MemorySwapMax=0"),"limit/unit")
reject("stop hook missing",lambda v:v[3].update(command=[x for x in v[3]["command"] if not x.startswith("--property=ExecStopPost=")]),"stop hook")
reject("no exact service OOM result",lambda v:v[5].remove(failed_record(v)),"systemd OOM")
reject("duplicate service OOM result",lambda v:v[5].append(copy.deepcopy(failed_record(v))),"systemd OOM")
reject("service failure message assigned to another unit",lambda v:failed_record(v).update(UNIT="unrelated.service"),"systemd OOM")
reject("service failure is an ordinary process message",lambda v:failed_record(v).update(_PID="1000"),"systemd authority")
reject("journal belongs to another guest",lambda v:failed_record(v).update(_HOSTNAME="deadsync-lua-20261119-14"),"wrong guest")
reject("service failure lies after attempt",lambda v:failed_record(v).update(__REALTIME_TIMESTAMP="1795061911503707"),"outside original attempt")
reject("control-process SIGKILL absent",lambda v:v[5].__setitem__(slice(None),[row for row in v[5] if "Control process exited" not in str(row.get("MESSAGE"))]),"control SIGKILL")
reject("unrelated kernel memory cgroup",lambda v:oom_record(v).update(MESSAGE=oom_record(v)["MESSAGE"].replace(module.UNIT,"unrelated")),"kernel memory-cgroup")
reject("kernel event from another boot",lambda v:oom_record(v).update(_BOOT_ID="0"*32),"identity mismatch")
reject("kernel event from another machine",lambda v:oom_record(v).update(_MACHINE_ID="0"*32),"identity mismatch")
reject("kernel event outside service failure window",lambda v:oom_record(v).update(__REALTIME_TIMESTAMP="1795060901484745"),"contemporaneous")
reject("kernel event killed another task",lambda v:oom_record(v).update(MESSAGE=oom_record(v)["MESSAGE"].replace("task=ITGmania-harnes","task=other")),"native process")
reject("kernel six-GiB usage evidence absent",lambda v:v[6].__setitem__(slice(None),[row for row in v[6] if not str(row.get("MESSAGE","")).startswith("memory: usage ")]),"six-GiB limit")
reject("native PID kill evidence absent",lambda v:v[6].__setitem__(slice(None),[row for row in v[6] if not str(row.get("MESSAGE","")).startswith("Memory cgroup out of memory: Killed process 6037 ")]),"PID kill")

for name,body in (("duplicate JSON object rejected",'{"x":1,"x":2}'),("nonfinite JSON value rejected",'{"x":NaN}')):
    try: module.decode(body)
    except ValueError as error: results.append({"name":name,"passed":True,"refusal":str(error)})
    else: raise AssertionError(name)

fresh = out/"derived-plan"
manifest = module.prepare(BASE,EVIDENCE,fresh)
for name in ("plan.json","selected-attempts.json","capture-jobs.json","supplemental-journal-authority.json"):
    if (fresh/name).read_bytes() != (PROPOSAL/name).read_bytes(): raise AssertionError("nondeterministic proposal: "+name)
results.append({"name":"real plan derivation deterministic with unchanged 53 rows and exact 54 counts","passed":True,"plan_sha256":manifest["plan_sha256"]})
authority_raw = (fresh/"supplemental-journal-authority.json").read_bytes()
if authority_raw != gzip.decompress((EVIDENCE/"remote-evidence.json.gz").read_bytes()): raise AssertionError("primary evidence rewritten")
results.append({"name":"host authority preserves primary evidence bytes verbatim","passed":True,"sha256":sha(authority_raw)})
compile((fresh/"publish-host-authority.py").read_bytes(),"publish-host-authority.py","exec")
results.append({"name":"prepared publication script compiles without being executed","passed":True})
before_repeat = (fresh/"manifest.json").read_bytes()
try: module.prepare(BASE,EVIDENCE,fresh)
except ValueError as error: results.append({"name":"existing proposal refuses overwrite","passed":True,"refusal":str(error)})
else: raise AssertionError("overwrite accepted")
if (fresh/"manifest.json").read_bytes() != before_repeat: raise AssertionError("overwrite mutated prior output")
try: module.prepare(BASE,EVIDENCE,ROOT/"outside-target-supplement-refused")
except ValueError as error: results.append({"name":"outside-target output refused without writes","passed":True,"refusal":str(error)})
else: raise AssertionError("outside output accepted")
after = identity()
if before != after or before["status"] or before["fixture_status"]: raise AssertionError("protected source/fixtures/helpers changed")
results.append({"name":"product fixtures accepted helpers and base plan unchanged","passed":True})
if sha(BASE.read_bytes()) != module.BASE_PLAN_SHA: raise AssertionError("base plan changed")
receipt = {"passed":True,"checks":results,"check_count":len(results),"helper_sha256":sha((HERE/"prepare_missing_stage_supplement.py").read_bytes()),
           "validator_sha256":sha(pathlib.Path(__file__).read_bytes()),"before":before,"after":after,"network_or_guest_actions":False,
           "publication_executed":False,"output":str(out)}
(out/"validation.json").write_bytes(module.encode(receipt))
print(json.dumps({"path":str(out/"validation.json"),"sha256":sha((out/"validation.json").read_bytes()),"passed":True,"checks":len(results),"helper_sha256":receipt["helper_sha256"],"derived_plan_sha256":manifest["plan_sha256"]}))
