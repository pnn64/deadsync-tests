#!/usr/bin/env python3
"""Creation-only transport of the separately proved streaming capture profile.

The host invokes these functions in memory. Export writes only stdout. Install
runs in its exact visible systemd unit, under the existing orchestration locks.
No function builds, captures, replays, resumes a queue, or promotes global bins.
"""
from __future__ import annotations
import argparse
import base64
import contextlib
import ctypes
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import time
import traceback
import types

sys.dont_write_bytecode = True
ROOT = Path('/opt/song-lua-audit/pass4')
PROFILES = ROOT / 'capture-profiles'
B_ID = 'be576a51d3f4ea203bb1ef298f01b21c9ad4091d09f77cc371da08b26cb6a858'
SOURCE_ID = '795b798c0c9e4bd236bc37080d3fd4614e0300010c42ce5df6717c0e7672fa9b'
SOURCE = PROFILES / SOURCE_ID / 'source'
NATIVE = Path('/opt/song-lua-audit/harness-pass4/vendor/itgmania')
COMMIT = 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c'
NATIVE_REVISION = '663525dcb86eb570d0ef6a2e209678436660ae26'
CLI_SHA = '1780c9e517994285775fa75c98c1975c601be0f94c4ad1a376cab16bd8684e8e'
ENGINE_SHA = 'c03763cac1270c14dbe790cbb055c96ebbced269448d64e0bb705385dc9537a3'
CONTROL_SHA = '7858d16eed264e1816642d51d41d71bd26e5be35c5349ee9f4137b950baacb6f'
WORKER_SHA = '4155f85dc78eaee40189d8ee5e2a9b177be8b8ad36093b6a4706a098ec9b0e72'
INVENTORY_SHA = '839b9900d404b9c4c102a3912cab79bdbc07ef65edea7158229e70b6fe4082e4'
ATTESTATION_SHA = 'a1876857a2b47c6a3712489ec72a215afedf3dcc6469056fced2946fafb8f37b'
DEPENDENCIES = {
    'resource_retry_coordinator': '61c6e2b1e25e36d85cc38509f2fd419b4480f09630453502336ef42d935f0cd3',
    'resource_retry_guest': '6ec76ceb4cff1629ff037f1a6bcfaa2ff49150d062491adc643cb374f088f072',
    'rollout_runner': 'fc7a8dd7f1fc3f53ba937a4b7a4a3a44c4e819cf52752bdf7b7316ce4a8ae4c9',
}
MAX_FILE = 256 * 1024**2
MAX_TOTAL = 512 * 1024**2
MAX_BUNDLE = MAX_TOTAL + 8 * 1024**2
RESERVE = 20 * 1024**3


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def identity(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def require_sha(value):
    if not isinstance(value, str) or re.fullmatch('[0-9a-f]{64}', value) is None:
        raise ValueError('Expected a complete SHA256 identity')
    return value


def relative(value):
    path = PurePosixPath(value)
    if not isinstance(value, str) or not value or path.is_absolute() or '..' in path.parts or str(path) != value or '\\' in value:
        raise ValueError('Noncanonical relative member path')
    return path


def regular(path):
    path = Path(path)
    if path.resolve() != path or not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('Expected an unsymlinked regular file: ' + str(path))
    return path


def record(path):
    path = regular(path)
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def require_record(value, path):
    if value != record(path):
        raise ValueError('Published byte record differs: ' + str(path))


def atomic_new_json(path, value):
    """Never replace an existing receipt, even in the late failure branch."""
    path = Path(path)
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('xb') as output:
        output.write(canonical(value) + b'\n'); output.flush(); os.fsync(output.fileno())
    os.link(temporary, path)
    temporary.unlink()


def module(path, expected, name):
    if sha(regular(path)) != expected:
        raise ValueError('Frozen Python dependency differs: ' + str(path))
    specification = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(result)
    return result


def memory_dependencies(encoded):
    if set(encoded) != set(DEPENDENCIES):
        raise ValueError('Install dependency set differs')
    result = {}
    for name, expected in DEPENDENCIES.items():
        raw = base64.b64decode(encoded[name], validate=True)
        if hashlib.sha256(raw).hexdigest() != expected:
            raise ValueError('Accepted install dependency differs: ' + name)
        value = types.ModuleType(name)
        value.__file__ = str(PROFILES / 'transport-dependencies' / (name + '.py'))
        sys.modules[name] = value
        exec(compile(raw, value.__file__, 'exec'), value.__dict__)
        result[name] = value
    return result


def candidate(config):
    value = config['candidate']
    if set(value) != {'id', 'build_proof_sha256', 'source_proof_sha256', 'runner_sha256'} or value['id'] != B_ID:
        raise ValueError('Transport requires the exact final B candidate')
    for digest in value.values(): require_sha(digest)
    build = load(ROOT / 'proof/build-proof.json')
    if (build.get('passed') is not True or build.get('candidate', {}).get('id') != B_ID
            or sha(ROOT / 'proof/build-proof.json') != value['build_proof_sha256']
            or sha(ROOT / 'proof/source-proof.json') != value['source_proof_sha256']
            or build.get('source_proof_sha256') != value['source_proof_sha256']
            or build['binaries']['runner']['sha256'] != value['runner_sha256']):
        raise ValueError('Installed B build/source proof differs')
    for item in build['binaries'].values(): require_record(item, Path(item['path']))
    if build['binaries']['native']['sha256'] != ENGINE_SHA:
        raise ValueError('Pinned native binary differs')
    if Path(build['binaries']['runner']['path']) != ROOT / 'bin/full_song_lua':
        raise ValueError('Global runner path differs')
    return build


@contextlib.contextmanager
def locks(builder=True):
    import fcntl
    with contextlib.ExitStack() as stack:
        # Candidate compilation runs only on1516. Fleet workers were cloned
        # before that lock existed; all their accepted rollout/queue/retry paths
        # share fleet-orchestration.lock. Read-only checks create no lock files.
        names = ('candidate-runner.lock', 'fleet-orchestration.lock') if builder else ('fleet-orchestration.lock',)
        for name in names:
            handle = stack.enter_context(regular(ROOT / name).open('rb'))
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def idle(allowed=()):
    result = subprocess.run(['systemctl', 'list-units', '--state=active,activating,deactivating,reloading',
        '--plain', '--no-pager', '--no-legend', 'song-lua-pass4-*', 'deadsync-lua-pass4-*',
        'itgmania-stream-build-*', 'itgmania-stream-control-*'], capture_output=True, text=True, check=True)
    busy = [line.split()[0] for line in result.stdout.splitlines() if line.strip()
        and line.split()[0] not in allowed and line.split()[0].endswith('.service')
        and re.search(r'(worker|discovery|catalog|capture|archive|replay|pack|pilot|candidate|build|control|retry)', line.split()[0])]
    if busy: raise ValueError('Task guest is busy: ' + repr(busy))


def report_contract(document, control):
    if document.get('errors') != [] or document.get('mismatches') != []:
        raise ValueError('Diagnostic result arrays are absent or nonempty')
    production = document.get('production_replay', {})
    if production.get('errors') != [] or production.get('mismatches') != []:
        raise ValueError('Production result arrays are absent or nonempty')
    observed = {}
    for field in control.OBSERVATION_FIELDS:
        value = document
        for part in field.split('.'): value = value[part]
        observed[field] = value
    return observed


def verify_profile(config):
    identifier = require_sha(config['profile'])
    if identifier == SOURCE_ID: raise ValueError('Final profile collides with its canonical source capsule')
    here = PROFILES / identifier
    for name, relative_name in {
        'profile_sha256': 'capture-profile.json', 'receipt_sha256': 'combined-control-receipt.json',
        'profile_source_sha256': 'proof/source-proof.json', 'profile_build_sha256': 'proof/build-proof.json',
        'report_sha256': 'ordinary/report.json',
    }.items():
        if sha(regular(here / relative_name)) != require_sha(config[name]):
            raise ValueError('Final profile proof differs: ' + name)
    build = candidate(config)
    manifest = load(here / 'manifest.json'); contract = manifest['contract']
    if manifest['id'] != identifier or identity(contract) != identifier or contract['candidate'] != B_ID:
        raise ValueError('Final combined manifest identity differs')
    for name in ('build_proof_sha256', 'source_proof_sha256', 'runner_sha256'):
        if contract[name] != config['candidate'][name]: raise ValueError('Combined contract uses another B proof')
    for name, expected in contract['inputs'].items():
        if PurePosixPath(name).name != name or sha(regular(here / name)) != expected:
            raise ValueError('Frozen combined input differs')
    receipt, state = load(here / 'combined-control-receipt.json'), load(here / 'state.json')
    if (receipt.get('passed') is not True or state.get('active') is not False or state.get('passed') is not True
            or receipt.get('global_inputs_unchanged') is not True or receipt.get('global_profile_published') is not False
            or receipt.get('native_capture_rerun') is not False or receipt.get('native_frames') != 228
            or receipt.get('candidate') != B_ID or receipt.get('profile') != identifier):
        raise ValueError('No complete, separately published combined control')
    for name in ('build_proof_sha256', 'source_proof_sha256'):
        if receipt['candidate_' + name] != config['candidate'][name]: raise ValueError('Control B proof differs')
    for key, name in (('report', 'ordinary/report.json'), ('source_proof', 'proof/source-proof.json'),
                      ('build_proof', 'proof/build-proof.json'), ('native_trace', 'ordinary/traces/native.json')):
        require_record(receipt[key], here / name)
    control = module(here / 'stream_combined_control.py', CONTROL_SHA, 'transport_combined_control')
    worker = module(here / 'worker.py', WORKER_SHA, 'transport_profile_worker')
    if receipt['native_trace']['sha256'] != control.TRACE_SHA: raise ValueError('Original native pilot differs')
    summary = worker.document_summary(here / 'ordinary/report.json', report=True)
    observed = report_contract(load(here / 'ordinary/report.json'), control)
    control.require_combined_report(summary, receipt['archive']['sha256'], 228, receipt['replay_stage']['exit'], observed)
    profile = load(here / 'capture-profile.json')
    expected_paths = {'harness': str(here / 'bin/itgmania-harness-rs'), 'runner': str(ROOT / 'bin/full_song_lua'),
        'engine': str(NATIVE / 'ITGmania-harness-trace'), 'theme': str(NATIVE / 'Themes/Harness Simply Love'),
        'noteskins': str(NATIVE / 'NoteSkins'), 'replay_assets': '/opt/song-lua-audit/deadsync-pass4/assets',
        'source_proof': str(here / 'proof/source-proof.json'), 'build_proof': str(here / 'proof/build-proof.json')}
    if profile['paths'] != expected_paths or profile != receipt['capture_profile']:
        raise ValueError('Published eight-path capture profile differs')
    composed, source = load(here / 'proof/build-proof.json'), load(here / 'proof/source-proof.json')
    if (composed.get('passed') is not True or composed['candidate'] != build['candidate']
            or composed['source_proof_sha256'] != config['profile_source_sha256']
            or composed.get('global_profile_published') is not False
            or source['repositories']['harness']['path'] != str(SOURCE)
            or source['repositories']['harness']['revision'] != COMMIT or source['pins']['native'] != NATIVE_REVISION):
        raise ValueError('Composed component/source proof differs')
    for name in ('harness', 'native', 'runner'):
        require_record(composed['binaries'][name], Path(expected_paths[{'native': 'engine'}.get(name, name)]))
    if composed['binaries']['harness']['sha256'] != CLI_SHA:
        raise ValueError('Separately proved streaming CLI differs')
    for parent, names in ((composed, ('runner_build_proof', 'stream_build_receipt', 'native_control_receipt')),
                          (source['capture_profile'], ('runner_source_proof', 'stream_build_receipt',
                            'stream_commit_attestation', 'native_control_receipt'))):
        for name in names:
            path = Path(parent[name]['path'])
            if path.parent != here: raise ValueError('Component receipt escapes its final profile')
            require_record(parent[name], path)
    if (sha(here / 'runner-build-proof.json') != config['candidate']['build_proof_sha256']
            or sha(here / 'runner-source-proof.json') != config['candidate']['source_proof_sha256']
            or sha(here / 'stream-commit-attestation.json') != ATTESTATION_SHA):
        raise ValueError('Copied source/component evidence differs')
    if composed['combined_control'] != profile['combined_control'] or source['capture_profile']['combined_control'] != profile['combined_control']:
        raise ValueError('Published combined proof linkage differs')
    combined = profile['combined_control']
    if (combined['path'] != str(here / 'ordinary/report.json') or combined['sha256'] != config['report_sha256']
            or combined['harness_sha256'] != CLI_SHA or combined['engine_sha256'] != ENGINE_SHA
            or combined['runner_sha256'] != config['candidate']['runner_sha256'] or combined['observation_coverage'] != observed):
        raise ValueError('Combined report/binary/counter binding differs')
    inventory = load(here / 'harness-source-files.json')
    if (sha(here / 'harness-source-files.json') != INVENTORY_SHA or len(inventory) != 409
            or source['repositories']['harness']['files_sha256'] != inventory):
        raise ValueError('Canonical compiled source inventory differs')
    for name, expected in inventory.items():
        path = SOURCE / relative(name)
        if sha(regular(path)) != expected: raise ValueError('Compiled source byte differs: ' + name)
    if not (ROOT / 'results').is_dir(): raise ValueError('Existing global results directory is absent')
    parser = argparse.ArgumentParser(); worker.add_common_arguments(parser)
    values = ['--worker', 'read-only-transport-profile', '--root', str(ROOT), '--headless', '--production']
    for name, value in expected_paths.items(): values += ['--' + name.replace('_', '-'), value]
    args = worker.prepare_arguments(parser.parse_args(values))
    if args.pins != profile['pins']: raise ValueError('Actual profile pins differ from the published profile')
    return here, profile, worker, inventory, receipt


def global_snapshot(config, worker):
    build = candidate(config)
    paths = [ROOT / 'proof/build-proof.json', ROOT / 'proof/source-proof.json', ROOT / 'worker.py', ROOT / 'corpus-manifest.json']
    paths += [Path(value['path']) for value in build['binaries'].values()]
    return {'files': {str(path): sha(regular(path)) for path in paths},
        'assets': {name: worker.tree_digest(path) for name, path in {
            'theme': NATIVE / 'Themes/Harness Simply Love', 'noteskins': NATIVE / 'NoteSkins',
            'replay_assets': Path('/opt/song-lua-audit/deadsync-pass4/assets')}.items()}}


def runtime_files(cli):
    """System libraries stay installed; bind their actual existing bytes."""
    files = {}; outputs = {}
    for executable in (cli, NATIVE / 'ITGmania-harness-trace'):
        result = subprocess.run(['ldd', str(executable)], capture_output=True, text=True, check=True)
        if 'not found' in result.stdout: raise ValueError('A proved executable has a missing dynamic library')
        outputs[str(executable)] = re.sub(r'\(0x[0-9a-fA-F]+\)', '(address omitted)', result.stdout)
        for line in result.stdout.splitlines():
            match = re.search(r'(?:=>\s*)?(/[^\s]+)\s+\(', line)
            if match:
                path = Path(match.group(1)).resolve(); files[str(path)] = record(path)
    commands = {}
    for name in ('ffmpeg', 'ffprobe', 'Xvfb'):
        found = shutil.which(name)
        if not found: raise ValueError('Required native utility is absent: ' + name)
        path = Path(found).resolve(); files[str(path)] = record(path); commands[name] = str(path)
    return {'files': files, 'commands': commands, 'ldd': outputs}


def export_manifest(config):
    if subprocess.check_output(['hostname'], text=True).strip() != 'deadsync-lua-20261119-build':
        raise ValueError('Export is restricted to the proved builder')
    idle()
    here, profile, worker, inventory, receipt = verify_profile(config)
    baseline = global_snapshot(config, worker)
    files = {}
    def add(path):
        path = regular(path)
        if not path.is_relative_to(PROFILES): raise ValueError('Bundle payload escapes new profile roots')
        row = record(path); row['mode'] = path.stat().st_mode & 0o777
        if row['bytes'] > MAX_FILE: raise ValueError('Profile member exceeds the bounded transport')
        files[path.relative_to(PROFILES).as_posix()] = row
    names = ['manifest.json', 'state.json', 'combined-control-receipt.json', 'capture-profile.json',
        'proof/source-proof.json', 'proof/build-proof.json', 'bin/itgmania-harness-rs',
        'runner-build-proof.json', 'runner-source-proof.json', 'stream-build-receipt.json',
        'native-control-receipt.json', 'pilot-source-identity.json', 'harness-source-files.json',
        'stream-commit-attestation.json', 'build-worker-transport-proof.json', 'stream_combined_control.py',
        'worker.py', 'baseline-before.json', 'baseline-after.json', 'ordinary/report.json',
        'ordinary/traces/native.json', 'ordinary/traces/_semantic_manifest.json', 'ordinary/candidate/index.json']
    names += list(load(here / 'manifest.json')['contract']['inputs'])
    for stage in ('archive', 'replay'):
        names += ['ordinary/stages/' + stage + '/' + name for name in ('spec.json', 'receipt.json', 'output.log', 'launch.json')]
    for name in sorted(set(names)): add(here / name)
    for name in ('controller.log', 'ordinary/stages/archive/journal.log', 'ordinary/stages/replay/journal.log'):
        if (here / name).exists(): add(here / name)
    for name in inventory: add(SOURCE / relative(name))
    add(SOURCE.parent / 'source-files-before.json')
    if sha(SOURCE.parent / 'source-files-before.json') != INVENTORY_SHA: raise ValueError('Original source inventory changed')
    if sum(row['bytes'] for row in files.values()) > MAX_TOTAL: raise ValueError('Profile transport exceeds its byte bound')
    # The capture/archive commands embed probe Lua and use the explicit native
    # path. These aliases also make the optional compiled-manifest doctor fallback
    # usable without copying another engine/theme or altering existing aliases.
    theme_target = (NATIVE / 'Themes/Harness Simply Love').resolve()
    if worker.tree_digest(SOURCE / 'vendor/simply-love') != worker.tree_digest(theme_target):
        raise ValueError('Private compiled theme differs from the existing pinned runtime theme')
    aliases = {str(SOURCE / 'vendor/itgmania'): str(NATIVE), str(SOURCE / 'vendor/simply-love'): str(theme_target)}
    runtime = runtime_files(here / 'bin/itgmania-harness-rs')
    if global_snapshot(config, worker) != baseline: raise ValueError('Builder baseline changed during export inspection')
    idle()
    contract = {'schema': 1, 'config': config, 'files': dict(sorted(files.items())), 'runtime_aliases': aliases,
        'runtime_existing': runtime, 'source_inventory_sha256': INVENTORY_SHA,
        'canonical_source_files': 409, 'canonical_source_root': str(SOURCE),
        'builder_global_snapshot': baseline, 'large_archive_retained_on_builder': receipt['archive'],
        'capture_commands': ['song-lua-catalog', 'song-lua-trace', 'song-lua-archive'],
        'profile_proof_bytes_preserved': True, 'global_promotion': False}
    return {'id': identity(contract), 'contract': contract}


def validate_manifest(manifest):
    contract = manifest['contract']
    if manifest['id'] != identity(contract) or contract.get('schema') != 1:
        raise ValueError('Bundle manifest identity differs')
    config = contract['config']; identifier = require_sha(config['profile'])
    if config['candidate']['id'] != B_ID or identifier == SOURCE_ID:
        raise ValueError('Bundle candidate/profile scope differs')
    files = contract['files']
    if not files or len(files) > 600: raise ValueError('Unexpected bounded profile member count')
    total = 0
    for name, row in files.items():
        rel = relative(name)
        if rel.parts[0] not in (identifier, SOURCE_ID) or row['path'] != str(PROFILES / rel):
            raise ValueError('Payload escapes its two exact owned profile roots')
        require_sha(row['sha256'])
        if type(row['bytes']) is not int or not 0 <= row['bytes'] <= MAX_FILE:
            raise ValueError('Invalid bounded payload length')
        if type(row['mode']) is not int or row['mode'] & ~0o777 or not row['mode'] & 0o400:
            raise ValueError('Invalid regular file permission mode')
        total += row['bytes']
    if total > MAX_TOTAL: raise ValueError('Bundle payload exceeds its byte bound')
    for path, target in contract['runtime_aliases'].items():
        expected = {str(SOURCE / 'vendor/itgmania'): str(NATIVE),
            str(SOURCE / 'vendor/simply-love'): str(NATIVE.parent / 'simply-love')}
        if expected.get(path) != target:
            raise ValueError('Runtime alias differs from its exact pinned native/theme target')
    if set(contract['runtime_aliases']) != {str(SOURCE / 'vendor/itgmania'), str(SOURCE / 'vendor/simply-love')}:
        raise ValueError('Runtime fallback closure is incomplete')
    if contract['canonical_source_root'] != str(SOURCE) or contract['canonical_source_files'] != 409:
        raise ValueError('Canonical source closure differs')
    return contract


def export_tar(manifest, output):
    contract = validate_manifest(manifest)
    if export_manifest(contract['config']) != manifest: raise ValueError('Builder export changed after its manifest was frozen')
    with tarfile.open(fileobj=output, mode='w|', format=tarfile.GNU_FORMAT) as archive:
        raw = canonical(manifest) + b'\n'; header = tarfile.TarInfo('manifest.json'); header.size = len(raw); header.mode = 0o444
        archive.addfile(header, io.BytesIO(raw))
        for name, row in contract['files'].items():
            header = tarfile.TarInfo('payload/' + name); header.size = row['bytes']; header.mode = row['mode']
            with regular(row['path']).open('rb') as stream: archive.addfile(header, stream)
    if export_manifest(contract['config']) != manifest: raise ValueError('Builder changed during the read-only transfer')


def check_tar(path, manifest, extract=None):
    contract = validate_manifest(manifest)
    expected = {'payload/' + name: row for name, row in contract['files'].items()}
    expected['manifest.json'] = {'bytes': len(canonical(manifest) + b'\n'), 'sha256': hashlib.sha256(canonical(manifest) + b'\n').hexdigest(), 'mode': 0o444}
    seen = set()
    with tarfile.open(path, 'r:') as archive:
        for item in archive:
            if item.name not in expected or item.name in seen or not item.isfile() or item.linkname or item.pax_headers:
                raise ValueError('Unexpected, duplicated, linked or extended bundle member')
            row = expected[item.name]
            if item.size != row['bytes'] or item.mode != row['mode']:
                raise ValueError('Bundle member size/mode differs')
            digest = hashlib.sha256(); stream = archive.extractfile(item); destination = None
            if extract is not None and item.name != 'manifest.json':
                target = Path(extract) / relative(item.name.removeprefix('payload/'))
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.resolve() != target: raise ValueError('Staging member path is symlinked')
                destination = target.open('xb')
            try:
                while chunk := stream.read(1024**2):
                    digest.update(chunk)
                    if destination is not None: destination.write(chunk)
            finally:
                if destination is not None: destination.close()
                stream.close()
            if digest.hexdigest() != row['sha256']: raise ValueError('Bundle member bytes differ')
            if destination is not None: target.chmod(row['mode'])
            seen.add(item.name)
    if seen != set(expected): raise ValueError('Bundle is missing a required member')


def require_absent_targets(manifest):
    identifier = validate_manifest(manifest)['config']['profile']
    if PROFILES.resolve() != PROFILES: raise ValueError('Profile parent is symlinked')
    for name in (identifier, SOURCE_ID):
        if os.path.lexists(PROFILES / name): raise ValueError('Refusing to overwrite an existing or unknown profile directory: ' + name)


def install_preflight(request, dependencies, allowed=()):
    config = validate_manifest(request['manifest'])['config']; vm = request['vm']
    if type(vm['vmid']) is not int or vm['vmid'] not in range(1501, 1516): raise ValueError('Install target is not a selected task worker')
    if subprocess.check_output(['hostname'], text=True).strip() != vm['guest_hostname']:
        raise ValueError('QGA-bound guest hostname differs')
    if Path('/etc/ssh/ssh_host_ed25519_key.pub').read_text().split()[:2] != vm['host_key'].split()[:2]:
        raise ValueError('QGA-bound guest host key differs')
    guest, rollout = dependencies['resource_retry_guest'], dependencies['rollout_runner']
    guest.idle(allowed)
    for name in ('runner-rollout-in-progress.json', 'resource-retry-role.json'):
        if (ROOT / name).exists(): raise ValueError('Another rollout/retry owner is present: ' + name)
    candidate(config)
    rollout.verified_installed(B_ID, config['candidate']['runner_sha256'])
    if sha(ROOT / 'worker.py') != WORKER_SHA: raise ValueError('Accepted worker4155 is not installed')
    marker = load(ROOT / 'fleet-drain-in-progress.json'); jobs_path = ROOT / 'assigned-jobs.json'; jobs = load(jobs_path)
    if (marker.get('jobs_path') != str(jobs_path) or marker.get('completed') is not True or marker.get('phase') != 'drained'
            or marker.get('native_cgroup_never_signalled') is not True or marker.get('stage_completed_before_coordinator_termination') is not True
            or not isinstance(jobs, list) or [job['id'] for job in jobs] != marker.get('job_ids')):
        raise ValueError('Drained original assignment path, IDs or order differs')
    drain = guest.drain_proof(vm['vmid'], sha(jobs_path))
    worker = module(ROOT / 'worker.py', WORKER_SHA, 'transport_installed_worker')
    baseline = global_snapshot(config, worker)
    baseline.update(jobs_sha256=sha(jobs_path), drain=drain,
        runner_rollout_receipt_sha256=sha(ROOT / 'runner-rollout-verified.json'),
        replay_wrapper_sha256=sha(ROOT / 'replay_only.py'))
    exported = request['manifest']['contract']['builder_global_snapshot']
    if baseline['assets'] != exported['assets']:
        raise ValueError('Worker runtime assets differ from the proved builder profile')
    for name, expected in exported['files'].items():
        if name != str(ROOT / 'worker.py') and baseline['files'].get(name) != expected:
            raise ValueError('Worker global proof/binary/corpus differs from the proved builder profile')
    for row in request['manifest']['contract']['runtime_existing']['files'].values():
        require_record(row, Path(row['path']))
    if request.get('expected_baseline') is not None and request['expected_baseline'] != baseline:
        raise ValueError('Worker changed after its exact install plan was frozen')
    return baseline


def inspect_install(request):
    dependencies = memory_dependencies(request['dependencies'])
    with locks(builder=False):
        baseline = install_preflight(request, dependencies)
        require_absent_targets(request['manifest'])
        return {'passed': True, 'vm': request['vm'], 'baseline': baseline,
            'bundle_manifest_id': request['manifest']['id'], 'guest_writes': False}


def rename_new(source, target):
    """Linux renameat2 RENAME_NOREPLACE closes the directory-publication race."""
    libc = ctypes.CDLL(None, use_errno=True)
    rename = libc.renameat2
    rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    rename.restype = ctypes.c_int
    if rename(-100, os.fsencode(source), -100, os.fsencode(target), 1) != 0:
        raise OSError(ctypes.get_errno(), 'Creation-only profile publication failed', str(target))


def install(request, input_stream):
    manifest = request['manifest']; contract = validate_manifest(manifest)
    require_sha(request['bundle_sha256']); require_sha(request['plan_id'])
    if identity({key: value for key, value in request.items() if key not in ('plan_id', 'unit')}) != request['plan_id']:
        raise ValueError('Install request differs from its frozen plan identity')
    if not request.get('expected_baseline'): raise ValueError('Install has no frozen worker/drain preflight')
    if type(request['bundle_bytes']) is not int or not 0 < request['bundle_bytes'] <= MAX_BUNDLE:
        raise ValueError('Invalid bounded bundle length')
    vmid = request['vm']['vmid']; own = 'itgmania-stream-control-install-' + request['plan_id'][:12] + '-' + str(vmid) + '.service'
    if request['unit'] != own: raise ValueError('Install unit does not identify its exact frozen plan/VM')
    dependencies = memory_dependencies(request['dependencies'])
    result = {'passed': False, 'plan_id': request['plan_id'], 'vm': request['vm'], 'bundle_sha256': request['bundle_sha256'],
        'manifest_id': manifest['id'], 'profile': contract['config']['profile'], 'candidate': B_ID,
        'unit': own, 'published_directories': [], 'global_promotion': False, 'queue_resumed': False}
    with locks(builder=False):
        before = install_preflight(request, dependencies, (own,))
        require_absent_targets(manifest)
        if shutil.disk_usage(PROFILES).free < RESERVE + request['bundle_bytes'] + sum(row['bytes'] for row in contract['files'].values()):
            raise ValueError('Profile transport would cross the guest20GiB reserve')
        directory = PROFILES / ('transport-' + request['plan_id'])
        directory.mkdir()
        result['receipt'] = str(directory / 'install-receipt.json')
        try:
            atomic_new_json(directory / 'install-request.json', request)
            digest = hashlib.sha256(); remaining = request['bundle_bytes']; bundle = directory / 'profile.tar'
            with bundle.open('xb') as output:
                while remaining:
                    chunk = input_stream.read(min(remaining, 1024**2))
                    if not chunk: raise ValueError('Profile bundle transfer ended early')
                    output.write(chunk); digest.update(chunk); remaining -= len(chunk)
                output.flush(); os.fsync(output.fileno())
            if input_stream.read(1): raise ValueError('Profile bundle transfer exceeds its exact byte length')
            if digest.hexdigest() != request['bundle_sha256']: raise ValueError('Transferred profile bundle hash differs')
            stage = directory / 'staging'; stage.mkdir()
            check_tar(bundle, manifest, stage)
            # Hold the published profile contract until every other payload is
            # materialized and its actual paths/binaries/assets are validated.
            identifier = contract['config']['profile']
            profile_raw = (stage / identifier / 'capture-profile.json').read_bytes()
            (stage / identifier / 'capture-profile.json').unlink()
            for source_path, target in contract['runtime_aliases'].items():
                alias = stage / Path(source_path).relative_to(PROFILES)
                alias.parent.mkdir(parents=True, exist_ok=True)
                if os.path.lexists(alias): raise ValueError('Runtime alias collides with a canonical source member')
                alias.symlink_to(target, target_is_directory=True)
            for name in (SOURCE_ID, identifier):
                rename_new(stage / name, PROFILES / name)
                result['published_directories'].append(str(PROFILES / name))
            after = install_preflight(request, dependencies, (own,))
            if after != before: raise ValueError('Global B/queue/drain inputs changed during installation')
            # profile() accepts the frozen in-memory contract; it does not need
            # capture-profile.json to exist until the final publication below.
            supplied = json.loads(profile_raw)
            proved = dependencies['resource_retry_guest'].profile(contract['config']['candidate'], supplied)
            if proved != supplied: raise ValueError('Installed retry consumer computes different profile pins')
            cli = Path(supplied['paths']['harness'])
            check = subprocess.run([str(cli), 'doctor', '--itgmania-root', str(NATIVE)], capture_output=True, text=True, timeout=30)
            result['runtime_check'] = {'command': check.args, 'exit': check.returncode, 'stdout': check.stdout, 'stderr': check.stderr}
            if check.returncode != 0: raise ValueError('Transported CLI cannot read its pinned native runtime closure')
            target = PROFILES / identifier / 'capture-profile.json'
            with target.open('xb') as output: output.write(profile_raw); output.flush(); os.fsync(output.fileno())
            verify_profile(contract['config'])
            for name, row in contract['files'].items(): require_record({key: row[key] for key in ('path', 'sha256', 'bytes')}, PROFILES / relative(name))
            final = install_preflight(request, dependencies, (own,))
            if final != before: raise ValueError('Global inputs changed before final publication receipt')
            result.update(passed=True, before=before, after=final, actual_profile=proved,
                source_files_verified=409, proof_bytes_preserved=True, drain_marker_preserved=True,
                finished_at_ns=time.time_ns())
            atomic_new_json(directory / 'install-receipt.json', result)
        except BaseException as error:
            result.update(passed=False, error=str(error), traceback=traceback.format_exc(), finished_at_ns=time.time_ns())
            if not (directory / 'install-receipt.json').exists():
                try: atomic_new_json(directory / 'install-failure.json', result)
                except BaseException: pass
        return result
