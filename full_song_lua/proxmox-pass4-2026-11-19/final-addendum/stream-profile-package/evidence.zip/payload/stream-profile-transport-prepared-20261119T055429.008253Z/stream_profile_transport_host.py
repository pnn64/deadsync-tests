#!/usr/bin/env python3
"""Prepare/export/install one separate capture profile; every remote action is explicit.

Run on the Proxmox host. Without --execute this only prints a local plan. Package
reads1516; freeze reads selected drained workers; install writes only new owned
capture-profile directories under an exact accepted package and frozen plan.
"""
from __future__ import annotations
import argparse
import base64
import datetime
import hashlib
import importlib.util
import ipaddress
import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
HOST = Path('/root/deadsync-lua-20261119')
ROOT = HOST / 'capture-profile-transports'
HERE = Path(__file__).resolve().parent
B_ID = 'be576a51d3f4ea203bb1ef298f01b21c9ad4091d09f77cc371da08b26cb6a858'


def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
def identity(value): return hashlib.sha256(canonical(value)).hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def sha(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
def save_new(path, value):
    with Path(path).open('xb') as stream: stream.write(canonical(value) + b'\n'); stream.flush(); __import__('os').fsync(stream.fileno())
def timestamp(): return datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
def run(args, **kwargs): return subprocess.run(list(map(str, args)), capture_output=True, check=True, **kwargs)


def guest_module(path):
    spec = importlib.util.spec_from_file_location('transport_guest_for_local_checks', path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


def verify_vm(vmid):
    if vmid not in range(1501, 1517): raise ValueError('VM is outside the exact task family')
    receipt = HOST / ('build-worker.json' if vmid == 1516 else 'fleet.json')
    values = [load(receipt)] if vmid == 1516 else load(receipt)
    rows = [row for row in values if row['vmid'] == vmid]
    if len(rows) != 1: raise ValueError('Selected VM is absent or ambiguous in task identity receipts')
    row = rows[0]
    resources = json.loads(run(['pvesh', 'get', '/cluster/resources', '--type', 'vm', '--output-format', 'json']).stdout)
    matches = [item for item in resources if item['vmid'] == vmid]
    if len(matches) != 1 or matches[0]['status'] != 'running': raise ValueError('Selected task VM is not running')
    node = matches[0]['node']
    config = json.loads(run(['pvesh', 'get', '/nodes/' + node + '/qemu/' + str(vmid) + '/config', '--output-format', 'json']).stdout)
    if config.get('tags') != 'deadsync-lua-20261119' or not config.get('name', '').startswith('deadsync-lua-20261119-'):
        raise ValueError('VM configuration is outside the proved task family')
    pending = json.loads(run(['pvesh', 'get', '/nodes/' + node + '/qemu/' + str(vmid) + '/pending', '--output-format', 'json']).stdout)
    if any('pending' in value or value.get('delete') for value in pending): raise ValueError('VM has an unowned pending configuration')
    networks = json.loads(run(['qm', 'guest', 'cmd', vmid, 'network-get-interfaces'], timeout=20).stdout)
    addresses = [item['ip-address'] for interface in networks for item in interface.get('ip-addresses', [])
        if item.get('ip-address-type') == 'ipv4' and ipaddress.ip_address(item['ip-address']) in ipaddress.ip_network('192.168.1.0/24')]
    if addresses != [row['ip']]: raise ValueError('Live QGA address differs from the frozen task transport')
    def qga(command):
        result = json.loads(run(['qm', 'guest', 'exec', vmid, '--', *command], timeout=20).stdout)
        if result.get('exitcode') != 0 or result.get('out-truncated'): raise ValueError('QGA identity read failed')
        return result['out-data'].strip()
    host_key = ' '.join(qga(['cat', '/etc/ssh/ssh_host_ed25519_key.pub']).split()[:2])
    if not host_key.startswith('ssh-ed25519 ') or host_key.split() != row['host_key'].split()[:2]:
        raise ValueError('Live QGA public host key differs from the task receipt')
    known = HOST / ('build-worker-known-hosts' if vmid == 1516 else 'fleet-known-hosts')
    line = [row['ip'], *host_key.split()]
    if line not in [value.split()[:3] for value in known.read_text().splitlines() if value.strip() and not value.startswith('#')]:
        raise ValueError('Pinned SSH known-hosts lacks the exact QGA address/key')
    return {'vmid': vmid, 'ip': row['ip'], 'host_key': host_key, 'guest_hostname': qga(['hostname']),
        'vm_name': config['name'], 'node': node, 'config_sha256': sha(Path('/etc/pve/qemu-server') / (str(vmid) + '.conf')),
        'identity_receipt': str(receipt), 'identity_row_sha256': identity(row), 'known_hosts': str(known)}


def transport(vm):
    return ['ssh', '-i', '/root/deadsync-pass3-20261116/transfer-key', '-o', 'BatchMode=yes',
        '-o', 'ConnectTimeout=10', '-o', 'StrictHostKeyChecking=yes', '-o', 'UserKnownHostsFile=' + vm['known_hosts'],
        '-o', 'ServerAliveInterval=15', '-o', 'ServerAliveCountMax=3', 'parity@' + vm['ip']]


def bootstrap(helper_raw, action, value):
    digest = hashlib.sha256(helper_raw).hexdigest()
    encoded = base64.b64encode(helper_raw).decode()
    payload = base64.b64encode(canonical(value)).decode()
    suffix = {
        'manifest': "with locks(): result=export_manifest(value)\nprint(json.dumps(result))",
        'export': "with locks(): export_tar(value,sys.stdout.buffer)",
        'inspect': "print(json.dumps(inspect_install(value)))",
        'install': "result=install(value,sys.stdin.buffer)\nprint(json.dumps(result),flush=True)\nraise SystemExit(0 if result['passed'] else 1)",
    }[action]
    return ("import base64,hashlib,json,sys\nsys.dont_write_bytecode=True\nraw=base64.b64decode(" + repr(encoded) + ")\n"
        + "assert hashlib.sha256(raw).hexdigest()==" + repr(digest) + "\n"
        + "value=json.loads(base64.b64decode(" + repr(payload) + "))\n"
        + "exec(compile(raw,'<proved-stream-profile-transport>','exec'),globals())\n" + suffix)


def remote(vm, helper, action, value, directory, output_name, binary_input=None):
    code = bootstrap(helper, action, value).encode()
    if len(code) > 1024**2: raise ValueError('Bounded in-memory transport recipe is too large')
    # Only this small framing program is a shell argument. The reviewed source,
    # proof manifest and dependencies travel in stdin, avoiding Linux ARG_MAX.
    reader = "import sys\nn=int(sys.stdin.buffer.readline(32))\nassert 0<n<=1048576\nraw=sys.stdin.buffer.read(n)\nassert len(raw)==n\nexec(compile(raw,'<framed-profile-recipe>','exec'),globals())"
    command = ['python3', '-B', '-c', reader]
    if action == 'install':
        command = ['sudo', 'systemd-run', '--quiet', '--collect', '--wait', '--pipe', '--unit=' + value['unit'],
            '--property=User=parity', '--property=Group=parity', '--property=MemoryMax=2G', '--property=MemorySwapMax=0',
            '--property=CPUQuota=100%', '--property=Nice=15', '--property=RuntimeMaxSec=1800', *command]
    destination, error_path = directory / output_name, directory / (output_name + '.stderr')
    with destination.open('xb') as output, error_path.open('xb') as errors:
        process = subprocess.Popen(transport(vm) + [shlex.join(command)], stdin=subprocess.PIPE, stdout=output, stderr=errors)
        try:
            process.stdin.write(str(len(code)).encode() + b'\n'); process.stdin.write(code)
            if binary_input is not None: shutil.copyfileobj(binary_input, process.stdin, 1024**2)
            process.stdin.close()
        except BrokenPipeError:
            try: process.stdin.close()
            except BrokenPipeError: pass
        returncode = process.wait(timeout=2000)
    receipt = {'exit': returncode, 'output': {'path': str(destination), 'sha256': sha(destination), 'bytes': destination.stat().st_size},
        'stderr': {'path': str(error_path), 'sha256': sha(error_path)}, 'action': action, 'vm': vm,
        'helper_sha256': hashlib.sha256(helper).hexdigest()}
    save_new(directory / (output_name + '.transfer.json'), receipt)
    if returncode != 0: raise ValueError('Exact remote ' + action + ' failed; original output/stderr retained')
    return destination


def dependency_bytes(guest):
    result = {}
    for name, expected in guest.DEPENDENCIES.items():
        path = HERE / (name + '.py')
        if sha(path) != expected: raise ValueError('Accepted dependency changed: ' + name)
        result[name] = base64.b64encode(path.read_bytes()).decode()
    return result


def package(request, directory, helper, guest):
    config = request['profile_config']
    if config['candidate']['id'] != B_ID: raise ValueError('Request does not identify B')
    selected = request['selected_vmids']
    if selected != sorted(set(selected)) or not selected or any(type(vmid) is not int or vmid not in range(1501, 1516) for vmid in selected):
        raise ValueError('Package requires an explicit unique sorted task-worker selection')
    builder = verify_vm(1516)
    if builder['ip'] != '192.168.1.41': raise ValueError('Builder transport no longer matches its reviewed identity')
    members = remote(builder, helper, 'manifest', config, directory, 'manifest.json')
    manifest = load(members); guest.validate_manifest(manifest)
    if manifest['contract']['config'] != config: raise ValueError('Exported config differs')
    size = sum(row['bytes'] for row in manifest['contract']['files'].values())
    if shutil.disk_usage(directory).free < 20 * 1024**3 + size * 2: raise ValueError('Host transport scratch reserve is insufficient')
    bundle = remote(builder, helper, 'export', manifest, directory, 'profile.tar')
    if bundle.stat().st_size > guest.MAX_BUNDLE: raise ValueError('Exported tar exceeds its bounded length')
    guest.check_tar(bundle, manifest)
    if verify_vm(1516) != builder: raise ValueError('Builder identity changed during profile export')
    targets = {str(vmid): verify_vm(vmid) for vmid in selected}
    receipt = {'passed': True, 'candidate': config['candidate'], 'profile': config['profile'], 'manifest': manifest,
        'bundle': {'path': str(bundle), 'sha256': sha(bundle), 'bytes': bundle.stat().st_size},
        'helper': {'path': str(directory / 'stream_profile_transport_guest.py'), 'sha256': hashlib.sha256(helper).hexdigest()},
        'dependencies': dependency_bytes(guest), 'builder': builder, 'targets': targets,
        'builder_writes': False, 'installed': False, 'package_request_sha256': identity(request)}
    save_new(directory / 'package-receipt.json', receipt)
    return receipt


def checked_package(args, guest):
    if sha(args.input) != args.expected_input_sha256: raise ValueError('Supplied package receipt hash differs')
    package = load(args.input)
    if package.get('passed') is not True or package['candidate']['id'] != B_ID: raise ValueError('No passed exact B package')
    guest.validate_manifest(package['manifest'])
    if (package['candidate'] != package['manifest']['contract']['config']['candidate']
            or package['profile'] != package['manifest']['contract']['config']['profile']):
        raise ValueError('Package candidate/profile contract differs')
    if sha(package['bundle']['path']) != package['bundle']['sha256'] or Path(package['bundle']['path']).stat().st_size != package['bundle']['bytes']:
        raise ValueError('Frozen profile bundle changed')
    if sha(package['helper']['path']) != package['helper']['sha256']: raise ValueError('Packaged guest helper changed')
    if package['helper']['sha256'] != args.expected_guest_helper_sha256:
        raise ValueError('Package requires a different reviewed guest helper')
    return package


def freeze(args, directory, guest):
    package = checked_package(args, guest)
    helper = Path(package['helper']['path']).read_bytes(); plans = {}
    for key, frozen in package['targets'].items():
        vm = verify_vm(int(key))
        if vm != frozen: raise ValueError('Selected worker identity changed since packaging')
        request = {'manifest': package['manifest'], 'vm': vm, 'dependencies': package['dependencies']}
        path = remote(vm, helper, 'inspect', request, directory, 'preflight-' + key + '.json')
        proof = load(path)
        if proof.get('passed') is not True or proof['vm'] != vm or proof['bundle_manifest_id'] != package['manifest']['id']:
            raise ValueError('Guest did not prove the exact idle/drained B installation')
        contract = {'package_receipt': str(Path(args.input).resolve()), 'package_receipt_sha256': args.expected_input_sha256,
            'bundle_sha256': package['bundle']['sha256'], 'bundle_bytes': package['bundle']['bytes'],
            'manifest': package['manifest'], 'vm': vm, 'expected_baseline': proof['baseline'],
            'dependencies': package['dependencies'], 'helper_sha256': package['helper']['sha256'],
            'attempt': timestamp()}
        identifier = identity(contract)
        plan = {'id': identifier, 'contract': contract}
        save_new(directory / ('install-plan-' + key + '.json'), plan)
        plans[key] = {'path': str(directory / ('install-plan-' + key + '.json')), 'sha256': sha(directory / ('install-plan-' + key + '.json'))}
    result = {'passed': True, 'plans': plans, 'guest_writes': False, 'installed': False}
    save_new(directory / 'freeze-receipt.json', result)
    return result


def install(args, directory, guest):
    if sha(args.input) != args.expected_input_sha256: raise ValueError('Frozen install plan hash differs')
    plan = load(args.input); contract = plan['contract']
    if plan['id'] != identity(contract): raise ValueError('Install plan identity differs')
    package_path = Path(contract['package_receipt'])
    if sha(package_path) != contract['package_receipt_sha256']: raise ValueError('Install plan package receipt changed')
    package = load(package_path); vm = verify_vm(contract['vm']['vmid'])
    if vm != contract['vm'] or vm != package['targets'].get(str(vm['vmid'])): raise ValueError('Selected VM identity changed after drain freeze')
    if (package.get('passed') is not True or package['manifest'] != contract['manifest']
            or package['bundle']['sha256'] != contract['bundle_sha256'] or package['bundle']['bytes'] != contract['bundle_bytes']
            or sha(package['bundle']['path']) != contract['bundle_sha256'] or package['dependencies'] != contract['dependencies']
            or package['helper']['sha256'] != contract['helper_sha256'] or sha(package['helper']['path']) != contract['helper_sha256']):
        raise ValueError('Install package/bundle/helper differs from its frozen plan')
    if contract['helper_sha256'] != args.expected_guest_helper_sha256: raise ValueError('Install plan requires another reviewed guest helper')
    helper = Path(package['helper']['path']).read_bytes()
    request = {**contract, 'plan_id': plan['id'], 'unit': 'itgmania-stream-control-install-' + plan['id'][:12] + '-' + str(vm['vmid']) + '.service'}
    with Path(package['bundle']['path']).open('rb') as stream:
        output = remote(vm, helper, 'install', request, directory, 'install-result.json', stream)
    result = load(output)
    unit = run(transport(vm) + [shlex.join(['systemctl', 'show', request['unit'],
        '--property=LoadState,ActiveState,SubState,Result,ExecMainStatus'])], timeout=30)
    state = {line.split('=', 1)[0]: line.split('=', 1)[1] for line in unit.stdout.decode().splitlines() if '=' in line}
    save_new(directory / 'completed-unit.json', state)
    if state.get('ActiveState') != 'inactive' or (state.get('LoadState') != 'not-found'
            and (state.get('Result') != 'success' or state.get('ExecMainStatus') != '0')):
        raise ValueError('Exact profile installation unit did not finish successfully')
    if (result.get('passed') is not True or result.get('plan_id') != plan['id'] or result.get('vm') != vm
            or result.get('before') != contract['expected_baseline'] or result.get('after') != contract['expected_baseline']
            or result.get('global_promotion') is not False or result.get('queue_resumed') is not False
            or result.get('drain_marker_preserved') is not True or verify_vm(vm['vmid']) != vm):
        raise ValueError('Completed installer did not preserve the exact frozen worker/drain/global proofs')
    receipt = {'passed': True, 'result': result, 'result_sha256': sha(output), 'plan_sha256': args.expected_input_sha256}
    save_new(directory / 'install-host-receipt.json', receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('package', 'freeze', 'install'))
    parser.add_argument('input', type=Path)
    parser.add_argument('--expected-input-sha256', required=True)
    parser.add_argument('--expected-guest-helper-sha256', required=True)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    helper_path = HERE / 'stream_profile_transport_guest.py'
    for expected in (args.expected_input_sha256, args.expected_guest_helper_sha256):
        if re.fullmatch('[0-9a-f]{64}', expected) is None: raise ValueError('A complete explicit SHA256 is required')
    if sha(args.input) != args.expected_input_sha256 or sha(helper_path) != args.expected_guest_helper_sha256:
        raise ValueError('Reviewed local input/helper changed')
    if not args.execute:
        print(json.dumps({'executed': False, 'action': args.action, 'input': str(args.input),
            'input_sha256': args.expected_input_sha256, 'guest_helper_sha256': args.expected_guest_helper_sha256,
            'candidate': B_ID}, indent=2)); return 0
    ROOT.mkdir(parents=True, exist_ok=True)
    if ROOT.resolve() != ROOT: raise ValueError('Owned host transport parent is symlinked')
    directory = ROOT / (timestamp() + '-' + args.action); directory.mkdir()
    helper = helper_path.read_bytes(); (directory / helper_path.name).write_bytes(helper)
    (directory / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    (directory / 'input.json').write_bytes(args.input.read_bytes())
    guest = guest_module(directory / helper_path.name)
    try:
        result = package(load(args.input), directory, helper, guest) if args.action == 'package' else globals()[args.action](args, directory, guest)
        receipt_name = {'package': 'package-receipt.json', 'freeze': 'freeze-receipt.json', 'install': 'install-host-receipt.json'}[args.action]
        print(json.dumps({'passed': True, 'action': args.action, 'directory': str(directory),
            'receipt': str(directory / receipt_name), 'receipt_sha256': sha(directory / receipt_name)}, indent=2))
        return 0
    except BaseException as error:
        result = {'passed': False, 'action': args.action, 'error': str(error), 'traceback': traceback.format_exc(), 'directory': str(directory)}
        save_new(directory / 'failure.json', result); print(json.dumps(result, indent=2)); return 1


if __name__ == '__main__':
    raise SystemExit(main())
