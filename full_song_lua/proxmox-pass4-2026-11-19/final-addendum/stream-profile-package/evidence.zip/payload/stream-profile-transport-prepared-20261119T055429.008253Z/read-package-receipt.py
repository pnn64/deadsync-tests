import hashlib,pathlib,sys
p=pathlib.Path('/root/deadsync-lua-20261119/capture-profile-transports/20261119T055530.146160Z-package/package-receipt.json')
raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='e4b79e0c2acd1505c27958271d4dd4a44d9d58fe5278e0823f3d606271682bb7'
sys.stdout.buffer.write(raw)
