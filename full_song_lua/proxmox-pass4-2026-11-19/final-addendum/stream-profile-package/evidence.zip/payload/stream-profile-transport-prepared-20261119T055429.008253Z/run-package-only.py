"""Execute only the root-authorized, exact prepared upload and package action."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PLAN_SHA = '39db12d9b581763a933fa17d86b45185cd341f3ef2ca54e539dc2f89ac5703d9'


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert sys.argv[1:] == ['--execute'], 'Explicit package-only execution flag is required'
    assert sha(HERE / 'invocation-plan.json') == PLAN_SHA
    plan = json.loads((HERE / 'invocation-plan.json').read_bytes())
    for name, expected in {**plan['inputs'], **plan['generated_scripts']}.items(): assert sha(HERE / name) == expected
    result = {'passed': False, 'plan_sha256': PLAN_SHA, 'actions': [], 'worker_freeze_invoked': False,
              'worker_install_invoked': False, 'global_profile_promoted': False}
    try:
        for action, command in zip(('upload', 'package'), plan['windows_commands'], strict=True):
            with (HERE / (action + '.stdout')).open('xb') as output, (HERE / (action + '.stderr')).open('xb') as errors:
                completed = subprocess.run(command, stdout=output, stderr=errors)
            result['actions'].append({'action': action, 'exit': completed.returncode,
                'stdout_sha256': sha(HERE / (action + '.stdout')), 'stderr_sha256': sha(HERE / (action + '.stderr'))})
            if completed.returncode != 0: raise RuntimeError('Exact ' + action + ' failed; original output is retained')
        packaged = json.loads((HERE / 'package.stdout').read_bytes())
        if packaged.get('passed') is not True: raise RuntimeError('Host did not report a passed package')
        host_receipt = packaged['receipt']
        assert host_receipt.startswith('/root/deadsync-lua-20261119/capture-profile-transports/') and host_receipt.endswith('/package-receipt.json')
        fetch = HERE / 'read-package-receipt.py'
        fetch.write_text('import hashlib,pathlib,sys\np=pathlib.Path(' + repr(host_receipt) + ')\nraw=p.read_bytes()\nassert hashlib.sha256(raw).hexdigest()=='
                         + repr(packaged['receipt_sha256']) + '\nsys.stdout.buffer.write(raw)\n', encoding='utf-8')
        with (HERE / 'package-receipt.json').open('xb') as output, (HERE / 'read-package-receipt.stderr').open('xb') as errors:
            read = subprocess.run([sys.executable, str(HERE.parent / 'remote.py'), str(fetch)], stdout=output, stderr=errors)
        assert read.returncode == 0 and sha(HERE / 'package-receipt.json') == packaged['receipt_sha256']
        receipt = json.loads((HERE / 'package-receipt.json').read_bytes())
        assert receipt['passed'] is True and receipt['installed'] is False and receipt['builder_writes'] is False
        result.update(passed=True, host_receipt=host_receipt, receipt_sha256=packaged['receipt_sha256'], bundle=receipt['bundle'],
                      source_files=receipt['manifest']['contract']['canonical_source_files'], profile=receipt['profile'])
    except BaseException as error:
        result['error'] = str(error)
    with (HERE / 'package-execution-receipt.json').open('xb') as output:
        output.write((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps(result, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__': raise SystemExit(main())
