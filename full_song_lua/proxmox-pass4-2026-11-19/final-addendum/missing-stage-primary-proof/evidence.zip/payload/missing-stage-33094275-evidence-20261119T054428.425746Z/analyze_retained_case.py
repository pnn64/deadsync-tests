"""Inspect already retained bytes; do not infer missing receipts from error text."""
import datetime
import hashlib
import json
import pathlib
import tarfile
import zstandard

HERE = pathlib.Path(__file__).resolve().parent
UNIT = "song-lua-pass4-capture-41f6bb473b71babb0511.service"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def journal(name):
    raw = (HERE / name).read_bytes()
    return raw, [json.loads(line) for line in raw.splitlines() if line.startswith(b"{")]


service_raw, service = journal("service_journal.stdout")
kernel_raw, kernel = journal("kernel_journal_0.stdout")
selected = []
for row in kernel:
    message = str(row.get("MESSAGE", ""))
    if any(term in message for term in ("oom-kill:", "Memory cgroup out of memory:", "memory: usage", "Killed process")):
        selected.append(row)
assert any(UNIT in str(row.get("MESSAGE")) and "oom-kill:" in str(row.get("MESSAGE")) and "CONSTRAINT_MEMCG" in str(row.get("MESSAGE")) for row in selected)
assert any("Failed with result 'oom-kill'." in str(row.get("MESSAGE")) for row in service)
assert any("Control process exited, code=killed, status=9/KILL" in str(row.get("MESSAGE")) for row in service)

original = (HERE / "capture-result.json").read_bytes()
assert sha(original) == "d21a1ba39e9d4aec9d1af3a96b5dfc8b6bd8c02a6dd1cd2c5abe43bff37a9d32"
result = json.loads(original)
spec_raw = (HERE / "stages/capture/spec.json").read_bytes()
launch_raw = (HERE / "stages/capture/launch.json").read_bytes()
spec = json.loads(spec_raw); launch = json.loads(launch_raw)
assert result["status"] == "capture_validation_or_infrastructure_error" and result["stages"] == {}
assert spec["unit"] + ".service" == UNIT and spec["memory_limit"] == "6G" and spec["timeout_seconds"] == 1290
assert "--property=MemorySwapMax=0" in launch["command"]

artifact = HERE / "artifacts/515dec2edf7489ad963d6440465f7656f8b3e287b5ba00cf1627ccf0fcbe1ee1.tar.zst"
assert hashlib.file_digest(artifact.open("rb"), "sha256").hexdigest() == artifact.name.split(".")[0]
members = []
with artifact.open("rb") as packed, zstandard.ZstdDecompressor().stream_reader(packed) as decoded:
    with tarfile.open(fileobj=decoded, mode="r|") as archive:
        for entry in archive:
            item = {"path": entry.name, "bytes": entry.size, "is_file": entry.isfile()}
            members.append(item)
            if not entry.isfile():
                continue
            source = archive.extractfile(entry); digest = hashlib.sha256(); head = b""; tail = b""
            while chunk := source.read(1024 * 1024):
                digest.update(chunk)
                if len(head) < 4096: head = (head + chunk)[:4096]
                tail = (tail + chunk)[-12288:]
            item["sha256"] = digest.hexdigest()
            if any(term in entry.name.lower() for term in ("/logs/", "crashinfo", "userlog", "info.txt")):
                item.update(head=head.decode("utf-8", errors="replace"), tail=tail.decode("utf-8", errors="replace"))

proof = {"scope": "Secondary read-only termination evidence; original result status and stages are unchanged.",
         "job_id": result["id"], "vmid": 1515, "attempt": "capture-bf480552aa7b55ac7fd8-001",
         "unit": UNIT, "original_result_sha256": sha(original),
         "original_status": result["status"], "original_stages": result["stages"],
         "spec_sha256": sha(spec_raw), "launch_sha256": sha(launch_raw),
         "service_journal_sha256": sha(service_raw), "kernel_journal_sha256": sha(kernel_raw),
         "service_records": service, "selected_kernel_records": selected,
         "native_diagnostic": {"path": str(artifact), "sha256": artifact.name.split(".")[0], "members": members},
         "finding": "The exact capture service hit its memory cgroup limit. Systemd recorded OOM-kill for the main process and then the control process; no ExecStopPost receipt was left. This is a journal/kernel-proven resource failure, not inferred from the worker's generic error wording.",
         "recommendation": "Eligible for a separate explicit original-attempt-bound capture resource retry after parent review. Keep existing infrastructure status and accepted planner input unchanged; bind original result, spec, journal/kernel evidence and original chart/source/pins in any new retry contract.",
         "limits": ["Does not prove the exact native allocation or source phase that exhausted memory.",
                    "The collected unit is now not-found; default Result=success and MemoryMax=infinity are not the historical outcome or limit.",
                    "A systemd message that the native child remained at stop time is not a claim that the PID is still alive now.",
                    "No new capture, replay, retry, classification rewrite, planner change, or guest mutation was performed."]}
destination = HERE / "termination-proof.json"
with destination.open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(proof, stream, indent=2, ensure_ascii=False)
    stream.write("\n")
def concise(row):
    time = int(row["__REALTIME_TIMESTAMP"]) / 1e6
    return {"utc": datetime.datetime.fromtimestamp(time, datetime.timezone.utc).isoformat(), "message": row.get("MESSAGE")}
print(json.dumps({"proof":str(destination),"bytes":destination.stat().st_size,"sha256":sha(destination.read_bytes()),
                  "service_messages":[concise(row) for row in service],"kernel_messages":[concise(row) for row in selected],
                  "diagnostic_member_count":len(members),
                  "diagnostic_members_first20":[{k:v for k,v in row.items() if k not in ('head','tail')} for row in members[:20]]},ensure_ascii=False))
