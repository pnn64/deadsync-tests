"""Read-only, hash-bound evidence collection for one missing stage receipt."""
import base64
import datetime
import gzip
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
import gather_artifacts
import remote

HERE = pathlib.Path(__file__).resolve().parent
SNAPSHOT = HERE / "collected/20261119T054020.048384Z-full.json.gz"
SNAPSHOT_SHA = "d1cfd6e88b6ce95e9fc12c378c2d09651efd4d4c5cfdb9d336bcdd2e62d8d915"
JOB = "33094275d983528c-c0003"
ATTEMPT = "capture-bf480552aa7b55ac7fd8-001"
UNIT = "song-lua-pass4-capture-41f6bb473b71babb0511"
RESULT_SHA = "d21a1ba39e9d4aec9d1af3a96b5dfc8b6bd8c02a6dd1cd2c5abe43bff37a9d32"
DIAGNOSTIC_SHA = "515dec2edf7489ad963d6440465f7656f8b3e287b5ba00cf1627ccf0fcbe1ee1"

GUEST = r'''
import base64,datetime,hashlib,json,pathlib,subprocess
root=pathlib.Path('/opt/song-lua-audit/pass4')
case=root/'results'/config['job']/config['attempt']
assert case.resolve().is_relative_to(root/'results')
result_path=case/'capture-result.json'
def sha(data):return hashlib.sha256(data).hexdigest()
result_raw=result_path.read_bytes()
assert sha(result_raw)==config['result_sha256']
result=json.loads(result_raw)
assert result['id']==config['job'] and result['worker']=='1515'
assert result['status']=='capture_validation_or_infrastructure_error' and not result['stages']
started=datetime.datetime.fromisoformat(result['started_at']).timestamp()-15
finished=datetime.datetime.fromisoformat(result['finished_at']).timestamp()+20
unit=config['unit']+'.service'
stage=case/'stages/capture'
def file_record(path,name):
    assert path.resolve().is_relative_to(case)
    raw=path.read_bytes()
    assert len(raw)<=32*1024*1024, ('file exceeds exact retention bound',str(path),len(raw))
    return {'path':str(path),'name':name,'bytes':len(raw),'sha256':sha(raw),'base64':base64.b64encode(raw).decode()}
def query(argv,timeout=40):
    p=subprocess.run(argv,capture_output=True,timeout=timeout)
    assert len(p.stdout)+len(p.stderr)<=32*1024*1024, ('query exceeds exact retention bound',argv)
    return {'argv':argv,'exit':p.returncode,'stdout_bytes':len(p.stdout),'stdout_sha256':sha(p.stdout),
            'stdout_base64':base64.b64encode(p.stdout).decode(),'stderr_bytes':len(p.stderr),
            'stderr_sha256':sha(p.stderr),'stderr_base64':base64.b64encode(p.stderr).decode()}
out={'vmid':1515,'job':config['job'],'attempt':config['attempt'],'unit':unit,
     'collected_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'time_window':{'since_epoch':started,'until_epoch':finished},
     'original_result':file_record(result_path,'capture-result.json'),'stage_files':[],'queries':{}}
for path in sorted(stage.iterdir()):
    if path.is_file():out['stage_files'].append(file_record(path,'stages/capture/'+path.name))
spec=json.loads((stage/'spec.json').read_bytes())
assert spec['unit']==config['unit'], 'unit differs from exact reviewed attempt'
out['queries']['unit_properties']=query(['systemctl','show',unit,'--property=Id,LoadState,ActiveState,SubState,Result,ExecMainStatus,ExecMainCode,MemoryCurrent,MemoryPeak,MemoryMax,MemorySwapMax,ControlGroup,ExecStopPost,ExecMainStartTimestamp,ExecMainExitTimestamp'])
out['queries']['unit_status']=query(['systemctl','status','--no-pager','--full',unit])
out['queries']['service_journal']=query(['sudo','-n','journalctl','-u',unit,'--no-pager','--since','@'+str(started),'--until','@'+str(finished),'-o','json'],90)
service=base64.b64decode(out['queries']['service_journal']['stdout_base64'])
records=[json.loads(line) for line in service.splitlines() if line.startswith(b'{')]
boots=sorted({record['_BOOT_ID'] for record in records if '_BOOT_ID' in record})
out['journal_boot_ids']=boots
for index,boot in enumerate(boots):
    out['queries']['kernel_journal_'+str(index)]=query(['sudo','-n','journalctl','_TRANSPORT=kernel','_BOOT_ID='+boot,'--no-pager','--since','@'+str(started),'--until','@'+str(finished),'-o','json'],90)
out['stage_receipt_exists']=(stage/'receipt.json').exists()
out['native_trace_exists']=(case/'traces/native.json').exists()
out['tmp_exists']=(case/'tmp').exists()
out['result_sha256_after']=sha(result_path.read_bytes())
assert out['result_sha256_after']==config['result_sha256']
for record in out['stage_files']:
    assert sha(pathlib.Path(record['path']).read_bytes())==record['sha256'], 'stage file changed during inspection'
print(json.dumps(out,separators=(',',':')))
'''

HOST = r'''
import base64,gzip,hashlib,json,pathlib,subprocess,sys
root=pathlib.Path('/root/deadsync-lua-20261119')
fleet_raw=(root/'fleet.json').read_bytes()
workers={row['vmid']:row for row in json.loads(fleet_raw)}
assert workers[1515]['ip']==config['ip']
def query(argv):
    p=subprocess.run(argv,capture_output=True,timeout=30)
    return {'argv':argv,'exit':p.returncode,'stdout_base64':base64.b64encode(p.stdout).decode(),
            'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_base64':base64.b64encode(p.stderr).decode()}
command=['ssh','-i','/root/deadsync-pass3-20261116/transfer-key','-o','BatchMode=yes',
         '-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(root/'fleet-known-hosts'),
         '-o','ConnectTimeout=10','parity@'+workers[1515]['ip'],'python3','-']
answer=subprocess.run(command,input=('config='+repr(config)+'\n'+guest).encode(),capture_output=True,timeout=240)
assert answer.returncode==0,answer.stderr.decode(errors='replace')[-8000:]
out={'fleet_sha256':hashlib.sha256(fleet_raw).hexdigest(),'worker_identity':workers[1515],
     'qm_config':query(['qm','config','1515']),'qm_status':query(['qm','status','1515']),
     'guest_ssh_stderr_base64':base64.b64encode(answer.stderr).decode(),'guest':json.loads(answer.stdout)}
sys.stdout.buffer.write(gzip.compress(json.dumps(out,separators=(',',':')).encode(),compresslevel=3,mtime=0))
'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


raw = SNAPSHOT.read_bytes()
assert sha(raw) == SNAPSHOT_SHA
snapshot = json.loads(gzip.decompress(raw))
assert snapshot['mode'] == 'full'
guest = next(row for row in snapshot['guests'] if row['vmid'] == 1515)
assert guest['connected']
entries = [row for row in guest['payload']['files'] if row['kind'] == 'capture_result' and row['data'].get('id') == JOB]
assert len(entries) == 1
entry = entries[0]
assert entry['sha256'] == RESULT_SHA and entry['data']['status'] == 'capture_validation_or_infrastructure_error'
assert entry['path'] == f'results/{JOB}/{ATTEMPT}/capture-result.json'
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
out = HERE / ('missing-stage-33094275-evidence-' + stamp)
out.mkdir()
(out / 'collector.py').write_bytes(pathlib.Path(__file__).read_bytes())
(out / 'selection.json').write_text(json.dumps({'snapshot':str(SNAPSHOT),'snapshot_sha256':SNAPSHOT_SHA,'vmid':1515,'ip':guest['ip'],'entry':entry},indent=2)+'\n',encoding='utf-8')
config = {'vmid':1515,'ip':guest['ip'],'job':JOB,'attempt':ATTEMPT,'unit':UNIT,'result_sha256':RESULT_SHA}
script = 'config='+repr(config)+'\nguest='+repr(GUEST)+'\n'+HOST
result = subprocess.run(remote.ssh()+['python3','-'],input=script.encode(),capture_output=True,timeout=300)
(out / 'host-stderr.log').write_bytes(result.stderr)
(out / 'remote-evidence.json.gz').write_bytes(result.stdout)
assert result.returncode == 0, result.stderr.decode(errors='replace')[-8000:]
payload = json.loads(gzip.decompress(result.stdout))
record = payload['guest']
for row in [record['original_result'], *record['stage_files']]:
    relative = pathlib.PurePosixPath(row['name'])
    assert not relative.is_absolute() and '..' not in relative.parts
    data = base64.b64decode(row['base64']); assert len(data)==row['bytes'] and sha(data)==row['sha256']
    path = out / relative; path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
for name, query in record['queries'].items():
    for channel in ('stdout','stderr'):
        data=base64.b64decode(query[channel+'_base64'])
        assert sha(data)==query[channel+'_sha256']
        (out / (name+'.'+channel)).write_bytes(data)
selected, references = gather_artifacts.select(SNAPSHOT)
diagnostic = selected[DIAGNOSTIC_SHA+'.tar.zst']
assert diagnostic['vmid']==1515
assert shutil.disk_usage(out).free-diagnostic['bytes'] >= 15*1024**3
artifacts = out/'artifacts'; artifacts.mkdir()
transfer = gather_artifacts.transfer(diagnostic,artifacts)
assert transfer['status'] in ('downloaded','already_present'),transfer
service = base64.b64decode(record['queries']['service_journal']['stdout_base64']).decode()
messages = [json.loads(line).get('MESSAGE') for line in service.splitlines() if line.startswith('{')]
summary = {'output':str(out),'snapshot_sha256':SNAPSHOT_SHA,'original_result_sha256':RESULT_SHA,
           'remote_evidence_sha256':sha(result.stdout),'remote_mutation':False,'original_status_unchanged':True,
           'queries':{name:{'exit':row['exit'],'stdout_bytes':row['stdout_bytes'],'stdout_sha256':row['stdout_sha256']} for name,row in record['queries'].items()},
           'stage_receipt_exists':record['stage_receipt_exists'],'service_messages':messages,
           'diagnostic_sha256':DIAGNOSTIC_SHA}
(out/'collection-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
