"""Prepare or collect exact completed Cold B evidence; never launch guest work."""
from __future__ import annotations
import argparse
import base64
import datetime
import hashlib
import inspect
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import traceback

sys.dont_write_bytecode = True
TASK = Path(__file__).resolve().parent
CANDIDATE = 'be576a51d3f4ea203bb1ef298f01b21c9ad4091d09f77cc371da08b26cb6a858'
ROOT = '/opt/song-lua-audit/pass4'
CONTROL = ROOT + '/controls/cold-case-lookup'
UNIT = 'song-lua-pass4-cold-' + CANDIDATE[:12] + '.service'
ARCHIVE_SHA = '5aed0bb71a0e2899c23cbad591d6700c52570ad6bf47a7e6bc5c7a49385589a3'
ARCHIVE_BYTES = 171092157
HELPER_SHA = '14e15e7141dba2046206c7ad7bbf41959ded82a979d1c5d872bbf59b15e2c81f'
LAUNCHER_SHA = 'e7277367089d4228b6aaa443804ef058801b5feb5ddc5b315fb90f3bb7180d77'
TRANSPORT_SHA = '823e2d7a8c7e81951ca4b903d9afab4f73bc5c6391cef3ed0fcbc31fa713c683'
MAX_FILE_BYTES = 256 * 1024**2
MAX_TOTAL_BYTES = 384 * 1024**2
EXPECTED_FRAMES = 1586
EXPECTED_STAGE_SAMPLES = 157


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    Path(path).write_bytes((json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode())


def require_stopped(unit):
    if unit.get('ActiveState') not in ('inactive', 'failed'):
        raise ValueError('Cold unit is still running or its state is unknown')


def require_successful_unit(unit):
    require_stopped(unit)
    if unit.get('ActiveState') != 'inactive' or unit.get('LoadState') not in ('loaded', 'not-found'):
        raise ValueError('Cold unit failed or its completion state is unknown')
    if unit['LoadState'] == 'loaded' and (unit.get('Result') != 'success' or unit.get('ExecMainStatus') != '0'):
        raise ValueError('Cold service result does not confirm successful completion')


def project_report(report):
    names = ('archive_accepted', 'capture_completed_gameplay', 'execution_path',
        'production_preparation_exercised', 'production_gameplay_checks_passed',
        'diagnostic_replay_checks_passed', 'fixture_sha256', 'native_frames',
        'replayed_frames', 'checked_stage_samples', 'compared_stage_fields',
        'diagnostic_compared_stage_fields', 'whole_song_parity_proven', 'pending_coverage')
    result = {name: report.get(name) for name in names}
    for prefix, document in (('', report), ('production_replay.', report.get('production_replay', {}))):
        if not isinstance(document, dict):
            document = {}
        for name in ('errors', 'mismatches'):
            value = document.get(name)
            result[prefix + name + '_count'] = len(value) if isinstance(value, list) else None
        for name in ('native_frames', 'replayed_frames', 'checked_stage_samples', 'compared_stage_fields'):
            result[prefix + name] = document.get(name)
        interactive = document.get('interactive', {})
        if not isinstance(interactive, dict):
            interactive = {}
        for name in ('draw_samples_compared', 'submitted_vertices_compared'):
            result[prefix + 'interactive.' + name] = interactive.get(name)
    return result


def require_report(summary, replay_exit):
    flags = ('archive_accepted', 'capture_completed_gameplay', 'production_preparation_exercised',
             'production_gameplay_checks_passed', 'diagnostic_replay_checks_passed')
    if replay_exit != 0 or any(summary.get(name) is not True for name in flags):
        raise ValueError('Cold replay did not pass every diagnostic/production gate')
    if (summary.get('execution_path') != 'production-and-diagnostic-live-lua'
            or summary.get('fixture_sha256') != ARCHIVE_SHA):
        raise ValueError('Cold report uses a different archive or execution path')
    for prefix in ('', 'production_replay.'):
        if (summary.get(prefix + 'native_frames') != EXPECTED_FRAMES
                or summary.get(prefix + 'replayed_frames') != EXPECTED_FRAMES
                or summary.get(prefix + 'checked_stage_samples') != EXPECTED_STAGE_SAMPLES):
            raise ValueError('Cold replay did not compare every captured frame and eligible stage sample')
        if summary.get(prefix + 'errors_count') != 0 or summary.get(prefix + 'mismatches_count') != 0:
            raise ValueError('Cold replay contains errors or mismatches')
        for name in ('interactive.draw_samples_compared', 'interactive.submitted_vertices_compared'):
            value = summary.get(prefix + name)
            if type(value) is not int or value <= 0:
                raise ValueError('Cold replay lacks actual draw/vertex comparison coverage: ' + prefix + name)
    diagnostic = summary.get('diagnostic_compared_stage_fields')
    production = summary.get('production_replay.compared_stage_fields')
    if (type(diagnostic) is not int or diagnostic <= 0 or type(production) is not int or production <= 0
            or summary.get('compared_stage_fields') != diagnostic + production):
        raise ValueError('Cold stage comparison counters do not account for both execution paths')


REMOTE_COMMON = r'''
import datetime,hashlib,json,pathlib,re,subprocess,sys,tarfile
root=pathlib.Path(config['root']);control=pathlib.Path(config['control'])
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def load(path):return json.loads(path.read_bytes())
def unit_state():
    result=subprocess.run(['systemctl','show',config['unit'],'--property=LoadState,ActiveState,SubState,Result,ExecMainStatus,ExecMainStartTimestamp,ExecMainExitTimestamp'],capture_output=True,text=True,timeout=10)
    state={line.split('=',1)[0]:line.split('=',1)[1] for line in result.stdout.splitlines() if '=' in line}
    state['query_exit']=result.returncode
    require_stopped(state)
    return state
def source_identity():
    repo='/opt/song-lua-audit/deadsync-pass4'
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
        'patch_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=repo)).hexdigest()}
def check_live():
    assert subprocess.check_output(['hostname'],text=True).strip()=='deadsync-lua-20261119-build'
    state=unit_state()
    directory=root/'candidates'/config['candidate']
    build_path=directory/'build-proof.json';source_path=directory/'source-proof.json'
    assert sha(build_path)==config['build_proof_sha256']==sha(root/'proof/build-proof.json')
    assert sha(source_path)==config['source_proof_sha256']==sha(root/'proof/source-proof.json')
    build=load(build_path)
    assert build['passed'] is True and build['candidate']['id']==config['candidate']
    assert build['source_proof_sha256']==config['source_proof_sha256']
    runner=pathlib.Path(build['binaries']['runner']['path'])
    assert runner==root/'bin/full_song_lua'
    assert sha(runner)==config['runner_sha256']==build['binaries']['runner']['sha256']
    return state,source_identity()
'''

REMOTE_METADATA = r'''
state,before=check_live()
latest_path=control/'latest-replay.json';latest=load(latest_path)
attempt=pathlib.Path(latest['attempt'])
assert attempt.parent==control and attempt.resolve()==attempt
assert re.fullmatch('replay-'+re.escape(config['candidate'][:12])+r'-\d{8}T\d{6}Z',attempt.name)
receipt_path=attempt/'receipt.json'
assert sha(receipt_path)==latest['receipt_sha256']
receipt=load(receipt_path)
assert receipt['candidate']==config['candidate'] and receipt['case_id']=='30bd12a3a8b6302a-c0001'
assert latest['passed'] is receipt['passed'] and receipt.get('finished_at')
assert receipt['build_proof_sha256']==config['build_proof_sha256']
assert receipt['source_proof_sha256']==config['source_proof_sha256']
assert receipt['runner_sha256']==config['runner_sha256']
assert receipt['source_before']==receipt['source_after']==before
assert receipt['helper_sha256']==config['helper_sha256']==sha(attempt/'cold_candidate_replay.py')
archive=control/(config['archive_sha256']+'.tar.zst')
assert receipt['archive']['path']==str(archive) and receipt['archive']['bytes']==config['archive_bytes']
assert receipt['archive']['sha256']==config['archive_sha256']==sha(archive)
assert archive.stat().st_size==config['archive_bytes']
assert receipt['command']==[str(root/'bin/full_song_lua'),'--archive',str(archive),'--report',str(attempt/'report.json'),'--production']
files=[];missing=[]
def add(relative,path,required=True):
    if not path.is_file():
        if required:raise ValueError('Required evidence is absent: '+str(path))
        missing.append(relative);return
    assert path.resolve()==path
    size=path.stat().st_size
    assert 0<=size<=config['max_file_bytes']
    files.append({'relative':relative,'path':str(path),'bytes':size,'sha256':sha(path)})
add('latest-replay.json',latest_path)
for name in ('receipt.json','cold_candidate_replay.py','build-proof.json','source-proof.json','manifest.json'):
    add(name,attempt/name)
for name in ('report.json','replay.log'):
    add(name,attempt/name,False)
add('unit.log',control/(config['unit'].removesuffix('.service')+'.log'),False)
assert sum(row['bytes'] for row in files)<=config['max_total_bytes']
assert sha(attempt/'build-proof.json')==config['build_proof_sha256']
assert sha(attempt/'source-proof.json')==config['source_proof_sha256']
if (attempt/'report.json').is_file():
    actual=next(row for row in files if row['relative']=='report.json')
    assert receipt['report']=={'path':actual['path'],'bytes':actual['bytes'],'sha256':actual['sha256']}
after_state,after=check_live();assert after==before
print(json.dumps({'candidate':config['candidate'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'unit':config['unit'],'unit_before':state,'unit_after':after_state,'source_identity':before,
    'latest_sha256':sha(latest_path),'attempt':str(attempt),'files':files,'missing_optional_files':missing,
    'guest_writes':False,'replay_receipt_passed':receipt['passed'],'replay_exit_code':receipt.get('exit_code')}))
'''

REMOTE_DOWNLOAD = r'''
state,before=check_live();assert before==metadata['source_identity']
assert sha(control/'latest-replay.json')==metadata['latest_sha256']
assert len({row['relative'] for row in metadata['files']})==len(metadata['files'])
for row in metadata['files']:
    path=pathlib.Path(row['path']);assert path.resolve()==path and path.is_relative_to(control)
    assert pathlib.PurePosixPath(row['relative']).name==row['relative']
    assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|') as packed:
    for row in metadata['files']:
        path=pathlib.Path(row['path']);info=packed.gettarinfo(str(path),arcname=row['relative'])
        assert info.isfile() and info.size==row['bytes']
        with path.open('rb') as stream:packed.addfile(info,stream)
for row in metadata['files']:
    path=pathlib.Path(row['path']);assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
after_state,after=check_live();assert after==before
assert sha(control/'latest-replay.json')==metadata['latest_sha256']
'''


def verify_transport():
    proof_path = TASK / 'stream-build-worker-transport-proof.json'
    if digest(proof_path) != TRANSPORT_SHA:
        raise ValueError('Builder transport proof changed')
    proof = json.loads(proof_path.read_bytes())
    if (proof.get('passed') is not True or proof.get('vmid') != 1516
            or proof.get('guest_ip') != '192.168.1.41' or proof.get('guest_name') != 'deadsync-lua-20261119-build'):
        raise ValueError('Builder identity does not match1516')
    raw = base64.b64decode(proof['host_files']['build-worker.json']['raw_base64'], validate=True)
    if hashlib.sha256(raw).hexdigest() != proof['host_files']['build-worker.json']['sha256']:
        raise ValueError('Original QGA-verified builder receipt digest differs')
    identity = json.loads(raw)
    if (identity['vmid'] != 1516 or identity['ip'] != proof['guest_ip']
            or identity['name'] != proof['guest_name']
            or identity['host_key'].split()[:2] != proof['expected_host_key'].split()):
        raise ValueError('Original builder receipt names a different guest/key')
    known = Path(proof['known_hosts']['path'])
    if (known.resolve() != (TASK / 'life-event-score-known-hosts').resolve()
            or digest(known) != proof['known_hosts']['sha256']
            or known.read_text().split() != [proof['guest_ip'], *proof['expected_host_key'].split()]):
        raise ValueError('Local SSH host key differs from verified builder identity')
    return proof, known


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build_proof_sha256', 'source_proof_sha256', 'runner_sha256'):
        parser.add_argument(name)
    parser.add_argument('--execute', action='store_true', help='Read/download completed evidence; never start guest work')
    args = parser.parse_args()
    expected = {name: getattr(args, name) for name in ('build_proof_sha256', 'source_proof_sha256', 'runner_sha256')}
    if any(not re.fullmatch('[0-9a-f]{64}', value) for value in expected.values()):
        raise ValueError('Each expected proof/binary digest must be64 lowercase hexadecimal characters')
    transport_proof, known = verify_transport()
    if digest(TASK / 'cold_candidate_replay.py') != HELPER_SHA or digest(TASK / 'launch_cold_candidate_replay.py') != LAUNCHER_SHA:
        raise ValueError('Accepted Cold launch/replay helpers changed')
    config = dict(expected, candidate=CANDIDATE, root=ROOT, control=CONTROL, unit=UNIT,
        helper_sha256=HELPER_SHA, archive_sha256=ARCHIVE_SHA, archive_bytes=ARCHIVE_BYTES,
        max_file_bytes=MAX_FILE_BYTES, max_total_bytes=MAX_TOTAL_BYTES)
    plan = {'candidate': CANDIDATE, 'executed': False, 'inspection_only': True,
        'guest_writes': False, 'unit': UNIT, 'expected': expected, 'guest_ip': transport_proof['guest_ip'],
        'transport_proof_sha256': TRANSPORT_SHA, 'helper_sha256': digest(Path(__file__)),
        'maximum_download_bytes': MAX_TOTAL_BYTES}
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return 0
    if shutil.disk_usage(TASK).free < 2 * MAX_TOTAL_BYTES + 1024**3:
        raise ValueError('Insufficient local room for full evidence and the exact transfer archive')
    import remote
    transport = remote.ssh(transport_proof['guest_ip'])
    transport = ['UserKnownHostsFile=' + str(known) if argument.startswith('UserKnownHostsFile=') else argument for argument in transport]
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    destination = TASK / ('cold-B-evidence-' + stamp)
    destination.mkdir()
    shutil.copyfile(Path(__file__), destination / Path(__file__).name)
    shutil.copyfile(TASK / 'stream-build-worker-transport-proof.json', destination / 'transport-proof.json')
    result = dict(plan, executed=True, passed=False, collection_complete=False, directory=str(destination))
    preamble = 'config=' + repr(config) + '\n' + inspect.getsource(require_stopped) + '\n' + REMOTE_COMMON
    try:
        completed = subprocess.run(transport + ['python3', '-B', '-'], input=(preamble + REMOTE_METADATA).encode(), capture_output=True, timeout=120)
        (destination / 'metadata.stdout').write_bytes(completed.stdout)
        (destination / 'metadata.stderr').write_bytes(completed.stderr)
        result['metadata_exit_code'] = completed.returncode
        if completed.returncode:
            raise ValueError('Remote metadata/identity read failed; exact stderr retained')
        metadata = json.loads(completed.stdout)
        save(destination / 'remote-manifest.json', metadata)
        program = preamble + '\nmetadata=' + repr(metadata) + '\n' + REMOTE_DOWNLOAD
        with (destination / 'evidence.tar').open('xb') as output, (destination / 'download.stderr').open('xb') as error:
            completed = subprocess.run(transport + ['python3', '-B', '-'], input=program.encode(), stdout=output, stderr=error, timeout=300)
        result['download_exit_code'] = completed.returncode
        if completed.returncode:
            raise ValueError('Remote evidence read changed or failed; exact transfer/error preserved')
        expected_files = {row['relative']: row for row in metadata['files']}
        found = set()
        evidence = destination / 'files'
        evidence.mkdir()
        with tarfile.open(destination / 'evidence.tar', mode='r:') as archive:
            for member in archive:
                if member.name not in expected_files or member.name in found or not member.isfile():
                    raise ValueError('Unexpected or duplicate transfer member')
                row = expected_files[member.name]
                if member.size != row['bytes'] or member.size > MAX_FILE_BYTES:
                    raise ValueError('Transfer member exceeds its exact bounded receipt')
                target = evidence / member.name
                with archive.extractfile(member) as source, target.open('xb') as output:
                    shutil.copyfileobj(source, output, 1024**2)
                if digest(target) != row['sha256']:
                    raise ValueError('Downloaded evidence digest differs: ' + member.name)
                found.add(member.name)
        if found != set(expected_files):
            raise ValueError('Transfer omitted an expected evidence member')
        replay_receipt = json.loads((evidence / 'receipt.json').read_bytes())
        report = json.loads((evidence / 'report.json').read_bytes())
        summary = project_report(report)
        save(destination / 'report-summary.json', summary)
        result.update(collection_complete=True, report_sha256=digest(evidence / 'report.json'),
            replay_receipt_sha256=digest(evidence / 'receipt.json'), full_report_retained=True,
            source_unchanged=replay_receipt['source_before'] == replay_receipt['source_after'], summary=summary)
        require_report(summary, replay_receipt.get('exit_code'))
        require_successful_unit(metadata['unit_before'])
        require_successful_unit(metadata['unit_after'])
        if replay_receipt.get('passed') is not True or metadata['replay_receipt_passed'] is not True:
            raise ValueError('Original Cold receipt does not declare successful replay')
        result['passed'] = True
    except BaseException as error:
        result.update(passed=False, error=str(error), traceback=traceback.format_exc())
    finally:
        result['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(destination / 'collection-receipt.json', result)
        files = [{'path': path.relative_to(destination).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest(path)}
            for path in sorted(destination.rglob('*')) if path.is_file()]
        save(destination / 'manifest.json', {'schema_version': 1, 'files': files})
        print(json.dumps({'directory': str(destination), 'passed': result['passed'],
            'collection_complete': result['collection_complete'], 'error': result.get('error'),
            'receipt_sha256': digest(destination / 'collection-receipt.json'),
            'manifest_sha256': digest(destination / 'manifest.json')}, indent=2))
    return 0 if result['passed'] else 2 if result['collection_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
