#!/usr/bin/env python3
"""Bind a passed final runner to the retained complete streaming native pilot.

This creates a separate capture profile. It never captures again, compiles,
changes the corpus, or replaces global executables/proofs. Failed attempts stay.
"""
from __future__ import annotations
import argparse
import copy
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import traceback
from types import SimpleNamespace

ROOT = Path('/opt/song-lua-audit/pass4')
STREAM_PROFILE = '2b4198134cd096549d4dc99c382a5920ee8eabbae3de4eab829ec704882896a9'
STREAM_CLI = '1780c9e517994285775fa75c98c1975c601be0f94c4ad1a376cab16bd8684e8e'
ENGINE_SHA = 'c03763cac1270c14dbe790cbb055c96ebbced269448d64e0bb705385dc9537a3'
WORKER_SHA = '4155f85dc78eaee40189d8ee5e2a9b177be8b8ad36093b6a4706a098ec9b0e72'
CONTROL = ROOT / 'controls/stream-native-d782ac54fc3b5e1b1ddc'
CONTROL_SHA = 'e814cbcf18869d6c1685684ba2c318338173081eb824a3a37bf517773c15b3d3'
BUILD_SHA = '6d525af7a4542af1ce2510b3a2cd8ec96b0269c47be5573139ac13a7c17920ad'
ATTESTATION_SHA = 'a1876857a2b47c6a3712489ec72a215afedf3dcc6469056fced2946fafb8f37b'
TRACE_SHA = 'e0fb31047f17477d8ee4c56ad12a9231d5ac323937031fa6c85c5ac6d50d9043'
COMMIT = 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c'
NATIVE_REVISION = '663525dcb86eb570d0ef6a2e209678436660ae26'
OBSERVATION_FIELDS = {
    'checked_stage_samples', 'diagnostic_compared_stage_fields',
    'interactive.draw_samples_compared', 'interactive.submitted_vertices_compared',
    'production_replay.native_frames', 'production_replay.replayed_frames',
    'production_replay.checked_stage_samples', 'production_replay.compared_stage_fields',
    'production_replay.interactive.draw_samples_compared',
    'production_replay.interactive.submitted_vertices_compared',
}
sys.dont_write_bytecode = True


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def file_record(path):
    path = Path(path)
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def publish_capture_profile(path, profile, result, writer=save):
    result['passed'] = False
    writer(path, profile)
    result['passed'] = True


def observation_coverage(path):
    """Read actual emitted counters without changing the frozen worker summary."""
    import ijson
    observed = {}
    with Path(path).open('rb') as stream:
        for prefix, event, value in ijson.parse(stream, use_float=True):
            if prefix in OBSERVATION_FIELDS and event not in {'map_key', 'end_map', 'end_array'}:
                if event != 'number' or type(value) is not int:
                    raise ValueError('noninteger comparison coverage counter: ' + prefix)
                observed[prefix] = value
    return observed


def require_combined_report(report, archive_sha, native_frames, exit_code, observed):
    required = ('archive_accepted', 'capture_completed_gameplay',
                'production_preparation_exercised', 'production_gameplay_checks_passed',
                'diagnostic_replay_checks_passed')
    if exit_code != 0 or any(report.get(name) is not True for name in required):
        raise ValueError('combined control did not pass all native/production/diagnostic acceptance gates')
    if (native_frames <= 0 or report.get('native_frames') != native_frames
            or report.get('replayed_frames') != native_frames
            or report.get('fixture_sha256') != archive_sha
            or report.get('mismatch_count') != 0 or report.get('error_count') != 0
            or report.get('execution_path') != 'production-and-diagnostic-live-lua'):
        raise ValueError('combined control has incomplete frames, mismatches, errors, or a different archive/path')
    if set(observed) != OBSERVATION_FIELDS:
        raise ValueError('combined control lacks actual stage/draw/vertex comparison counters')
    if any(type(value) is not int or value <= 0 for value in observed.values()):
        raise ValueError('combined control did not exercise both stage/draw/vertex comparison paths')
    # The immutable trace contains 17 stage records. The comparator explicitly
    # excludes overlay-init; 1 active + 13 progress + 1 end + 1 exit are compared.
    if (observed['checked_stage_samples'] != 16
            or observed['production_replay.checked_stage_samples'] != 16
            or observed['production_replay.native_frames'] != native_frames
            or observed['production_replay.replayed_frames'] != native_frames):
        raise ValueError('combined control did not compare every eligible stage sample/frame in both paths')
    if (type(report.get('compared_stage_fields')) is not int or report['compared_stage_fields'] <= 0
            or report['compared_stage_fields'] != observed['diagnostic_compared_stage_fields']
                + observed['production_replay.compared_stage_fields']):
        raise ValueError('combined stage field counts do not match the actual two replay paths')


def idle(own_unit):
    result = subprocess.run(['systemctl', 'list-units', '--state=active,activating,deactivating,reloading',
        '--plain', '--no-pager', '--no-legend', 'song-lua-pass4-*', 'deadsync-lua-pass4-*',
        'itgmania-stream-build-*', 'itgmania-stream-control-*'], capture_output=True, text=True, check=True)
    busy = [line.split()[0] for line in result.stdout.splitlines() if line.strip()
        and line.split()[0] != own_unit and line.split()[0].endswith('.service')
        and re.search(r'(worker|discovery|catalog|capture|archive|replay|pack|pilot|candidate|build|control|retry)', line.split()[0])]
    if busy:
        raise ValueError('builder still has active task work: ' + repr(busy))


def main():
    import fcntl
    here = Path(__file__).resolve().parent
    manifest = load(here / 'manifest.json')
    contract = manifest['contract']
    assert manifest['id'] == identity(contract)
    assert here == ROOT / 'capture-profiles' / manifest['id']
    assert subprocess.check_output(['hostname'], text=True).strip() == 'deadsync-lua-20261119-build'
    for name, expected in contract['inputs'].items():
        assert Path(name).name == name and sha(here / name) == expected, name
    assert sha(here / 'worker.py') == WORKER_SHA
    assert sha(here / 'stream-commit-attestation.json') == ATTESTATION_SHA
    assert not (here / 'state.json').exists(), 'Preserve this existing attempt; use a new contract attempt token'
    locks = []
    for name in ('candidate-runner.lock', 'fleet-orchestration.lock'):
        handle = (ROOT / name).open('a')
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        locks.append(handle)
    idle('itgmania-stream-control-' + manifest['id'][:12] + '.service')
    assert shutil.disk_usage(here).free >= 20 * 1024**3
    result = {'passed': False, 'started_at': now(), 'candidate': contract['candidate'],
              'profile': manifest['id'], 'helper_sha256': sha(Path(__file__)),
              'native_capture_rerun': False, 'global_profile_published': False}
    stage = 'preflight'
    try:
        save(here / 'state.json', {'active': True, 'stage': stage, 'at': now()})
        candidate = ROOT / 'candidates' / contract['candidate']
        build_path, source_path = candidate / 'build-proof.json', candidate / 'source-proof.json'
        assert sha(build_path) == contract['build_proof_sha256']
        assert sha(source_path) == contract['source_proof_sha256']
        build, source = load(build_path), load(source_path)
        assert build['passed'] is True and build['candidate']['id'] == contract['candidate']
        assert build['source_proof_sha256'] == contract['source_proof_sha256']
        assert sha(ROOT / 'proof/build-proof.json') == contract['build_proof_sha256']
        assert sha(ROOT / 'proof/source-proof.json') == contract['source_proof_sha256']
        runner = Path(build['binaries']['runner']['path'])
        engine = Path(build['binaries']['native']['path'])
        assert runner == ROOT / 'bin/full_song_lua'
        assert sha(runner) == contract['runner_sha256'] == build['binaries']['runner']['sha256']
        assert sha(engine) == ENGINE_SHA == build['binaries']['native']['sha256']
        old_cli = Path(build['binaries']['harness']['path'])
        assert sha(old_cli) == build['binaries']['harness']['sha256']
        stream_dir = ROOT / 'capture-profiles' / STREAM_PROFILE
        assert sha(stream_dir / 'build-receipt.json') == BUILD_SHA
        assert sha(CONTROL / 'control-receipt.json') == CONTROL_SHA
        stream_build, native_control = load(stream_dir / 'build-receipt.json'), load(CONTROL / 'control-receipt.json')
        assert stream_build['passed'] and native_control['passed']
        assert native_control['cli'] == stream_build['cli']
        assert stream_build['cli']['sha256'] == STREAM_CLI
        source_cli = Path(stream_build['cli']['path'])
        assert sha(source_cli) == STREAM_CLI
        assert source_cli.is_relative_to(stream_dir)
        attestation = load(here / 'stream-commit-attestation.json')
        assert attestation['passed'] and attestation['harness_commit'] == COMMIT
        assert attestation['cli'] == stream_build['cli']
        assert attestation['source_patch']['sha256'] == stream_build['source_patch_sha256']
        assert attestation['source_inventory_sha256'] == stream_build['source_files_sha256']
        inventory_path = Path(stream_build['source_root']).parent / 'source-files-before.json'
        assert sha(inventory_path) == stream_build['source_files_sha256']
        inventory = load(inventory_path)
        assert len(inventory) == attestation['compiled_source_files_verified'] == 409
        for relative, expected in inventory.items():
            assert sha(Path(stream_build['source_root']) / relative) == expected, relative
        ordinary = native_control['ordinary_control']
        original_trace = Path(ordinary['trace']['path'])
        assert ordinary['passed'] and sha(original_trace) == TRACE_SHA == ordinary['trace']['sha256']
        pilot_identity_path = CONTROL / 'pilot-source-identity.json'
        pilot_identity = load(pilot_identity_path)
        pilot = ROOT / 'pilot/input/Songs/fleet-pilot/control.ssc'
        for name, expected in pilot_identity['files'].items():
            assert Path(name).name == name and sha(pilot.parent / name) == expected
        worker_spec = importlib.util.spec_from_file_location('stream_combined_worker', here / 'worker.py')
        worker = importlib.util.module_from_spec(worker_spec)
        worker_spec.loader.exec_module(worker)
        native_root = engine.parent
        assert subprocess.check_output(['git', '-C', str(native_root), 'rev-parse', 'HEAD'], text=True).strip() == NATIVE_REVISION
        assert subprocess.run(['git', '-C', str(native_root), 'diff', '--quiet', 'HEAD', '--', 'src']).returncode == 0
        theme, noteskins = native_root / 'Themes/Harness Simply Love', native_root / 'NoteSkins'
        workspace = Path(source['repositories']['deadsync']['path'])
        replay_assets = workspace / 'assets'
        for relative, expected in source['repositories']['deadsync']['files_sha256'].items():
            if relative.startswith('assets/'):
                assert sha(workspace / relative) == expected, relative
        original_inputs = native_control['original_inputs_verified']
        asset_trees = {'theme': worker.tree_digest(theme), 'noteskins': worker.tree_digest(noteskins),
                       'replay_assets': worker.tree_digest(replay_assets), 'pilot': worker.tree_digest(pilot.parent)}
        assert asset_trees['theme'] == original_inputs['theme_tree_sha256']
        assert asset_trees['noteskins'] == original_inputs['noteskins_tree_sha256']
        assert sha(ROOT / 'corpus-manifest.json') == original_inputs['corpus_sha256']
        baseline_paths = [runner, engine, old_cli, source_cli, ROOT / 'worker.py',
            ROOT / 'proof/build-proof.json', ROOT / 'proof/source-proof.json', ROOT / 'corpus-manifest.json',
            original_trace, CONTROL / 'control-receipt.json', stream_dir / 'build-receipt.json']
        before = {str(path): sha(path) for path in baseline_paths}
        save(here / 'baseline-before.json', before)
        for original, name in [(build_path, 'runner-build-proof.json'), (source_path, 'runner-source-proof.json'),
            (stream_dir / 'build-receipt.json', 'stream-build-receipt.json'),
            (CONTROL / 'control-receipt.json', 'native-control-receipt.json'),
            (pilot_identity_path, 'pilot-source-identity.json'), (inventory_path, 'harness-source-files.json')]:
            shutil.copyfile(original, here / name)
        (here / 'bin').mkdir()
        cli = here / 'bin/itgmania-harness-rs'
        shutil.copy2(source_cli, cli)
        assert sha(cli) == STREAM_CLI
        trace = here / 'ordinary/traces/native.json'
        trace.parent.mkdir(parents=True)
        shutil.copyfile(original_trace, trace)
        assert sha(trace) == TRACE_SHA
        summary = worker.document_summary(trace)
        frames = worker.validate_native(trace, summary,
            {'chart_index': pilot_identity['starting_chart']['index'], 'expected_chart': pilot_identity['starting_chart']},
            NATIVE_REVISION, screen_gameplay_sha256=original_inputs['screen_gameplay_sha256'])
        assert frames == ordinary['native_frames'] == 228
        assert summary['capabilities']['native_drawable_vertices'] is True
        import collections
        import ijson
        with trace.open('rb') as stream:
            phases = collections.Counter(row['phase'] for row in ijson.items(stream, 'stage_samples.item'))
        assert phases == {'overlay-init': 1, 'screen-active': 1, 'progress': 13, 'screen-end': 1, 'gameplay-exit': 1}
        result['native_stage_observations'] = {'phases': dict(phases), 'recorded': 17,
                                              'compared_per_path': 16, 'excluded_phase': 'overlay-init'}
        worker.write_json(trace.parent / '_semantic_manifest.json', {
            'fixture_schema_version': 1, 'oracle_schema_version': summary['schema_version'],
            'harness_version': summary['harness_version'],
            'itgmania': {'git_revision': NATIVE_REVISION, 'git_dirty': 'false'},
            'simfiles': [{'simfile': 'fleet-pilot/control.ssc', 'fixture': 'native.json',
                         'title': 'Fleet pipeline pilot', 'status': 'ok',
                         'command_observer': summary['command_observer']}]})
        args = SimpleNamespace(root=here, display=':99', noteskins=noteskins, user='parity',
            binary_stats={str(path): (path.stat().st_size, path.stat().st_mtime_ns) for path in (cli, engine, runner)})
        binding = {'candidate': contract['candidate'], 'runner_sha256': contract['runner_sha256'],
                   'native_trace_sha256': TRACE_SHA, 'harness_sha256': STREAM_CLI, 'engine_sha256': ENGINE_SHA,
                   'stream_commit_attestation_sha256': ATTESTATION_SHA,
                   'runner_build_proof_sha256': contract['build_proof_sha256']}
        stage = 'archive'
        save(here / 'state.json', {'active': True, 'stage': stage, 'at': now()})
        archive_dir = here / 'ordinary/candidate'
        archive_receipt = worker.execute_stage(args, here / 'ordinary', 'archive',
            [cli, 'song-lua-archive', pilot.parent.parent, '--traces', trace.parent,
             '--out', archive_dir, '--uncompressed', '--theme-assets', theme], 900, '6G', binding)
        result['archive_stage'] = archive_receipt
        assert archive_receipt['exit'] == 0
        entries = load(archive_dir / 'index.json')['archives']
        assert len(entries) == 1
        archive = worker.checked_relative(archive_dir, entries[0]['archive'])
        archive_sha = sha(archive)
        assert archive.name == archive_sha + '.tar'
        stage = 'combined-replay'
        save(here / 'state.json', {'active': True, 'stage': stage, 'at': now()})
        report_path = here / 'ordinary/report.json'
        replay_receipt = worker.execute_stage(args, here / 'ordinary', 'replay',
            [runner, '--archive', archive, '--report', report_path, '--production'], 1800, '6G',
            {**binding, 'candidate_sha256': archive_sha})
        result['replay_stage'] = replay_receipt
        report = worker.document_summary(report_path, report=True)
        result['summary'] = report
        result['report'] = file_record(report_path)
        observed = observation_coverage(report_path)
        result['observation_coverage'] = observed
        require_combined_report(report, archive_sha, frames, replay_receipt['exit'], observed)
        assert {str(path): sha(path) for path in baseline_paths} == before
        assert sha(trace) == TRACE_SHA and sha(archive) == archive_sha
        assert asset_trees == {'theme': worker.tree_digest(theme), 'noteskins': worker.tree_digest(noteskins),
                              'replay_assets': worker.tree_digest(replay_assets), 'pilot': worker.tree_digest(pilot.parent)}
        save(here / 'baseline-after.json', before)
        combined = {**file_record(report_path), 'harness_sha256': STREAM_CLI,
                    'engine_sha256': ENGINE_SHA, 'runner_sha256': contract['runner_sha256'],
                    'observation_coverage': observed}
        # Preserve the passed runner source proof, replacing only the capture
        # component with the independently proved canonical-export source.
        composed_source = copy.deepcopy(source)
        composed_source['created_at'] = now()
        composed_source['pins']['harness'] = COMMIT
        composed_source['repositories']['harness'] = {
            'path': stream_build['source_root'], 'revision': COMMIT,
            'snapshot_kind': 'canonical-git-export-plus-verified-patch',
            'committed_tree': attestation['git_tree'], 'files_sha256': inventory,
            'commit_attestation_sha256': ATTESTATION_SHA}
        composed_source['harness_base_revision'] = stream_build['harness_base_revision']
        composed_source['harness_upstream_base_revision'] = attestation['harness_upstream_base']
        composed_source['harness_bundle_sha256'] = attestation['git_bundle']['sha256']
        composed_source['harness_candidate_patch_sha256'] = stream_build['source_patch_sha256']
        composed_source['capture_profile'] = {
            'id': manifest['id'], 'runner_source_proof': file_record(here / 'runner-source-proof.json'),
            'stream_build_receipt': file_record(here / 'stream-build-receipt.json'),
            'stream_commit_attestation': file_record(here / 'stream-commit-attestation.json'),
            'native_control_receipt': file_record(here / 'native-control-receipt.json'),
            'combined_control': combined}
        proof_dir = here / 'proof'
        save(proof_dir / 'source-proof.json', composed_source)
        composed_build = {
            'passed': True, 'kind': 'composed-components-verified-by-complete-combined-control',
            'created_at': now(), 'candidate': build['candidate'], 'pins': composed_source['pins'],
            'source_proof_sha256': sha(proof_dir / 'source-proof.json'),
            'binaries': {'harness': file_record(cli), 'native': file_record(engine), 'runner': file_record(runner)},
            'runner_build_proof': file_record(here / 'runner-build-proof.json'),
            'stream_build_receipt': file_record(here / 'stream-build-receipt.json'),
            'native_control_receipt': file_record(here / 'native-control-receipt.json'),
            'combined_control': combined, 'global_profile_published': False}
        save(proof_dir / 'build-proof.json', composed_build)
        paths = {'harness': str(cli), 'runner': str(runner), 'engine': str(engine), 'theme': str(theme),
                 'noteskins': str(noteskins), 'replay_assets': str(replay_assets),
                 'source_proof': str(proof_dir / 'source-proof.json'), 'build_proof': str(proof_dir / 'build-proof.json')}
        parser = argparse.ArgumentParser()
        worker.add_common_arguments(parser)
        arguments = ['--worker', 'stream-final-combined', '--root', str(here), '--headless', '--production',
                     '--songs', str(ROOT / 'Songs'), '--corpus-manifest', str(ROOT / 'corpus-manifest.json')]
        for name, value in paths.items():
            arguments.extend(['--' + name.replace('_', '-'), value])
        validated = worker.prepare_arguments(parser.parse_args(arguments))
        assert validated.pins['harness_sha256'] == STREAM_CLI
        assert validated.pins['engine_sha256'] == ENGINE_SHA
        assert validated.pins['runner_sha256'] == contract['runner_sha256']
        profile = {'paths': paths, 'pins': validated.pins, 'combined_control': combined}
        stage = 'publish-profile'
        result.update(native_frames=frames, native_trace=file_record(trace),
            archive=file_record(archive), combined_control=combined, asset_trees=asset_trees,
            candidate_build_proof_sha256=contract['build_proof_sha256'],
            candidate_source_proof_sha256=contract['source_proof_sha256'],
            fixture_sha256=report['fixture_sha256'], capture_completed_gameplay=report['capture_completed_gameplay'],
            source_proof=file_record(proof_dir / 'source-proof.json'), build_proof=file_record(proof_dir / 'build-proof.json'),
            global_inputs_unchanged=True, capture_profile=profile)
        publish_capture_profile(here / 'capture-profile.json', profile, result)
    except BaseException as error:
        result.update(passed=False, failed_stage=stage, error=str(error), traceback=traceback.format_exc())
        proof = here / 'proof/build-proof.json'
        if proof.is_file():
            shutil.copyfile(proof, here / 'build-proof.before-final-validation-failure.json')
            failed = load(proof)
            failed.update(passed=False, final_validation_error=str(error))
            save(proof, failed)
    finally:
        result['finished_at'] = now()
        save(here / 'combined-control-receipt.json', result)
        save(here / 'state.json', {'active': False, 'passed': result['passed'],
                                 'stage': 'complete' if result['passed'] else 'failed', 'at': now()})
        print(json.dumps({'passed': result['passed'], 'profile': manifest['id'],
            'receipt': file_record(here / 'combined-control-receipt.json'),
            'failed_stage': result.get('failed_stage'), 'error': result.get('error')}, indent=2), flush=True)
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
