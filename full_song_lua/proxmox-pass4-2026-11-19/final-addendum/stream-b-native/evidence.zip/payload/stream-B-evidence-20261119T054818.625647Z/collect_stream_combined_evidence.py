"""Read/download one completed final-B stream profile from its exact launch files."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import traceback

sys.dont_write_bytecode = True
TASK = Path(__file__).resolve().parent
COLD_COLLECTOR_SHA = '25f5300c109549fac66e042a9c7865ac0a1d89cff5774fd888f0b045f28bf1e6'
CONTROL_SHA = '7858d16eed264e1816642d51d41d71bd26e5be35c5349ee9f4137b950baacb6f'
LAUNCHER_SHA = 'f6ae5aeef72897e7446e323531878208dea55f02d2bba7cfb59f8fd069b6f211'
B_ID = 'be576a51d3f4ea203bb1ef298f01b21c9ad4091d09f77cc371da08b26cb6a858'
MAX_FILE_BYTES = 256 * 1024**2
MAX_TOTAL_BYTES = 384 * 1024**2


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    Path(path).write_bytes((json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode())


def pinned_module(name, filename, expected):
    path = TASK / filename
    if sha(path) != expected:
        raise ValueError('Accepted dependency changed: ' + filename)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def require_launch_data(manifest, launch, expected):
    contract = manifest['contract']
    identifier = manifest['id']
    if identifier != identity(contract) or contract.get('candidate') != B_ID:
        raise ValueError('Launch manifest does not identify the exact B profile')
    if any(contract.get(name) != value for name, value in expected.items()):
        raise ValueError('Launch contract differs from supplied B build/source/runner proofs')
    guest = '/opt/song-lua-audit/pass4/capture-profiles/' + identifier
    unit = 'itgmania-stream-control-' + identifier[:12] + '.service'
    if (launch.get('executed') is not True or launch.get('launch_exit_code') != 0
            or launch.get('candidate') != B_ID or launch.get('guest_directory') != guest
            or launch.get('unit') != unit or launch.get('launch_helper_sha256') != LAUNCHER_SHA):
        raise ValueError('Launch result does not confirm the exact profile/unit')
    outputs = {'receipt': guest + '/combined-control-receipt.json',
        'capture_profile': guest + '/capture-profile.json', 'combined_report': guest + '/ordinary/report.json'}
    if launch.get('outputs') != outputs:
        raise ValueError('Launch result names different evidence outputs')
    return guest, unit


def require_stopped(unit):
    if unit.get('ActiveState') not in ('inactive', 'failed'):
        raise ValueError('Stream control unit is still running or its state is unknown')


def report_contract(document, control):
    """Project actual JSON using the frozen worker's report-summary fields."""
    fields = {'archive_accepted', 'fixture_sha256', 'native_frames', 'replayed_frames',
        'compared_stage_fields', 'execution_path', 'whole_song_parity_proven', 'pending_coverage',
        'capture_completed_gameplay', 'production_preparation_exercised', 'production_parity_proven',
        'production_gameplay_checks_passed', 'diagnostic_replay_checks_passed', 'acceptance_basis', 'diagnostic_only'}
    if not isinstance(document.get('errors'), list) or not isinstance(document.get('mismatches'), list):
        raise ValueError('Full combined report is missing its diagnostic result arrays')
    if document['errors'] or document['mismatches']:
        raise ValueError('Full combined report contains diagnostic errors or mismatches')
    production = document.get('production_replay')
    if (not isinstance(production, dict) or production.get('errors') != [] or production.get('mismatches') != []):
        raise ValueError('Full combined report contains or omits production result arrays')
    summary = {key: value for key, value in document.items() if key in fields or key.startswith('dropped_')}
    summary.update(mismatch_count=0, mismatch_fields={}, first_mismatches=[], error_count=0, errors=[])
    observed = {}
    for field in control.OBSERVATION_FIELDS:
        value = document
        for part in field.split('.'):
            value = value[part]
        observed[field] = value
    return summary, observed


REMOTE_METADATA = r'''
state,before=check_live()
manifest_path=control/'manifest.json'
assert sha(manifest_path)==config['manifest_sha256']
manifest=load(manifest_path);assert manifest==config['manifest']
for name,expected in manifest['contract']['inputs'].items():
    assert pathlib.PurePosixPath(name).name==name and sha(control/name)==expected
status=load(control/'state.json');assert status['active'] is False
receipt=load(control/'combined-control-receipt.json')
assert receipt['candidate']==config['candidate'] and receipt['profile']==manifest['id']
assert receipt.get('finished_at') and receipt['native_capture_rerun'] is False and receipt['global_profile_published'] is False
assert status['passed'] is receipt['passed']
children={}
for stage in ('archive','replay'):
    child=receipt.get(stage+'_stage',{}).get('unit')
    if child:
        child=child.removesuffix('.service')+'.service'
        assert re.fullmatch('song-lua-pass4-'+stage+'-[0-9a-f]{20}'+r'\.service',child)
        query=subprocess.run(['systemctl','show',child,'--property=LoadState,ActiveState,SubState,Result,ExecMainStatus'],capture_output=True,text=True,timeout=10)
        value={line.split('=',1)[0]:line.split('=',1)[1] for line in query.stdout.splitlines() if '=' in line}
        require_stopped(value);children[child]=value
build=load(root/'proof/build-proof.json')
baseline={}
baseline_path=control/'baseline-before.json'
if baseline_path.exists():
    baseline=load(baseline_path)
    expected_paths={str(root/'bin/full_song_lua'),build['binaries']['native']['path'],build['binaries']['harness']['path'],
        config['stream_cli_path'],str(root/'worker.py'),str(root/'proof/build-proof.json'),str(root/'proof/source-proof.json'),
        str(root/'corpus-manifest.json'),config['original_trace_path'],config['native_control_path'],config['stream_build_path']}
    assert set(baseline)==expected_paths
    for name,expected in baseline.items():assert sha(pathlib.Path(name))==expected
    if (control/'baseline-after.json').exists():assert load(control/'baseline-after.json')==baseline
assert sha(pathlib.Path(build['binaries']['native']['path']))==config['engine_sha256']==build['binaries']['native']['sha256']
assert sha(pathlib.Path(build['binaries']['harness']['path']))==build['binaries']['harness']['sha256']
files=[];missing=[];profile_binaries={}
def add(relative,required=False):
    path=control/relative
    if not path.is_file():
        if required:raise ValueError('Required completed-control evidence is absent: '+relative)
        missing.append(relative);return
    assert path.resolve()==path and path.is_relative_to(control)
    size=path.stat().st_size;assert 0<=size<=config['max_file_bytes']
    files.append({'relative':relative,'path':str(path),'bytes':size,'sha256':sha(path)})
for name in ('manifest.json','state.json','combined-control-receipt.json',*manifest['contract']['inputs']):add(name,True)
for name in ('controller.log','runner-build-proof.json','runner-source-proof.json','stream-build-receipt.json',
    'native-control-receipt.json','pilot-source-identity.json','harness-source-files.json','baseline-before.json',
    'baseline-after.json','capture-profile.json','proof/build-proof.json','proof/source-proof.json',
    'build-proof.before-final-validation-failure.json','ordinary/report.json','ordinary/traces/native.json',
    'ordinary/traces/_semantic_manifest.json','ordinary/candidate/index.json'):add(name)
for stage in ('archive','replay'):
    for name in ('spec.json','receipt.json','output.log','launch.json','journal.log'):add('ordinary/stages/'+stage+'/'+name)
assert sum(row['bytes'] for row in files)<=config['max_total_bytes']
if receipt['passed']:
    assert baseline and (control/'baseline-after.json').exists()
    composed=load(control/'proof/build-proof.json')
    for name,path,expected in (
        ('harness',control/'bin/itgmania-harness-rs',config['stream_cli_sha256']),
        ('native',pathlib.Path(build['binaries']['native']['path']),config['engine_sha256']),
        ('runner',root/'bin/full_song_lua',config['runner_sha256'])):
        record=composed['binaries'][name]
        assert record['path']==str(path) and record['sha256']==expected==sha(path) and record['bytes']==path.stat().st_size
        profile_binaries[str(path)]=expected
    archive=pathlib.Path(receipt['archive']['path'])
    assert archive.parent==control/'ordinary/candidate' and archive.name==receipt['archive']['sha256']+'.tar'
    assert archive.stat().st_size==receipt['archive']['bytes'] and sha(archive)==receipt['archive']['sha256']
after_state,after=check_live();assert after==before
print(json.dumps({'candidate':config['candidate'],'profile':manifest['id'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'unit':config['unit'],'unit_before':state,'unit_after':after_state,'child_units':children,'source_identity':before,
    'files':files,'missing_optional_files':missing,'global_baseline':baseline,'profile_binaries':profile_binaries,'guest_writes':False,
    'combined_receipt_passed':receipt['passed'],'receipt_sha256':sha(control/'combined-control-receipt.json')}))
'''

REMOTE_DOWNLOAD = r'''
state,before=check_live();assert before==metadata['source_identity']
assert sha(control/'manifest.json')==config['manifest_sha256']
assert sha(control/'combined-control-receipt.json')==metadata['receipt_sha256']
for name,expected in metadata['global_baseline'].items():assert sha(pathlib.Path(name))==expected
for name,expected in metadata['profile_binaries'].items():assert sha(pathlib.Path(name))==expected
assert len({row['relative'] for row in metadata['files']})==len(metadata['files'])
for row in metadata['files']:
    path=pathlib.Path(row['path']);relative=pathlib.PurePosixPath(row['relative'])
    assert not relative.is_absolute() and '..' not in relative.parts and path==control/relative
    assert path.resolve()==path and path.is_relative_to(control)
    assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|') as packed:
    for row in metadata['files']:
        path=pathlib.Path(row['path']);info=packed.gettarinfo(str(path),arcname=row['relative'])
        assert info.isfile() and info.size==row['bytes']
        with path.open('rb') as stream:packed.addfile(info,stream)
for row in metadata['files']:
    path=pathlib.Path(row['path']);assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
after_state,after=check_live();assert after==before
for name,expected in metadata['global_baseline'].items():assert sha(pathlib.Path(name))==expected
for name,expected in metadata['profile_binaries'].items():assert sha(pathlib.Path(name))==expected
'''


def validate_profile(files, metadata, config, control_module, cold):
    receipt = load(files / 'combined-control-receipt.json')
    state = load(files / 'state.json')
    if (receipt.get('passed') is not True or state.get('active') is not False or state.get('passed') is not True
            or receipt.get('global_inputs_unchanged') is not True or receipt.get('global_profile_published') is not False):
        raise ValueError('Combined control did not finish with unchanged global inputs and a passed receipt')
    cold.require_successful_unit(metadata['unit_before'])
    cold.require_successful_unit(metadata['unit_after'])
    for unit in metadata['child_units'].values():
        cold.require_successful_unit(unit)
    for name in ('build_proof_sha256', 'source_proof_sha256'):
        if receipt.get('candidate_' + name) != config[name]:
            raise ValueError('Combined receipt uses a different B proof')
    if receipt.get('native_frames') != 228 or receipt.get('native_capture_rerun') is not False:
        raise ValueError('Combined receipt did not reuse the complete retained native pilot')
    def record_matches(record, relative):
        path = files / relative
        if record != {'path':config['control'] + '/' + relative, 'sha256':sha(path), 'bytes':path.stat().st_size}:
            raise ValueError('Receipt file binding differs: ' + relative)
    record_matches(receipt['native_trace'], 'ordinary/traces/native.json')
    if receipt['native_trace']['sha256'] != control_module.TRACE_SHA:
        raise ValueError('Retained native pilot changed')
    record_matches(receipt['report'], 'ordinary/report.json')
    record_matches(receipt['source_proof'], 'proof/source-proof.json')
    record_matches(receipt['build_proof'], 'proof/build-proof.json')
    profile = load(files / 'capture-profile.json')
    build = load(files / 'proof/build-proof.json')
    source = load(files / 'proof/source-proof.json')
    if (build.get('passed') is not True or build.get('candidate', {}).get('id') != B_ID
            or build.get('global_profile_published') is not False
            or build.get('source_proof_sha256') != sha(files / 'proof/source-proof.json')):
        raise ValueError('Composed build proof does not bind the exact passed profile/source')
    if profile != receipt.get('capture_profile'):
        raise ValueError('Published capture profile differs from its completed receipt')
    if source['capture_profile']['id'] != metadata['profile'] or source['pins']['harness'] != control_module.COMMIT:
        raise ValueError('Composed source proof identifies a different capture source/profile')
    original_source = load(files / 'runner-source-proof.json')
    if (sha(files / 'runner-source-proof.json') != config['source_proof_sha256']
            or sha(files / 'runner-build-proof.json') != config['build_proof_sha256']
            or source['repositories']['deadsync'] != original_source['repositories']['deadsync']):
        raise ValueError('Composed source proof changed the independently built B product source')
    record_matches(build['runner_build_proof'], 'runner-build-proof.json')
    record_matches(source['capture_profile']['runner_source_proof'], 'runner-source-proof.json')
    for name in ('stream_build_receipt', 'native_control_receipt'):
        relative = name.replace('_', '-') + '.json'
        record_matches(build[name], relative)
        record_matches(source['capture_profile'][name], relative)
    expected_binary = {'harness': control_module.STREAM_CLI, 'native': control_module.ENGINE_SHA,
                       'runner': config['runner_sha256']}
    for name, expected in expected_binary.items():
        if build['binaries'][name]['sha256'] != expected:
            raise ValueError('Composed binary identity differs: ' + name)
    for name, expected in (('harness_sha256', control_module.STREAM_CLI), ('engine_sha256', control_module.ENGINE_SHA),
                          ('runner_sha256', config['runner_sha256']), ('source_proof_sha256', sha(files/'proof/source-proof.json')),
                          ('binary_proof_sha256', sha(files/'proof/build-proof.json'))):
        if profile['pins'].get(name) != expected:
            raise ValueError('Worker capture-profile pin differs: ' + name)
    if (profile['paths']['source_proof'] != config['control'] + '/proof/source-proof.json'
            or profile['paths']['build_proof'] != config['control'] + '/proof/build-proof.json'
            or profile['paths']['harness'] != config['control'] + '/bin/itgmania-harness-rs'
            or profile['paths']['runner'] != '/opt/song-lua-audit/pass4/bin/full_song_lua'):
        raise ValueError('Capture profile points outside the composed proof/binary locations')
    combined = receipt['combined_control']
    if combined != profile['combined_control'] or combined != build['combined_control'] or combined != source['capture_profile']['combined_control']:
        raise ValueError('Composed profile/proofs do not share one exact combined-control binding')
    if any(combined.get(name) != value for name,value in receipt['report'].items()):
        raise ValueError('Combined-control report bytes differ from the retained report')
    for name, expected in (('harness_sha256', control_module.STREAM_CLI), ('engine_sha256', control_module.ENGINE_SHA),
                          ('runner_sha256', config['runner_sha256'])):
        if combined.get(name) != expected:
            raise ValueError('Combined-control binary binding differs: ' + name)
    summary, observed = report_contract(load(files / 'ordinary/report.json'), control_module)
    control_module.require_combined_report(summary, receipt['archive']['sha256'], 228, receipt['replay_stage']['exit'], observed)
    if summary != receipt['summary'] or observed != receipt['observation_coverage'] or observed != combined['observation_coverage']:
        raise ValueError('Full report counters/results differ from the published acceptance receipt')
    return summary, observed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('launch_directory')
    for name in ('build_proof_sha256', 'source_proof_sha256', 'runner_sha256'):
        parser.add_argument(name)
    parser.add_argument('--execute', action='store_true', help='Read/download only; never launch or mutate guest work')
    args = parser.parse_args()
    expected = {name:getattr(args,name) for name in ('build_proof_sha256','source_proof_sha256','runner_sha256')}
    if any(not re.fullmatch('[0-9a-f]{64}', value) for value in expected.values()):
        raise ValueError('Expected B proof/binary digests must be64 lowercase hexadecimal characters')
    cold = pinned_module('accepted_cold_collector', 'collect_cold_candidate_evidence.py', COLD_COLLECTOR_SHA)
    control_module = pinned_module('accepted_stream_control', 'stream_combined_control.py', CONTROL_SHA)
    if sha(TASK/'launch_stream_combined_control.py') != LAUNCHER_SHA:
        raise ValueError('Accepted stream launcher changed')
    proof, known = cold.verify_transport()
    launch_dir = Path(args.launch_directory).resolve()
    if launch_dir.parent != TASK.resolve() or not launch_dir.name.startswith('stream-combined-prepared-'):
        raise ValueError('Expected the original local stream launch directory')
    manifest, launch = load(launch_dir/'manifest.json'), load(launch_dir/'launch-result.json')
    guest, unit = require_launch_data(manifest, launch, expected)
    if launch['manifest_sha256'] != sha(launch_dir/'manifest.json'):
        raise ValueError('Launch manifest bytes differ from the actual launch receipt')
    input_pins = {'stream_combined_control.py':CONTROL_SHA, 'worker.py':control_module.WORKER_SHA,
        'stream-commit-attestation.json':control_module.ATTESTATION_SHA,
        'build-worker-transport-proof.json':cold.TRANSPORT_SHA}
    if manifest['contract']['inputs'] != input_pins:
        raise ValueError('Launch manifest does not contain the exact accepted control inputs')
    for name, expected_sha in input_pins.items():
        if sha(launch_dir/name) != expected_sha:
            raise ValueError('Original launch input changed: ' + name)
    for name, key in (('launch.stdout','launch_stdout_sha256'),('launch.stderr','launch_stderr_sha256')):
        if sha(launch_dir/name) != launch[key]:
            raise ValueError('Original launch output bytes changed: ' + name)
    launched = load(launch_dir/'launch.stdout')
    if launched.get('executed') is not True or launched.get('exit_code') != 0 or launched.get('unit') != unit or launched.get('directory') != guest:
        raise ValueError('Actual remote launch output names a different profile/unit')
    config = dict(expected,candidate=B_ID,root='/opt/song-lua-audit/pass4',control=guest,unit=unit,
        manifest=manifest,manifest_sha256=sha(launch_dir/'manifest.json'),engine_sha256=control_module.ENGINE_SHA,
        stream_cli_sha256=control_module.STREAM_CLI,
        stream_cli_path='/opt/song-lua-audit/pass4/capture-profiles/'+control_module.STREAM_PROFILE+'/bin/itgmania-harness-rs',
        original_trace_path='/opt/song-lua-audit/pass4/controls/stream-native-d782ac54fc3b5e1b1ddc/ordinary-control/traces/native.json',
        native_control_path='/opt/song-lua-audit/pass4/controls/stream-native-d782ac54fc3b5e1b1ddc/control-receipt.json',
        stream_build_path='/opt/song-lua-audit/pass4/capture-profiles/'+control_module.STREAM_PROFILE+'/build-receipt.json',
        max_file_bytes=MAX_FILE_BYTES,max_total_bytes=MAX_TOTAL_BYTES)
    plan = {'candidate':B_ID,'profile':manifest['id'],'unit':unit,'guest_directory':guest,'executed':False,
        'inspection_only':True,'guest_writes':False,'expected':expected,'helper_sha256':sha(Path(__file__)),
        'launch_manifest_sha256':config['manifest_sha256'],'launch_result_sha256':sha(launch_dir/'launch-result.json'),
        'cold_transport_helper_sha256':COLD_COLLECTOR_SHA,'acceptance_helper_sha256':CONTROL_SHA}
    if not args.execute:
        print(json.dumps(plan,indent=2));return 0
    if shutil.disk_usage(TASK).free < 2*MAX_TOTAL_BYTES+1024**3:
        raise ValueError('Insufficient local space for bounded full evidence and exact transfer archive')
    import remote
    transport = remote.ssh(proof['guest_ip'])
    transport = ['UserKnownHostsFile='+str(known) if arg.startswith('UserKnownHostsFile=') else arg for arg in transport]
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    destination = TASK/('stream-B-evidence-'+stamp);destination.mkdir()
    local = destination/'launch';local.mkdir()
    launch_files = (*input_pins,'manifest.json','launch-result.json','launch.stdout','launch.stderr','launch-plan.json')
    launch_snapshot = {name:sha(launch_dir/name) for name in launch_files}
    for name in launch_files:
        shutil.copyfile(launch_dir/name,local/name)
        if sha(local/name) != launch_snapshot[name] or sha(launch_dir/name) != launch_snapshot[name]:
            raise ValueError('Original local launch evidence changed during retention: ' + name)
    shutil.copyfile(Path(__file__),destination/Path(__file__).name)
    shutil.copyfile(TASK/'collect_cold_candidate_evidence.py',destination/'collect_cold_candidate_evidence.py')
    result = dict(plan,executed=True,passed=False,collection_complete=False,directory=str(destination))
    preamble = 'config='+repr(config)+'\n'+inspect.getsource(require_stopped)+'\n'+cold.REMOTE_COMMON
    try:
        completed = subprocess.run(transport+['python3','-B','-'],input=(preamble+REMOTE_METADATA).encode(),capture_output=True,timeout=180)
        (destination/'metadata.stdout').write_bytes(completed.stdout);(destination/'metadata.stderr').write_bytes(completed.stderr)
        result['metadata_exit_code']=completed.returncode
        if completed.returncode:raise ValueError('Read-only profile metadata/identity validation failed; stderr retained')
        metadata=json.loads(completed.stdout);save(destination/'remote-manifest.json',metadata)
        with (destination/'evidence.tar').open('xb') as output,(destination/'download.stderr').open('xb') as error:
            completed=subprocess.run(transport+['python3','-B','-'],input=(preamble+'\nmetadata='+repr(metadata)+'\n'+REMOTE_DOWNLOAD).encode(),
                stdout=output,stderr=error,timeout=300)
        result['download_exit_code']=completed.returncode
        if completed.returncode:raise ValueError('Read-only profile transfer changed or failed; exact bytes/error retained')
        wanted={row['relative']:row for row in metadata['files']};found=set();files=destination/'files';files.mkdir()
        with tarfile.open(destination/'evidence.tar',mode='r:') as archive:
            for member in archive:
                relative=Path(member.name)
                if (member.name not in wanted or member.name in found or not member.isfile()
                        or relative.is_absolute() or '..' in relative.parts):raise ValueError('Unexpected transfer member')
                row=wanted[member.name]
                if member.size!=row['bytes'] or member.size>MAX_FILE_BYTES:raise ValueError('Transfer member size differs')
                target=files/relative;target.parent.mkdir(parents=True,exist_ok=True)
                with archive.extractfile(member) as source,target.open('xb') as output:shutil.copyfileobj(source,output,1024**2)
                if sha(target)!=row['sha256']:raise ValueError('Downloaded member digest differs: '+member.name)
                found.add(member.name)
        if found!=set(wanted):raise ValueError('Transfer omitted expected evidence')
        result['collection_complete']=True
        summary,observed=validate_profile(files,metadata,config,control_module,cold)
        save(destination/'report-summary.json',{'summary':summary,'observation_coverage':observed})
        result.update(passed=True,summary=summary,observation_coverage=observed,
            capture_profile_sha256=sha(files/'capture-profile.json'),composed_build_proof_sha256=sha(files/'proof/build-proof.json'),
            composed_source_proof_sha256=sha(files/'proof/source-proof.json'),report_sha256=sha(files/'ordinary/report.json'))
    except BaseException as error:
        result.update(passed=False,error=str(error),traceback=traceback.format_exc())
    finally:
        result['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(destination/'collection-receipt.json',result)
        entries=[{'path':path.relative_to(destination).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)}
            for path in sorted(destination.rglob('*')) if path.is_file()]
        save(destination/'manifest.json',{'schema_version':1,'files':entries})
        print(json.dumps({'directory':str(destination),'passed':result['passed'],'collection_complete':result['collection_complete'],
            'error':result.get('error'),'receipt_sha256':sha(destination/'collection-receipt.json'),
            'manifest_sha256':sha(destination/'manifest.json')},indent=2))
    return 0 if result['passed'] else 2 if result['collection_complete'] else 1


if __name__=='__main__':
    raise SystemExit(main())
