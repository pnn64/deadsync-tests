"""Commit only the reviewed visual registration and published fixture link."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
HEAD = '21f47c8783a1fe429a8a5f341ca604d03773601c'
FIXTURE = '11f6edff529423df9ffef9458e93f7726183a646'
SOURCE = 'crates/deadsync-song-lua/tests/live_visuals.rs'
SOURCE_SHA = 'a1c8fc5150d8cc56b1e9956fe63be8f276d53f090b9624f27a0a03149631012a'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args, cwd=ROOT): return subprocess.check_output(['git', '-C', str(cwd), *args])

receipt_path = Path(sys.argv[1]).resolve()
assert receipt_path.is_relative_to(TASK) and receipt_path.name == 'receipt.json'
raw = receipt_path.read_bytes()
assert sha(raw) == sys.argv[2]
receipt = json.loads(raw)
assert [row['name'] for row in receipt['commands']] == ['diff-check', 'live-visuals']
patch = git('diff', '--binary', '--full-index', 'HEAD')
identity = {'source': {'head': HEAD, 'patch_sha256': sha(patch)},
    'fixtures': {'head': FIXTURE, 'patch_sha256': sha(b'')}}
for row in receipt['commands']:
    assert row['exit_code'] == 0 and row['source_unchanged'] is True
    assert row['source_before'] == row['source_after'] == identity
    log_path = Path(row['log']).resolve()
    assert log_path.parent == receipt_path.parent and sha(log_path.read_bytes()) == row['log_sha256']
    if row['name'] == 'live-visuals':
        assert len(row['result_lines']) == 1
        assert row['result_lines'][0].startswith('test result: ok. 13 passed; 0 failed; 0 ignored;')
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('diff', '--cached', '--name-only').strip()
assert not git('ls-files', '--others', '--exclude-standard', '-z').strip(b'\0')
assert git('rev-parse', 'HEAD', cwd=ROOT / 'tests/fixtures').decode().strip() == FIXTURE
assert not git('status', '--porcelain=v1', cwd=ROOT / 'tests/fixtures').strip()
assert set(git('diff', '--name-only', 'HEAD', '-z').decode().strip('\0').split('\0')) == {SOURCE, 'tests/fixtures'}
assert sha((ROOT / SOURCE).read_bytes()) == SOURCE_SHA
git('diff', '--check')
out = TASK / 'visual-registration-commit.json'
assert not out.exists()
git('add', '--', SOURCE, 'tests/fixtures')
assert git('diff', '--cached', '--binary', '--full-index', 'HEAD') == patch
git('diff', '--cached', '--check')
print(git('commit', '-m', 'test(song-lua): register visual fixture paths portably', '-m',
    'Register the independently known script and texture files before their directory so full paths have distinct cross-platform snapshot identities. Keep runtime data and all non-path observations unchanged.').decode(), end='')
assert git('rev-parse', 'HEAD^').decode().strip() == HEAD
assert not git('status', '--porcelain=v1').strip()
result = {'commit': git('rev-parse', 'HEAD').decode().strip(), 'parent': HEAD,
    'fixtures': FIXTURE, 'passed_patch_sha256': sha(patch), 'source_sha256': SOURCE_SHA,
    'windows_gate_receipt': str(receipt_path), 'windows_gate_receipt_sha256': sha(raw)}
out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
