"""Read immutable retained Circles captures/reports; emit bounded evidence only."""
import collections
import hashlib
import json
import pathlib
import re
import struct
import subprocess
import tarfile
from fractions import Fraction

import zstandard

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = HERE.parent
CASES = [
    ("latest-debug-sm", "ccfbbe2824310517-c0001", 1503,
     HERE / "artifacts/44103dfe5e1703a205551dd40b208bae181bdcde0fff77344a419d51dde7f358.json.zst",
     "1467b5bccb06fe84d622d5590f5ee732dfbd6ed0b4fcbf9af7036f37d9b2a38e.tar.zst", (1, Fraction(499, 2), Fraction(999, 4))),
    ("latest-debug-ssc", "eb4e5c5559461e35-c0001", 1505,
     HERE / "artifacts/015b35dc065d6875625b8f499035f1c73a0f710349b72e1b80b9832fcdd197e5.json.zst", None, None),
    ("debug-pack-sm", "88c8cb8267270d98-c0001", 1513,
     HERE / "artifacts/1dd609a40d31d08646072688562dbfb5bc1c1655925a6a654657e71e93dc612d.json.zst", None, None),
    ("debug-pack-ssc", "e6af5210a8656afe-c0001", 1514,
     BASE / "corpus-audit-artifacts/06e3a401bf6c2cc5978348fdd0d84595ef247f21730d3f950bf4d4b29aee1be5.json.zst",
     "aa65e43a02f76f6d19caa5cf442cd41248dca209acd2898ed0ef7d9c44bb8637.tar.zst", (2, Fraction(57), Fraction(229, 4))),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def f32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


def packed_json(path):
    raw = path.read_bytes()
    assert sha(raw) == path.name.split(".")[0]
    with zstandard.ZstdDecompressor().stream_reader(raw) as stream:
        plain = stream.read()
    return json.loads(plain), {"path": str(path), "bytes": len(raw), "sha256": sha(raw),
                               "decoded_bytes": len(plain), "decoded_sha256": sha(plain)}


def archive_parts(path):
    result = {}
    with path.open("rb") as packed, zstandard.ZstdDecompressor().stream_reader(packed) as stream:
        with tarfile.open(fileobj=stream, mode="r|") as archive:
            for member in archive:
                if member.name in ("manifest.json", "trace/semantic.json", "song/Circles.sm", "song/Circles.ssc", "song/lua/default.lua"):
                    data = archive.extractfile(member).read()
                    result[member.name] = (data, {"path": member.name, "bytes": len(data), "sha256": sha(data)})
    manifest = json.loads(result["manifest.json"][0])
    entries = {entry["path"]: entry for entry in manifest["files"]}
    for name, (data, record) in result.items():
        if name != "manifest.json":
            assert entries[name]["bytes"] == len(data) and entries[name]["sha256"] == record["sha256"]
    return result, manifest


def holds(text, is_sm):
    bodies = re.findall(r"#NOTES\s*:(.*?);", text, re.I | re.S)
    assert len(bodies) == 1
    body = bodies[0].split(":", 5)[5] if is_sm else bodies[0]
    body = re.sub(r"//[^\r\n]*", "", body)
    opened, found = {}, []
    for measure, raw in enumerate(body.split(",")):
        rows = [line.strip() for line in raw.splitlines() if line.strip()]
        for row_index, row in enumerate(rows):
            assert re.fullmatch(r"[01234MLFK]{4}", row), row
            beat = Fraction(measure * 4) + Fraction(4 * row_index, len(rows))
            for column, char in enumerate(row):
                if char in "24":
                    assert column not in opened
                    opened[column] = (beat, char, measure, row_index, len(rows))
                elif char == "3":
                    start, kind, start_measure, start_row, start_rows = opened.pop(column)
                    found.append({"column_zero_based": column, "type": "hold" if kind == "2" else "roll",
                                  "head_beat": float(start), "tail_beat": float(beat),
                                  "head_beat_fraction": str(start), "tail_beat_fraction": str(beat),
                                  "head_native_row": round(start * 48), "tail_native_row": round(beat * 48),
                                  "head_measure_zero_based": start_measure, "head_row_in_measure": start_row,
                                  "head_measure_rows": start_rows, "tail_measure_zero_based": measure,
                                  "tail_row_in_measure": row_index, "tail_measure_rows": len(rows)})
    assert not opened
    return found


head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
assert head == "81c18c105ad9e70e1d6d9a84c610e3a2de477899"
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT)
output = {"scope": "Read-only baseline diagnosis. Candidate B has not been replayed by this analysis.",
          "product_head": head, "candidate_b": "be576a51d3f4ea203bb1ef298f01b21c9ad4091d09f77cc371da08b26cb6a858", "cases": []}
for label, job, vmid, report_path, archive_name, selected_hold in CASES:
    report, report_identity = packed_json(report_path)
    queries = report["command_queries"]
    mismatch_queries = [entry for entry in report["mismatches"] if entry["field"] == "command_query_event"]
    row = {"variant": label, "job_id": job, "vmid": vmid, "report": report_identity,
           "scope": {key: report.get(key) for key in ("execution_path", "production_preparation_exercised", "archive_accepted", "whole_song_parity_proven", "production_parity_proven")},
           "frames": report["native_frames"], "replayed_frames": report["replayed_frames"],
           "retained_mismatch_counts": dict(collections.Counter(entry["field"] for entry in report["mismatches"])),
           "errors": report["errors"], "command_queries": {key: queries[key] for key in ("compared", "native_count", "actual_count", "uncompared_actual")},
           "query_mismatches": mismatch_queries}
    if archive_name:
        archive_path = HERE / "artifacts" / archive_name
        receipt = json.loads(archive_path.with_name(archive_name + ".receipt.json").read_bytes())
        assert receipt["status"] in ("downloaded", "already_present") and receipt["sha256"] == archive_name.split(".")[0]
        parts, manifest = archive_parts(archive_path)
        trace = json.loads(parts["trace/semantic.json"][0])
        assert trace["input"]["autoplay"] == 1 and trace["input"]["game"] == "dance"
        simfile_name = manifest["chart"]["simfile"]
        parsed_holds = holds(parts[simfile_name][0].decode("utf-8-sig"), simfile_name.endswith(".sm"))
        hold = next(value for value in parsed_holds if (value["column_zero_based"], Fraction(value["head_beat_fraction"]), Fraction(value["tail_beat_fraction"])) == selected_hold)
        times = {(entry["native"]["scene"], entry["native"]["seconds"]) for entry in mismatch_queries}
        assert len(times) == 1
        scene, seconds = next(iter(times))
        matches = [index for index, frame in enumerate(trace["update_frames"]) if frame["scene"] == scene and frame["seconds"] == seconds]
        assert len(matches) == 1
        index = matches[0]
        window = trace["update_frames"][index - 2:index + 3]
        assert window[0]["beat"] < hold["head_beat"] <= hold["tail_beat"] < window[1]["beat"]
        seen, timeline = set(), []
        actual_by_native_index = dict(zip(queries["native_event_indices"], queries["actual"]))
        wanted_times = {frame["seconds"] for frame in window}
        for event_index, event in enumerate(trace["events"]):
            key = (event.get("seconds"), event.get("actor"))
            if event.get("scene") == scene and event.get("seconds") in wanted_times and event.get("operation") == "Actor.x" and event.get("actor") in ("external-0025", "external-0026") and key not in seen:
                seen.add(key)
                timeline.append({"native_event_index_zero_based": event_index, "native": event,
                                 "actual": actual_by_native_index.get(event_index)})
        for mismatch in mismatch_queries:
            native = next(event for event in trace["events"] if event["seq"] == mismatch["native"]["seq"])
            for field in ("scene", "seconds", "beat", "operation", "args", "source", "line"):
                assert native[field] == mismatch["native"][field]
        row["native_evidence"] = {"archive": receipt, "members": [record for _, record in parts.values()],
                                  "source_authority": manifest["itgmania"], "runtime": manifest["runtime"],
                                  "chart": manifest["chart"], "theme": trace["theme"], "input": trace["input"],
                                  "frame_phase": trace["update_frame_phase"], "completion": trace["completion"],
                                  "focus_hold": hold, "update_window": window, "actor_query_window": timeline,
                                  "f32_diagnostics": {"frame_delta": window[2]["delta"],
                                                      "tap_lifetime_minus_delta": f32(f32(0.9) - window[2]["delta"]),
                                                      "hold_lifetime_minus_delta": f32(f32(0.8) - window[2]["delta"]),
                                                      "fresh_hold_lifetime": f32(0.8)}}
    output["cases"].append(row)

assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT)
destination = HERE / "query-windows.json"
with destination.open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(output, stream, indent=2, ensure_ascii=False)
    stream.write("\n")
print(json.dumps({"output": str(destination), "bytes": destination.stat().st_size, "sha256": sha(destination.read_bytes()),
                  "cases": [{"variant": row["variant"], "counts": row["retained_mismatch_counts"],
                             "window": row.get("native_evidence", {}).get("update_window"),
                             "arithmetic": row.get("native_evidence", {}).get("f32_diagnostics")} for row in output["cases"]]}, ensure_ascii=False))
