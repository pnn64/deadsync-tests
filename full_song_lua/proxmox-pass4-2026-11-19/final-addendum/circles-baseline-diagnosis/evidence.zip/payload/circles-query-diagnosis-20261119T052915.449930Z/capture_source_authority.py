"""Bind read-only Circles timing diagnosis to pinned source and retained values."""
import hashlib
import json
import pathlib
import struct
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
PRODUCT = HERE.parents[2]
HARNESS = PRODUCT.parent / "itgmania-harness"
NATIVE = HARNESS / "vendor/itgmania"
THEME = HARNESS / "vendor/simply-love"
BASELINE = "2da5562bb050d155a90498fd075279a0249ae479"
PRODUCT_HEAD = "81c18c105ad9e70e1d6d9a84c610e3a2de477899"
NATIVE_HEAD = "663525dcb86eb570d0ef6a2e209678436660ae26"
CAPTURE_HARNESS = "9eb6619c0eaf9c3aceabf7348efbb06a7fd37273"


def git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def f32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


def source(root, rev, path, ranges):
    canonical = git(root, "show", rev + ":" + path)
    working = (root / path).read_bytes()
    assert working.replace(b"\r\n", b"\n") == canonical.replace(b"\r\n", b"\n")
    lines = canonical.decode("utf-8").splitlines()
    return {"repository": str(root), "revision": rev, "path": path,
            "git_blob": git(root, "rev-parse", rev + ":" + path).decode().strip(),
            "git_blob_bytes": len(canonical), "git_blob_sha256": sha(canonical),
            "worktree_bytes": len(working), "worktree_sha256": sha(working),
            "worktree_byte_equal": working == canonical,
            "worktree_lf_equivalent": True,
            "regions": [{"start_line": begin, "end_line": end,
                         "text": "\n".join(lines[begin - 1:end]) + "\n"} for begin, end in ranges]}


assert git(PRODUCT, "rev-parse", "HEAD").decode().strip() == PRODUCT_HEAD
assert not git(PRODUCT, "status", "--porcelain")
assert git(NATIVE, "rev-parse", "HEAD").decode().strip() == NATIVE_HEAD
theme_revision = git(HARNESS, "rev-parse", CAPTURE_HARNESS + ":vendor/simply-love").decode().strip()
assert git(THEME, "rev-parse", "HEAD").decode().strip() == theme_revision

evidence = json.loads((HERE / "query-windows.json").read_bytes())
data = {"purpose": "Read-only cause diagnosis; no product mutation, new native capture, replay, or tolerance change.",
        "baseline_product_revision": BASELINE, "frozen_product_revision": PRODUCT_HEAD,
        "native_revision": NATIVE_HEAD, "capture_harness_revision": CAPTURE_HARNESS,
        "theme_revision_bound_by_capture_harness_gitlink": theme_revision,
        "query_evidence_sha256": sha((HERE / "query-windows.json").read_bytes()),
        "source_regions": [], "unchanged_relevant_paths": [], "exact_observed_timer_arithmetic": []}

for path, regions in [
    ("src/Actor.cpp", [(795, 847), (852, 890), (949, 959)]),
    ("src/ActorFrame.cpp", [(449, 476), (500, 509)]),
    ("src/Player.cpp", [(905, 937), (1206, 1305), (1391, 1454), (1598, 1610), (1655, 1670), (1720, 1742), (3111, 3185)]),
    ("src/NoteTypes.h", [(342, 350)]),
    ("src/HoldJudgment.cpp", [(45, 77)]),
    ("Themes/_fallback/metrics.ini", [(1149, 1160)]),
]:
    data["source_regions"].append(source(NATIVE, NATIVE_HEAD, path, regions))
data["source_regions"].append(source(THEME, theme_revision, "metrics.ini", [(1832, 1834)]))
for path, regions in [
    ("crates/deadsync-gameplay/src/runtime_update.rs", [(268, 314)]),
    ("crates/deadsync-gameplay/src/runtime_methods.rs", [(730, 758), (808, 817), (865, 899), (972, 1006), (2128, 2179), (2342, 2373)]),
    ("crates/deadsync-gameplay/src/holds.rs", [(1132, 1199)]),
    ("crates/deadsync-song-lua/src/actors/live_feedback.rs", [(93, 173), (258, 272)]),
    ("crates/deadsync-song-lua/src/actors/song_multitap.rs", [(590, 630), (688, 709)]),
    ("tests/song_lua_itgmania_semantic_parity/native_gameplay.rs", [(177, 215), (313, 329)]),
]:
    data["source_regions"].append(source(PRODUCT, PRODUCT_HEAD, path, regions))

for path, start, end in [
    ("crates/deadsync-gameplay/src/runtime_update.rs", "        // Player::UpdateHoldNotes runs before CrossedRows", "        let survival_tick"),
    ("crates/deadsync-gameplay/src/runtime_methods.rs", "    pub fn run_autoplay(&mut self", "        let mut roll_cols"),
    ("crates/deadsync-gameplay/src/runtime_methods.rs", "    pub fn run_post_input_gameplay_phases(", "        self.apply_pending_mine_hits();"),
    ("crates/deadsync-gameplay/src/holds.rs", None, None),
    ("crates/deadsync-song-lua/src/actors/live_feedback.rs", None, None),
]:
    old = git(PRODUCT, "show", BASELINE + ":" + path).decode("utf-8").replace("\r\n", "\n")
    new = git(PRODUCT, "show", PRODUCT_HEAD + ":" + path).decode("utf-8").replace("\r\n", "\n")
    if start is not None:
        old = old[old.index(start):old.index(end, old.index(start))]
        new = new[new.index(start):new.index(end, new.index(start))]
    assert old == new
    data["unchanged_relevant_paths"].append({"path": path, "start_marker": start, "end_marker_excluded": end,
                                            "baseline_and_frozen_lf_text_equal": True,
                                            "lf_text_sha256": sha(new.encode("utf-8")), "bytes": len(new.encode("utf-8"))})

for case in evidence["cases"]:
    native = case.get("native_evidence")
    if not native:
        continue
    frames = native["update_window"]
    at = next(item for item in native["actor_query_window"] if item["native"]["actor"] == "external-0025" and item["native"]["seconds"] == frames[2]["seconds"])
    previous = next(item for item in native["actor_query_window"] if item["native"]["actor"] == "external-0025" and item["native"]["seconds"] == frames[1]["seconds"])
    prior_native_tap = previous["native"]["detail"]["native_tween_time_left"]
    assert prior_native_tap == f32(f32(f32(0.1) + f32(0.6)) + f32(0.2))
    predicted_remaining = f32(prior_native_tap - frames[2]["delta"])
    assert predicted_remaining == at["actual"]["tween_time_left"]
    assert at["native"]["detail"]["native_tween_time_left"] == f32(f32(0.3) + f32(0.5))
    data["exact_observed_timer_arithmetic"].append({"variant": case["variant"],
        "crossing_frame": frames[1]["sequence"], "mismatch_frame": frames[2]["sequence"],
        "prior_captured_native_tap_lifetime": prior_native_tap,
        "captured_actor_delta": frames[2]["delta"], "f32_subtraction": predicted_remaining,
        "actual_owned_recursive_max": at["actual"]["tween_time_left"],
        "captured_fresh_native_hold_max": at["native"]["detail"]["native_tween_time_left"],
        "interpretation": "Exact equality is diagnostic reasoning only; no expected fields were supplied to a replay. The extraction file's literal f32(0.9) convenience value is one ULP lower than the actual three-segment sum."})

assert not git(PRODUCT, "status", "--porcelain")
destination = HERE / "source-authority.json"
with destination.open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(data, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({"path": str(destination), "bytes": destination.stat().st_size, "sha256": sha(destination.read_bytes()),
                  "unchanged_regions": len(data["unchanged_relevant_paths"]),
                  "exact_arithmetic": data["exact_observed_timer_arithmetic"]}))
