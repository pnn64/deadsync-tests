The retained Circles query failures have a source-backed one-update cause: DeadSync resolves a newly autoplayed short hold during the update that crosses both its head and tail. Native ITGmania checks holds before autoplay crosses rows, so that hold's result and fresh feedback start on the following update. This is established for the two retained baseline windows below. Candidate B replay is still pending; this analysis did not run a new capture, replay, test, or product change.

All four reports use baseline runner `100d005699815a5ab6ad67692bb547c3b44049630050688cc977e42a9338f26b`, `execution_path=diagnostic-live-lua`, and `production_preparation_exercised=false`. They must not be reported as B or full production results.

| Variant / job | Captured updates | Retained query mismatches | Other retained mismatch examples |
|---|---:|---:|---|
| Latest-debug SM / `ccfbbe2824310517-c0001` | 2,483 | 12 | None |
| Latest-debug SSC / `eb4e5c5559461e35-c0001` | 2,504 | 0 | None; baseline diagnostic acceptance only |
| Debug-pack SM / `88c8cb8267270d98-c0001` | 2,460 | 0 | 100 resource-case examples |
| Debug-pack SSC / `e6af5210a8656afe-c0001` | 2,444 | 18 | 100 resource-case examples |

The 100 draw entries are retained examples, not a claim about the total number of failing drawable comparisons. The existing `circles-case-resource-authority.json` covers `BG.mp4` versus `bg.mp4` identity separately.

Every affected command is an authored `Actor.x`, `Actor.y`, or `Actor.rotationz` call on P1 or P2, from `song:/lua/default.lua`'s `LoopMessageCommand` (recorded definition line 287). Scene, music time, beat, operation, call count and arguments agree. The differing field is the Player actor's recursive `tween_time_left`.

| Variant | Short hold (zero-based column) | Previous / crossing / mismatch update beats | Native recursive maximum | Owned recursive maximum |
|---|---|---|---:|---:|
| Debug-pack SSC | Column 2, head 57, tail 57.25; rows 2736–2748 | 516: 56.98896408081055; 517: 57.28070831298828; 518: 57.43213653564453 | 0.800000011920929 | 0.7721090316772461 |
| Latest-debug SM | Column 1, head 249.5, tail 249.75; rows 11976–11988 | 1620: 249.4907684326172; 1621: 249.75733947753906; 1622: 249.89154052734375 | 0.800000011920929 | 0.7400950193405151 |

The archive's authored note rows were parsed independently and matched against each exact source member hash. In both cases, one native update moves from before the head to after the tail. On that update the native child tree shows a fresh tap judgment but no fresh judgment for that short hold. On the next update it contains a fresh HoldJudgment with 0.8 seconds left. The native tap judgment has already advanced. In the SSC tree an older hold also has 0.6721090078353882 seconds left, distinguishing it from the new 0.8-second child.

The observed previous native tap lifetime is exactly `0.9000000357627869`, the f32 sum of the three 0.1, 0.6, and 0.2-second segments. Subtracting the recorded actor-update delta with f32 rounding exactly gives the owned maximum:

- SSC: `f32(0.9000000357627869 - 0.12789100408554077) = 0.7721090316772461`.
- SM: `f32(0.9000000357627869 - 0.15990500152111053) = 0.7400950193405151`.

This is diagnostic arithmetic, not replay input. `query-windows.json` also retains a convenience calculation using literal `f32(0.9)`; that literal is one ULP below the actual three-segment sum and is not used as the equality proof. `source-authority.json` contains the exact observed calculation and assertions.

The pinned native source is `663525dcb86eb570d0ef6a2e209678436660ae26`:

- `src/Player.cpp:918` first updates ActorFrame children. The hold pass at 1206–1267 runs before `CrossedRows` at 1291/1295 and `UpdateJudgedRows` at 1302. `CrossedRows` dispatches autoplay `Step` at 3172–3177.
- `Player.cpp:1427–1430` requires the hold head to have a tap or early tap judgment. Only the `!RequireStepOnHoldHeads` branch bypasses that condition at 1451–1453. The fallback metric at `Themes/_fallback/metrics.ini:1155` enables this requirement for dance; the capture input says dance/autoplay, and the captured child timing agrees with that branch.
- `Player.cpp:1603–1604` resolves a tail only after the rounded song row reaches its end and the head is judged. `NoteTypes.h:347–349` already rounds the native note row. This is not evidence of a missing row-rounding rule.
- `ActorFrame.cpp:449–476` advances parent tweens, children, then the Lua UpdateFunction. Its `GetTweenTimeLeft` at 500–509 takes the maximum over its children. `HoldJudgment.cpp:53–64` resets and starts the Held command; the captured Simply Love metrics define the 0.3 + 0.5-second feedback duration.

The frozen owned source is `81c18c105ad9e70e1d6d9a84c610e3a2de477899`:

- `crates/deadsync-gameplay/src/runtime_update.rs:276–280` snapshots active holds for rendering before autoplay. This snapshot does not defer hold-result resolution.
- `runtime_update.rs:288` runs autoplay before `run_post_input_gameplay_phases` at 306. `runtime_methods.rs:2175` judges the crossed head; the hit path starts its active hold at 2832, through 2081–2109 and 889–925. The later post-input phase calls `update_active_holds` at 2369, and `holds.rs:1191–1193` immediately resolves a reached tail.
- `runtime_methods.rs:808–816` publishes the new hold feedback timestamp. `actors/song_multitap.rs:688–707` already schedules PlayerFeedback after the player's child traversal. `actors/live_feedback.rs:127–166` starts each new hold feedback once; its judgment path uses 0.1 + 0.6 + 0.2-second tap feedback.

The relevant autoplay/update/hold-resolution blocks are byte-equivalent after LF representation between baseline `2da5562bb050d155a90498fd075279a0249ae479` and frozen B source. `holds.rs` and `actors/live_feedback.rs` are unchanged whole Git blobs. The B `song_multitap.rs` change only finishes transitions; it does not change the Player feedback scheduling. Exact pinned Git-blob hashes, raw worktree hashes, CRLF equivalence and source regions are retained in `source-authority.json`.

This establishes a narrow gameplay-feedback timing cause for the baseline query windows. It does not establish an authored parent/child traversal bug, wrong loop arguments, faulty recursive maximum arithmetic, different file identity, or a candidate-B outcome. The other two captures do not exercise an exposed mismatch at these particular sampled boundaries. Adjacent command-query observations match in both affected captures; a later fresh tap can hide a differently aged hold beneath the same recursive maximum.

The next focused regression should cross a dance autoplay hold's head and tail in one update, inspect both players immediately and on the next update, and check hold-result/feedback timing alongside the tap and score observations. Any fix should respect native hold-before-autoplay ordering and the existing physical-input boundary, including paused/routine/replaced-hold behavior. It should not reorder all authored ActorFrame children or adjust comparison tolerance. No such fix is included here.

Evidence files: `query-windows.json` preserves all 30 query mismatch pairs plus five exact native frames and native/owned Player-x observations around each affected window. `selection.json`, `main-sm-selection.json`, and artifact receipts bind the original full collection and compressed/decoded artifact hashes. Large immutable archives remain content-addressed in `artifacts/`; no source/native expected data was normalized or rewritten. Native-source order was also reviewed independently by `linux_capture`, who found no alternative phase explanation. Final product status remained clean.
