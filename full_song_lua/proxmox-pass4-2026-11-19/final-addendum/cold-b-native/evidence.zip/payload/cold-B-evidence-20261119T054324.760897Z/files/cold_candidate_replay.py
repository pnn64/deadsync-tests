"""Guest-side retained Cold replay, bound to one passed candidate proof."""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import traceback

ROOT=Path('/opt/song-lua-audit/pass4')
HERE=ROOT/'controls/cold-case-lookup'
REPO=Path('/opt/song-lua-audit/deadsync-pass4')
ARCHIVE=HERE/'5aed0bb71a0e2899c23cbad591d6700c52570ad6bf47a7e6bc5c7a49385589a3.tar.zst'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
def source_identity():
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
        'patch_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=REPO)).hexdigest()}
def main():
    parser=argparse.ArgumentParser()
    for name in ['candidate','build_proof_sha256','runner_sha256']:parser.add_argument(name)
    args=parser.parse_args()
    for value in vars(args).values():assert len(value)==64 and all(c in '0123456789abcdef' for c in value)
    assert Path(__file__).resolve().parent==HERE
    assert subprocess.check_output(['hostname'],text=True).strip()=='deadsync-lua-20261119-build'
    candidate_lock=(ROOT/'candidate-runner.lock').open('a')
    fcntl.flock(candidate_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    fleet_lock=(ROOT/'fleet-orchestration.lock').open('a')
    fcntl.flock(fleet_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    attempt=HERE/('replay-'+args.candidate[:12]+'-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    attempt.mkdir()
    shutil.copy2(Path(__file__),attempt/'cold_candidate_replay.py')
    receipt={'schema_version':1,'candidate':args.candidate,'passed':False,
        'case_id':'30bd12a3a8b6302a-c0001','attempt':str(attempt),
        'purpose':'Exact retained native Cold archive through diagnostic and production gameplay on Linux',
        'helper_sha256':sha(Path(__file__))}
    try:
        directory=ROOT/'candidates'/args.candidate
        proof_path=directory/'build-proof.json'
        assert sha(proof_path)==args.build_proof_sha256
        proof=json.loads(proof_path.read_text())
        assert proof['passed'] is True and proof['candidate']['id']==args.candidate
        assert sha(ROOT/'proof/build-proof.json')==args.build_proof_sha256
        source_proof=directory/'source-proof.json'
        assert sha(source_proof)==proof['source_proof_sha256']
        assert sha(ROOT/'proof/source-proof.json')==proof['source_proof_sha256']
        runner=Path(proof['binaries']['runner']['path'])
        assert runner==ROOT/'bin/full_song_lua',runner
        assert proof['binaries']['runner']['sha256']==args.runner_sha256==sha(runner)
        assert sha(ARCHIVE)==ARCHIVE.name.removesuffix('.tar.zst')
        for name in ['build-proof.json','source-proof.json','manifest.json']:
            shutil.copy2(directory/name,attempt/name)
        receipt.update(build_proof_sha256=args.build_proof_sha256,
            source_proof_sha256=proof['source_proof_sha256'],runner_sha256=args.runner_sha256,
            archive={'path':str(ARCHIVE),'sha256':sha(ARCHIVE),'bytes':ARCHIVE.stat().st_size},
            source_before=source_identity())
        output=attempt/'report.json'
        command=[str(runner),'--archive',str(ARCHIVE),'--report',str(output),'--production']
        receipt['command']=command
        environment=dict(os.environ,LIBGL_ALWAYS_SOFTWARE='1',LP_NUM_THREADS='1',OMP_NUM_THREADS='1',TMPDIR=str(attempt/'tmp'))
        (attempt/'tmp').mkdir()
        save(attempt/'receipt.json',receipt)
        with (attempt/'replay.log').open('wb') as log:
            completed=subprocess.run(command,cwd=REPO,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=1700)
        receipt['exit_code']=completed.returncode
        receipt['source_after']=source_identity()
        assert receipt['source_before']==receipt['source_after']
        assert sha(runner)==args.runner_sha256 and sha(ROOT/'proof/build-proof.json')==args.build_proof_sha256
        if output.exists():
            report=json.loads(output.read_text())
            receipt['report']={'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size}
            receipt['summary']={key:report.get(key) for key in ['native_frames','replayed_frames','compared_stage_fields',
                'archive_accepted','diagnostic_replay_checks_passed','production_preparation_exercised','production_gameplay_checks_passed','pending_coverage']}
            receipt['summary'].update(errors=report.get('errors',[]),mismatch_count=len(report.get('mismatches',[])),
                first_mismatches=report.get('mismatches',[])[:3])
            receipt['passed']=completed.returncode==0 and report.get('archive_accepted') is True
    except BaseException as error:
        receipt['error']=str(error);receipt['traceback']=traceback.format_exc()
    finally:
        receipt['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(attempt/'receipt.json',receipt)
        save(HERE/'latest-replay.json',{'attempt':str(attempt),'passed':receipt['passed'],
            'receipt_sha256':sha(attempt/'receipt.json')})
        print(json.dumps(receipt),flush=True)
    return 0 if receipt['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
