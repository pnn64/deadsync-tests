# Final evidence retention proposal

This is a local proposal only. Product, fixtures, accepted helpers and guests were not modified.

Frozen product `81c18c105ad9e70e1d6d9a84c610e3a2de477899`, fixtures `11f6edff529423df9ffef9458e93f7726183a646`, candidate B `be576a51d3f4ea203bb1ef298f01b21c9ad4091d09f77cc371da08b26cb6a858`.

The pinned fixture manifest already publishes 191 files (75,091,540 bytes). Of those, 181 canonical Git blobs match exactly; 10 copied live-visual migration artifacts differ only by CRLF conversion, and their original bytes remain verified in the Windows checkout. Preserve those historical identities and append the groups below.

| Proposed group | Files | Source bytes | Evidence scope |
|---|---:|---:|---|
| portable-evidence-original-bytes | 2 | 202,454 | The exact ten original byte sequences are recoverable and match their historical manifest hashes; their committed flat evidence copies differ only by CRLF conversion. |
| candidate-b-build | 4 | 3,336,583 | Exact Linux B build passed all 20 nonzero gates and built the final runner; all gate logs and source/fixture proofs are present. |
| windows-portable-visuals | 13 | 15,129 | Final Windows diff-check and full live_visuals target passed 13/13; the source patch is bound by the subsequent portable-test commit receipt. |
| cold-b-native | 18 | 63,497,377 | Linux B Cold replay passed both paths: 1,586 frames, 157 eligible stage samples, 10,773 stage fields, 9,496 draws and 56,976 vertices per path, with zero errors or mismatches. |
| stream-b-native | 51 | 4,883,129 | The separately composed streaming capture profile passed an ordinary retained capture against B in both paths: 228 frames, 16 eligible stage samples, 1,204 fields, 38 draws and 228 vertices per path, with zero errors or mismatches. |
| circles-baseline-diagnosis | 18 | 3,192,410 | Two baseline Circles variants show a source-backed one-update short-hold scoring/tween phase discrepancy; exact query windows and native/owned source evidence are retained. |
| quarantine-one-attempt | 2 | 249,959 | One retained Quarantine capture has 128 retained native tween-overflow errors and 22 dropped diagnostics; its original capture_error is preserved. |
| missing-stage-primary-proof | 23 | 6,582,619 | Exact VM 1515/job 33094275d983528c-c0003 service and kernel records prove a 6 GiB cgroup OOM, including the native PID and killed stop hook. |
| retry-planning-and-authority | 41 | 8,922,422 | The reviewed 54-case supplement preserves all 53 original selections, adds one exactly bound journal-proved case, and retains original/projection snapshots and removal ledger; the host authority publication receipt is separate from the unchanged proposal. |
| stream-profile-package | 16 | 599,610 | Root-authorized packaging retained the 409-file runtime closure in a 21,585,920-byte host bundle, with exact package and transport-review receipts. |
| rollout-point-in-time | 11 | 100,337 | Immutable local drain/install/queue receipts through this inventory's observed cutoff; successful installation and queue launch are distinct from completed fleet replays. |
| commit-map-checkpoint | 2 | 174,610 | The exact 11 product commits map to eight runtime repairs, two comparison/acceptance changes and one portable-test change. |

Cold's full 61,415,386-byte report must be inside a compressed package, not committed as a raw blob. The duplicate transport tar is referenced by hash. Candidate-build and Quarantine ZIPs can be reused unchanged. The source-level Circles diagnosis and retry planning remain separate from executed controls and rollout results.

## Operational cutoff

{
  "drained_vmids": [
    1501,
    1502,
    1503,
    1504,
    1505,
    1506,
    1507,
    1508,
    1509,
    1510,
    1511,
    1512,
    1513,
    1514,
    1515
  ],
  "installed_b_vmids": [
    1501,
    1503,
    1505,
    1506,
    1508,
    1509,
    1510,
    1511,
    1514,
    1515
  ],
  "production_queue_launched_vmids": [
    1501,
    1506,
    1508,
    1509,
    1510,
    1511,
    1514,
    1515
  ],
  "failed_or_incomplete_operations": []
}

These are installation/launch observations, not completed fleet outcomes. Later operations must be retained as new receipts rather than changing the original planning artifacts.

## Still required before final publication

- Final all-worker B/profile installation and resume receipts beyond the observed cutoff.
- Final candidate-bound resource role contract, activation, per-attempt outcomes and original-queue restoration.
- A complete final-candidate fleet collection, with baseline/candidate/profile identities and unsupported/source-error/resource cases distinguished.
- Final per-archive coverage and pending flags; no replacement of whole_song_parity_proven=false with a blanket parity claim.

All selected files, reference-only inputs, hashes, byte counts, original identities, preservation rules and scope limits are enumerated in inventory.json. No fixture application or new parity execution occurred.
