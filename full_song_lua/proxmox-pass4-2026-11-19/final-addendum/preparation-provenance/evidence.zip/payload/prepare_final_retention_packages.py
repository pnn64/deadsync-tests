"""Prepare opaque evidence packages and a reviewed publication plan locally only."""
import collections
import datetime as dt
import difflib
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import zipfile

TASK = Path(__file__).resolve().parent
PRODUCT = TASK.parents[1]
FIXTURES = Path(r"C:\GitHub\deadsync-fixtures-lua-fleet-20261119")
HEAD = "81c18c105ad9e70e1d6d9a84c610e3a2de477899"
FIXTURE_HEAD = "11f6edff529423df9ffef9458e93f7726183a646"
PREFIX = "full_song_lua/proxmox-pass4-2026-11-19/"
INVENTORY = TASK / "final-retention-proposal-20261119T060614Z/inventory.json"
INVENTORY_SHA = "54b7de34aee6bbaa36cbcad6b7017bee1d8d1b30ad43fb7994c2e2b4b6c35ae6"
BUILD = "610be24222fac61761ca70c5f18f986840ff971566d52417b9bde14726963d1e"
SOURCE_PROOF = "18f5fe495952a649abaf758df3a20deb62abc8cf49411e1acc3de9affb03e717"
RUNNER = "90abd15f5e2f6e15a23b33faacc83ec81bde13a2f709f095576a10ce0c8405e4"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def raw_json(doc):
    return (json.dumps(doc, indent=2, ensure_ascii=False) + "\n").encode()


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args])


def unchanged():
    result = {}
    for name, root, expected in [("product", PRODUCT, HEAD), ("fixtures", FIXTURES, FIXTURE_HEAD), ("product_fixtures", PRODUCT / "tests/fixtures", FIXTURE_HEAD)]:
        head = git(root, "rev-parse", "HEAD").decode().strip()
        status = git(root, "status", "--porcelain", "--untracked-files=no")
        assert head == expected and not status, (name, head, status)
        result[name] = {"head": head, "tracked_status": "clean"}
    return result


def record(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def checked(row):
    path = Path(row["path"])
    assert path.resolve().is_relative_to(TASK.resolve())
    actual = record(path)
    assert actual["bytes"] == row["bytes"] and actual["sha256"] == row["sha256"], path
    return path


def member_name(row):
    relative = Path(row["path"]).relative_to(TASK).as_posix()
    assert not PurePosixPath(relative).is_absolute() and ".." not in PurePosixPath(relative).parts
    return "payload/" + relative


def write_zip(path, manifest_path, sources, meta):
    members = [{"path": member_name(row), "bytes": row["bytes"], "sha256": row["sha256"], "original_source_path": row["path"]} for row in sources]
    assert len({x["path"] for x in members}) == len(members)
    doc = {"schema_version": 1, **meta, "files": members}
    raw = raw_json(doc)
    with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for row, member in zip(sources, members):
            source = checked(row)
            info = zipfile.ZipInfo(member["path"], (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            digest = hashlib.sha256(); count = 0
            with source.open("rb") as stream, archive.open(info, "w", force_zip64=True) as dest:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    dest.write(block); digest.update(block); count += len(block)
            assert count == row["bytes"] and digest.hexdigest() == row["sha256"]
        info = zipfile.ZipInfo("manifest.json", (1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, raw, compresslevel=9)
    manifest_path.write_bytes(raw)
    assert path.stat().st_size < 50_000_000


def validate_bundle(archive_path, manifest_path, layout):
    raw = manifest_path.read_bytes(); manifest = json.loads(raw)
    members = manifest["members"] if layout == "external" else manifest["files"]
    key = "archive_path" if layout == "external" else "path"
    indexed = {x[key]: x for x in members}; assert len(indexed) == len(members)
    if layout == "external":
        actual = record(archive_path)
        assert actual["bytes"] == manifest["archive"]["bytes"] and actual["sha256"] == manifest["archive"]["sha256"]
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist(); assert len(names) == len(set(names))
        assert set(names) == set(indexed) | ({"manifest.json"} if layout == "embedded" else set())
        if layout == "embedded":
            assert archive.read("manifest.json") == raw
        for name, row in indexed.items():
            assert not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts and "\\" not in name
            with archive.open(name) as stream:
                digest = hashlib.sha256(); count = 0
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block); count += len(block)
            assert count == row["bytes"] and digest.hexdigest() == row["sha256"], name
    return len(names)


RECOVERY_CODE = '''
def original_byte_recovery():
    # Only these reviewed historical copies have Git-normalized line endings.
    folder = ROOT / "final-addendum/portable-evidence-original-bytes"
    manifest_raw = (folder / "manifest.json").read_bytes()
    archive_raw = (folder / "evidence.zip").read_bytes()
    assert digest(manifest_raw) == "10963583ffc9fdded187c82f73f2c251ffa5b04d7f8afbfcd77bb95a9b238530"
    assert len(archive_raw) == 198268
    assert digest(archive_raw) == "42b777470b0be39339ac3a36f7e9abbce4b9c1aadd0f2ea2ab0b6b7118239cba"
    manifest = json.loads(manifest_raw)
    assert manifest["historical_fixture_commit"] == "11f6edff529423df9ffef9458e93f7726183a646"
    assert manifest["historical_manifest_sha256"] == "f6e8576ae742e41fda910a386ca459502d83afbeaf527ae7d7104c0c25d56b7f"
    expected = {
        "live-visual-path-migration/" + state + "/" + name
        for state in ("original", "proposed")
        for name in ("live_visuals.rs", ".gitattributes", "28e74d92d026cc0b.snap", "b3216bc62d36e29c.snap", "be88a6d727933ed4.snap")
    }
    rows = {row["path"]: row for row in manifest["files"]}
    assert len(rows) == len(manifest["files"]) == 10 and set(rows) == expected
    result = {}
    with zipfile.ZipFile(folder / "evidence.zip") as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and set(names) == expected | {"manifest.json"}
        assert archive.read("manifest.json") == manifest_raw
        for name, row in rows.items():
            original = archive.read(name)
            assert len(original) == row["bytes"] and digest(original) == row["sha256"]
            canonical = original.replace(b"\\r\\n", b"\\n")
            assert canonical != original and row["difference_is_crlf_only"] is True
            assert len(canonical) == row["canonical_git_blob_bytes"]
            assert digest(canonical) == row["canonical_git_blob_sha256"]
            result["full_song_lua/proxmox-pass4-2026-11-19/" + name] = (original, canonical)
    return result


def verify_evidence_item(item, data, recovery):
    if item["path"] in recovery:
        original, canonical = recovery[item["path"]]
        # The old index still names the exact original bytes, never a new hash.
        assert len(original) == item["bytes"] and digest(original) == item["sha256"], item["path"]
        assert data == original or data == canonical, item["path"]
        recovered = data == canonical
    else:
        assert len(data) == item["bytes"], item["path"]
        assert digest(data) == item["sha256"], item["path"]
        recovered = False
    assert len(data) < 50_000_000, item["path"]
    return recovered


'''


def patch_text(before, after, relative):
    return "".join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile="a/" + relative, tofile="b/" + relative)).encode()


def main():
    before = unchanged()
    inventory_raw = INVENTORY.read_bytes(); assert sha(inventory_raw) == INVENTORY_SHA
    inventory = json.loads(inventory_raw)
    assert len(inventory["groups"]) == 12
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    out = TASK / ("final-retention-packages-" + stamp); out.mkdir()
    payload = out / "payload"; namespace = payload / PREFIX
    destination = namespace / "final-addendum"; destination.mkdir(parents=True)
    bundles = []; package_groups = []

    def package(group):
        key = group["key"]; folder = destination / key; folder.mkdir()
        sources = group["selected_files"]
        for row in sources:
            checked(row)
        meta = {"group": key, "scope": group["claim"], "limits": group["limits"], "inventory_sha256": INVENTORY_SHA, "inventory_cutoff": inventory["created_at"], "packaged_at": stamp, "packaging_product_head": HEAD, "packaging_fixture_head": FIXTURE_HEAD, "candidate_context": inventory["candidate"], "reference_only_files": group.get("reference_only_files", [])}
        if key in ("candidate-b-build", "cold-b-native", "stream-b-native"):
            meta["tested_b_pins"] = {"runner_sha256": RUNNER, "build_proof_sha256": BUILD, "source_proof_sha256": SOURCE_PROOF}
        if key == "portable-evidence-original-bytes":
            archive = next(x for x in sources if x["path"].endswith(".zip"))
            manifest = next(x for x in sources if x["path"].endswith("-manifest.json"))
            shutil.copyfile(checked(archive), folder / "evidence.zip")
            shutil.copyfile(checked(manifest), folder / "manifest.json")
            bundles.append((folder / "evidence.zip", folder / "manifest.json", "embedded"))
        elif key == "quarantine-one-attempt":
            archive = next(x for x in sources if x["path"].endswith(".zip"))
            manifest = next(x for x in sources if x["path"].endswith("manifest.json"))
            shutil.copyfile(checked(archive), folder / "evidence.zip")
            shutil.copyfile(checked(manifest), folder / "manifest.json")
            bundles.append((folder / "evidence.zip", folder / "manifest.json", "embedded"))
        elif key == "candidate-b-build":
            source_archive = next(x for x in sources if x["path"].endswith(".zip"))
            archive_path = folder / "candidate-evidence.zip"
            shutil.copyfile(checked(source_archive), archive_path)
            with zipfile.ZipFile(archive_path) as archive:
                members = [{"archive_path": name, "bytes": archive.getinfo(name).file_size, "sha256": sha(archive.read(name))} for name in archive.namelist()]
            descriptor = {"schema_version": 1, **meta, "scope": "Exact original candidate ZIP, including its verbatim evidence-manifest.json; descriptor is newly generated", "archive": record(archive_path), "members": members}
            manifest_path = folder / "candidate-evidence-manifest.json"; manifest_path.write_bytes(raw_json(descriptor))
            bundles.append((archive_path, manifest_path, "external"))
            remaining = [x for x in sources if x is not source_archive]
            write_zip(folder / "provenance.zip", folder / "provenance-manifest.json", remaining, meta)
            bundles.append((folder / "provenance.zip", folder / "provenance-manifest.json", "embedded"))
        else:
            write_zip(folder / "evidence.zip", folder / "manifest.json", sources, meta)
            bundles.append((folder / "evidence.zip", folder / "manifest.json", "embedded"))
        package_groups.append({"key": key, "claim": group["claim"], "limits": group["limits"], "source_files": len(sources), "source_bytes": sum(x["bytes"] for x in sources)})

    for group in inventory["groups"]:
        package(group)
    later_dirs = ["final-b-rollout-consolidated-20261119T061000Z", "b-representative-matrix-20261119T061359.293216Z", "door-b-report-evidence-20261119T061550.999378Z"]
    assert sha((TASK / later_dirs[0] / "inventory.json").read_bytes()) == "5805c633429595850cae904f868627c5b592470e286e3fe1452b2d520ba9af90"
    assert sha((TASK / "collected/20261119T060837.263748Z-full.json.gz").read_bytes()) == "94f36e050bc0b62f5c36b83a06cab2deeee525752f55432b10a5755330d1f7a5"
    later = [p for name in later_dirs for p in sorted((TASK / name).rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
    later += [TASK / "collected/20261119T060837.263748Z-full.json.gz", TASK / "collected/20261119T060837.263748Z-B-summary.json", TASK / "prepare_b_representative_matrix.py"]
    package({"key": "post-cutoff-rollout-and-b-results", "selected_files": [record(x) for x in later], "claim": "Separate later checkpoint: all 15 B installs, 13 ordinary queue resumes, held workers 1503/1505, and the first root-frozen B result collection plus a 35-case representative matrix.", "limits": ["The original inventory cutoff remains unchanged.", "The collection is incomplete: 43 B passes, 3 parity failures and 3 running; historical baseline attempts are excluded from B acceptance.", "Door Open's raw native alpha is not observed; the EPSILON causal explanation remains unproven.", "Profile v2 installation and resource-role execution receipts are later additions, not inferred from this checkpoint."]})
    provenance = [INVENTORY, INVENTORY.parent / "proposal.md", INVENTORY.parent / "receipt.json", Path(__file__), TASK / "apply_final_retention_addendum.py"]
    package({"key": "preparation-provenance", "selected_files": [record(x) for x in provenance], "claim": "Exact accepted inventory and local packaging/publication helper sources; publication is not executed by this package.", "limits": ["This package records preparation, not a fixture commit, push, gitlink change or new parity run."]})
    verified = []
    for archive, manifest, layout in bundles:
        count = validate_bundle(archive, manifest, layout)
        verified.append({"archive": archive.relative_to(namespace).as_posix(), "manifest": manifest.relative_to(namespace).as_posix(), "layout": layout, "verified_members": count, "archive_bytes": archive.stat().st_size, "archive_sha256": sha(archive.read_bytes()), "manifest_sha256": sha(manifest.read_bytes())})
    index = {"schema_version": 1, "prepared_at": stamp, "publication_executed": False, "accepted_inventory_sha256": INVENTORY_SHA, "accepted_inventory_cutoff_preserved": inventory["created_at"], "product_head": HEAD, "fixture_parent": FIXTURE_HEAD, "candidate": inventory["candidate"], "groups": package_groups, "bundles": verified, "historical_canonical_copy_limit": "Only the exact ten documented copied evidence paths may use their recorded canonical LF bytes; original bytes remain verified in the opaque ZIP. Real test snapshots are unchanged."}
    (destination / "package-index.json").write_bytes(raw_json(index))
    readme = ("# Final B evidence addendum\n\nThis addendum preserves original evidence bytes inside ZIPs. Historical manifests and the 06:06 inventory cutoff remain unchanged. Later rollout and B results are a separate package.\n\nThe frozen product is " + HEAD + ", fixtures " + FIXTURE_HEAD + ", and B runner " + RUNNER + ". The Linux build passed all 20 gates. Cold passed both paths over 1,586 frames and the separate streaming-profile control passed over 228 frames. Original reports retain all pending coverage and whole_song_parity_proven=false.\n\nThe first fleet B snapshot is incomplete. Installation and queue-launch receipts are operational evidence, not completed-job results. The two Door Open failures and Circles query failure remain retained.\n\nTen copied historical evidence files acquired only CRLF-to-LF conversion in their Git blobs because nested copied .gitattributes affected their storage. The opaque recovery ZIP preserves the exact original hashes. The verifier accepts only their exact original or recorded canonical bytes, after verifying the pinned ZIP, manifest, member identities and one-way CRLF conversion. No historical index row, copied attribute file, product input or real test snapshot is rewritten.\n\nSee package-index.json for every package identity, scope and limit.\n").encode()
    (destination / "README.md").write_bytes(readme)
    new_files = []
    for path in sorted(destination.rglob("*")):
        if path.is_file():
            row = record(path); assert row["bytes"] < 50_000_000
            new_files.append({"repo_path": path.relative_to(payload).as_posix(), "prepared_path": path.relative_to(out).as_posix(), "bytes": row["bytes"], "sha256": row["sha256"]})
    changes = out / "changes"; changes.mkdir()
    old = {name: (FIXTURES / PREFIX / name).read_bytes() for name in ["README.md", "evidence-files.json", "verify_evidence.py"]}
    additions = [{"path": x["repo_path"], "bytes": x["bytes"], "sha256": x["sha256"]} for x in new_files]
    index_before = json.loads(old["evidence-files.json"])
    closing = b"\r\n]\r\n"; assert old["evidence-files.json"].endswith(closing)
    inner = b"\r\n".join(x.encode() for x in json.dumps(additions, indent=2).splitlines()[1:-1])
    index_after = old["evidence-files.json"][:-len(closing)] + b",\r\n" + inner + closing
    assert json.loads(index_after) == index_before + additions
    nl = b"\r\n" if b"\r\n" in old["README.md"] else b"\n"
    readme_after = old["README.md"] + ("\n\n## Final B evidence addendum\n\nfinal-addendum/ retains the exact Linux B gates, Cold and streaming controls,\nWindows portable visual gate, scoped open diagnoses and resource retry proof.\nIts package index preserves the earlier inventory cutoff and labels the later\nall-worker installation and first B result snapshot separately. Those fleet\nresults are incomplete and retain all original coverage limits.\n\nTen copied evidence artifacts have exact recorded canonical LF Git blobs and\noriginal CRLF bytes. Both identities are bound to the opaque recovery ZIP;\nno historical evidence row or real test snapshot is rewritten.\n").encode().replace(b"\n", nl)
    verifier_before = old["verify_evidence.py"]
    vn = b"\r\n" if b"\r\n" in verifier_before else b"\n"
    anchor = b'        ("stream-finalization/stream-commit-b2af4f3.zip", "stream-finalization/manifest.json", "embedded"),'
    assert verifier_before.count(anchor) == 1
    entries = vn.join(('        (' + repr(x["archive"]) + ', ' + repr(x["manifest"]) + ', ' + repr(x["layout"]) + '),').encode() for x in verified)
    registered = verifier_before.replace(anchor, anchor + vn + entries, 1)
    recovery = RECOVERY_CODE.encode().replace(b"\n", vn)
    assert registered.count(b"def verify():") == 1
    portable = registered.replace(b"def verify():", recovery + b"def verify():", 1)
    first = b'    evidence = json.loads((ROOT / "evidence-files.json").read_text(encoding="utf-8"))'
    portable = portable.replace(first, first + vn + b"    recovery = original_byte_recovery()" + vn + b"    canonical_copies = []", 1)
    checks = vn.join([b'        assert len(data) == item["bytes"], item["path"]', b'        assert digest(data) == item["sha256"], item["path"]', b'        assert len(data) < 50_000_000, item["path"]'])
    assert portable.count(checks) == 1
    portable = portable.replace(checks, vn.join([b"        if verify_evidence_item(item, data, recovery):", b'            canonical_copies.append(item["path"])']), 1)
    final_print = b'    print(json.dumps({"verified_files": len(evidence), "verified_zip_members": counts}, sort_keys=True))'
    assert portable.count(final_print) == 1
    portable = portable.replace(final_print, b'    print(json.dumps({"verified_files": len(evidence), "verified_zip_members": counts, "canonical_git_evidence_copies_verified": sorted(canonical_copies), "opaque_original_evidence_verified": len(recovery)}, sort_keys=True))', 1)
    (changes / "verifier-registration.patch").write_bytes(patch_text(verifier_before, registered, PREFIX + "verify_evidence.py"))
    (changes / "verifier-portability.patch").write_bytes(patch_text(registered, portable, PREFIX + "verify_evidence.py"))
    modified = []
    for name, after in [("README.md", readme_after), ("evidence-files.json", index_after), ("verify_evidence.py", portable)]:
        before_path = changes / (name + ".before"); after_path = changes / (name + ".after")
        before_path.write_bytes(old[name]); after_path.write_bytes(after)
        modified.append({"repo_path": PREFIX + name, "before": {k: v for k, v in record(before_path).items() if k != "path"}, "after": {k: v for k, v in record(after_path).items() if k != "path"}, "prepared_after_path": after_path.relative_to(out).as_posix()})
    # Verify the complete proposed layout using copies only; original repositories stay frozen.
    shadow = out / "validation/fixture-shadow"; shadow.mkdir(parents=True)
    for row in index_before:
        src = FIXTURES / row["path"]; raw = src.read_bytes()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
        dest = shadow / row["path"]; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
    for name, raw in old.items():
        dest = shadow / PREFIX / name; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
    (shadow / ".gitattributes").write_bytes((FIXTURES / ".gitattributes").read_bytes())
    subprocess.run(["git", "init", "-q", str(shadow)], check=True)
    subprocess.run(["git", "-C", str(shadow), "add", "--", ".gitattributes", *[PREFIX + x for x in old]], check=True, capture_output=True)
    for row in new_files:
        dest = shadow / row["repo_path"]; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(out / row["prepared_path"], dest)
    for row in modified:
        (shadow / row["repo_path"]).write_bytes((out / row["prepared_after_path"]).read_bytes())
    commands = []
    def run_check(name, command):
        result = subprocess.run(command, cwd=shadow, capture_output=True)
        for kind, raw in [("stdout", result.stdout), ("stderr", result.stderr)]:
            (out / "validation" / (name + "." + kind)).write_bytes(raw)
        commands.append({"name": name, "command": command, "exit_code": result.returncode, "stdout_sha256": sha(result.stdout), "stderr_sha256": sha(result.stderr)})
        assert result.returncode == 0, (name, result.stderr.decode(errors="replace"))
    run_check("original-byte-layout", [sys.executable, "-X", "utf8", str(shadow / PREFIX / "verify_evidence.py")])
    for row in inventory["published"]["canonical_differences"]:
        canonical = git(FIXTURES, "show", FIXTURE_HEAD + ":" + row["path"])
        assert len(canonical) == row["canonical_git_blob_bytes"] and sha(canonical) == row["canonical_git_blob_sha256"]
        (shadow / row["path"]).write_bytes(canonical)
    run_check("canonical-git-layout", [sys.executable, "-X", "utf8", str(shadow / PREFIX / "verify_evidence.py")])
    run_check("diff-check", ["git", "-C", str(shadow), "diff", "--check"])
    (changes / "combined-metadata.patch").write_bytes(git(shadow, "diff", "--binary", "--full-index"))
    # Direct focused controls use only the actual ten original/Git byte pairs.
    scope = {"__name__": "retention_verifier_review", "__file__": str(shadow / PREFIX / "verify_evidence.py")}
    exec(compile(portable, "proposed-verify_evidence.py", "exec"), scope)
    recovery = scope["original_byte_recovery"](); focused = []
    def expect_failure(name, call):
        try:
            call()
        except (AssertionError, FileNotFoundError, zipfile.BadZipFile):
            focused.append({"name": name, "passed": True})
        else:
            raise AssertionError(name)
    for row in inventory["published"]["canonical_differences"]:
        item = {"path": row["path"], "bytes": row["manifest_bytes"], "sha256": row["manifest_sha256"]}
        original, canonical = recovery[row["path"]]
        assert scope["verify_evidence_item"](item, original, recovery) is False
        assert scope["verify_evidence_item"](item, canonical, recovery) is True
        focused += [{"name": row["path"] + ": actual original", "passed": True}, {"name": row["path"] + ": actual Git blob", "passed": True}]
    item = {"path": inventory["published"]["canonical_differences"][0]["path"], "bytes": len(original), "sha256": sha(original)}
    original, canonical = recovery[item["path"]]; item.update(bytes=len(original), sha256=sha(original))
    expect_failure("unlisted path has no normalization fallback", lambda: scope["verify_evidence_item"]({**item, "path": PREFIX + "unlisted.rs"}, canonical, recovery))
    expect_failure("mapped canonical bytes reject a changed byte", lambda: scope["verify_evidence_item"](item, canonical + b"x", recovery))
    expect_failure("historical index cannot replace original hash", lambda: scope["verify_evidence_item"]({**item, "bytes": len(canonical), "sha256": sha(canonical)}, canonical, recovery))
    recover_folder = shadow / PREFIX / "final-addendum/portable-evidence-original-bytes"
    for name in ["evidence.zip", "manifest.json"]:
        path = recover_folder / name; raw = path.read_bytes(); path.write_bytes(raw + b"x")
        expect_failure("pinned recovery " + name + " rejects tampering", lambda: scope["original_byte_recovery"]())
        path.write_bytes(raw)
    assert len(scope["original_byte_recovery"]()) == 10
    focused_receipt = {"passed": True, "checks": focused, "actual_original_and_canonical_pairs": 10, "historical_index_changed": False, "new_zip_registration_patch": record(changes / "verifier-registration.patch"), "separate_portability_patch": record(changes / "verifier-portability.patch")}
    (out / "validation/recovery-controls.json").write_bytes(raw_json(focused_receipt))
    plan = {"schema_version": 1, "scope": "Prepared evidence-only publication, not applied", "fixture_worktree": str(FIXTURES), "fixture_parent": FIXTURE_HEAD, "product_head": HEAD, "publication_helper_sha256": sha((TASK / "apply_final_retention_addendum.py").read_bytes()), "accepted_inventory_sha256": INVENTORY_SHA, "new_files": new_files, "modified_files": modified, "bundles": verified, "checks": commands, "recovery_controls": record(out / "validation/recovery-controls.json"), "registration_patch": record(changes / "verifier-registration.patch"), "portability_patch": record(changes / "verifier-portability.patch"), "historical_index_prefix_preserved": True, "historical_manifests_unchanged": True, "product_gitlink_unchanged": True, "applied": False}
    plan_path = out / "publication-plan.json"; plan_path.write_bytes(raw_json(plan))
    result = subprocess.run([sys.executable, "-X", "utf8", str(TASK / "apply_final_retention_addendum.py"), "--prepared", str(out), "--plan-sha256", sha(plan_path.read_bytes())], capture_output=True)
    (out / "validation/publication-preflight.stdout").write_bytes(result.stdout); (out / "validation/publication-preflight.stderr").write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr.decode(errors="replace")
    assert unchanged() == before
    receipt = {"directory": str(out), "plan": record(plan_path), "new_files": len(new_files), "new_bytes": sum(x["bytes"] for x in new_files), "bundles": len(bundles), "verified_members": sum(x["verified_members"] for x in verified), "largest_blob_bytes": max(x["bytes"] for x in new_files), "recovery_controls": len(focused), "publication_preflight_passed": True, "publication_executed": False, "repositories_unchanged": True}
    (out / "receipt.json").write_bytes(raw_json(receipt))
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
