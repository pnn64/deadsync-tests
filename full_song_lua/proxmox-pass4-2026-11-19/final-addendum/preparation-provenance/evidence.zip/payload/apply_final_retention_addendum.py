"""Review or apply one hash-bound evidence-only publication; never commit or push."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys

TASK = Path(__file__).resolve().parent
PRODUCT = TASK.parents[1]
FIXTURES = Path(r"C:\GitHub\deadsync-fixtures-lua-fleet-20261119")
HEAD = "81c18c105ad9e70e1d6d9a84c610e3a2de477899"
FIXTURE_HEAD = "11f6edff529423df9ffef9458e93f7726183a646"
PREFIX = "full_song_lua/proxmox-pass4-2026-11-19/"
MODIFIED = {PREFIX + name for name in ["README.md", "evidence-files.json", "verify_evidence.py"]}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result, key
        result[key] = value
    return result


def git(path, *args):
    return subprocess.check_output(["git", "-C", str(path), *args])


def safe_path(value):
    path = PurePosixPath(value)
    assert value and not path.is_absolute() and ".." not in path.parts and "\\" not in value and ":" not in value
    return path


def checked_bytes(path, row):
    raw = path.read_bytes()
    assert len(raw) == row["bytes"] and sha(raw) == row["sha256"], path
    assert len(raw) < 50_000_000, path
    return raw


def unchanged_product():
    for path, expected in [(PRODUCT, HEAD), (PRODUCT / "tests/fixtures", FIXTURE_HEAD)]:
        assert git(path, "rev-parse", "HEAD").decode().strip() == expected
        assert not git(path, "status", "--porcelain", "--untracked-files=no")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--plan-sha256", required=True)
    parser.add_argument("--apply", action="store_true", help="Without this explicit flag, perform read-only preflight only")
    args = parser.parse_args()
    prepared = args.prepared.resolve(strict=True)
    assert prepared.is_relative_to(TASK.resolve())
    raw = (prepared / "publication-plan.json").read_bytes()
    assert sha(raw) == args.plan_sha256
    plan = json.loads(raw, object_pairs_hook=no_duplicates)
    assert plan["fixture_parent"] == FIXTURE_HEAD and plan["product_head"] == HEAD
    assert plan["publication_helper_sha256"] == sha(Path(__file__).read_bytes())
    assert Path(plan["fixture_worktree"]).resolve() == FIXTURES.resolve()
    unchanged_product()
    assert git(FIXTURES, "rev-parse", "HEAD").decode().strip() == FIXTURE_HEAD
    assert not git(FIXTURES, "status", "--porcelain", "--untracked-files=all")
    assert not git(FIXTURES, "diff", "--cached", "--binary")
    assert {x["repo_path"] for x in plan["modified_files"]} == MODIFIED
    names = [x["repo_path"] for x in plan["new_files"]]
    assert len(names) == len(set(names)) and not set(names).intersection(MODIFIED)
    new_bytes = []; modified_bytes = []
    for row in plan["new_files"]:
        rel = safe_path(row["repo_path"])
        assert str(rel).startswith(PREFIX + "final-addendum/")
        target = FIXTURES / rel
        assert target.resolve().is_relative_to((FIXTURES / PREFIX / "final-addendum").resolve())
        assert not target.exists(), target
        source = prepared / safe_path(row["prepared_path"])
        assert source.resolve().is_relative_to(prepared)
        new_bytes.append((target, checked_bytes(source, row)))
    for row in plan["modified_files"]:
        target = FIXTURES / safe_path(row["repo_path"])
        checked_bytes(target, row["before"])
        source = prepared / safe_path(row["prepared_after_path"])
        assert source.resolve().is_relative_to(prepared)
        modified_bytes.append((target, checked_bytes(source, row["after"])))
    before_index = json.loads((FIXTURES / PREFIX / "evidence-files.json").read_bytes())
    after_index = json.loads(next(data for path, data in modified_bytes if path.name == "evidence-files.json"))
    expected_additions = [{"path": x["repo_path"], "bytes": x["bytes"], "sha256": x["sha256"]} for x in plan["new_files"]]
    assert after_index == before_index + expected_additions
    preview = {"scope": "Evidence-only publication; no source, expectation, product gitlink, commit or push", "plan_sha256": args.plan_sha256, "preflight_passed": True, "apply_requested": args.apply, "new_files": len(new_bytes), "modified_files": sorted(MODIFIED), "fixture_parent": FIXTURE_HEAD}
    if not args.apply:
        print(json.dumps(preview, indent=2))
        return
    assert not (prepared / "application-receipt.json").exists()
    for target, data in new_bytes:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(data)
        assert target.read_bytes() == data
    for target, data in modified_bytes:
        temporary = target.with_name(target.name + ".final-addendum.tmp")
        with temporary.open("xb") as stream:
            stream.write(data)
        temporary.replace(target)
        assert target.read_bytes() == data
    checks = []
    for name, command in [("fixture-verifier", [sys.executable, "-X", "utf8", str(FIXTURES / PREFIX / "verify_evidence.py")]), ("diff-check", ["git", "-C", str(FIXTURES), "diff", "--check"])]:
        result = subprocess.run(command, cwd=FIXTURES, capture_output=True)
        for kind, data in [("stdout", result.stdout), ("stderr", result.stderr)]:
            with (prepared / ("application-" + name + "." + kind)).open("xb") as stream:
                stream.write(data)
        checks.append({"name": name, "command": command, "exit_code": result.returncode, "stdout_sha256": sha(result.stdout), "stderr_sha256": sha(result.stderr)})
    unchanged_product()
    assert not git(FIXTURES, "diff", "--cached", "--binary")
    assert set(git(FIXTURES, "diff", "--name-only").decode().splitlines()) == MODIFIED
    untracked = set(filter(None, git(FIXTURES, "ls-files", "--others", "--exclude-standard", "-z").decode().split("\0")))
    assert untracked == set(names), untracked ^ set(names)
    receipt = {**preview, "applied": True, "checks": checks, "passed": all(x["exit_code"] == 0 for x in checks), "product_unchanged": True, "fixture_index_unchanged": True, "committed": False, "pushed": False}
    with (prepared / "application-receipt.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps(receipt, indent=2))
    assert receipt["passed"], "Publication bytes retained for review; verification failed and no automatic rollback or commit was performed"


if __name__ == "__main__":
    main()
