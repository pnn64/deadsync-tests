# Quarantine retained native diagnostic overflow

This bundle describes exactly one retained attempt: VM 1501, job
`2f376ce76ff65534-c0003`, capture `493516b8fcaa99cc32bd-001`.
The original `capture_error` is preserved. No recapture, validator change,
guest write, or result reclassification was performed.

The native trace retains 128 script errors and reports 22 additional dropped
errors. Every retained error is a ScreenGameplay tween overflow. The capture
reached the gameplay exit and committed its stage, but an errorful completed
run cannot be accepted as a valid parity fixture. Its service exited with code
1; its resource receipt does not indicate OOM or timeout.

The pinned observer limits retained script errors to 128 and increments a
dropped counter thereafter. The pinned Rust validator rejects that nonzero
counter before displaying the first retained error, producing the generic
"native script-error diagnostics are incomplete" message. The worker's
original classifier does not recognize this particular diagnostic as its
`native_lua_or_setup_error` family, so the retained status is `capture_error`.

The authored source, matched to the frozen corpus hash, creates a Quad for
each enabled player. Both subscribe to Loop/Loop2 messages and queue the same
message after a short sleep. Native queuemessage uses a global broadcast. This
feedback path is consistent with the P1/P2 tween-queue overflow records; this
is a source-based causal inference, not a reconstruction of all dropped
observer objects. No claim is made about other Quarantine attempts or the
other similarly worded capture failures.

Source authority (canonical bytes retained under source/):

- native/src/Actor.cpp: 801-845 executes queued global broadcasts; 989-1002
  reports and recovers from a queue over 50 tweens; 1490-1509 implements sleep
  and queued messages; 1512-1525 registers message subscribers.
- native/src/LuaManager.cpp: 811-833 broadcasts/logs script errors.
- harness/native/interactive_trace.cpp: 344-352 bounds the error observer.
- harness/native/trace_adapter.cmake: 153-155 injects the native observer hook.
- harness/src/song_lua_runtime.rs: 342-355 rejects dropped diagnostics before
  reporting the first retained error.
- harness/probe_theme/SongLuaTrace.lua: 1278-1292 separates destination-screen
  errors from gameplay errors; the original dropped count remains explicit.
- authored/multitap/Default.lua: 1221-1237 creates one subscriber per player;
  1297-1346 defines the Loop and Loop2 feedback handlers.
- worker.py: 412-421 preserves the original classification behavior.

`original-capture-result.json` exactly matches the original guest byte hash.
`inspection-receipt.json` records the read-only remote inspection, the native
document hash, all log member hashes, and the compressed/decompressed archive
checks. The exact small logs and native metadata are included. The 355 MB
native document remains inside the separately retained 15 MB diagnostic
archive; the archive's location and hashes are referenced in diagnosis.json.
The compact ZIP does not embed that large diagnostic archive.
