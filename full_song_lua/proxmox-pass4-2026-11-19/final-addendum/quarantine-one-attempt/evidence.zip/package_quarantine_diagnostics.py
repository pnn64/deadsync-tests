"""Package one already-inspected Quarantine failure; no network or guest writes."""
import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import zipfile

import zstandard


HERE = Path(__file__).resolve().parent
INSPECTION = HERE / 'quarantine-diagnostics-inspection-20261119T045409.260172Z'
RECEIPT_SHA = 'ba00302bce0ca8e83e33664fe71da4be508a3934b2921116e12f2e82b456bcec'
NATIVE_PIN = '663525dcb86eb570d0ef6a2e209678436660ae26'
HARNESS_PIN = '9eb6619c0eaf9c3aceabf7348efbb06a7fd37273'
NATIVE_REPO = Path('C:/GitHub/itgmania-harness/vendor/itgmania')
HARNESS_REPO = Path('C:/GitHub/itgmania-harness-linux-20261119')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode())


stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
destination = HERE / ('quarantine-diagnostics-evidence-' + stamp)
destination.mkdir()
receipt_bytes = (INSPECTION / 'receipt.json').read_bytes()
assert sha(receipt_bytes) == RECEIPT_SHA
receipt = json.loads(receipt_bytes)
assert receipt['exit_code'] == 0 and receipt['guest_writes'] is False
data = receipt['inspection']
original = receipt['original_capture_result']
assert original['data']['id'] == '2f376ce76ff65534-c0003'
assert original['data']['status'] == 'capture_error'
native = data['native']
metadata = native['metadata']
errors = metadata['script_errors']
assert len(errors) == 128 and metadata['dropped_script_errors'] == 22

# Reconstruct using the original worker's write_json serialization, then require
# byte identity with the original on-guest receipt digest before retaining it.
original_bytes = (json.dumps(original['data'], ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
assert len(original_bytes) == original['bytes'] and sha(original_bytes) == original['sha256']
(destination / 'original-capture-result.json').write_bytes(original_bytes)
(destination / 'inspection-receipt.json').write_bytes(receipt_bytes)
for name in ('remote.stdout', 'remote.stderr'):
    content = (INSPECTION / name).read_bytes()
    key = 'stdout_sha256' if name.endswith('stdout') else 'stderr_sha256'
    assert sha(content) == receipt[key]
    (destination / name).write_bytes(content)
selection = HERE / 'quarantine-diagnostics-selection.json.gz'
assert digest(selection) == receipt['selection_sha256']
shutil.copyfile(selection, destination / selection.name)
save_json(destination / 'native-metadata.json', native)

# Extract only the three small log members from the already-downloaded archive.
# The full native document stays in that exact retained artifact; its separately
# verified byte hash is kept in the metadata and inspection receipt.
artifact = data['archive']
archive_path = HERE / 'quarantine-diagnostics-artifacts' / (artifact['sha256'] + '.tar.zst')
assert archive_path.stat().st_size == artifact['bytes'] and digest(archive_path) == artifact['sha256']
expected_logs = {row['path']: row for row in data['logs']}
assert len(expected_logs) == 3
log_evidence = []
found = set()
with archive_path.open('rb') as packed, zstandard.ZstdDecompressor().stream_reader(packed) as decoded:
    with tarfile.open(fileobj=decoded, mode='r|') as archive:
        for member in archive:
            if member.name not in expected_logs:
                continue
            expected = expected_logs[member.name]
            assert member.isfile() and member.size == expected['bytes']
            content = archive.extractfile(member).read()
            assert len(content) == expected['bytes'] and sha(content) == expected['sha256']
            target = destination / 'logs' / Path(member.name).name
            target.parent.mkdir(exist_ok=True)
            target.write_bytes(content)
            lines = content.decode('utf-8', errors='replace').splitlines()
            overflow = [{'line': i, 'text': line} for i, line in enumerate(lines, 1) if 'Tween overflow:' in line]
            log_evidence.append({
                'member': member.name, 'file': target.relative_to(destination).as_posix(),
                'sha256': sha(content), 'bytes': len(content),
                'overflow_lines': overflow,
                'overflow_by_player': dict(collections.Counter(
                    'P1' if 'MultitapFrameP1/' in row['text'] else 'P2' if 'MultitapFrameP2/' in row['text'] else 'other'
                    for row in overflow)),
            })
            found.add(member.name)
            if found == set(expected_logs):
                break
assert found == set(expected_logs)

# Use canonical Git blobs at the actual native/harness pins, not mutable worktree
# copies or platform newline conversions.
source_evidence = []
sources = [
    (NATIVE_REPO, NATIVE_PIN, 'src/Actor.cpp', 'native'),
    (NATIVE_REPO, NATIVE_PIN, 'src/LuaManager.cpp', 'native'),
    (HARNESS_REPO, HARNESS_PIN, 'native/interactive_trace.cpp', 'harness'),
    (HARNESS_REPO, HARNESS_PIN, 'native/trace_adapter.cmake', 'harness'),
    (HARNESS_REPO, HARNESS_PIN, 'src/song_lua_runtime.rs', 'harness'),
    (HARNESS_REPO, HARNESS_PIN, 'probe_theme/SongLuaTrace.lua', 'harness'),
]
for repo, pin, relative, family in sources:
    actual = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', pin + '^{commit}']).decode().strip()
    assert actual == pin
    content = subprocess.check_output(['git', '-C', str(repo), 'show', pin + ':' + relative])
    blob = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', pin + ':' + relative]).decode().strip()
    target = destination / 'source' / family / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    source_evidence.append({'commit': pin, 'git_path': relative, 'blob': blob,
        'file': target.relative_to(destination).as_posix(), 'bytes': len(content), 'sha256': sha(content)})
worker = HERE / 'worker.py'
assert digest(worker) == original['data']['pins']['worker_script_sha256']
shutil.copyfile(worker, destination / 'source' / 'worker.py')

manifest_path = HERE / 'corpus-manifest.json'
corpus = json.loads(manifest_path.read_bytes())
authored_path = '__variants__/debug-pack/Cringle Culmination/Quarantine/multitap/Default.lua'
authored = next(row for row in corpus['files'] if row['path'] == authored_path)
assert authored['sha256'] == '488e6fd77c30fd586f447a4156d5cdf39ea47586dd6e3e6a529db9c71e2ad4f2'
authored_bytes = Path(authored['source_path']).read_bytes()
assert len(authored_bytes) == authored['bytes'] and sha(authored_bytes) == authored['sha256']
target = destination / 'source' / 'authored' / 'multitap' / 'Default.lua'
target.parent.mkdir(parents=True)
target.write_bytes(authored_bytes)
save_json(destination / 'authored-source-binding.json', {
    'corpus_manifest_sha256': digest(manifest_path), 'entry': authored,
    'source_simfile': original['data']['job']['source_simfile'],
    'simfile_sha256': original['data']['job']['simfile_sha256'],
    'folder_sha256': original['data']['job']['folder_sha256'],
})
save_json(destination / 'source-authority.json', source_evidence)
error_groups = collections.Counter((row['screen'], row['message']) for row in errors)
assert all(row['screen'] == 'ScreenGameplay' and row['message'].startswith('Tween overflow:') for row in errors)
summary = {
    'schema_version': 1, 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Only VM 1501 job 2f376ce76ff65534-c0003 capture-493516b8fcaa99cc32bd-001 was inspected.',
    'original_classification': original['data']['status'], 'classification_changed': False,
    'new_capture': False, 'validator_changed': False, 'guest_writes': False,
    'original_capture_result_sha256': original['sha256'],
    'native_sha256': native['sha256'], 'native_bytes': native['bytes'],
    'native_update_frames': native['update_frames_before_events'],
    'script_error_records': len(errors), 'dropped_script_errors': metadata['dropped_script_errors'],
    'observer_error_total': len(errors) + metadata['dropped_script_errors'],
    'script_error_groups': [{'screen': key[0], 'message': key[1], 'count': count}
                            for key, count in sorted(error_groups.items())],
    'completion': metadata.get('completion'),
    'other_drop_counters': {key: value for key, value in metadata.items()
                            if key.startswith('dropped_') and key != 'dropped_script_errors'},
    'capture_stage': original['data']['stages']['capture'],
    'logs': log_evidence,
    'large_artifact_reference': {**artifact, 'downloaded_local_path': str(archive_path),
        'included_in_this_compact_bundle': False},
    'interpretation': {
        'observed': 'The native gameplay emitted tween-overflow script errors. The observer retained its first 128 errors and counted 22 additional errors. The harness rejects the nonzero dropped count before formatting the first retained error.',
        'source_inference': 'The authored versus foreground creates one Loop/Loop2 subscriber per enabled player. Each handler sleeps and queues the same global message. Native queuemessage broadcasts to subscribers; this is a source-backed feedback path consistent with the observed MultitapFrameP1/P2 overflow storm.',
        'limits': 'The 22 dropped native error objects are not recoverable from the capped observer array. Exact full logs are retained separately; duplicate logging is not counted as additional observer events. This one attempt does not classify every similarly worded failure.',
    },
}
save_json(destination / 'diagnosis.json', summary)
readme = '''# Quarantine retained native diagnostic overflow

This bundle describes exactly one retained attempt: VM 1501, job
`2f376ce76ff65534-c0003`, capture `493516b8fcaa99cc32bd-001`.
The original `capture_error` is preserved. No recapture, validator change,
guest write, or result reclassification was performed.

The native trace retains 128 script errors and reports 22 additional dropped
errors. Every retained error is a ScreenGameplay tween overflow. The capture
reached the gameplay exit and committed its stage, but an errorful completed
run cannot be accepted as a valid parity fixture. Its service exited with code
1; its resource receipt does not indicate OOM or timeout.

The pinned observer limits retained script errors to 128 and increments a
dropped counter thereafter. The pinned Rust validator rejects that nonzero
counter before displaying the first retained error, producing the generic
"native script-error diagnostics are incomplete" message. The worker's
original classifier does not recognize this particular diagnostic as its
`native_lua_or_setup_error` family, so the retained status is `capture_error`.

The authored source, matched to the frozen corpus hash, creates a Quad for
each enabled player. Both subscribe to Loop/Loop2 messages and queue the same
message after a short sleep. Native queuemessage uses a global broadcast. This
feedback path is consistent with the P1/P2 tween-queue overflow records; this
is a source-based causal inference, not a reconstruction of all dropped
observer objects. No claim is made about other Quarantine attempts or the
other similarly worded capture failures.

Source authority (canonical bytes retained under source/):

- native/src/Actor.cpp: 801-845 executes queued global broadcasts; 989-1002
  reports and recovers from a queue over 50 tweens; 1490-1509 implements sleep
  and queued messages; 1512-1525 registers message subscribers.
- native/src/LuaManager.cpp: 811-833 broadcasts/logs script errors.
- harness/native/interactive_trace.cpp: 344-352 bounds the error observer.
- harness/native/trace_adapter.cmake: 153-155 injects the native observer hook.
- harness/src/song_lua_runtime.rs: 342-355 rejects dropped diagnostics before
  reporting the first retained error.
- harness/probe_theme/SongLuaTrace.lua: 1278-1292 separates destination-screen
  errors from gameplay errors; the original dropped count remains explicit.
- authored/multitap/Default.lua: 1221-1237 creates one subscriber per player;
  1297-1346 defines the Loop and Loop2 feedback handlers.
- worker.py: 412-421 preserves the original classification behavior.

`original-capture-result.json` exactly matches the original guest byte hash.
`inspection-receipt.json` records the read-only remote inspection, the native
document hash, all log member hashes, and the compressed/decompressed archive
checks. The exact small logs and native metadata are included. The 355 MB
native document remains inside the separately retained 15 MB diagnostic
archive; the archive's location and hashes are referenced in diagnosis.json.
The compact ZIP does not embed that large diagnostic archive.
'''
(destination / 'README.md').write_bytes(readme.encode())
for helper in ('inspect_quarantine_diagnostics.py', Path(__file__).name):
    shutil.copyfile(HERE / helper, destination / helper)
files = [{'path': path.relative_to(destination).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest(path)}
         for path in sorted(destination.rglob('*')) if path.is_file()]
save_json(destination / 'manifest.json', {'schema_version': 1, 'files': files})
zip_path = destination.with_suffix('.zip')
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as packed:
    for path in sorted(destination.rglob('*')):
        if path.is_file():
            packed.write(path, path.relative_to(destination).as_posix())
with zipfile.ZipFile(zip_path) as packed:
    assert packed.read('manifest.json') == (destination / 'manifest.json').read_bytes()
    assert set(packed.namelist()) == {row['path'] for row in files} | {'manifest.json'}
    for row in files:
        content = packed.read(row['path'])
        assert len(content) == row['bytes'] and sha(content) == row['sha256']
print(json.dumps({'directory': str(destination), 'zip': str(zip_path),
    'zip_bytes': zip_path.stat().st_size, 'zip_sha256': digest(zip_path),
    'manifest_sha256': digest(destination / 'manifest.json'), 'files': len(files),
    'script_error_records': len(errors), 'dropped_script_errors': metadata['dropped_script_errors'],
    'script_error_groups': summary['script_error_groups'],
    'logs': [{key: row[key] for key in ('file', 'bytes', 'sha256', 'overflow_by_player')}
             for row in log_evidence]}, indent=2))
