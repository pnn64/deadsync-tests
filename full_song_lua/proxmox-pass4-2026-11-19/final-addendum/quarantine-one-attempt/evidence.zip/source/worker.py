#!/usr/bin/env python3
"""Resumable, bounded native song-Lua captures and independent DeadSync replays.

Run on a Linux guest as parity (passwordless sudo for systemd-run/journalctl).
All source inputs are frozen; only --root/results is written. Native failures
remain failures. A successful replay proves only its implemented comparisons.
"""
from __future__ import annotations

import argparse
import collections
import contextlib
import datetime as dt
import hashlib
import json
import math
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tarfile
import time
import traceback

if os.name == "posix":
    import fcntl


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(path):
    with pathlib.Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def tree_digest(root):
    root = pathlib.Path(root)
    hasher = hashlib.sha256()
    for directory, names, filenames in os.walk(root):
        names[:] = sorted(name for name in names if name != ".git")
        for filename in sorted(filenames):
            if filename == ".git":
                continue
            path = pathlib.Path(directory) / filename
            relative = path.relative_to(root).as_posix()
            hasher.update(relative.encode("utf-8") + b"\0" + digest(path).encode("ascii") + b"\n")
    return hasher.hexdigest()


def identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def write_json(path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp." + str(os.getpid()))
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def read_json(path):
    return json.loads(pathlib.Path(path).read_text(encoding="utf-8"))


def bounded(value, depth=0):
    if depth > 7:
        return "<nested value retained in full artifact>"
    if isinstance(value, str):
        return value[:2000]
    if isinstance(value, list):
        return [bounded(item, depth + 1) for item in value[:40]]
    if isinstance(value, dict):
        return {key: bounded(item, depth + 1) for key, item in list(value.items())[:50]}
    return value


def tail(path, limit=12000):
    path = pathlib.Path(path)
    if not path.is_file():
        return ""
    with path.open("rb") as stream:
        stream.seek(max(0, path.stat().st_size - limit))
        return stream.read().decode("utf-8", errors="replace")


def checked_relative(root, relative):
    root = pathlib.Path(root).resolve()
    candidate = (root / relative).resolve()
    if not candidate.is_relative_to(root) or candidate == root:
        raise ValueError(f"path escapes selected root: {relative}")
    return candidate


def systemd_quote(value):
    value = str(value)
    if any(char in value for char in "\r\n\0"):
        raise ValueError("invalid systemd command argument")
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"').replace("%", "%%") + '"'


def stage_finished(spec_path):
    """ExecStopPost persists the outcome even after timeout/OOM/coordinator loss."""
    spec = read_json(spec_path)
    service_result = os.environ.get("SERVICE_RESULT", "unknown")
    exit_code = os.environ.get("EXIT_CODE")
    exit_status = os.environ.get("EXIT_STATUS")
    if service_result == "success":
        code = 0
    elif service_result == "timeout":
        code = 124
    elif service_result == "oom-kill":
        code = 137
    elif exit_code == "exited" and str(exit_status).isdigit():
        code = int(exit_status) or 1
    else:
        code = 1
    metrics = subprocess.run(["systemctl", "show", spec["unit"], "--property=MemoryPeak",
                              "--property=CPUUsageNSec"], capture_output=True, text=True)
    resource_usage = {}
    for line in metrics.stdout.splitlines():
        key, separator, value = line.partition("=")
        if separator and value.isdigit():
            resource_usage[key] = int(value)
    write_json(pathlib.Path(spec_path).with_name("receipt.json"), {
        "fingerprint": spec["fingerprint"], "unit": spec["unit"],
        "command": spec["command"], "started_at": spec["started_at"],
        "finished_at": now(), "elapsed_seconds": round(time.time() - spec["started_epoch"], 3),
        "exit": code, "service_result": service_result,
        "exit_code": exit_code, "exit_status": exit_status,
        "memory_limit": spec["memory_limit"], "timeout_seconds": spec["timeout_seconds"],
        "resource_usage": resource_usage,
    })


class StageError(RuntimeError):
    def __init__(self, stage, receipt, message):
        super().__init__(message)
        self.stage, self.receipt = stage, receipt


def execute_stage(args, directory, name, command, seconds, memory, binding):
    """A complete matching receipt is replayed; active matching units are adopted."""
    for binary, observed in args.binary_stats.items():
        current = pathlib.Path(binary).stat()
        if (current.st_size, current.st_mtime_ns) != observed:
            raise RuntimeError("pinned executable changed during worker run: " + binary)
    directory = pathlib.Path(directory) / "stages" / name
    directory.mkdir(parents=True, exist_ok=True)
    log_path = directory / "output.log"
    spec_path = directory / "spec.json"
    receipt_path = directory / "receipt.json"
    environment = {
        "TMPDIR": str(pathlib.Path(directory).parents[1] / "tmp"),
        "DISPLAY": args.display, "LIBGL_ALWAYS_SOFTWARE": "1", "LP_NUM_THREADS": "1",
        "ITGMANIA_SONG_LUA_NOTESKIN_ROOT": str(args.noteskins),
    }
    pathlib.Path(environment["TMPDIR"]).mkdir(parents=True, exist_ok=True)
    command = list(map(str, command))
    contract = {"command": command, "environment": environment, "binding": binding,
                "memory_limit": memory, "timeout_seconds": seconds,
                "working_directory": str(args.root), "user": args.user}
    fingerprint = identity(contract)
    unit = "song-lua-pass4-" + name + "-" + fingerprint[:20]
    if spec_path.exists():
        spec = read_json(spec_path)
        if spec["fingerprint"] != fingerprint:
            raise RuntimeError(f"refusing changed stage contract at {directory}")
    else:
        spec = {**contract, "fingerprint": fingerprint, "unit": unit,
                "started_at": now(), "started_epoch": time.time()}
        write_json(spec_path, spec)
    if receipt_path.exists():
        receipt = read_json(receipt_path)
        if receipt.get("fingerprint") != fingerprint:
            raise RuntimeError(f"stage receipt binding mismatch at {directory}")
        receipt["reused_receipt"] = True
        return receipt
    active = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True).stdout.strip()
    if active in {"active", "activating", "deactivating", "reloading"}:
        while not receipt_path.exists():
            time.sleep(2)
            active = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True).stdout.strip()
            if active not in {"active", "activating", "deactivating", "reloading"}:
                break
    else:
        # An earlier process might have exited between the preceding checks.
        journal = subprocess.run(["sudo", "journalctl", "--no-pager", "-u", unit, "-n", "1", "-o", "cat"],
                                 capture_output=True, text=True)
        if journal.stdout.strip() and "No entries" not in journal.stdout:
            raise RuntimeError(f"orphaned stage {unit}: journal exists without a receipt; inspect before retry")
        stop_command = " ".join(systemd_quote(part) for part in
                                [sys.executable, pathlib.Path(__file__).resolve(), "__stage_finished", spec_path])
        launch = ["sudo", "systemd-run", "--quiet", "--wait", "--collect", "--unit=" + unit,
                  "--property=MemoryMax=" + memory, "--property=MemorySwapMax=0",
                  "--property=OOMPolicy=kill", "--property=RuntimeMaxSec=" + str(seconds),
                  "--property=TimeoutStopSec=30", "--property=KillMode=control-group",
                  "--property=User=" + args.user, "--property=Group=" + args.user,
                  "--property=StandardOutput=append:" + str(log_path),
                  "--property=StandardError=append:" + str(log_path),
                  "--property=ExecStopPost=" + stop_command,
                  "--working-directory=" + str(args.root)]
        launch += ["--setenv=" + key + "=" + value for key, value in environment.items()]
        launched = subprocess.run([*launch, *command], capture_output=True, text=True)
        write_json(directory / "launch.json", {"command": launch + command,
                   "exit": launched.returncode, "stdout": launched.stdout[-4000:], "stderr": launched.stderr[-4000:]})
    if not receipt_path.exists():
        raise RuntimeError(f"stage {unit} ended without durable ExecStopPost receipt; inspect {directory}")
    receipt = read_json(receipt_path)
    if receipt.get("fingerprint") != fingerprint:
        raise RuntimeError(f"stage receipt binding mismatch for {unit}")
    journal = subprocess.run(["sudo", "journalctl", "--no-pager", "-u", unit, "-n", "32", "-o", "short-iso"],
                             capture_output=True, text=True)
    (directory / "journal.log").write_text(journal.stdout + journal.stderr, encoding="utf-8")
    return receipt


def document_summary(path, report=False):
    import ijson
    from ijson.common import ObjectBuilder
    fields = {"schema_version", "harness_version", "command_observer", "completion", "input",
              "script_errors", "transition_script_errors", "capture_limits", "capabilities",
              "style", "difficulty", "steps_type", "end_position", "error", "display"}
    if report:
        fields = {"archive_accepted", "fixture_sha256", "native_frames", "replayed_frames",
                  "compared_stage_fields", "execution_path", "whole_song_parity_proven",
                  "pending_coverage", "capture_completed_gameplay", "production_preparation_exercised",
                  "production_parity_proven", "acceptance_basis", "diagnostic_only"}
    result, samples, errors, groups = {}, [], [], collections.Counter()
    active, builder, depth, mismatch_count, error_count = None, None, 0, 0, 0
    with pathlib.Path(path).open("rb") as stream:
        for prefix, event, value in ijson.parse(stream, use_float=True):
            if active is not None:
                builder.event(event, value)
                depth += int(event in {"start_map", "start_array"}) - int(event in {"end_map", "end_array"})
                if depth == 0:
                    if active == "mismatches.item":
                        samples.append(bounded(builder.value)); groups[builder.value.get("field", "unknown")] += 1
                    elif active == "errors.item":
                        errors.append(bounded(builder.value))
                    else:
                        result[active] = builder.value
                    active, builder = None, None
                continue
            if report and prefix == "mismatches.item" and event == "start_map":
                mismatch_count += 1
                if len(samples) < 40:
                    active, builder, depth = prefix, ObjectBuilder(), 1; builder.event(event, value)
                continue
            if report and prefix == "mismatches.item.field" and event == "string":
                groups[value] += 1
            if report and prefix == "errors.item" and event not in {"end_map", "end_array", "map_key"}:
                error_count += 1
                if event in {"start_map", "start_array"} and len(errors) < 40:
                    active, builder, depth = prefix, ObjectBuilder(), 1; builder.event(event, value)
                elif event not in {"start_map", "start_array"} and len(errors) < 40:
                    errors.append(bounded(value))
                continue
            if prefix in fields or ("." not in prefix and prefix.startswith("dropped_")):
                if event in {"start_map", "start_array"}:
                    active, builder, depth = prefix, ObjectBuilder(), 1; builder.event(event, value)
                elif event not in {"map_key", "end_map", "end_array"}:
                    result[prefix] = value
    if report:
        result.update(mismatch_count=mismatch_count, mismatch_fields=dict(groups),
                      first_mismatches=samples, error_count=error_count, errors=errors)
    return result


def validate_native(path, summary, job, native_revision, full=True, screen_gameplay_sha256=None):
    import ijson
    source = summary.get("input", {}).get("native_source", {})
    if source.get("revision") != native_revision or source.get("modified_src") is not False:
        raise ValueError("native executable source provenance differs from the pinned clean engine")
    if full and summary.get("completion", {}).get("reason") != "gameplay-exit":
        raise ValueError("native capture did not reach gameplay exit")
    for key, value in summary.items():
        if key.startswith("dropped_") and value != 0:
            raise ValueError(f"native capture lost observations: {key}={value}")
    if summary.get("script_errors") or summary.get("transition_script_errors") or summary.get("error"):
        raise ValueError("native capture contains script/transition errors")
    if summary.get("capabilities", {}).get("native_song_position_clocks") is not True:
        raise ValueError("native capture does not declare complete song-position clocks")
    if full and summary.get("capabilities", {}).get("native_gameplay_clock_inputs") is not True:
        raise ValueError("fresh native capture lacks the independent gameplay timer input capability")
    if full and (not re.fullmatch(r"[0-9a-f]{64}", source.get("screen_gameplay_sha256", ""))
                 or screen_gameplay_sha256 is not None and source["screen_gameplay_sha256"] != screen_gameplay_sha256):
        raise ValueError("native ScreenGameplay timer source identity is absent or differs")
    expected = job.get("expected_chart", {})
    starting = summary.get("input", {}).get("starting_chart", {})
    if job.get("chart_index") is not None and starting.get("index") != job["chart_index"]:
        raise ValueError("native starting chart differs from requested chart index")
    for key in ("index", "steps_type", "difficulty", "description", "chart_name", "meter", "is_autogen"):
        if key in expected and starting.get(key) != expected[key]:
            raise ValueError(f"native chart identity changed: {key}: {starting.get(key)!r} != {expected[key]!r}")
    # Steps::GetHash can be zero until its note data is loaded. Discovery may
    # select another chart, so compare hashes only when both native observations
    # contain a computed value; the frozen source and exact index remain bound.
    if expected.get("hash") and starting.get("hash") and expected["hash"] != starting["hash"]:
        raise ValueError("computed native note hash differs from discovery")
    frames, gameplay_clocks, no_gameplay_clock_call = 0, 0, 0
    with pathlib.Path(path).open("rb") as stream:
        for frame in ijson.items(stream, "update_frames.item", use_float=True):
            frames += 1
            if frame.get("sequence") != frames:
                raise ValueError("native update frame sequence is incomplete")
            for key in ("seconds", "song_beat", "visible_seconds", "visible_beat", "beat", "delta"):
                value = frame.get(key)
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                    raise ValueError(f"native frame {frames} has invalid {key}")
            if frame["beat"] != frame["song_beat"] or frame["delta"] < 0:
                raise ValueError("native semantic clock alias/delta is invalid")
            if full:
                if "gameplay_clock_inputs" not in frame:
                    raise ValueError("fresh native frame lacks explicit gameplay timer observation/null")
                clocks = frame["gameplay_clock_inputs"]
                if clocks is None:
                    no_gameplay_clock_call += 1
                elif isinstance(clocks, dict):
                    gameplay_clocks += 1
                    if clocks.get("phase") != "after-gameplay-actors":
                        raise ValueError("native gameplay timer observation has an invalid phase")
                    for key in ("scene", "native_update_frame", "native_update_sequence"):
                        value = frame.get(key)
                        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0 or clocks.get(key) != value:
                            raise ValueError("native gameplay timer observation is misbound: " + key)
                    for key in ("delta_seconds", "music_rate"):
                        value = clocks.get(key)
                        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                            raise ValueError("native gameplay timer observation has invalid " + key)
                    if not isinstance(clocks.get("steps_time_active"), bool):
                        raise ValueError("native gameplay timer observation lacks its active-steps diagnostic")
                else:
                    raise ValueError("native gameplay timer input must be an object or explicit null")
    if frames == 0:
        raise ValueError("native capture has no observed update frames")
    if full:
        with pathlib.Path(path).open("rb") as stream:
            for sample in ijson.items(stream, "stage_samples.item", use_float=True):
                value = sample.get("steps_seconds")
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                    raise ValueError("fresh native stage sample lacks valid steps_seconds")
        summary["gameplay_clock_validation"] = {"capability": True, "observations": gameplay_clocks,
                                                 "not_called": no_gameplay_clock_call, "frames": frames}
    with pathlib.Path(path).open("rb") as stream:
        for event in ijson.items(stream, "events.item", use_float=True):
            if event.get("kind") == "error":
                raise ValueError("native semantic events include an error: " + str(bounded(event)))
    return frames


def compress_verified(path, output_directory, suffix=None):
    import zstandard
    path, output_directory = pathlib.Path(path), pathlib.Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    raw_sha = digest(path)
    temporary = output_directory / ("compress-" + raw_sha + ".tmp")
    with path.open("rb") as source, temporary.open("wb") as target:
        zstandard.ZstdCompressor(level=3, write_checksum=True).copy_stream(source, target)
    decoded = hashlib.sha256()
    with temporary.open("rb") as source, zstandard.ZstdDecompressor().stream_reader(source) as stream:
        while block := stream.read(4 * 1024 * 1024):
            decoded.update(block)
    if decoded.hexdigest() != raw_sha:
        raise ValueError("compressed artifact failed round-trip verification")
    packed_sha = digest(temporary)
    destination = output_directory / (packed_sha + (suffix or path.suffix) + ".zst")
    temporary.replace(destination)
    return {"path": str(destination), "bytes": destination.stat().st_size,
            "sha256": packed_sha, "uncompressed_sha256": raw_sha}


def restore_verified(record, destination):
    import zstandard
    source, destination = pathlib.Path(record["path"]), pathlib.Path(destination)
    if digest(source) != record["sha256"]:
        raise ValueError("retained candidate compressed hash differs")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".restoring")
    with source.open("rb") as src, temporary.open("wb") as dst:
        zstandard.ZstdDecompressor().copy_stream(src, dst)
    if digest(temporary) != record["uncompressed_sha256"]:
        raise ValueError("retained candidate decoded hash differs")
    temporary.replace(destination)


def preserve_diagnostics(case):
    root = pathlib.Path(case) / "tmp" / "itgmania-harness-rs"
    selected = []
    for run in sorted(root.glob("song-lua-*")):
        for relative in ("Logs", "Save/itgmania-harness", "Save/Preferences.ini", "crashinfo.txt"):
            source = run / relative
            if source.exists():
                selected.append((source, run.name + "/" + relative))
    if not selected:
        return None
    raw = pathlib.Path(case) / "native-diagnostics.tar"
    with tarfile.open(raw, "w") as archive:
        for source, relative in selected:
            archive.add(source, arcname=relative, recursive=True)
    record = compress_verified(raw, pathlib.Path(case) / "retained", ".tar")
    raw.unlink()
    return record


def classify(stage, receipt, detail):
    service = receipt.get("service_result", "")
    lowered = detail.lower()
    if service == "oom-kill" or "oom-kill" in lowered or "out of memory" in lowered:
        return stage + "_resource_limit"
    if service == "timeout" or "did not write a semantic trace within" in lowered or "timed out" in lowered:
        return stage + "_timeout"
    if stage == "capture" and any(text in lowered for text in ("script loading or execution failed", "native gameplay capture contains errors", "probe script reported")):
        return "native_lua_or_setup_error"
    return stage + "_error"


def verify_song(args, job):
    simfile = checked_relative(args.songs, job["source_simfile"])
    if not simfile.is_file() or digest(simfile) != job["simfile_sha256"]:
        raise ValueError("simfile differs from frozen corpus")
    folder = pathlib.PurePosixPath(job["source_simfile"]).parent.as_posix().rstrip("/") + "/"
    files = [row for row in args.manifest["files"]
             if (row.get("folder_sha256") == job["folder_sha256"] if job.get("folder_sha256")
                 else row["path"].startswith(folder))]
    if not files:
        raise ValueError("song folder absent from frozen manifest")
    for row in files:
        path = checked_relative(args.songs, row["path"])
        info = path.stat()
        key = (str(path), info.st_size, info.st_mtime_ns, row["sha256"])
        if key in args.verified_files:
            continue
        if not path.is_file() or info.st_size != row["bytes"] or digest(path) != row["sha256"]:
            raise ValueError("asset differs from frozen corpus: " + row["path"])
        args.verified_files.add(key)
    return simfile


def capture_command(args, job, output, until_end=True):
    command = [args.harness, "song-lua-trace", checked_relative(args.songs, job["source_simfile"]),
               "--itgmania-bin", args.engine, "--fallback-theme", args.theme.name,
               "--game", job.get("game", "dance"), "--style", job.get("style", "versus"),
               "--capture-fps", str(job.get("capture_fps", 60)),
               "--max-events", str(job.get("max_events", 2000000)),
               "--timeout", str(job.get("capture_timeout", 1200)),
               "--random-seed", str(job.get("random_seed", 1)), "--out", output]
    command += ["--until-gameplay-end"] if until_end else ["--until-beat", "0"]
    if args.headless:
        command.append("--headless")
    if job.get("drawable_samples", args.drawables):
        command.append("--drawable-samples")
    if job.get("chart_index") is not None:
        command += ["--chart-index", str(job["chart_index"])]
    if job.get("difficulty"):
        command += ["--difficulty", job["difficulty"].removeprefix("Difficulty_")]
    if job.get("player_options"):
        command += ["--player-options", job["player_options"]]
    elif job.get("game", "dance") != "dance":
        command += ["--player-options", "default"]
    if job.get("fixed_update_fps"):
        command += ["--fixed-update-fps", str(job["fixed_update_fps"])]
    if job.get("gc_mode") == "stopped":
        command.append("--stop-lua-gc")
    if job.get("autoplay") is not None:
        command += ["--autoplay", str(int(job["autoplay"]))]
    if job.get("fast_note_rendering") is not None:
        command += ["--fast-note-rendering", str(int(job["fast_note_rendering"]))]
    return command


def choose_capture_directory(args, job, capture_binding):
    base = checked_relative(args.results, job["id"])
    base.mkdir(parents=True, exist_ok=True)
    prefix = "capture-" + identity(capture_binding)[:20]
    candidates = sorted(base.glob(prefix + "-*"))
    if candidates:
        current = candidates[-1]
        outcome = current / "capture-result.json"
        if not args.retry_failed or not outcome.exists() or read_json(outcome).get("status") == "complete":
            return current
    current = base / (prefix + "-" + f"{len(candidates) + 1:03d}")
    current.mkdir(exist_ok=False)
    return current


def run_case(args, job):
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", job["id"]) or job["id"] in {".", ".."}:
        raise ValueError("invalid case ID")
    verify_song(args, job)
    capture_binding = {"job": {key: value for key, value in job.items()
                               if key not in {"replay_timeout", "stage_memory", "archive_timeout", "pack_timeout"}},
                       "harness_sha256": args.pins["harness_sha256"], "engine_sha256": args.pins["engine_sha256"],
                       "native_revision": args.pins["native_revision"], "corpus_sha256": args.pins["corpus_sha256"],
                       "theme_tree_sha256": args.pins["theme_tree_sha256"], "fallback_theme": args.theme.name,
                       "noteskins_tree_sha256": args.pins["noteskins_tree_sha256"],
                       "headless": args.headless, "drawable_samples": args.drawables}
    case = choose_capture_directory(args, job, capture_binding)
    capture_path = case / "capture-result.json"
    native_path = case / "traces" / "native.json"
    native_path.parent.mkdir(parents=True, exist_ok=True)
    native_result = read_json(capture_path) if capture_path.exists() else {
        "id": job["id"], "job": job, "worker": args.worker, "started_at": now(),
        "pins": args.pins, "binding": capture_binding, "status": "running", "stages": {}, "artifacts": []}
    if native_result["status"] not in {"running", "complete"}:
        return native_result
    if native_result["status"] != "complete":
        write_json(capture_path, native_result)
        try:
            if shutil.disk_usage(args.root).free < args.minimum_free_gib * 1024 ** 3:
                raise ValueError("worker free disk below declared reserve")
            command = capture_command(args, job, native_path)
            receipt = execute_stage(args, case, "capture", command,
                                    job.get("capture_timeout", 1200) + 90, job.get("stage_memory", args.memory), capture_binding)
            native_result["stages"]["capture"] = receipt
            if receipt["exit"]:
                raise StageError("capture", receipt, tail(case / "stages/capture/output.log"))
            summary = document_summary(native_path)
            frames = validate_native(native_path, summary, job, args.pins["native_revision"],
                                     screen_gameplay_sha256=args.pins["screen_gameplay_sha256"])
            native_result.update(native=summary, native_frames=frames)
            expected_hash = job.get("expected_chart", {}).get("hash")
            observed_hash = summary.get("input", {}).get("starting_chart", {}).get("hash")
            native_result["native_note_hash_check"] = {
                "expected": expected_hash, "observed": observed_hash,
                "compared": bool(expected_hash and observed_hash),
                "reason": "both native hashes computed" if expected_hash and observed_hash
                          else "zero or absent native lazy-load hash; source SHA and native index remain bound"}
            write_json(native_path.parent / "_semantic_manifest.json", {
                "fixture_schema_version": 1, "oracle_schema_version": summary["schema_version"],
                "harness_version": summary["harness_version"],
                "itgmania": {"git_revision": args.pins["native_revision"], "git_dirty": "false"},
                "simfiles": [{"simfile": job["source_simfile"], "fixture": "native.json",
                              "title": job.get("title", job["source_simfile"]), "status": "ok",
                              "command_observer": summary["command_observer"]}]})
            candidate_dir = case / "candidate"
            command = [args.harness, "song-lua-archive", args.songs, "--traces", native_path.parent,
                       "--out", candidate_dir, "--uncompressed", "--theme-assets", args.theme]
            receipt = execute_stage(args, case, "archive", command, job.get("archive_timeout", 900),
                                    job.get("stage_memory", args.memory), capture_binding)
            native_result["stages"]["archive"] = receipt
            if receipt["exit"]:
                raise StageError("archive", receipt, tail(case / "stages/archive/output.log"))
            entries = read_json(candidate_dir / "index.json")["archives"]
            if len(entries) != 1:
                raise ValueError("capture did not produce exactly one candidate")
            candidate = checked_relative(candidate_dir, entries[0]["archive"])
            candidate_sha = digest(candidate)
            if candidate.name != candidate_sha + ".tar":
                raise ValueError("candidate content address is invalid")
            native_result.update(status="complete", candidate_path=str(candidate), candidate_sha256=candidate_sha,
                                 archive_entry=entries[0], finished_at=now())
            write_json(capture_path, native_result)
        except Exception as error:
            native_result.update(status=classify(error.stage, error.receipt, str(error)) if isinstance(error, StageError)
                                 else "capture_validation_or_infrastructure_error", reason=str(error), finished_at=now())
            native_result["traceback"] = traceback.format_exc()
            try:
                diagnostic = preserve_diagnostics(case)
                if diagnostic:
                    native_result["artifacts"].append(diagnostic)
                if native_path.exists():
                    native_result["artifacts"].append(compress_verified(native_path, case / "retained", ".json"))
                    native_path.unlink()
                if (case / "tmp").exists():
                    shutil.rmtree(checked_relative(case, "tmp"))
            except Exception as retention_error:
                native_result["retention_error"] = str(retention_error)
            write_json(capture_path, native_result)
            return native_result
    candidate = pathlib.Path(native_result["candidate_path"])
    replay_binding = {"candidate_sha256": native_result["candidate_sha256"],
                      "runner_sha256": args.pins["runner_sha256"], "job_id": job["id"],
                      "replay_assets_tree_sha256": args.pins["replay_assets_tree_sha256"],
                      "timeout": job.get("replay_timeout", 1800), "memory": job.get("stage_memory", args.memory)}
    replay = case / ("replay-" + identity(replay_binding)[:20])
    replay.mkdir(exist_ok=True)
    outcome_path = replay / "result.json"
    if outcome_path.exists() and read_json(outcome_path).get("finished_at"):
        return read_json(outcome_path)
    if not candidate.exists():
        restore_verified(native_result["retained_candidate"], candidate)
    if digest(candidate) != native_result["candidate_sha256"]:
        raise ValueError("candidate differs from its capture receipt")
    result = {"id": job["id"], "source_simfile": job["source_simfile"], "chart_index": job.get("chart_index"),
              "title": job.get("title"), "job": job, "worker": args.worker, "started_at": now(),
              "capture_result": str(capture_path), "pins": args.pins, "status": "running", "stages": {}, "artifacts": []}
    write_json(outcome_path, result)
    try:
        report_path = replay / "report.json"
        command = [args.runner, "--archive", candidate, "--report", report_path]
        receipt = execute_stage(args, replay, "replay", command, job.get("replay_timeout", 1800),
                                job.get("stage_memory", args.memory), replay_binding)
        result["stages"]["replay"] = receipt
        if report_path.exists():
            report = document_summary(report_path, report=True)
            result["comparison"] = report
            complete = (receipt["exit"] == 0 and report.get("archive_accepted") is True
                        and report.get("fixture_sha256") == native_result["candidate_sha256"]
                        and report.get("native_frames") == native_result["native_frames"]
                        and report.get("replayed_frames") == native_result["native_frames"]
                        and report.get("capture_completed_gameplay") is True
                        and report.get("mismatch_count") == 0 and report.get("error_count") == 0)
            result["status"] = "pass" if complete else "parity_failure"
            if complete:
                command = [args.harness, "song-lua-pack", candidate, "--report", report_path, "--out", replay / "accepted"]
                receipt = execute_stage(args, replay, "pack", command, job.get("pack_timeout", 1200),
                                        job.get("stage_memory", args.memory), replay_binding)
                result["stages"]["pack"] = receipt
                if receipt["exit"]:
                    raise StageError("pack", receipt, tail(replay / "stages/pack/output.log"))
                packed = list((replay / "accepted").glob("*.tar.zst"))
                if len(packed) != 1 or digest(packed[0]) + ".tar.zst" != packed[0].name:
                    raise ValueError("accepted artifact content address is invalid")
                record = {"path": str(packed[0]), "bytes": packed[0].stat().st_size,
                          "sha256": digest(packed[0]), "uncompressed_sha256": native_result["candidate_sha256"]}
                # Acceptance is bound to the plain tar. Verify the compressed body too.
                import zstandard
                decoded = hashlib.sha256()
                with packed[0].open("rb") as stream, zstandard.ZstdDecompressor().stream_reader(stream) as body:
                    while block := body.read(4 * 1024 * 1024):
                        decoded.update(block)
                if decoded.hexdigest() != native_result["candidate_sha256"]:
                    raise ValueError("packed candidate no longer matches the accepted report")
                native_result["retained_candidate"] = record
                result["artifacts"].append(record)
            result["artifacts"].append(compress_verified(report_path, replay / "retained", ".json"))
            report_path.unlink()
        else:
            raise StageError("replay", receipt, tail(replay / "stages/replay/output.log"))
    except Exception as error:
        result.update(status=classify(error.stage, error.receipt, str(error)) if isinstance(error, StageError)
                      else "replay_validation_or_infrastructure_error", reason=str(error), traceback=traceback.format_exc())
    finally:
        try:
            if (replay / "report.json").exists():
                result["artifacts"].append(compress_verified(replay / "report.json", replay / "retained", ".json"))
                (replay / "report.json").unlink()
            if "retained_candidate" not in native_result:
                native_result["retained_candidate"] = compress_verified(candidate, case / "retained", ".tar")
            write_json(capture_path, native_result)
            if candidate.exists():
                candidate.unlink()
            if native_path.exists():
                # Its exact bytes are contained in the retained verified candidate.
                native_path.unlink()
            scratch = case / "tmp"
            if scratch.exists():
                shutil.rmtree(checked_relative(case, "tmp"))
        except Exception as error:
            result["retention_error"] = str(error)
            result["status"] = "retention_error"
        result["finished_at"] = now()
        write_json(outcome_path, result)
    return result


def add_common_arguments(parser):
    parser.add_argument("--root", type=pathlib.Path, default=pathlib.Path("/opt/song-lua-audit/pass4"))
    parser.add_argument("--songs", type=pathlib.Path)
    parser.add_argument("--harness", type=pathlib.Path)
    parser.add_argument("--runner", type=pathlib.Path)
    parser.add_argument("--engine", type=pathlib.Path, default=pathlib.Path("/opt/song-lua-audit/harness-pass4/vendor/itgmania/ITGmania-harness-trace"))
    parser.add_argument("--theme", type=pathlib.Path)
    parser.add_argument("--noteskins", type=pathlib.Path, help="Pinned native NoteSkins directory; defaults to the native installation's exact-case root")
    parser.add_argument("--replay-assets", type=pathlib.Path, help="Assets directory used by the runner's compiled DeadSync workspace")
    parser.add_argument("--source-proof", type=pathlib.Path)
    parser.add_argument("--build-proof", type=pathlib.Path, help="Passed binary build receipt; required for corpus replay")
    parser.add_argument("--corpus-manifest", type=pathlib.Path)
    parser.add_argument("--display", default=":99")
    parser.add_argument("--user", default="parity")
    parser.add_argument("--memory", default="6G")
    parser.add_argument("--minimum-free-gib", type=int, default=8)
    parser.add_argument("--headless", action="store_true", help="Requires validated real offscreen graphics adapter when drawables are enabled")
    parser.add_argument("--no-drawables", action="store_false", dest="drawables", help="Explicit null/semantic profile; retain its geometry coverage gap")
    parser.add_argument("--retry-failed", action="store_true", help="New capture attempt; prior failed artifacts remain")
    parser.add_argument("--worker", required=True)


def prepare_arguments(args, require_runner=True):
    args.root = args.root.resolve()
    args.songs = (args.songs or args.root / "Songs").resolve()
    args.harness = (args.harness or args.root / "bin/itgmania-harness-rs").resolve()
    args.runner = (args.runner or args.root / "bin/full_song_lua").resolve()
    args.engine = args.engine.resolve()
    # The installed theme is a symlink to vendor/simply-love. Native theme lookup
    # needs its installation alias, while tree hashing still reads the real bytes.
    args.theme = (args.theme or args.engine.parent / "Themes/Harness Simply Love").absolute()
    args.noteskins = (args.noteskins or args.engine.parent / "NoteSkins").resolve()
    args.source_proof = (args.source_proof or (args.root / "proof/source-proof.json"
                         if (args.root / "proof/source-proof.json").is_file() else args.root / "source-proof.json")).resolve()
    args.build_proof = (args.build_proof or args.root / "proof/build-proof.json").resolve()
    args.corpus_manifest = (args.corpus_manifest or args.root / "corpus-manifest.json").resolve()
    args.results = args.root / "results"
    args.results.mkdir(parents=True, exist_ok=True)
    if not args.source_proof.is_file() or not args.corpus_manifest.is_file():
        raise ValueError("source-proof.json and frozen corpus-manifest.json are required")
    args.manifest = read_json(args.corpus_manifest)
    args.proof = read_json(args.source_proof)
    for directory in [args.theme, args.noteskins]:
        if not directory.is_dir():
            raise ValueError("pinned native asset directory is absent: " + str(directory))
    args.verified_files = set()
    native_root = args.engine.parent
    revision = subprocess.check_output(["git", "-C", str(native_root), "rev-parse", "HEAD"], text=True).strip()
    dirty = subprocess.run(["git", "-C", str(native_root), "diff", "--quiet", "HEAD", "--", "src"]).returncode
    if dirty != 0:
        raise ValueError("native source tree has modifications or cannot be verified")
    declared_revision = args.proof.get("pins", {}).get("native")
    if declared_revision is not None and revision != declared_revision:
        raise ValueError("native revision differs from source proof")
    args.pins = {"harness_sha256": digest(args.harness), "engine_sha256": digest(args.engine),
                 "native_revision": revision, "corpus_sha256": digest(args.corpus_manifest),
                 "screen_gameplay_sha256": digest(native_root / "src/ScreenGameplay.cpp"),
                 "source_proof_sha256": digest(args.source_proof),
                 "worker_script_sha256": digest(pathlib.Path(__file__)),
                 "theme_tree_sha256": tree_digest(args.theme), "noteskins_tree_sha256": tree_digest(args.noteskins)}
    args.pins["native_noteskins_root"] = str(args.noteskins)
    args.pins["native_noteskins_tree_sha256"] = args.pins["noteskins_tree_sha256"]
    if require_runner:
        args.pins["runner_sha256"] = digest(args.runner)
        workspace = args.proof.get("repositories", {}).get("deadsync", {}).get("path")
        if args.replay_assets is None and not workspace:
            raise ValueError("source proof must identify the runner's compiled workspace or --replay-assets must be explicit")
        args.replay_assets = (args.replay_assets or pathlib.Path(workspace) / "assets").resolve()
        if not (args.replay_assets / "noteskins").is_dir():
            raise ValueError("pinned replay assets lack the workspace noteskins directory")
        args.pins["replay_assets_root"] = str(args.replay_assets)
        args.pins["replay_assets_tree_sha256"] = tree_digest(args.replay_assets)
    binary_proof_path = args.build_proof
    if not require_runner and not binary_proof_path.is_file():
        binary_proof_path = args.root / "proof/capture-binaries.json"
    if binary_proof_path.is_file():
        proof = read_json(binary_proof_path)
        if proof.get("passed") is not True:
            raise ValueError("binary proof does not report successful required checks")
        if proof.get("source_proof_sha256") != args.pins["source_proof_sha256"]:
            raise ValueError("binary build is bound to a different source proof")
        for name, observed in [("harness", args.pins["harness_sha256"]), ("native", args.pins["engine_sha256"])] + (
                [("runner", args.pins["runner_sha256"])] if require_runner else []):
            if proof.get("binaries", {}).get(name, {}).get("sha256") != observed:
                raise ValueError("live executable differs from declared build proof: " + name)
        args.pins["binary_proof_sha256"] = digest(binary_proof_path)
    elif require_runner:
        raise ValueError("passed build-proof.json is required before corpus replay")
    args.binary_stats = {str(path): (path.stat().st_size, path.stat().st_mtime_ns)
                         for path in ([args.harness, args.engine, args.runner] if require_runner
                                      else [args.harness, args.engine])}
    return args


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jobs", type=pathlib.Path, help="JSON array, or object containing jobs")
    add_common_arguments(parser)
    args = prepare_arguments(parser.parse_args())
    document = read_json(args.jobs)
    jobs = document if isinstance(document, list) else document["jobs"]
    progress = args.results / ("worker-" + re.sub(r"[^A-Za-z0-9_.-]", "_", args.worker) + ".json")
    completed = []
    for job in jobs:
        write_json(progress, {"worker": args.worker, "total": len(jobs), "completed": len(completed),
                             "current": job, "updated_at": now(), "pins": args.pins})
        lock_path = args.results / (job["id"] + ".lock")
        try:
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", job["id"]):
                raise ValueError("invalid case ID")
            with lock_path.open("a") as lock:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
                result = run_case(args, job)
            row = {"id": job["id"], "source_simfile": job["source_simfile"],
                   "chart_index": job.get("chart_index"), "status": result["status"],
                   "mismatches": result.get("comparison", {}).get("mismatch_count"),
                   "errors": result.get("comparison", {}).get("error_count")}
        except Exception as error:
            row = {"id": job.get("id"), "source_simfile": job.get("source_simfile"),
                   "status": "worker_error", "reason": str(error), "traceback": traceback.format_exc()}
            write_json(args.results / ("worker-error-" + identity(job)[:20] + ".json"), row)
        completed.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)
    write_json(progress, {"worker": args.worker, "total": len(jobs), "completed": len(completed),
                         "results": completed, "pins": args.pins, "finished_at": now()})


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "__stage_finished":
        stage_finished(sys.argv[2])
    else:
        main()
