"""Read the exact retained diagnostic archive on its original guest; no writes there."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import remote

HERE = Path(__file__).resolve().parent
selection = HERE / 'quarantine-diagnostics-selection.json.gz'
payload = json.loads(gzip.decompress(selection.read_bytes()))
assert len(payload['guests']) == 1
guest = payload['guests'][0]
assert guest['vmid'] == 1501
items = guest['payload']['files']
assert len(items) == 1 and items[0]['data']['id'] == '2f376ce76ff65534-c0003'
original = items[0]
artifact = original['data']['artifacts'][0]
assert artifact['sha256'] == '76dab4220dd449ccb076d8ec603b8f9bbeee0e67da4ed2c78316f2360c705717'
config = {'vmid': guest['vmid'], 'ip': guest['ip'], 'artifact': artifact}
guest_code = r'''
import collections,hashlib,io,json,pathlib,tarfile
import ijson
from ijson.common import ObjectBuilder
import zstandard
path=pathlib.Path(config['artifact']['path'])
assert path.is_relative_to('/opt/song-lua-audit/pass4/results/2f376ce76ff65534-c0003/capture-493516b8fcaa99cc32bd-001')
before=path.stat()
def digest_file(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert before.st_size==config['artifact']['bytes'] and digest_file(path)==config['artifact']['sha256']
class HashReader:
    def __init__(self,source):self.source=source;self.hasher=hashlib.sha256();self.bytes=0
    def read(self,size=-1):
        data=self.source.read(size);self.hasher.update(data);self.bytes+=len(data);return data
    def readinto(self,buffer):
        data=self.read(len(buffer));buffer[:len(data)]=data;return len(data)
result={'archive':config['artifact'],'members':[],'native':None,'logs':[]}
with path.open('rb') as packed,zstandard.ZstdDecompressor().stream_reader(packed) as decoded:
    tar_stream=HashReader(decoded)
    with tarfile.open(fileobj=tar_stream,mode='r|') as archive:
        for member in archive:
            item={'path':member.name,'bytes':member.size,'type':member.type.decode(errors='replace')}
            result['members'].append(item)
            if not member.isfile():continue
            stream=HashReader(archive.extractfile(member))
            if member.name.endswith('/Save/itgmania-harness/song-lua-trace.json'):
                fields={'schema_version','harness_version','completion','script_errors','transition_script_errors',
                        'dropped_script_errors','capture_limits','capabilities','input','title','simfile','end_position'}
                observed={};active=None;builder=None;depth=0;frame_count=0
                for prefix,event,value in ijson.parse(stream,use_float=True):
                    if active is not None:
                        builder.event(event,value)
                        depth+=int(event in ('start_map','start_array'))-int(event in ('end_map','end_array'))
                        if depth==0:observed[active]=builder.value;active=None;builder=None
                        continue
                    if prefix=='update_frames.item' and event=='start_map':frame_count+=1
                    if prefix=='events' and event=='start_array':break
                    if prefix in fields or ('.' not in prefix and prefix.startswith('dropped_')):
                        if event in ('start_map','start_array'):
                            active=prefix;builder=ObjectBuilder();depth=1;builder.event(event,value)
                        elif event not in ('end_map','end_array','map_key'):observed[prefix]=value
                while stream.read(4*1024*1024):pass
                result['native']={'member':member.name,'bytes':stream.bytes,'sha256':stream.hasher.hexdigest(),
                                  'metadata':observed,'update_frames_before_events':frame_count,
                                  'parsing_scope':'top-level metadata before the final event spool; remaining bytes hashed'}
            elif '/Logs/' in member.name or member.name.endswith('/crashinfo.txt'):
                tail=b'';prefix_bytes=b'';matches=[];matched=0;pending=b''
                while block:=stream.read(1024*1024):
                    if len(prefix_bytes)<4096:prefix_bytes=(prefix_bytes+block)[:4096]
                    tail=(tail+block)[-16000:]
                    lines=(pending+block).split(b'\n');pending=lines.pop()
                    for line in lines:
                        if any(word in line.lower() for word in (b'error',b'exception',b'warning')):
                            matched+=1
                            if len(matches)<30:matches.append(line.decode('utf-8',errors='replace')[:3000])
                result['logs'].append({'path':member.name,'bytes':stream.bytes,'sha256':stream.hasher.hexdigest(),
                    'matching_lines':matched,'first_matching_lines':matches,
                    'prefix':prefix_bytes.decode('utf-8',errors='replace'),'tail':tail.decode('utf-8',errors='replace')})
            else:
                while stream.read(4*1024*1024):pass
            item['sha256']=stream.hasher.hexdigest()
    while tar_stream.read(4*1024*1024):pass
    result['uncompressed_sha256']=tar_stream.hasher.hexdigest()
    result['uncompressed_bytes']=tar_stream.bytes
assert result['uncompressed_sha256']==config['artifact']['uncompressed_sha256']
after=path.stat();assert (before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino)
assert digest_file(path)==config['artifact']['sha256'] and result['native'] is not None
print(json.dumps(result))
'''
host = r'''
import json,pathlib,subprocess
fleet=json.loads(pathlib.Path('/root/deadsync-lua-20261119/fleet.json').read_text())
row=next(row for row in fleet if row['vmid']==config['vmid'])
assert row['ip']==config['ip']
command=['ssh','-i','/root/deadsync-pass3-20261116/transfer-key','-o','BatchMode=yes',
 '-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=/root/deadsync-lua-20261119/fleet-known-hosts',
 '-o','ConnectTimeout=10','parity@'+row['ip'],'nice','-n','15','python3','-']
completed=subprocess.run(command,input=('config='+repr(config)+'\n'+guest_code).encode())
raise SystemExit(completed.returncode)
'''
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
destination = HERE / ('quarantine-diagnostics-inspection-' + stamp)
destination.mkdir()
program = 'config=' + repr(config) + '\nguest_code=' + repr(guest_code) + '\n' + host
completed = subprocess.run(remote.ssh() + ['python3', '-'], input=program.encode(), capture_output=True, timeout=180)
(destination / 'remote.stdout').write_bytes(completed.stdout)
(destination / 'remote.stderr').write_bytes(completed.stderr)
receipt = {'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':completed.returncode,
    'selection_sha256':hashlib.sha256(selection.read_bytes()).hexdigest(),'original_capture_result':original,
    'helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'guest_writes':False,
    'stdout_sha256':hashlib.sha256(completed.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(completed.stderr).hexdigest()}
if completed.returncode==0:
    data=json.loads(completed.stdout)
    receipt['inspection']=data
    errors=data['native']['metadata'].get('script_errors',[])
    summary={'native_sha256':data['native']['sha256'],'native_bytes':data['native']['bytes'],
        'retained_script_errors':len(errors),'dropped_script_errors':data['native']['metadata'].get('dropped_script_errors'),
        'first_error':errors[0] if errors else None,'completion':data['native']['metadata'].get('completion'),
        'log_files':[{'path':row['path'],'bytes':row['bytes'],'matching_lines':row['matching_lines']} for row in data['logs']]}
else:
    summary={'error':completed.stderr.decode(errors='replace')[-3000:]}
(destination / 'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'receipt':str(destination/'receipt.json'),'receipt_sha256':hashlib.sha256((destination/'receipt.json').read_bytes()).hexdigest(),
                  'exit_code':completed.returncode,**summary},indent=2))
raise SystemExit(completed.returncode)
