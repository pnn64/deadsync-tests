"""Prove a Git tree contains exactly the bytes used by the isolated CLI build."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys

task=Path(__file__).resolve().parent
repo=Path('C:/GitHub/itgmania-harness-stream-20261119')
evidence=task/'stream-build-evidence-20261119T040830Z'
expected=json.loads((evidence/'build/source-files-before.json').read_text())
treeish=sys.argv[1] if len(sys.argv)>1 else 'HEAD'


def git(*arguments):
    return subprocess.check_output(['git','-C',str(repo),*arguments])


tree=git('rev-parse',treeish+'^{tree}').decode().strip()
rows=[];submodules={}
for item in git('ls-tree','-r','-z','--full-tree',tree).split(b'\0'):
    if not item:continue
    metadata,name=item.split(b'\t',1)
    mode,kind,object_id=metadata.split()
    if kind==b'commit':
        submodules[name.decode()]=object_id.decode()
    else:
        assert kind==b'blob'
        rows.append((name.decode(),object_id.decode()))
process=subprocess.run(['git','-C',str(repo),'cat-file','--batch'],
    input=''.join(object_id+'\n' for _,object_id in rows).encode(),capture_output=True,check=True)
stream=io.BytesIO(process.stdout);actual={}
for name,expected_object in rows:
    object_id,kind,size=stream.readline().split()
    assert object_id.decode()==expected_object and kind==b'blob'
    data=stream.read(int(size));assert stream.read(1)==b'\n'
    actual[name]=hashlib.sha256(data).hexdigest()
assert not stream.read()
assert actual==expected, {'missing':sorted(set(expected)-set(actual)),
    'extra':sorted(set(actual)-set(expected)),
    'changed':[name for name in set(actual)&set(expected) if actual[name]!=expected[name]]}
assert submodules=={'vendor/itgmania':'663525dcb86eb570d0ef6a2e209678436660ae26',
                   'vendor/simply-love':'1feda1fd43d96baca951351bb28a35d5e690ebc7'}
result={'passed':True,'treeish':treeish,'git_tree':tree,'files_verified':len(actual),
    'source_inventory_sha256':hashlib.sha256((evidence/'build/source-files-before.json').read_bytes()).hexdigest(),
    'build_receipt_sha256':hashlib.sha256((evidence/'build/build-receipt.json').read_bytes()).hexdigest(),
    'native_equivalence_receipt_sha256':hashlib.sha256((evidence/'native-equivalence/receipt.json').read_bytes()).hexdigest(),
    'submodules':submodules,'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
destination=task/('stream-source-tree-'+tree+'.json')
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'path':str(destination),**result},indent=2))
