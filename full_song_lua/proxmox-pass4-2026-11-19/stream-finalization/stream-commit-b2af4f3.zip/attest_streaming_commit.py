"""Bind the committed harness tree to its already completed isolated controls."""
from __future__ import annotations
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

TASK = Path(__file__).resolve().parent
REPO = Path('C:/GitHub/itgmania-harness-stream-20261119')
COMMIT = 'b2af4f355d827fb0e89aead84b4c75a9b8cccf6c'
BASE = '9eb6619c0eaf9c3aceabf7348efbb06a7fd37273'
TREE = 'b94ed50e020d6c5d7f2bd0e939438c9c14c55038'
OUT = TASK / ('stream-commit-' + COMMIT)
BUILD = TASK / 'stream-build-evidence-20261119T040830Z'
CONTROL = TASK / 'stream-control-evidence-20261119T042311Z'
CHANGED = [
    'probe_theme/SongLuaTrace.lua', 'probe_theme/TraceJson.lua',
    'src/song_lua_runtime.rs', 'tests/fixtures/trace-json-control.lua',
    'tests/oracle_cli.rs',
]


def sha(path: Path) -> str:
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def record(path: Path) -> dict:
    return {'path': str(path.relative_to(OUT)).replace('\\', '/'),
            'sha256': sha(path), 'bytes': path.stat().st_size}


def copy(source: Path, destination: str) -> dict:
    target = OUT / destination
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert sha(source) == sha(target)
    return record(target)


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
assert git('rev-parse', COMMIT + '^').decode().strip() == BASE
assert git('rev-parse', COMMIT + '^{tree}').decode().strip() == TREE
assert git('status', '--porcelain') == b'', 'Committed source is not clean'
assert sorted(git('diff-tree', '--no-commit-id', '--name-only', '-r', COMMIT)
              .decode().splitlines()) == sorted(CHANGED)
source_tree_path = TASK / ('stream-source-tree-' + TREE + '.json')
source_tree = json.loads(source_tree_path.read_bytes())
assert source_tree['passed'] and source_tree['git_tree'] == TREE
assert source_tree['files_verified'] == 409
build_path = BUILD / 'build/build-receipt.json'
control_path = CONTROL / 'control-receipt.json'
build = json.loads(build_path.read_bytes())
control = json.loads(control_path.read_bytes())
download = json.loads((CONTROL / 'download-receipt.json').read_bytes())
assert sha(build_path) == '6d525af7a4542af1ce2510b3a2cd8ec96b0269c47be5573139ac13a7c17920ad'
assert sha(control_path) == 'e814cbcf18869d6c1685684ba2c318338173081eb824a3a37bf517773c15b3d3'
assert build['passed'] and control['passed'] and download['passed']
assert control['cli'] == build['cli']
assert control['build_receipt_sha256'] == sha(build_path)
assert control['ordinary_control']['passed'] and control['actual_oom_recovery']['passed']
assert control['global_proofs_and_binaries_unchanged']
assert not control['whole_song_parity_proven']
assert control['limits_preserved'] == {
    'memory_max': 6442450944, 'swap_max': 0, 'capture_runtime_max': 1290}
assert not OUT.exists(), 'Preserve an existing attestation instead of replacing it'
OUT.mkdir()

patch = git('diff', '--binary', '--full-index', BASE, COMMIT)
assert hashlib.sha256(patch).hexdigest() == build['source_patch_sha256']
(OUT / 'source.patch').write_bytes(patch)
files = []
inventory = json.loads((BUILD / 'build/source-files-before.json').read_bytes())
for name in CHANGED:
    payload = git('show', COMMIT + ':' + name)
    assert hashlib.sha256(payload).hexdigest() == inventory[name]
    target = OUT / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(payload)
    files.append({'source_path': name, **record(target)})

bundle = OUT / 'itgmania-stream-finalization.bundle'
subprocess.run(['git', '-C', str(REPO), 'bundle', 'create', str(bundle),
                BASE + '..HEAD'], check=True, capture_output=True)
verified = subprocess.run(['git', '-C', str(REPO), 'bundle', 'verify', str(bundle)],
                          check=True, capture_output=True)
(OUT / 'bundle-verify.log').write_bytes(verified.stdout + verified.stderr)
evidence = {
    'source_tree': copy(source_tree_path, 'evidence/source-tree.json'),
    'build_receipt': copy(build_path, 'evidence/build-receipt.json'),
    'control_receipt': copy(control_path, 'evidence/control-receipt.json'),
    'build_evidence': copy(BUILD / 'stream-build-evidence.zip', 'evidence/build-evidence.zip'),
    'control_evidence': copy(CONTROL / 'stream-control-evidence.zip', 'evidence/control-evidence.zip'),
    'control_download': copy(CONTROL / 'download-receipt.json', 'evidence/control-download.json'),
    'source_verifier': copy(TASK / 'verify_streaming_source_tree.py', 'evidence/verify-source-tree.py'),
}
failed_attempts = []
for number, folder, reason in [
    (1, 'stream-cli-build-20261119T033734.226917Z',
     'Canonical patch rejected CRLF-exported staging before compilation.'),
    (2, 'stream-cli-build-20261119T033948.244247Z',
     'Private source export lacked the pinned Simply Love theme input.'),
    (3, 'stream-cli-build-20261119T035004.913118Z',
     'Copied private libjpeg CMake outputs contained nonrelocatable absolute paths.'),
    (4, 'stream-cli-build-20261119T035302.956519Z',
     'Native equivalence passed; normal suite had 227 passes and two missing relative-fixture failures. '
     'The unchanged compiled suite later passed in a separate complete validation cwd.'),
]:
    directory = TASK / folder
    manifest = json.loads((directory / 'manifest.json').read_bytes())
    retained = []
    local_only = []
    for source in sorted(directory.iterdir()):
        if not source.is_file():
            continue
        if source.suffix == '.tar':
            local_only.append({'path': str(source), 'sha256': sha(source),
                               'bytes': source.stat().st_size})
        else:
            retained.append(copy(source, f'failed-attempts/{number:02d}/{source.name}'))
    failed_attempts.append({'attempt': number, 'original_directory': str(directory),
                            'original_manifest': manifest, 'reason': reason,
                            'status': 'failed-preserved', 'retained_files': retained,
                            'canonical_base_archives_retained_locally': local_only})

receipt = {
    'schema': 1,
    'kind': 'committed-stream-finalization-native-capture-attestation',
    'passed': True,
    'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'harness_commit': COMMIT,
    'harness_base': BASE,
    'harness_upstream_base': '40d89835c4ea85d632eec0ccb2361ff4569c6ac4',
    'git_tree': TREE,
    'clean_committed_worktree': True,
    'build_source_method': 'Canonical Git export plus exact patch; committed tree matches all 409 compiled source blobs.',
    'compiled_source_files_verified': source_tree['files_verified'],
    'source_inventory_sha256': source_tree['source_inventory_sha256'],
    'source_patch': record(OUT / 'source.patch'),
    'changed_files': files,
    'submodules': source_tree['submodules'],
    'git_bundle': record(bundle),
    'profile': build['profile'],
    'compiled_parent_profile': build['parent_profile'],
    'cli': build['cli'],
    'native_binary_sha256': build['native_binary_sha256'],
    'evidence': evidence,
    'preserved_failed_attempts': failed_attempts,
    'normal_suite': {'passed': 229, 'failed': 0, 'ignored': 7,
                     'compiled_binary_sha256': build['unchanged_test_binary_sha256'],
                     'log_sha256': build['checks'][0]['log_sha256'],
                     'validation_cwd_proof_sha256': build['validation_cwd_proof_sha256']},
    'native_equivalence_receipt_sha256': source_tree['native_equivalence_receipt_sha256'],
    'ordinary_control': {key: value for key, value in control['ordinary_control'].items() if key != 'native'},
    'kaboom_control': {key: value for key, value in control['actual_oom_recovery'].items() if key != 'native'},
    'kaboom_archive': control['archive'],
    'original_failure': control['original_failure'],
    'original_inputs_verified': control['original_inputs_verified'],
    'limits_preserved': control['limits_preserved'],
    'resource_usage': download['resource_usage'],
    'timing_variability': 'Original and retry use the same inputs, capture settings, limits, automatic GC, native engine and assets; worker hardware/timing and resulting sample counts differ.',
    'global_proofs_and_binaries_unchanged': True,
    'global_profile_published': False,
    'whole_song_parity_proven': False,
    'final_runner_combined_control': 'pending-final-B-runner',
    'large_kaboom_outputs': 'Retained on VM1516 at the exact paths/hashes above; not embedded in this compact local evidence archive.',
    'attestation_helper_sha256': sha(Path(__file__)),
}
copy(Path(__file__), 'attest_streaming_commit.py')
write_json(OUT / 'attestation.json', receipt)
write_json(OUT / 'manifest.json', {'files': [record(p) for p in sorted(OUT.rglob('*')) if p.is_file()]})
archive = OUT.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            output.write(path, path.relative_to(OUT).as_posix())
print(json.dumps({'directory': str(OUT), 'commit': COMMIT, 'tree': TREE,
                  'attestation_sha256': sha(OUT / 'attestation.json'),
                  'bundle_sha256': sha(bundle), 'archive': str(archive),
                  'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
                  'failed_attempts_retained': len(failed_attempts)}, indent=2))
