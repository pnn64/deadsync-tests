#!/usr/bin/env python3
"""Build only an isolated streaming CLI; never publish global fleet proofs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time
import traceback

DIRECTORY = Path(__file__).resolve().parent
ROOT = Path('/opt/song-lua-audit/pass4')
OLD_HARNESS = Path('/opt/song-lua-audit/harness-pass4')
NATIVE = OLD_HARNESS / 'vendor/itgmania'
OLD_CACHE = Path('/opt/song-lua-audit/harness/target')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, data):
    path = DIRECTORY / name
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(path)


def command(args, **kwargs):
    return subprocess.check_output(list(map(str, args)), text=True, **kwargs).strip()


def baseline():
    paths = [ROOT / 'bin/itgmania-harness-rs', NATIVE / 'ITGmania-harness-trace',
             ROOT / 'proof/build-proof.json', ROOT / 'proof/source-proof.json']
    candidate = command(['systemctl', 'show', 'deadsync-lua-pass4-candidate',
                         '--property=ActiveState,SubState,Result,ExecMainStatus,MainPID,MemoryCurrent,MemoryPeak,ControlGroup'])
    return {'at': now(), 'candidate': candidate,
            'files': [{'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size} for path in paths]}


def step(name, args, *, cwd=None, environment=None):
    record = {'name': name, 'command': list(map(str, args)), 'cwd': str(cwd or DIRECTORY), 'started_at': now()}
    save('state.json', {'stage': name, 'started_at': STARTED, 'active': True})
    with (DIRECTORY / (name + '.log')).open('wb') as log:
        result = subprocess.run(args, cwd=cwd or DIRECTORY, env=environment, stdout=log, stderr=subprocess.STDOUT)
    record.update(exit_code=result.returncode, finished_at=now(), log=str(DIRECTORY / (name + '.log')),
                  log_sha256=sha(DIRECTORY / (name + '.log')))
    save(name + '.json', record)
    if result.returncode:
        raise RuntimeError(name + ' failed: ' + str(result.returncode))
    return record


def source_inventory(directory):
    names = json.loads((DIRECTORY / 'source-file-names.json').read_text())
    return {name: sha(directory / name) for name in names}


STARTED = now()
try:
    assert command(['hostname']) == 'deadsync-lua-20261119-build'
    manifest = json.loads((DIRECTORY / 'manifest.json').read_text())
    contract = manifest['contract']
    assert manifest['id'] == hashlib.sha256(json.dumps(contract, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    for name, expected in contract['inputs'].items():
        assert sha(DIRECTORY / name) == expected['sha256'], name
        assert (DIRECTORY / name).stat().st_size == expected['bytes'], name
    assert shutil.disk_usage(DIRECTORY).free >= 20 * 1024**3
    before = baseline()
    save('baseline-before.json', before)
    assert before['files'][0]['sha256'] == contract['original_cli_sha256']
    assert before['files'][1]['sha256'] == contract['native_binary_sha256']
    assert command(['git', '-C', NATIVE, 'rev-parse', 'HEAD']) == contract['native_revision']
    assert not command(['git', '-C', NATIVE, 'status', '--porcelain', '--untracked-files=no'])

    source = DIRECTORY / 'source'
    source.mkdir()
    with tarfile.open(DIRECTORY / 'base-source.tar') as archive:
        archive.extractall(source, filter='data')
    step('apply-check', ['git', 'apply', '--check', str(DIRECTORY / 'source.patch')], cwd=source)
    step('apply-patch', ['git', 'apply', str(DIRECTORY / 'source.patch')], cwd=source)
    source_before = source_inventory(source)
    save('source-files-before.json', source_before)

    target = DIRECTORY / 'cargo-target'
    target.mkdir()
    assert OLD_CACHE.is_dir()
    step('copy-target-cache', ['cp', '-a', '--reflink=auto', str(OLD_CACHE) + '/.', str(target)])
    cargo_home = DIRECTORY / 'cargo-home'
    cargo_home.mkdir()
    old_cargo = Path.home() / '.cargo'
    assert (old_cargo / 'registry').is_dir()
    step('copy-registry-cache', ['cp', '-a', '--reflink=auto', str(old_cargo / 'registry'), str(cargo_home / 'registry')])
    if (old_cargo / 'git').is_dir():
        step('copy-git-cache', ['cp', '-a', '--reflink=auto', str(old_cargo / 'git'), str(cargo_home / 'git')])
    assert shutil.disk_usage(DIRECTORY).free >= 5 * 1024**3
    cargo = old_cargo / 'bin/cargo'
    assert cargo.is_file()
    environment = dict(os.environ,
        PATH=str(old_cargo / 'bin') + ':' + os.environ['PATH'],
        CARGO_HOME=str(cargo_home), CARGO_TARGET_DIR=str(target), RUSTUP_TOOLCHAIN='1.100.0',
        CARGO_BUILD_JOBS='1', CARGO_NET_OFFLINE='true',
        CARGO_PROFILE_RELEASE_LTO='false', CARGO_PROFILE_RELEASE_CODEGEN_UNITS='16',
        CARGO_PROFILE_RELEASE_DEBUG='0', CARGO_PROFILE_RELEASE_STRIP='none',
        ITGMANIA_ROOT=str(NATIVE), ITGMANIA_HARNESS_TRACE_BIN=str(NATIVE / 'ITGmania-harness-trace'),
        ITGMANIA_SONG_LUA_NOTESKIN_ROOT=str(NATIVE / 'NoteSkins'),
        LIBGL_ALWAYS_SOFTWARE='1', GALLIUM_DRIVER='llvmpipe', LP_NUM_THREADS='1', OMP_NUM_THREADS='1')
    rust = command([cargo, '--version'], env=environment)
    common = [str(cargo), 'test', '--offline', '--locked', '--release', '-j', '1']
    control = step('native-json-equivalence', common + ['--test', 'oracle_cli',
        'streams_trace_json_with_native_bytes_and_write_failures', '--', '--exact', '--nocapture'],
        cwd=source, environment=environment)
    log = (DIRECTORY / 'native-json-equivalence.log').read_text(errors='replace')
    assert 'test result: ok. 1 passed;' in log
    receipts = list((source / 'target/trace-json-controls').glob('*/receipt.json'))
    assert len(receipts) == 1, receipts
    native_control = json.loads(receipts[0].read_text())
    assert native_control['passed'] and native_control['native_source'] == contract['native_revision']
    assert native_control['expected_sha256'] == native_control['streamed_sha256']
    unit_tests = step('harness-unit-tests', ['xvfb-run', '-a', '-s', '-screen 0 1280x720x24 -nolisten tcp',
        *common, '--bin', 'itgmania-harness-rs'], cwd=source, environment=environment)
    assert 'test result: ok.' in (DIRECTORY / 'harness-unit-tests.log').read_text(errors='replace')
    build = step('harness-build', [str(cargo), 'build', '--offline', '--locked', '--release', '-j', '1', '--message-format=json'],
                 cwd=source, environment=environment)
    executables = set()
    for line in (DIRECTORY / 'harness-build.log').read_text(errors='replace').splitlines():
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        if message.get('reason') == 'compiler-artifact' and message.get('target', {}).get('name') == 'itgmania-harness-rs' and message.get('executable'):
            executables.add(message['executable'])
    assert len(executables) == 1, executables
    executable = Path(executables.pop())
    binary = DIRECTORY / 'bin/itgmania-harness-rs'
    binary.parent.mkdir()
    shutil.copy2(executable, binary)
    assert sha(binary) == sha(executable)
    source_after = source_inventory(source)
    assert source_before == source_after
    save('source-files-after.json', source_after)
    after = baseline()
    save('baseline-after.json', after)
    assert before['files'][:2] == after['files'][:2], 'existing capture binaries changed'
    receipt = {'passed': True, 'kind': 'isolated-cli-build-and-embedded-native-controls',
        'profile': manifest['id'], 'started_at': STARTED, 'finished_at': now(),
        'harness_base_revision': contract['harness_base_revision'], 'source_patch_sha256': contract['inputs']['source.patch']['sha256'],
        'native_revision': contract['native_revision'], 'native_binary_sha256': contract['native_binary_sha256'],
        'cli': {'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size},
        'source_files_sha256': sha(DIRECTORY / 'source-files-before.json'),
        'helper_sha256': sha(Path(__file__)), 'cargo': rust,
        'native_control_receipt': {'path': str(receipts[0]), 'sha256': sha(receipts[0])},
        'checks': [control, unit_tests, build],
        'global_proofs_unchanged': before['files'][2:] == after['files'][2:],
        'actual_oom_recovery_verified': False, 'global_profile_published': False}
    save('build-receipt.json', receipt)
    save('state.json', {'stage': 'complete', 'active': False, 'passed': True, 'finished_at': now()})
    print(json.dumps(receipt), flush=True)
except BaseException as error:
    failure = {'stage': 'failed', 'active': False, 'passed': False, 'started_at': STARTED,
               'finished_at': now(), 'error': str(error), 'traceback': traceback.format_exc()}
    save('state.json', failure)
    print(json.dumps(failure), flush=True)
    raise
