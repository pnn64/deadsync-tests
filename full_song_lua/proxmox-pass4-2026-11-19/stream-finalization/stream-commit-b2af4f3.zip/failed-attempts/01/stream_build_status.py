"""Read-only build resource probe used outside the bounded compilation cgroup."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

def properties(unit):
    result = subprocess.run(['systemctl', 'show', unit,
        '--property=Id,ActiveState,SubState,Result,ExecMainStatus,MainPID,MemoryCurrent,MemoryPeak,ControlGroup'],
        capture_output=True, text=True)
    return dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)

def group(props):
    path = props.get('ControlGroup', '')
    if not path:
        return {}
    root = Path('/sys/fs/cgroup') / path.lstrip('/')
    output = {}
    for name in ('memory.events', 'memory.pressure'):
        if (root / name).exists():
            output[name] = (root / name).read_text()
    return output

profile = Path(__file__).resolve().parent
manifest = json.loads((profile / 'manifest.json').read_text())
unit = 'itgmania-stream-build-' + manifest['id'][:12] + '.service'
assert subprocess.check_output(['hostname'], text=True).strip() == 'deadsync-lua-20261119-build'
candidate = properties('deadsync-lua-pass4-candidate.service')
own = properties(unit)
memory = {line.split(':', 1)[0]: int(line.split(':', 1)[1].split()[0])
          for line in Path('/proc/meminfo').read_text().splitlines()
          if line.startswith(('MemAvailable:', 'MemTotal:'))}
out = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'unit': unit,
       'own': own, 'own_group': group(own), 'candidate': candidate, 'candidate_group': group(candidate),
       'memory_kib': memory, 'global_memory_pressure': Path('/proc/pressure/memory').read_text(),
       'free_bytes': shutil.disk_usage(profile).free}
for name in ('state.json', 'build-receipt.json'):
    path = profile / name
    if path.exists():
        out[name] = json.loads(path.read_text())
if '--preflight' in sys.argv:
    inputs = manifest['contract']['inputs']
    for name, record in inputs.items():
        path = profile / name
        assert path.stat().st_size == record['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256'], name
    out['baseline_files'] = []
    for path in [Path('/opt/song-lua-audit/pass4/bin/itgmania-harness-rs'),
                 Path('/opt/song-lua-audit/harness-pass4/vendor/itgmania/ITGmania-harness-trace'),
                 Path('/opt/song-lua-audit/pass4/proof/build-proof.json'),
                 Path('/opt/song-lua-audit/pass4/proof/source-proof.json')]:
        with path.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        out['baseline_files'].append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest})
    for name in ('registry',):
        assert (Path.home() / '.cargo' / name).is_dir()
    assert (Path.home() / '.cargo/bin/cargo').is_file()
    assert out['free_bytes'] >= 20 * 1024**3
    assert out['memory_kib']['MemAvailable'] >= 3 * 1024**2
print(json.dumps(out))
