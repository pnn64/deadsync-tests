#!/usr/bin/env python3
"""Build only an isolated streaming CLI; never publish global fleet proofs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time
import traceback

DIRECTORY = Path(__file__).resolve().parent
ROOT = Path('/opt/song-lua-audit/pass4')
OLD_HARNESS = Path('/opt/song-lua-audit/harness-pass4')
NATIVE = OLD_HARNESS / 'vendor/itgmania'
OLD_THEME = OLD_HARNESS / 'vendor/simply-love'
OLD_CACHE = Path('/opt/song-lua-audit/harness/target')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, data):
    path = DIRECTORY / name
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(path)


def command(args, **kwargs):
    return subprocess.check_output(list(map(str, args)), text=True, **kwargs).strip()


def baseline():
    paths = [ROOT / 'bin/itgmania-harness-rs', NATIVE / 'ITGmania-harness-trace',
             ROOT / 'proof/build-proof.json', ROOT / 'proof/source-proof.json']
    candidate = command(['systemctl', 'show', 'deadsync-lua-pass4-candidate',
                         '--property=ActiveState,SubState,Result,ExecMainStatus,MainPID,MemoryCurrent,MemoryPeak,ControlGroup'])
    return {'at': now(), 'candidate': candidate,
            'files': [{'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size} for path in paths]}


def step(name, args, *, cwd=None, environment=None):
    record = {'name': name, 'command': list(map(str, args)), 'cwd': str(cwd or DIRECTORY), 'started_at': now()}
    save('state.json', {'stage': name, 'started_at': STARTED, 'active': True})
    with (DIRECTORY / (name + '.log')).open('wb') as log:
        result = subprocess.run(args, cwd=cwd or DIRECTORY, env=environment, stdout=log, stderr=subprocess.STDOUT)
    record.update(exit_code=result.returncode, finished_at=now(), log=str(DIRECTORY / (name + '.log')),
                  log_sha256=sha(DIRECTORY / (name + '.log')))
    save(name + '.json', record)
    if result.returncode:
        raise RuntimeError(name + ' failed: ' + str(result.returncode))
    return record


def source_inventory(directory):
    names = json.loads((DIRECTORY / 'source-file-names.json').read_text())
    return {name: sha(directory / name) for name in names}


def native_dependencies():
    modules = ['extern/libpng', 'extern/zlib', 'extern/libjpeg-turbo', 'extern/ogg', 'extern/vorbis']
    module_rows = command(['git', '-C', NATIVE, 'submodule', 'status', '--', *modules]).splitlines()
    assert len(module_rows) == len(modules)
    assert all(not row.startswith(('-', '+', 'U')) for row in module_rows), module_rows
    required = ['src/Song.h', 'src/NotesLoaderSM.h', 'src/NotesLoaderSSC.h',
        'extern/lua-5.1/src/lua.h', 'extern/jsoncpp/json/json.h', 'extern/pcre/pcre.h.generic',
        'extern/miniz/miniz.h', 'CMake/SMDefs.cmake', 'extern/libpng/pngread.c',
        'extern/libpng/scripts/pnglibconf.h.prebuilt', 'extern/zlib/inflate.c',
        'extern/libjpeg-turbo/CMakeLists.txt', 'extern/ogg/src/framing.c',
        'extern/vorbis/lib/vorbisfile.c', 'Themes/_fallback/Scripts/03 Gameplay.lua',
        'Themes/_fallback/metrics.ini']
    for name in required:
        assert (NATIVE / name).is_file(), name
    assert not command(['git', '-C', NATIVE, 'status', '--porcelain', '--untracked-files=no'])
    return {'revision': command(['git', '-C', NATIVE, 'rev-parse', 'HEAD']),
            'submodules': module_rows, 'required_files': {name: sha(NATIVE / name) for name in required}}


def export_theme(source, expected_revision):
    assert command(['git', '-C', OLD_THEME, 'rev-parse', 'HEAD']) == expected_revision
    assert not command(['git', '-C', OLD_THEME, 'status', '--porcelain', '--untracked-files=no'])
    archive_path = DIRECTORY / 'theme-source.tar'
    with archive_path.open('wb') as stream:
        subprocess.run(['git', '-C', str(OLD_THEME), '-c', 'core.autocrlf=false', '-c', 'core.eol=lf',
                        'archive', '--format=tar', expected_revision], stdout=stream, check=True)
    theme = source / 'vendor/simply-love'
    theme.mkdir(parents=True, exist_ok=True)
    assert not any(theme.iterdir())
    with tarfile.open(archive_path) as archive:
        archive.extractall(theme, filter='data')
    rows = subprocess.check_output(['git', '-C', str(OLD_THEME), 'ls-tree', '-r', '-z', expected_revision])
    files = {}
    for row in rows.split(b'\0'):
        if not row:
            continue
        metadata, name = row.split(b'\t', 1)
        mode, kind, object_id = metadata.split()
        assert kind == b'blob', (kind, name)
        path = theme / name.decode()
        data = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == object_id.decode(), name
        files[name.decode()] = hashlib.sha256(data).hexdigest()
    for name in ('Scripts/SL_Init.lua', 'Scripts/SL-Helpers.lua', 'Scripts/99 SL-ThemePrefs.lua',
                 'Scripts/SL-ChartParser.lua', 'Scripts/SL-ChartParserHelpers.lua', 'metrics.ini'):
        assert name in files, name
    save('theme-source-proof.json', {'revision': expected_revision,
        'tree': command(['git', '-C', OLD_THEME, 'rev-parse', expected_revision + '^{tree}']),
        'archive_sha256': sha(archive_path), 'files': files, 'canonical_git_blobs_verified': True})
    return theme, files


STARTED = now()
try:
    assert command(['hostname']) == 'deadsync-lua-20261119-build'
    manifest = json.loads((DIRECTORY / 'manifest.json').read_text())
    contract = manifest['contract']
    assert manifest['id'] == hashlib.sha256(json.dumps(contract, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    for name, expected in contract['inputs'].items():
        assert sha(DIRECTORY / name) == expected['sha256'], name
        assert (DIRECTORY / name).stat().st_size == expected['bytes'], name
    assert shutil.disk_usage(DIRECTORY).free >= 20 * 1024**3
    before = baseline()
    save('baseline-before.json', before)
    assert before['files'][0]['sha256'] == contract['original_cli_sha256']
    assert before['files'][1]['sha256'] == contract['native_binary_sha256']
    assert command(['git', '-C', NATIVE, 'rev-parse', 'HEAD']) == contract['native_revision']
    assert not command(['git', '-C', NATIVE, 'status', '--porcelain', '--untracked-files=no'])
    dependencies_before = native_dependencies()
    save('native-dependencies-before.json', dependencies_before)

    source = DIRECTORY / 'source'
    source.mkdir()
    with tarfile.open(DIRECTORY / 'base-source.tar') as archive:
        archive.extractall(source, filter='data')
    step('apply-check', ['git', 'apply', '--check', str(DIRECTORY / 'source.patch')], cwd=source)
    step('apply-patch', ['git', 'apply', str(DIRECTORY / 'source.patch')], cwd=source)
    theme, theme_before = export_theme(source, contract['theme_revision'])
    source_before = source_inventory(source)
    save('source-files-before.json', source_before)

    target = DIRECTORY / 'cargo-target'
    target.mkdir()
    assert OLD_CACHE.is_dir()
    step('copy-target-cache', ['cp', '-a', '--reflink=auto', str(OLD_CACHE) + '/.', str(target)])
    # CMake caches name their absolute build directory. Regenerate only these
    # newly copied private codec outputs; the completed source cache stays read-only.
    relocated_caches = []
    for jpeg in sorted(target.glob('**/out/native-jpeg')):
        assert jpeg.resolve().is_relative_to(target.resolve()) and not jpeg.is_symlink()
        cache = jpeg / 'CMakeCache.txt'
        assert cache.is_file(), jpeg
        relocated_caches.append({'private_path': str(jpeg), 'cache_sha256': sha(cache)})
        shutil.rmtree(jpeg)
    save('relocated-cmake-caches.json', relocated_caches)
    cargo_home = DIRECTORY / 'cargo-home'
    cargo_home.mkdir()
    old_cargo = Path.home() / '.cargo'
    assert (old_cargo / 'registry').is_dir()
    step('copy-registry-cache', ['cp', '-a', '--reflink=auto', str(old_cargo / 'registry'), str(cargo_home / 'registry')])
    if (old_cargo / 'git').is_dir():
        step('copy-git-cache', ['cp', '-a', '--reflink=auto', str(old_cargo / 'git'), str(cargo_home / 'git')])
    assert shutil.disk_usage(DIRECTORY).free >= 5 * 1024**3
    cargo = old_cargo / 'bin/cargo'
    assert cargo.is_file()
    jobs = str(contract['limits']['jobs'])
    environment = dict(os.environ,
        PATH=str(old_cargo / 'bin') + ':' + os.environ['PATH'],
        CARGO_HOME=str(cargo_home), CARGO_TARGET_DIR=str(target), RUSTUP_TOOLCHAIN='1.100.0',
        CARGO_BUILD_JOBS=jobs, CARGO_NET_OFFLINE='true',
        CARGO_PROFILE_RELEASE_LTO='false', CARGO_PROFILE_RELEASE_CODEGEN_UNITS='16',
        CARGO_PROFILE_RELEASE_DEBUG='0', CARGO_PROFILE_RELEASE_STRIP='none',
        ITGMANIA_ROOT=str(NATIVE), ITGMANIA_HARNESS_TRACE_BIN=str(NATIVE / 'ITGmania-harness-trace'),
        ITGMANIA_SONG_LUA_NOTESKIN_ROOT=str(NATIVE / 'NoteSkins'),
        LIBGL_ALWAYS_SOFTWARE='1', GALLIUM_DRIVER='llvmpipe', LP_NUM_THREADS='1', OMP_NUM_THREADS='1')
    rust = command([cargo, '--version'], env=environment)
    common = [str(cargo), 'test', '--offline', '--locked', '--release', '-j', jobs]
    control = step('native-json-equivalence', common + ['--test', 'oracle_cli',
        'streams_trace_json_with_native_bytes_and_write_failures', '--', '--exact', '--nocapture'],
        cwd=source, environment=environment)
    log = (DIRECTORY / 'native-json-equivalence.log').read_text(errors='replace')
    assert 'test result: ok. 1 passed;' in log
    receipts = list((source / 'target/trace-json-controls').glob('*/receipt.json'))
    assert len(receipts) == 1, receipts
    native_control = json.loads(receipts[0].read_text())
    assert native_control['passed'] and native_control['native_source'] == contract['native_revision']
    assert native_control['expected_sha256'] == native_control['streamed_sha256']
    unit_tests = step('harness-unit-tests', ['xvfb-run', '-a', '-s', '-screen 0 1280x720x24 -nolisten tcp',
        *common, '--bin', 'itgmania-harness-rs'], cwd=source, environment=environment)
    assert 'test result: ok.' in (DIRECTORY / 'harness-unit-tests.log').read_text(errors='replace')
    build = step('harness-build', [str(cargo), 'build', '--offline', '--locked', '--release', '-j', jobs, '--message-format=json'],
                 cwd=source, environment=environment)
    executables = set()
    for line in (DIRECTORY / 'harness-build.log').read_text(errors='replace').splitlines():
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        if message.get('reason') == 'compiler-artifact' and message.get('target', {}).get('name') == 'itgmania-harness-rs' and message.get('executable'):
            executables.add(message['executable'])
    assert len(executables) == 1, executables
    executable = Path(executables.pop())
    binary = DIRECTORY / 'bin/itgmania-harness-rs'
    binary.parent.mkdir()
    shutil.copy2(executable, binary)
    assert sha(binary) == sha(executable)
    source_after = source_inventory(source)
    assert source_before == source_after
    save('source-files-after.json', source_after)
    for name, expected in theme_before.items():
        path = theme / name
        data = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected, name
    assert native_dependencies() == dependencies_before
    save('native-dependencies-after.json', dependencies_before)
    after = baseline()
    save('baseline-after.json', after)
    assert before['files'][:2] == after['files'][:2], 'existing capture binaries changed'
    receipt = {'passed': True, 'kind': 'isolated-cli-build-and-embedded-native-controls',
        'profile': manifest['id'], 'started_at': STARTED, 'finished_at': now(),
        'harness_base_revision': contract['harness_base_revision'], 'source_patch_sha256': contract['inputs']['source.patch']['sha256'],
        'native_revision': contract['native_revision'], 'native_binary_sha256': contract['native_binary_sha256'],
        'theme_revision': contract['theme_revision'], 'theme_source_proof_sha256': sha(DIRECTORY / 'theme-source-proof.json'),
        'native_dependencies_proof_sha256': sha(DIRECTORY / 'native-dependencies-before.json'),
        'cli': {'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size},
        'source_files_sha256': sha(DIRECTORY / 'source-files-before.json'),
        'helper_sha256': sha(Path(__file__)), 'cargo': rust,
        'native_control_receipt': {'path': str(receipts[0]), 'sha256': sha(receipts[0])},
        'checks': [control, unit_tests, build],
        'global_proofs_unchanged': before['files'][2:] == after['files'][2:],
        'actual_oom_recovery_verified': False, 'global_profile_published': False}
    save('build-receipt.json', receipt)
    save('state.json', {'stage': 'complete', 'active': False, 'passed': True, 'finished_at': now()})
    print(json.dumps(receipt), flush=True)
except BaseException as error:
    failure = {'stage': 'failed', 'active': False, 'passed': False, 'started_at': STARTED,
               'finished_at': now(), 'error': str(error), 'traceback': traceback.format_exc()}
    save('state.json', failure)
    print(json.dumps(failure), flush=True)
    raise
