#!/usr/bin/env python3
"""Bounded supplemental native control; source and every outcome are retained."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback
import wave

ROOT = Path('/opt/song-lua-audit/pass4')
HERE = Path(__file__).resolve().parent
REPO = Path('/opt/song-lua-audit/harness-pass4')
ENGINE = REPO / 'vendor/itgmania/ITGmania-harness-trace'
HARNESS = ROOT / 'bin/itgmania-harness-rs'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def file_info(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def command(*args):
    return subprocess.check_output(list(map(str, args)), text=True).strip()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def main():
    assert HERE == ROOT / 'controls/life-event-score', HERE
    attempt = HERE / ('attempt-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    attempt.mkdir()
    shutil.copy2(Path(__file__), attempt / 'capture_control.py')
    receipt = {'schema_version': 1, 'started_at': now(), 'passed': False,
               'purpose': 'Independent native callback and manual integer-score observations',
               'attempt': str(attempt), 'authoring_recipe': file_info(Path(__file__))}
    try:
        pins = {
            'harness': '9eb6619c0eaf9c3aceabf7348efbb06a7fd37273',
            'native': '663525dcb86eb570d0ef6a2e209678436660ae26',
            'theme': '1feda1fd43d96baca951351bb28a35d5e690ebc7',
        }
        assert command('git', '-C', REPO, 'rev-parse', 'HEAD') == pins['harness']
        assert not command('git', '-C', REPO, 'status', '--porcelain', '--untracked-files=no', '--ignore-submodules')
        assert command('git', '-C', ENGINE.parent, 'rev-parse', 'HEAD') == pins['native']
        assert command('git', '-C', REPO / 'vendor/simply-love', 'rev-parse', 'HEAD') == pins['theme']
        subprocess.run(['git', '-C', str(ENGINE.parent), 'diff', '--quiet', 'HEAD', '--', 'src'], check=True)
        assert sha(HARNESS) == '4868fd245547b55ea554632b2a0dcf61dbaa022c9a6e9f2515c9259983bdec7f'
        assert sha(ENGINE) == 'c03763cac1270c14dbe790cbb055c96ebbced269448d64e0bb705385dc9537a3'
        proof = json.loads((ROOT / 'proof/build-proof.json').read_text())
        assert proof['passed'] is True
        sys.path.insert(0, str(ROOT))
        import worker
        receipt['pins'] = pins
        receipt['binaries'] = {'harness': file_info(HARNESS), 'native': file_info(ENGINE)}
        receipt['assets'] = {
            'theme_tree_sha256': worker.tree_digest(ENGINE.parent / 'Themes/Harness Simply Love'),
            'native_noteskins_tree_sha256': worker.tree_digest(ENGINE.parent / 'NoteSkins'),
        }
        for name in ['source-proof.json', 'build-proof.json', 'capture-binaries.json']:
            shutil.copy2(ROOT / 'proof' / name, attempt / name)
        receipt['source_proof'] = file_info(attempt / 'source-proof.json')
        receipt['build_proof'] = file_info(attempt / 'build-proof.json')
        fixture = attempt / 'fixture'
        fixture.mkdir()
        for name in ['control.ssc', 'control.lua', 'input-script.json']:
            shutil.copy2(HERE / name, fixture / name)
        with wave.open(str(fixture / 'music.wav'), 'wb') as stream:
            stream.setnchannels(1)
            stream.setsampwidth(2)
            stream.setframerate(8000)
            stream.writeframes(b'\0\0' * 8000 * 4)
        receipt['fixture'] = {path.name: file_info(path) for path in sorted(fixture.iterdir())}
        output = attempt / 'native.json'
        args = ['xvfb-run', '-a', '-s', '-screen 0 1280x720x24 +extension GLX',
                str(HARNESS), 'song-lua-trace', str(fixture / 'control.ssc'),
                '--itgmania-bin', str(ENGINE), '--fallback-theme', 'Harness Simply Love',
                '--game', 'dance', '--style', 'versus', '--chart-index', '1',
                '--capture-fps', '120', '--max-events', '2000000', '--timeout', '150',
                '--random-seed', '1', '--out', str(output), '--until-gameplay-end',
                '--headless', '--autoplay', '0', '--player-options', 'default,failimmediatecontinue',
                '--input-script', str(fixture / 'input-script.json'), '--keep-run-dir']
        environment = os.environ.copy()
        environment.update({'LIBGL_ALWAYS_SOFTWARE': '1', 'LP_NUM_THREADS': '1',
                            'ITGMANIA_SONG_LUA_NOTESKIN_ROOT': str(ENGINE.parent / 'NoteSkins'),
                            'TMPDIR': str(attempt / 'tmp')})
        (attempt / 'tmp').mkdir()
        receipt['command'] = args
        receipt['profile'] = 'Native physical input and Lua semantics with Null renderer; no drawable or render parity claim'
        receipt['environment'] = {key: environment[key] for key in
            ['LIBGL_ALWAYS_SOFTWARE', 'LP_NUM_THREADS', 'ITGMANIA_SONG_LUA_NOTESKIN_ROOT', 'TMPDIR']}
        save(attempt / 'receipt.json', receipt)
        with (attempt / 'capture.log').open('wb') as log:
            result = subprocess.run(args, cwd=HERE, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        receipt['capture_exit_code'] = result.returncode
        assert result.returncode == 0, result.returncode
        trace = json.loads(output.read_text())
        receipt['native_trace'] = file_info(output)
        receipt['completion'] = trace.get('completion')
        worker.validate_native(output, trace, {'chart_index': 1}, pins['native'],
            full=True, screen_gameplay_sha256=sha(ENGINE.parent / 'src/ScreenGameplay.cpp'))
        assert trace['capabilities']['native_gameplay_clock_inputs'] is True
        dropped = {key: value for key, value in trace.items() if key.startswith('dropped_')}
        assert all(value == 0 for value in dropped.values()), dropped
        observations = [event['args'][1] for event in trace['events']
                        if event.get('operation') == 'MessageManager.Broadcast'
                        and event.get('args', [None])[0] == 'LifeEventScoreObservation']
        save(attempt / 'observations.json', observations)
        receipt['observations'] = file_info(attempt / 'observations.json')
        receipt['native_frames'] = len(trace['update_frames'])
        receipt['native_inputs'] = len(trace['input_events'])
        receipt['gameplay_clock_reads'] = sum(row['gameplay_clock_inputs'] is not None for row in trace['update_frames'])
        receipt['dropped'] = dropped
        input_types = [row['event']['type'] for row in trace['input_events']]
        assert input_types.count('InputEventType_FirstPress') == 4, input_types
        assert input_types.count('InputEventType_Release') == 4, input_types
        assert all(kind in ['InputEventType_FirstPress', 'InputEventType_Release', 'InputEventType_Repeat'] for kind in input_types), input_types
        receipt['native_input_types'] = {kind: input_types.count(kind) for kind in sorted(set(input_types))}
        def phase(name):
            selected = [row for row in observations if row['phase'] == name]
            assert len(selected) == 1, (name, len(selected))
            return selected[0]
        scripted = []
        for label, target in [('P1-early', 0.25), ('P2-early', 0.75),
                              ('P1-W1-row', 0), ('P2-held', 0)]:
            before, inside, after = [phase(prefix + ':' + label) for prefix in ['before', 'inside', 'after']]
            assert before['serial'] < inside['serial'] < after['serial']
            assert inside['meter'] == target, (label, inside)
            assert inside['current_life'] == before['current_life'], (label, before, inside)
            assert after['current_life'] == target, (label, after)
            scripted.append({'label': label, 'before': before, 'inside': inside, 'after': after})
        scoring = []
        for label in ['P1-W1-row', 'P2-held']:
            before = phase('before:' + label)
            after = phase('post-score:' + label)
            assert before['failed'] is False, before
            assert after['score'] - before['score'] > 10, (label, before, after)
            assert after['current_max_score'] > before['current_max_score'], (label, before, after)
            scoring.append({'label': label, 'before': before, 'after': after})
        natural = [row for row in observations if row['phase'] == 'natural']
        for judgment in ['TapNoteScore_W1', 'TapNoteScore_Miss', 'HoldNoteScore_Held']:
            assert any(row['judgment'] == judgment for row in natural), judgment
        assert any(row['meter'] != row['current_life'] for row in natural), natural
        receipt['checks'] = {'scripted_writes': scripted, 'weighted_manual_scores': scoring,
                             'natural_events': natural,
                             'final': [phase('final:P1'), phase('final:P2')]}
        assert all(row['failed'] for row in receipt['checks']['final']), receipt['checks']['final']
        receipt['passed'] = True
    except Exception as exc:
        receipt['error'] = str(exc)
        receipt['traceback'] = traceback.format_exc()
    finally:
        receipt['completed_at'] = now()
        save(attempt / 'receipt.json', receipt)
        save(HERE / 'latest-attempt.json', {'path': str(attempt), 'passed': receipt['passed'],
             'receipt': file_info(attempt / 'receipt.json')})
        print(json.dumps({'passed': receipt['passed'], 'path': str(attempt),
                          'error': receipt.get('error'), 'native_frames': receipt.get('native_frames')}), flush=True)
    return 0 if receipt['passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
