"""Retain exact native inputs and successful/failed replay evidence with scope."""
import hashlib
import io
import json
from pathlib import Path
import zipfile

WORK = Path(__file__).resolve().parent
REPOSITORY = Path('C:/GitHub/deadsync-fixtures-lua-fleet-20261119')
ROOT = REPOSITORY / 'full_song_lua/proxmox-pass4-2026-11-19'
GLX = WORK / 'life-event-score-glx-evidence'
OUT = ROOT / 'repaired-native-controls'
NATIVE_OUT = ROOT / 'native-life-score-glx'
HEAD = '45da6736ad118301055d1a3b2031ae35dd4d47b4'
PATCH = 'ea3359c7722c1b37211c2c2a8ab8fffc7f9c1e8dd76ce53203f30d90b79816e0'

def sha(data): return hashlib.sha256(data).hexdigest()
def encoded(value): return (json.dumps(value, indent=2) + '\n').encode()
def load(path): return json.loads(path.read_bytes())
def stable(path, data):
    assert len(data) < 50_000_000, path
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, ('immutable retained evidence differs', path)
    else:
        path.write_bytes(data)

download = load(GLX / 'download-receipt.json')
native_zip = (GLX / 'life-event-score-glx-evidence.zip').read_bytes()
assert len(native_zip) == download['bytes'] == 4_300_150
assert sha(native_zip) == download['sha256'] == '80a6bcd006c365ff2ed615786a3c7594b9ceb7bd6cf229c7b3cbb6b843d62227'
native_manifest_bytes = (GLX / 'manifest.json').read_bytes()
assert sha(native_manifest_bytes) == download['manifest_sha256']
native_manifest = json.loads(native_manifest_bytes)
assert native_manifest['capture_completed'] and native_manifest['complete_final_update']
assert native_manifest['requested_exercise_passed'] is False
native_members = {row['path']: row for row in native_manifest['files']}
assert len(native_members) == len(native_manifest['files']) == 15
with zipfile.ZipFile(io.BytesIO(native_zip)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist()))
    assert set(archive.namelist()) == set(native_members) | {'manifest.json'}
    assert archive.read('manifest.json') == native_manifest_bytes
    for name, expected in native_members.items():
        data = archive.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], name
assert native_members['bounded-glx/native.json']['sha256'] == '00b8b029335de11264806ad163517b032324240ffa2eaff172651190017d5e85'

current = WORK / 'corpus-audit-native-controls-20261119T025321Z'
null = WORK / 'corpus-audit-native-controls-20261119T025916Z'
receipts = []
for directory in [current, null]:
    receipt = load(directory / 'receipt.json')
    for case in receipt['cases']:
        assert case['source_unchanged'] and case['source_before'] == case['source_after'], case['case']
        assert case['source_before']['head'] == HEAD and case['source_before']['patch_sha256'] == PATCH
        report = case.get('report')
        if report and case.get('report_sha256'):
            assert sha(Path(report).read_bytes()) == case['report_sha256'], report
        for record in case['reference_inputs']:
            path = Path(record['path'])
            assert path.stat().st_size == record['bytes'] and sha(path.read_bytes()) == record['sha256'], path
    receipts.append(receipt)

for name in ['life-glx-report.json', 'life-glx-diagnostic-report.json']:
    report = load(current / name)
    assert report['native_frames'] == report['replayed_frames'] == 116
    assert report['compared_stage_fields'] == 731 and not report['mismatches'] and not report['errors']
    assert not report['archive_accepted'] and not report['whole_song_parity_proven']
    assert report['interactive']['draw_mismatches'] == 0
say = load(current / 'say-something-report.json')
assert say['archive_accepted'] and say['production_gameplay_checks_passed'] and say['diagnostic_replay_checks_passed']
assert say['native_frames'] == say['replayed_frames'] == 1865 and say['compared_stage_fields'] == 25138
assert not say['mismatches'] and not say['errors'] and not say['whole_song_parity_proven']
for name in ['life-report.json', 'life-diagnostic-report.json']:
    report = load(null / name)
    assert report['native_frames'] == report['replayed_frames'] == 1071
    assert report['compared_stage_fields'] == 3164 and not report['mismatches']
    assert len(report['errors']) == 1 and not report['archive_accepted']

scope = {
    'schema_version': 1,
    'source_head': HEAD,
    'full_index_patch_sha256': PATCH,
    'native_revision': '663525dcb86eb570d0ef6a2e209678436660ae26',
    'harness_revision': '9eb6619c0eaf9c3aceabf7348efbb06a7fd37273',
    'complete_glx_life_control': {'frames_each_path': 116, 'stage_fields_each_path': 731,
        'errors': 0, 'mismatches': 0, 'complete_final_update': True,
        'held_note_dance_points_callback_observed': True, 'intended_w1_exercise_observed': False,
        'capture_bounded_at_beat': 8, 'archive_accepted': False},
    'original_null_counterevidence': {'frames_each_path': 1071, 'stage_fields_each_path': 3164,
        'mismatches': 0, 'errors_each_path': 1, 'archive_accepted': False,
        'error': 'The retained final update lacks a complete raw timer/input phase; it remains rejected.',
        'w1_score_and_dance_points_before_partial_tail_match': True},
    'say_something': {'frames_each_path': 1865, 'combined_stage_fields': 25138,
        'errors': 0, 'mismatches': 0, 'implemented_combined_checks_passed': True},
    'retained_unresolved_cases': {
        'MODULO': 'scene reload timing and committed-stage counter boundary',
        'VANITY ANGEL': 'native drawable def-0010 lacks an independently identified owned visual slot',
        'Cold': 'default sprite sheet frame width rounds differently; this receipt predates that correction'},
    'application_build_exercised': False,
    'whole_song_parity_proven': False,
    'pixel_parity_proven': False,
    'fleet_completion_claimed': False,
    'native_inputs_modified': False,
}

sources = []
for name in ['corpus-audit-native-controls-20261119T022511Z',
             'corpus-audit-native-controls-20261119T025321Z',
             'corpus-audit-native-controls-20261119T025916Z',
             'corpus-audit-shared-controls-20261119T023752Z']:
    for path in sorted((WORK / name).rglob('*')):
        if path.is_file(): sources.append((path, path.relative_to(WORK).as_posix()))
for name in ['actor-crop-native-authority.json', 'dance-points-callback-authority.json',
             'vtubers-song-end-authority.json', 'retain_repaired_native_controls.py']:
    sources.append((WORK / name, 'authority-and-recipe/' + name))
members = {name: path.read_bytes() for path, name in sources}
assert len(members) == len(sources)
manifest = {'schema_version': 1, 'scope': scope, 'files': [
    {'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())]}
manifest_bytes = encoded(manifest)
packed = io.BytesIO()
with zipfile.ZipFile(packed, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in [*sorted(members.items()), ('manifest.json', manifest_bytes)]:
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 19, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
bundle = packed.getvalue()

files = {
    NATIVE_OUT / 'life-event-score-glx-evidence.zip': native_zip,
    NATIVE_OUT / 'manifest.json': native_manifest_bytes,
    NATIVE_OUT / 'download-receipt.json': (GLX / 'download-receipt.json').read_bytes(),
    OUT / 'replay-evidence.zip': bundle,
    OUT / 'manifest.json': manifest_bytes,
    OUT / 'scope.json': encoded(scope),
}
for path, data in files.items(): stable(path, data)
index_path = ROOT / 'evidence-files.json'
index = {item['path']: item for item in load(index_path)}
for path, data in files.items():
    relative = path.relative_to(REPOSITORY).as_posix()
    index[relative] = {'path': relative, 'bytes': len(data), 'sha256': sha(data)}
index_path.write_bytes(encoded(list(index.values())))
print(json.dumps({'retained_files': len(files), 'native_zip_members': len(native_members) + 1,
    'replay_zip_members': len(members) + 1, 'replay_zip_bytes': len(bundle),
    'source_head': HEAD, 'source_patch_sha256': PATCH, 'whole_song_parity_proven': False}))
