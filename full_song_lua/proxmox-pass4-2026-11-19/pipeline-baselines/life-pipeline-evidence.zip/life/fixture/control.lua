-- This song authors inputs and displays observations. It supplies no oracle values.
-- Repeated equal formatted samples are run-length encoded to keep native text
-- geometry small while retaining every returned sample and the table length.
local function record_text(values)
    local parts = {}
    local previous, repeated
    local function flush()
        if previous then
            parts[#parts + 1] = previous .. '*' .. repeated
        end
    end
    for _, value in ipairs(values) do
        local current = string.format('%.6f', value)
        if current == previous then
            repeated = repeated + 1
        else
            flush()
            previous, repeated = current, 1
        end
    end
    flush()
    return '#' .. #values .. '[' .. table.concat(parts, ',') .. ']'
end

local events = {
    {at = 0.25, player = 1, life = 0.25, label = 'P1-first'},
    {at = 0.75, player = 2, life = 0.875, label = 'P2-first'},
    {at = 1.25, player = 1, life = 0.75, label = 'P1-second'},
    {at = 1.75, player = 2, life = 0.375, label = 'P2-second'},
}
local queries = {
    {name = 'default100', last_second = 3},
    {name = 'two', last_second = 3, samples = 2},
    {name = 'five', last_second = 3, samples = 5},
    {name = 'zero-default100', last_second = 3, samples = 0},
    {name = 'negative-default100', last_second = 3, samples = -7},
    {name = 'early-five', last_second = 0.5, samples = 5},
}

local root = Def.ActorFrame {
    Name = 'LifeRecordControl',
    OnCommand = function(self)
        self:sleep(30)
        local screen = SCREENMAN:GetTopScreen()
        local players = {screen:GetChild('PlayerP1'), screen:GetChild('PlayerP2')}
        assert(players[1] and players[2], 'life record control requires versus players')
        local stage = STATSMAN:GetCurStageStats()
        local stats = {stage:GetPlayerStageStats(PLAYER_1), stage:GetPlayerStageStats(PLAYER_2)}
        local function query(player, last_second, samples)
            if samples == nil then
                return stats[player]:GetLifeRecord(last_second)
            end
            return stats[player]:GetLifeRecord(last_second, samples)
        end
        local function both(last_second, samples)
            return 'P1=' .. record_text(query(1, last_second, samples))
                .. ' P2=' .. record_text(query(2, last_second, samples))
        end
        local next_event = 1
        self:SetUpdateFunction(function()
            local seconds = GAMESTATE:GetCurMusicSeconds()
            while events[next_event] and seconds >= events[next_event].at do
                local event = events[next_event]
                local before = both(3, 5)
                players[event.player]:SetLife(event.life)
                local after = both(3, 5)
                self:GetChild('Write' .. next_event):settext(event.label
                    .. ' at=' .. string.format('%.6f', seconds)
                    .. ' before ' .. before .. ' immediate ' .. after)
                next_event = next_event + 1
            end
            for index, query in ipairs(queries) do
                self:GetChild('Query' .. index):settext(query.name .. ' ' .. both(query.last_second, query.samples))
            end
            if seconds >= 2.5 then
                self:GetChild('AfterHistory'):settext('after-history ' .. both(3, 5)
                    .. ' short ' .. both(0.5, 5))
            end
        end)
    end,
}

local function label(name, line)
    return LoadFont('Common Normal') .. {
        Name = name,
        InitCommand = function(self)
            self:halign(0):valign(0):xy(8, 8 + line * 24):zoom(0.16):settext(name)
        end,
    }
end
for index = 1, #queries do
    root[#root + 1] = label('Query' .. index, index - 1)
end
for index = 1, #events do
    root[#root + 1] = label('Write' .. index, #queries + index - 1)
end
root[#root + 1] = label('AfterHistory', #queries + #events)
return root
