
return Def.ActorFrame {
    Name='VibratingParent',
    OnCommand=function(self)
        self:sleep(30)
        SCREENMAN:GetTopScreen():vibrate():effectmagnitude(2,1,0)
        self:vibrate():effectmagnitude(4,3,0)
        self:SetDrawFunction(function(parent)
            parent:GetChild('Repeat'):Draw()
            parent:GetChild('Repeat'):Draw()
            parent:GetChild('FakeChild'):Draw()
        end)
    end,
    Def.Quad { Name='Repeat', InitCommand=function(self)
        self:zoomto(16,16):xy(32,32):vibrate():effectmagnitude(1,2,0)
        self:AddWrapperState():vibrate():effectmagnitude(3,5,0)
    end },
    Def.ActorFrame { Name='Fake', InitCommand=function(self) self:vibrate():effectmagnitude(1,1,0) end },
    Def.Quad { Name='FakeChild', InitCommand=function(self)
        self:zoomto(16,16):xy(80,80):vibrate():effectmagnitude(0,0,0)
    end, OnCommand=function(self) self:SetFakeParent(self:GetParent():GetChild('Fake')) end },
}
