
    return Def.ActorFrame{OnCommand=function(self)
     -- Change only this isolated native control's visual clock. The observer
     -- must read both fields, rather than reconstruct one from initial inputs.
     PREFSMAN:SetPreference('VisualDelaySeconds',0.125)
     self:SetUpdateFunction(function()
      local player=SCREENMAN:GetTopScreen():GetChild('PlayerP1')
      if not player then return end
      for col,actor in ipairs(player:GetChild('NoteField'):GetColumnActors()) do
       local handler=actor:GetPosHandler()
       handler:SetSplineMode('NoteColumnSplineMode_Position')
       handler:SetBeatsPerT(1)
       local spline=handler:GetSpline()
       spline:SetSize(2)
       local direction=GAMESTATE:GetSongBeat()<4 and 1 or -1
       spline:SetPoint(1,{64*(col-2.5),-135*direction,0})
       spline:SetPoint(2,{64*(col-2.5),165*direction,0})
       spline:Solve()
      end
     end)
    end,
    Def.Model{Name='DiffuseGlowControl',Meshes='material.txt',Materials='material.txt',Bones='material.txt',
     InitCommand=function(self)
      self:xy(240,240):diffuse({1,0.5,0.25,0.5}):glow({0.2,0.4,0.6,0.25})
       :blend('BlendMode_Add'):zwrite(false):ztestmode('ZTestMode_Off'):cullmode('CullMode_None')
     end},
    Def.Model{Name='FadingMaterialControl',Meshes='material.txt',Materials='material.txt',Bones='material.txt',
     InitCommand=function(self) self:xy(320,240):diffusealpha(0.9):linear(3):diffusealpha(0.3) end},
    Def.Model{Name='TransparentMaterialControl',Meshes='transparent.txt',Materials='transparent.txt',Bones='transparent.txt',
     InitCommand=function(self) self:xy(400,240) end}}
    