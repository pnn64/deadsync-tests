
local pause_started, resumed, changed_rate = nil, false, false
return Def.ActorFrame {
    OnCommand=function(self)
        self:sleep(30)
        self:SetUpdateFunction(function()
            local seconds=GAMESTATE:GetSongPosition():GetMusicSeconds()
            if seconds>=0.5 and not pause_started then
                pause_started=GetTimeSinceStart()
                SCREENMAN:GetTopScreen():PauseGame(true)
            elseif pause_started and not resumed and GetTimeSinceStart()-pause_started>=0.15 then
                SCREENMAN:GetTopScreen():PauseGame(false)
                resumed=true
            end
            if seconds>=1 and not changed_rate then
                GAMESTATE:GetSongOptionsObject('ModsLevel_Song'):MusicRate(1.5)
                GAMESTATE:GetSongOptionsObject('ModsLevel_Current'):MusicRate(1.5)
                changed_rate=true
            end
        end)
    end,
}
