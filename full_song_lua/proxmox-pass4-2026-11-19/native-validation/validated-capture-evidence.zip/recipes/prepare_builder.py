#!/usr/bin/env python3
"""Build a pinned pass-four baseline in fresh guest worktrees; preserve old WIP."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path('/opt/song-lua-audit')
WORK = ROOT / 'pass4'
INPUTS = WORK / 'inputs'
LOGS = WORK / 'logs'
PROOF = WORK / 'proof'
BIN = WORK / 'bin'
DEADSYNC = ROOT / 'deadsync-pass4'
HARNESS = ROOT / 'harness-pass4'
NATIVE = HARNESS / 'vendor/itgmania'
THEME = HARNESS / 'vendor/simply-love'
NATIVE_BUILD = WORK / 'native-build'
PINS = {
    'deadsync': '2da5562bb050d155a90498fd075279a0249ae479',
    'harness': '40d89835c4ea85d632eec0ccb2361ff4569c6ac4',
    'native': '663525dcb86eb570d0ef6a2e209678436660ae26',
    'theme': '1feda1fd43d96baca951351bb28a35d5e690ebc7',
    'fixtures': 'fdf26ec30d7c3edcd624b82aae24eea4fe3765c7',
}
FIXTURE_SUPPORT_SHA256 = '6770ecc48fe7c863cd2e3bfe3986be34dd559ad313ad528fe5b88a778a8192d6'
FIXTURE_SUPPORT_BYTES = 189247009
TOOLCHAIN = '1.100.0'
UNIT = 'deadsync-lua-pass4-build'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f'.{os.getpid()}.{time.time_ns()}.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def command(*args, cwd=None, env=None):
    return subprocess.check_output([str(arg) for arg in args], cwd=cwd, env=env,
                                   text=True, encoding='utf-8').strip()


def step(name, args, *, cwd=ROOT, env=None):
    receipt = {'stage': name, 'started_at': now(), 'command': list(map(str, args)),
               'cwd': str(cwd)}
    save(PROOF / 'build-state.json', receipt)
    print(now(), name, flush=True)
    started = time.monotonic()
    with (LOGS / (name + '.log')).open('w') as log:
        code = subprocess.run(list(map(str, args)), cwd=cwd, env=env,
                              stdout=log, stderr=subprocess.STDOUT).returncode
    receipt.update(exit_code=code, elapsed_seconds=round(time.monotonic() - started, 3),
                   finished_at=now())
    save(PROOF / (name + '.json'), receipt)
    if code:
        raise RuntimeError(f'{name} failed with exit {code}; see {LOGS / (name + ".log")}')
    return receipt


def ensure_commit(repository, revision):
    probe = subprocess.run(['git', '-C', str(repository), 'cat-file', '-e', revision + '^{commit}'],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if probe.returncode:
        command('git', '-C', repository, 'fetch', '--no-recurse-submodules', 'origin', revision)
    assert command('git', '-C', repository, 'rev-parse', revision) == revision


def worktree(repository, destination, revision):
    ensure_commit(repository, revision)
    if destination.exists() and list(destination.iterdir()):
        assert command('git', '-C', destination, 'rev-parse', 'HEAD') == revision, destination
    else:
        command('git', '-C', repository, 'worktree', 'add', '--detach', destination, revision)


def gitlinks(repository):
    raw = subprocess.check_output(['git', '-C', str(repository), 'ls-files', '--stage', '-z'])
    for item in raw.decode().split('\0'):
        if item.startswith('160000 '):
            metadata, relative = item.split('\t', 1)
            yield relative, metadata.split()[1]


def dependencies(repository, previous):
    for relative, revision in gitlinks(repository):
        target = repository / relative
        old = previous / relative
        if target.exists() and list(target.iterdir()):
            assert command('git', '-C', target, 'rev-parse', 'HEAD') == revision, target
        elif (old / '.git').exists():
            ensure_commit(old, revision)
            command('git', 'clone', '--shared', '--no-checkout', old, target)
            command('git', '-C', target, 'checkout', '--detach', revision)
        else:
            command('git', '-C', repository, 'submodule', 'update', '--init', '--depth', '1', '--', relative)
        dependencies(target, old)


def source_snapshot(repository):
    raw = subprocess.check_output(['git', '-C', str(repository), 'ls-files', '--stage', '-z'])
    files, links = {}, {}
    for item in raw.decode().split('\0'):
        if not item:
            continue
        metadata, relative = item.split('\t', 1)
        mode, object_id, _ = metadata.split()
        path = repository / relative
        if mode == '160000':
            links[relative] = object_id
        elif path.is_symlink():
            files[relative] = {'symlink': os.readlink(path)}
        else:
            files[relative] = sha(path)
    return {'path': str(repository), 'revision': command('git', '-C', repository, 'rev-parse', 'HEAD'),
            'tracked_status': command('git', '-C', repository, 'status', '--porcelain',
                                      '--untracked-files=no', '--ignore-submodules'),
            'files_sha256': files, 'gitlinks': links}


def prepare_sources():
    worktree(ROOT / 'deadsync', DEADSYNC, PINS['deadsync'])
    worktree(ROOT / 'harness', HARNESS, PINS['harness'])
    old_native = ROOT / 'harness/vendor/itgmania'
    worktree(old_native, NATIVE, PINS['native'])
    dependencies(NATIVE, old_native)
    worktree(ROOT / 'harness/vendor/simply-love', THEME, PINS['theme'])
    link = NATIVE / 'Themes/Harness Simply Love'
    if not link.exists():
        link.symlink_to(THEME, target_is_directory=True)
    assert link.resolve() == THEME.resolve()
    patch = INPUTS / 'linux-headless.patch'
    assert patch.is_file(), patch
    current = command('git', '-C', HARNESS, 'diff', '--ignore-submodules')
    if not current:
        command('git', '-C', HARNESS, 'apply', '--check', patch)
        command('git', '-C', HARNESS, 'apply', patch)
    else:
        # A retry may reuse only this exact already-applied patch.
        command('git', '-C', HARNESS, 'apply', '--reverse', '--check', patch)
        changed = set(command('git', '-C', HARNESS, 'diff', '--name-only', '--ignore-submodules').splitlines())
        assert changed == {'native/trace_adapter.cpp', 'native/trace_adapter.cmake', 'native/TRACE_ADAPTER.md'}, changed
    snapshot = {'created_at': now(), 'pins': PINS, 'linux_patch_sha256': sha(patch),
                'repositories': {name: source_snapshot(path) for name, path in
                    [('deadsync', DEADSYNC), ('harness', HARNESS), ('native', NATIVE), ('theme', THEME)]}}
    for name in ('deadsync', 'native', 'theme'):
        assert not snapshot['repositories'][name]['tracked_status'], name
    assert snapshot['repositories']['deadsync']['gitlinks']['tests/fixtures'] == PINS['fixtures']
    save(PROOF / 'source-proof.json', snapshot)
    return snapshot


def extract_fixtures():
    support = INPUTS / 'fixture-support.tar.zst'
    deadline = time.monotonic() + 1800
    while not support.is_file() or not (INPUTS / 'fixture-support.ready').is_file():
        if time.monotonic() > deadline:
            raise RuntimeError('fixture-support bundle was not delivered within 30 minutes')
        time.sleep(2)
    destination = DEADSYNC / 'tests/fixtures'
    receipt = PROOF / 'fixture-support.json'
    digest = sha(support)
    expected = json.loads((INPUTS / 'fixture-support-receipt.json').read_text())
    assert expected['revision'] == PINS['fixtures']
    assert expected['sha256'] == digest == FIXTURE_SUPPORT_SHA256
    assert expected['bytes'] == support.stat().st_size == FIXTURE_SUPPORT_BYTES
    assert expected['archive'] == support.name and expected['lfs_pointers'] == []
    if receipt.exists():
        assert json.loads(receipt.read_text())['sha256'] == digest
        return
    assert destination.is_dir() and not list(destination.iterdir()), destination
    decoder = subprocess.Popen(['zstd', '-dc', str(support)], stdout=subprocess.PIPE)
    files = 0
    try:
        with tarfile.open(fileobj=decoder.stdout, mode='r|') as archive:
            for member in archive:
                archive.extract(member, destination, filter='data')
                files += int(member.isfile())
    finally:
        decoder.stdout.close()
    assert decoder.wait() == 0
    assert files == expected['files'], (files, expected['files'])
    save(receipt, {'archive': str(support), 'sha256': digest, 'bytes': support.stat().st_size,
                   'files': files, 'revision': expected['revision'],
                   'input_receipt_sha256': sha(INPUTS / 'fixture-support-receipt.json'),
                   'extracted_to': str(destination), 'finished_at': now()})


def build_runner(env):
    # Cargo's JSON message identifies the exact current runner, even with older
    # hash-named executables present in the reused target cache.
    step('deadsync-build', ['cargo', 'test', '--locked', '--release', '--test', 'full_song_lua',
         '--no-run', '-j', '6', '--message-format=json-render-diagnostics'], cwd=DEADSYNC, env=env)
    executables = []
    for line in (LOGS / 'deadsync-build.log').read_text(errors='replace').splitlines():
        if not line.startswith('{'):
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'full_song_lua' and item.get('executable'):
            executables.append(Path(item['executable']))
    assert len(set(executables)) == 1, executables
    shutil.copy2(executables[0], BIN / 'full_song_lua')


def build():
    started = now()
    env = dict(os.environ, PATH='/home/parity/.cargo/bin:' + os.environ['PATH'],
               HOME='/home/parity', CARGO_PROFILE_RELEASE_LTO='false',
               CARGO_PROFILE_RELEASE_CODEGEN_UNITS='16', CARGO_PROFILE_RELEASE_DEBUG='0',
               CARGO_PROFILE_RELEASE_STRIP='none', LIBGL_ALWAYS_SOFTWARE='1',
               GALLIUM_DRIVER='llvmpipe', LP_NUM_THREADS='1', OMP_NUM_THREADS='1')
    missing = [tool for tool in ['ffmpeg', 'ffprobe', 'Xvfb', 'xvfb-run', 'xauth', 'zstd']
               if not shutil.which(tool)]
    python_dependencies = subprocess.run(['python3', '-c', 'import ijson,zstandard'],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    if missing or not python_dependencies:
        step('apt-update', ['sudo', 'apt-get', 'update'])
        step('capture-dependencies', ['sudo', 'apt-get', 'install', '-y', '--no-install-recommends',
             'ffmpeg', 'xvfb', 'xauth', 'zstd', 'libgl1-mesa-dri', 'mesa-utils',
             'python3-ijson', 'python3-zstandard'])
    for tool in ['ffmpeg', 'ffprobe', 'Xvfb', 'xvfb-run', 'xauth', 'zstd', 'cmake', 'g++']:
        assert shutil.which(tool), tool
    step('python-dependencies', ['python3', '-c', 'import ijson,zstandard'])
    snapshot = prepare_sources()
    if subprocess.run(['rustup', 'run', TOOLCHAIN, 'rustc', '--version'], env=env,
                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode:
        step('rustup', ['rustup', 'toolchain', 'install', TOOLCHAIN, '--profile', 'minimal'], env=env)
    env['RUSTUP_TOOLCHAIN'] = TOOLCHAIN
    rust = command('rustc', '-Vv', env=env)
    (PROOF / 'rustc-version.txt').write_text(rust + '\n')

    harness_env = dict(env, CARGO_TARGET_DIR=str(ROOT / 'harness/target'))
    native_env = dict(env)
    extract_fixtures()
    deadsync_env = dict(env, CARGO_TARGET_DIR=str(ROOT / 'deadsync/target'))
    runner_log = (LOGS / 'deadsync-launch.log').open('w')
    runner = subprocess.Popen(['python3', str(Path(__file__).resolve()), '--build-runner'],
                              env=deadsync_env, stdout=runner_log, stderr=subprocess.STDOUT)
    save(PROOF / 'deadsync-launch.json', {'pid': runner.pid, 'started_at': now(),
                                        'parallel_jobs': 6, 'target_dir': deadsync_env['CARGO_TARGET_DIR']})
    step('native-configure', ['cmake', '-S', NATIVE, '-B', NATIVE_BUILD,
         '-DCMAKE_BUILD_TYPE=Release', '-DWITH_LTO=OFF', '-DWITH_FULL_RELEASE=OFF',
         '-DWITH_CLUB_FANTASTIC=OFF', '-DWITH_FFMPEG_JOBS=6',
         '-DCMAKE_PROJECT_INCLUDE=' + str(HARNESS / 'native/trace_adapter.cmake')], env=native_env)
    step('native-libusb', ['cmake', '--build', NATIVE_BUILD, '--target', 'libusb', '--parallel', '6'], env=native_env)
    step('native-build', ['cmake', '--build', NATIVE_BUILD, '--target', 'ITGmania', '--parallel', '6'], env=native_env)
    native_binary = NATIVE / 'ITGmania-harness-trace'
    assert native_binary.is_file(), native_binary
    harness_env['ITGMANIA_HARNESS_TRACE_BIN'] = str(native_binary)
    harness_env['ITGMANIA_SONG_LUA_NOTESKIN_ROOT'] = str(DEADSYNC / 'assets/noteskins')
    step('harness-build', ['cargo', 'build', '--locked', '--release', '-j', '4'], cwd=HARNESS, env=harness_env)
    shutil.copy2(ROOT / 'harness/target/release/itgmania-harness-rs', BIN / 'itgmania-harness-rs')
    step('harness-unit-tests', ['cargo', 'test', '--locked', '--release', '-j', '4', '--bin',
         'itgmania-harness-rs'], cwd=HARNESS, env=harness_env)
    for name in ['native_notefield_capture_includes_models_and_position_caps',
                 'native_render_random_scopes_preserve_parent_wrapper_and_repeated_draw_inputs']:
        step(name, ['xvfb-run', '-a', '-s', '-screen 0 1280x720x24 -nolisten tcp',
             'cargo', 'test', '--locked', '--release', '-j', '4', '--bin', 'itgmania-harness-rs',
             name, '--', '--ignored', '--nocapture'], cwd=HARNESS, env=harness_env)

    save(PROOF / 'capture-binaries.json', {'passed': True, 'finished_at': now(), 'pins': PINS,
         'source_proof_sha256': sha(PROOF / 'source-proof.json'),
         'linux_patch_sha256': snapshot['linux_patch_sha256'],
         'binaries': {name: {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
                      for name, path in [('harness', BIN / 'itgmania-harness-rs'), ('native', native_binary)]}})
    runner_exit = runner.wait()
    runner_log.close()
    assert runner_exit == 0, f'DeadSync build failed with exit {runner_exit}; see deadsync-launch.log'
    binaries = {'harness': BIN / 'itgmania-harness-rs', 'runner': BIN / 'full_song_lua',
                'native': native_binary}
    final = {'started_at': started, 'finished_at': now(), 'passed': True, 'pins': PINS,
             'rustc': rust, 'linux_patch_sha256': snapshot['linux_patch_sha256'],
             'source_proof_sha256': sha(PROOF / 'source-proof.json'),
             'binaries': {name: {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
                          for name, path in binaries.items()},
             'versions': {'harness': command(BIN / 'itgmania-harness-rs', '--version'),
                          'ffmpeg': command('ffmpeg', '-version').splitlines()[0],
                          'ffprobe': command('ffprobe', '-version').splitlines()[0]},
             'capture_environment': {key: env[key] for key in ['LIBGL_ALWAYS_SOFTWARE', 'GALLIUM_DRIVER', 'LP_NUM_THREADS', 'OMP_NUM_THREADS']},
             'fixture_support': json.loads((PROOF / 'fixture-support.json').read_text())}
    assert not command('git', '-C', NATIVE, 'diff', '--name-only', 'HEAD', '--', 'src')
    save(PROOF / 'build-proof.json', final)
    save(PROOF / 'build-state.json', {'stage': 'complete', 'passed': True, 'finished_at': now()})
    print(json.dumps({'passed': True, 'pins': PINS, 'binaries': final['binaries']}), flush=True)


def main():
    assert ROOT.is_dir(), ROOT
    for directory in [WORK, INPUTS, LOGS, PROOF, BIN]:
        directory.mkdir(parents=True, exist_ok=True)
    if '--build-runner' in sys.argv:
        build_runner(dict(os.environ))
        return
    if '--build' in sys.argv:
        code = 1
        try:
            build()
            code = 0
        except BaseException:
            detail = traceback.format_exc()
            save(PROOF / 'build-error.json', {'at': now(), 'traceback': detail})
            print(detail, file=sys.stderr, flush=True)
            raise
        finally:
            (PROOF / 'build.exit').write_text(str(code) + '\n')
        return
    stable_script = WORK / 'prepare_builder.py'
    if Path(__file__).resolve() != stable_script:
        shutil.copy2(__file__, stable_script)
    existing = subprocess.run(['systemctl', 'is-active', '--quiet', UNIT]).returncode == 0
    assert not existing, 'baseline build is already running; inspect its existing state'
    for name in ['build.exit', 'build-error.json', 'build-proof.json']:
        prior = PROOF / name
        if prior.exists():
            retained = PROOF / ('previous-' + str(time.time_ns()) + '-' + name)
            prior.rename(retained)
    save(PROOF / 'build-state.json', {'stage': 'launching', 'started_at': now()})
    result = subprocess.run(['sudo', 'systemd-run', '--collect', '--unit=' + UNIT,
        '--property=User=parity', '--property=Group=parity', '--property=MemoryMax=28G',
        '--property=MemorySwapMax=0', '--property=OOMPolicy=kill', '--property=RuntimeMaxSec=14400',
        '--property=StandardOutput=append:' + str(LOGS / 'build-launch.log'),
        '--property=StandardError=append:' + str(LOGS / 'build-launch.log'),
        '--setenv=HOME=/home/parity', 'python3', str(stable_script), '--build'], check=True)
    print(json.dumps({'unit': UNIT, 'launched': result.returncode == 0,
                      'state': str(PROOF / 'build-state.json'), 'exit_receipt': str(PROOF / 'build.exit')}))


if __name__ == '__main__':
    main()
