#!/usr/bin/env python3
"""Guest-side incremental capture build; retain the validated Linux baseline."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback

WORK = Path('/opt/song-lua-audit/pass4')
FROZEN_RECIPE_SHA256 = '8e7f51a166aee51e5cc6249f8127511c280aba6ed010f7f23490426b228361d0'
BASE_REVISION = '40d89835c4ea85d632eec0ccb2361ff4569c6ac4'
LINUX_PATCH_SHA256 = 'ed4ac250b920a3e0c10843d3b9b01bb1feb069224a7a4876146674a9f4417011'
UNIT = 'deadsync-lua-pass4-capture-refresh'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


assert sha(WORK / 'prepare_builder.py') == FROZEN_RECIPE_SHA256
sys.path.insert(0, str(WORK))
import prepare_builder as build


def refresh():
    started = build.now()
    request = json.loads((build.INPUTS / 'capture-revision.json').read_text())
    assert request['base_revision'] == BASE_REVISION
    revision = request['revision']
    assert len(revision) == 40 and all(char in '0123456789abcdef' for char in revision)
    bundle = build.INPUTS / 'capture.bundle'
    assert sha(bundle) == request['bundle_sha256']
    candidate_patch = build.INPUTS / 'gameplay-clock.patch'
    assert sha(candidate_patch) == request['candidate_patch_sha256']
    state = build.command('systemctl', 'show', build.UNIT, '-p', 'ActiveState', '--value')
    assert state not in ('active', 'activating', 'deactivating'), state
    retained = WORK / 'baseline-linux'
    if not retained.exists():
        baseline = json.loads((build.PROOF / 'build-proof.json').read_text())
        assert baseline['passed'] is True
        assert (build.PROOF / 'build.exit').read_text().strip() == '0'
        assert baseline['pins']['harness'] == BASE_REVISION
        for binary in baseline['binaries'].values():
            assert sha(binary['path']) == binary['sha256'], binary['path']
        original = build.INPUTS / 'linux-headless.patch'
        assert sha(original) == LINUX_PATCH_SHA256
        snapshot = json.loads((build.PROOF / 'source-proof.json').read_text())
        assert sha(build.PROOF / 'source-proof.json') == baseline['source_proof_sha256']
        assert build.command('git', '-C', build.HARNESS, 'rev-parse', 'HEAD') == BASE_REVISION
        for relative, digest in snapshot['repositories']['harness']['files_sha256'].items():
            if isinstance(digest, str):
                assert sha(build.HARNESS / relative) == digest, relative
        build.command('git', '-C', build.HARNESS, 'apply', '--reverse', '--check', original)
        retained.mkdir()
        shutil.copytree(build.PROOF, retained / 'proof')
        shutil.copytree(build.LOGS, retained / 'logs')
        shutil.copy2(build.NATIVE / 'ITGmania-harness-trace', retained / 'ITGmania-harness-trace')
        shutil.copy2(build.BIN / 'itgmania-harness-rs', retained / 'itgmania-harness-rs')
        shutil.copy2(original, retained / 'linux-headless.patch')
        build.command('git', '-C', build.HARNESS, 'apply', '--reverse', original)
    baseline = json.loads((retained / 'proof/build-proof.json').read_text())
    assert sha(build.BIN / 'full_song_lua') == baseline['binaries']['runner']['sha256']
    assert not build.command('git', '-C', build.HARNESS, 'status', '--porcelain',
                             '--untracked-files=no', '--ignore-submodules')
    build.command('git', '-C', build.HARNESS, 'bundle', 'verify', bundle)
    build.command('git', '-C', build.HARNESS, 'fetch', '--no-tags', bundle,
                  'refs/heads/linux-capture-20261119')
    assert build.command('git', '-C', build.HARNESS, 'rev-parse', 'FETCH_HEAD') == revision
    build.command('git', '-C', build.HARNESS, 'merge-base', '--is-ancestor', BASE_REVISION, revision)
    for name in ['capture-binaries.json', 'build-proof.json', 'build.exit', 'build-error.json']:
        path = build.PROOF / name
        if path.exists():
            path.rename(build.PROOF / ('before-clock-' + name))
    build.command('git', '-C', build.HARNESS, 'checkout', '--detach', revision)
    build.command('git', '-C', build.HARNESS, 'apply', '--check', candidate_patch)
    build.command('git', '-C', build.HARNESS, 'apply', candidate_patch)
    build.command('git', '-C', build.HARNESS, 'diff', '--check')
    pins = dict(baseline['pins'], harness=revision)
    snapshot = {'created_at': build.now(), 'pins': pins,
        'harness_base_revision': BASE_REVISION, 'harness_bundle_sha256': sha(bundle),
        'harness_candidate_patch_sha256': sha(candidate_patch),
        'linux_patch_sha256': LINUX_PATCH_SHA256,
        'repositories': {name: build.source_snapshot(path) for name, path in
            [('deadsync', build.DEADSYNC), ('harness', build.HARNESS),
             ('native', build.NATIVE), ('theme', build.THEME)]}}
    for name, repository in snapshot['repositories'].items():
        assert repository['revision'] == pins[name], name
        if name != 'harness':
            assert not repository['tracked_status'], name
    build.save(build.PROOF / 'source-proof.json', snapshot)
    build.save(build.PROOF / 'capture-refresh-input.json', request)
    env = dict(os.environ, PATH='/home/parity/.cargo/bin:' + os.environ['PATH'],
        HOME='/home/parity', RUSTUP_TOOLCHAIN=build.TOOLCHAIN,
        CARGO_PROFILE_RELEASE_LTO='false', CARGO_PROFILE_RELEASE_CODEGEN_UNITS='16',
        CARGO_PROFILE_RELEASE_DEBUG='0', CARGO_PROFILE_RELEASE_STRIP='none',
        LIBGL_ALWAYS_SOFTWARE='1', GALLIUM_DRIVER='llvmpipe', LP_NUM_THREADS='1',
        OMP_NUM_THREADS='1', CARGO_TARGET_DIR=str(build.ROOT / 'harness/target'),
        ITGMANIA_HARNESS_TRACE_BIN=str(build.NATIVE / 'ITGmania-harness-trace'),
        ITGMANIA_SONG_LUA_NOTESKIN_ROOT=str(build.NATIVE / 'NoteSkins'))
    build.step('clock-native-configure', ['cmake', '-S', build.NATIVE, '-B', build.NATIVE_BUILD,
        '-DCMAKE_BUILD_TYPE=Release', '-DWITH_LTO=OFF', '-DWITH_FULL_RELEASE=OFF',
        '-DWITH_CLUB_FANTASTIC=OFF', '-DWITH_FFMPEG_JOBS=6',
        '-DCMAKE_PROJECT_INCLUDE=' + str(build.HARNESS / 'native/trace_adapter.cmake')], env=env)
    build.step('clock-native-build', ['cmake', '--build', build.NATIVE_BUILD,
        '--target', 'ITGmania', '--parallel', '6'], env=env)
    build.step('clock-harness-build', ['cargo', 'build', '--locked', '--release', '-j', '4'],
        cwd=build.HARNESS, env=env)
    shutil.copy2(build.ROOT / 'harness/target/release/itgmania-harness-rs',
                 build.BIN / 'itgmania-harness-rs')
    build.step('clock-harness-unit-tests', ['cargo', 'test', '--locked', '--release', '-j', '4',
        '--bin', 'itgmania-harness-rs'], cwd=build.HARNESS, env=env)
    for name in ['native_gameplay_clock_inputs_reproduce_stage_observations',
                 'native_notefield_capture_includes_models_and_position_caps',
                 'native_render_random_scopes_preserve_parent_wrapper_and_repeated_draw_inputs']:
        build.step('clock-' + name, ['xvfb-run', '-a', '-s',
            '-screen 0 1280x720x24 -nolisten tcp', 'cargo', 'test', '--locked', '--release',
            '-j', '4', '--bin', 'itgmania-harness-rs', name, '--', '--ignored', '--nocapture'],
            cwd=build.HARNESS, env=env)
    assert not build.command('git', '-C', build.NATIVE, 'diff', '--name-only', 'HEAD', '--', 'src')
    assert sha(build.BIN / 'full_song_lua') == baseline['binaries']['runner']['sha256']
    paths = {'harness': build.BIN / 'itgmania-harness-rs',
             'native': build.NATIVE / 'ITGmania-harness-trace', 'runner': build.BIN / 'full_song_lua'}
    binaries = {name: {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
                for name, path in paths.items()}
    common = {'passed': True, 'finished_at': build.now(), 'pins': pins,
        'harness_base_revision': BASE_REVISION, 'harness_bundle_sha256': sha(bundle),
        'harness_candidate_patch_sha256': sha(candidate_patch),
        'source_proof_sha256': sha(build.PROOF / 'source-proof.json'),
        'linux_patch_sha256': LINUX_PATCH_SHA256,
        'capture_recipe_sha256': sha(__file__), 'native_gameplay_clock_inputs': True}
    build.save(build.PROOF / 'capture-candidate-proof.json', dict(common,
        started_at=started, binaries=binaries))
    shutil.copy2(build.PROOF / 'source-proof.json', build.PROOF / 'capture-candidate-source-proof.json')
    build.save(build.PROOF / 'build-state.json', {'stage': 'candidate-tested', 'passed': True,
        'finished_at': build.now(), 'harness_revision': revision})
    print(json.dumps({'candidate_passed': True, 'pins': pins, 'binaries': binaries}), flush=True)


def publish():
    """Bind tested source bytes to the subsequently created harness commit."""
    request = json.loads((build.INPUTS / 'capture-revision.json').read_text())
    candidate = json.loads((build.PROOF / 'capture-candidate-proof.json').read_text())
    tested = json.loads((build.PROOF / 'capture-candidate-source-proof.json').read_text())
    baseline_path = WORK / 'baseline-linux/proof/build-proof.json'
    baseline = json.loads(baseline_path.read_text())
    assert candidate['passed'] is True
    assert sha(build.PROOF / 'capture-candidate-source-proof.json') == candidate['source_proof_sha256']
    for binary in candidate['binaries'].values():
        assert sha(binary['path']) == binary['sha256'], binary['path']
    for name, repository in tested['repositories'].items():
        assert build.source_snapshot(repository['path']) == repository, name
    bundle = build.INPUTS / 'capture.bundle'
    assert request['base_revision'] == BASE_REVISION
    assert sha(bundle) == request['bundle_sha256']
    patch = build.INPUTS / 'gameplay-clock.patch'
    assert sha(patch) == candidate['harness_candidate_patch_sha256']
    build.command('git', '-C', build.HARNESS, 'bundle', 'verify', bundle)
    build.command('git', '-C', build.HARNESS, 'fetch', '--no-tags', bundle,
                  'refs/heads/linux-capture-20261119')
    revision = request['revision']
    assert build.command('git', '-C', build.HARNESS, 'rev-parse', 'FETCH_HEAD') == revision
    build.command('git', '-C', build.HARNESS, 'merge-base', '--is-ancestor',
                  candidate['pins']['harness'], revision)
    build.command('git', '-C', build.HARNESS, 'apply', '--reverse', '--check', patch)
    build.command('git', '-C', build.HARNESS, 'apply', '--reverse', patch)
    build.command('git', '-C', build.HARNESS, 'checkout', '--detach', revision)
    snapshot = dict(tested)
    snapshot.update(created_at=build.now(), pins=dict(tested['pins'], harness=revision),
                    harness_bundle_sha256=sha(bundle))
    snapshot['repositories'] = {name: build.source_snapshot(repository['path'])
                               for name, repository in tested['repositories'].items()}
    for name, repository in snapshot['repositories'].items():
        assert not repository['tracked_status'], name
        assert repository['files_sha256'] == tested['repositories'][name]['files_sha256'], name
        assert repository['gitlinks'] == tested['repositories'][name]['gitlinks'], name
        assert repository['revision'] == snapshot['pins'][name], name
    build.save(build.PROOF / 'source-proof.json', snapshot)
    common = dict(candidate, finished_at=build.now(), pins=snapshot['pins'],
        harness_bundle_sha256=sha(bundle),
        source_proof_sha256=sha(build.PROOF / 'source-proof.json'),
        tested_source_proof_sha256=candidate['source_proof_sha256'],
        tested_source_bytes_match_committed_tree=True)
    build.save(build.PROOF / 'capture-binaries.json', dict(common,
        binaries={name: candidate['binaries'][name] for name in ('harness', 'native')}))
    final = dict(baseline, **common)
    final.update(previous_build_proof_sha256=sha(baseline_path))
    final['versions']['harness'] = build.command(build.BIN / 'itgmania-harness-rs', '--version')
    build.save(build.PROOF / 'build-proof.json', final)
    build.save(build.PROOF / 'build-state.json', {'stage': 'complete', 'passed': True,
        'finished_at': build.now(), 'harness_revision': revision})
    print(json.dumps({'passed': True, 'pins': snapshot['pins'],
        'binaries': candidate['binaries']}), flush=True)


def main():
    if '--publish' in sys.argv:
        assert subprocess.run(['systemctl', 'is-active', '--quiet', UNIT]).returncode != 0
        publish()
        return
    if '--build' in sys.argv:
        code = 1
        try:
            refresh()
            code = 0
        except BaseException:
            build.save(build.PROOF / 'build-error.json',
                {'at': build.now(), 'traceback': traceback.format_exc()})
            raise
        finally:
            (build.PROOF / 'capture-refresh.exit').write_text(str(code) + '\n')
            (build.PROOF / 'build.exit').write_text(str(code) + '\n')
        return
    assert subprocess.run(['systemctl', 'is-active', '--quiet', UNIT]).returncode != 0
    assert Path(__file__).resolve() == WORK / 'finalize_capture.py'
    subprocess.run(['sudo', 'systemd-run', '--collect', '--unit=' + UNIT,
        '--property=User=parity', '--property=Group=parity', '--property=MemoryMax=28G',
        '--property=MemorySwapMax=0', '--property=OOMPolicy=kill', '--property=RuntimeMaxSec=3600',
        '--property=StandardOutput=append:' + str(build.LOGS / 'clock-launch.log'),
        '--property=StandardError=append:' + str(build.LOGS / 'clock-launch.log'),
        '--setenv=HOME=/home/parity', 'python3', str(Path(__file__).resolve()), '--build'], check=True)
    print(json.dumps({'launched': True, 'unit': UNIT}))


if __name__ == '__main__':
    main()
