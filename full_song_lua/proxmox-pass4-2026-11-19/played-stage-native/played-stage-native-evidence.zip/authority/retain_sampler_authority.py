"""Record the pinned native sampler contract and exact before/after controls."""
import hashlib
import json
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parent
NATIVE = WORK.parents[1].parent / 'itgmania-harness/vendor/itgmania'
COMMIT = '663525dcb86eb570d0ef6a2e209678436660ae26'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=NATIVE)
assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
assert not git('status', '--porcelain')
authority = []
for name, ranges in [('src/Actor.cpp', [(772, 775)]), ('src/Sprite.cpp', [(585, 592), (643, 673)])]:
    raw = (NATIVE / name).read_bytes()
    pinned = git('show', COMMIT + ':' + name)
    assert raw.replace(b'\r\n', b'\n') == pinned.replace(b'\r\n', b'\n')
    lines = raw.decode().splitlines()
    authority.append({'path': name, 'sha256': sha(raw), 'pinned_blob_sha256': sha(pinned),
        'raw_bytes_equal': raw == pinned, 'equal_after_crlf_normalization': True,
        'regions': [{'first_line': first, 'last_line': last, 'text': '\n'.join(lines[first-1:last])} for first, last in ranges]})
controls = []
for name, expected, result in [
    ('corpus-audit-history-controls-20261119T033312Z/sampler.log', 'c7686aaad9cc72dc6e367f9273b8743e001282b52cb3f5941c45bb7e41c96e9e', 'failed ordinary sprite nearest-filter exercise'),
    ('corpus-audit-history-controls-20261119T034114Z/sampler.log', 'e90799d287bb28954ecdc414f3355890961cfb008691284b81f1b74e4b722d6f', 'passed 32 sampler/blend/cache/camera combinations'),
    ('corpus-audit-native-controls-20261119T031048Z/cold-report.json', '5da805938b9a75bae85e457c9e35c14a14c10fe8ef40014459436dee2dc8696c', 'before sampler repair: both paths retain draw sampler mismatches')]:
    raw = (WORK / name).read_bytes()
    assert sha(raw) == expected, name
    controls.append({'path': name, 'sha256': sha(raw), 'bytes': len(raw), 'result': result})
value = {'native_commit': COMMIT, 'authority': authority, 'controls': controls,
    'contract': 'Sprite sets its actor texture filtering and wrapping once before diffuse and glow, with no sampler change between those submissions.',
    'fixes': ['Preserve the explicit sampler on cached textured glow geometry.', 'Route ordinary unmasked sprites with nondefault filtering or wrapping through the existing native mesh sampler path.'],
    'scope_limits': ['This does not repair masked sprites with nondefault samplers.', 'This is draw-state and geometry coverage, not pixel or full application coverage.'],
    'native_cold_replay_after_fix_pending': True}
data = (json.dumps(value, indent=2) + '\n').encode()
path = WORK / 'sampler-native-authority.json'
if path.exists(): assert path.read_bytes() == data
else: path.write_bytes(data)
print(json.dumps({'path': str(path), 'sha256': sha(data), 'bytes': len(data)}))
