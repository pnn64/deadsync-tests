"""Commit only stage-history blocks and the published fixture used by passing gates."""
import hashlib
import json
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parent
REPO = WORK.parents[1]
HEAD = '23c79b2fb64f2467f0b2afe3e7b3aa1eecf90aa5'
PATCH = '693e51d4a7d5ebb8afd0cd11e108ea68e2c6fba3a080908e587b365825a808b6'
FIXTURE = '0a49b80d8dd1cbc59d86ac764e739537fcc1a79b'
FILES = sorted([
    'crates/deadsync-song-lua/src/actors/live_observation.rs',
    'crates/deadsync-song-lua/src/actors/live_scene.rs',
    'crates/deadsync-song-lua/src/actors/top_screen.rs',
    'crates/deadsync-song-lua/src/actors/transitions.rs',
    'crates/deadsync-song-lua/src/live.rs',
    'crates/deadsync-song-lua/src/live_scene.rs',
    'crates/deadsync-song-lua/src/managers/statistics.rs',
    'crates/deadsync-song-lua/src/managers/statistics/history.rs',
    'crates/deadsync-song-lua/src/statistics.rs',
    'crates/deadsync-song-lua/tests/statistics.rs',
    'crates/deadsync-song-lua/tests/transitions.rs',
    'tests/fixtures',
    'tests/song_lua_itgmania_semantic_parity/native_gameplay.rs',
])
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=REPO)
def blocks(raw):
    result = {}
    for piece in raw.split(b'diff --git ')[1:]:
        block = b'diff --git ' + piece
        path = block.split(b'\n', 1)[0].split(b' b/', 1)[1].decode()
        assert path not in result
        result[path] = block
    return result

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('diff', '--cached', '--name-only').strip(), 'preserve unrelated staged work'
assert git('-C', 'tests/fixtures', 'rev-parse', 'HEAD').decode().strip() == FIXTURE
assert not git('-C', 'tests/fixtures', 'status', '--porcelain').strip()
checks = []
for directory, name, count, log_sha in [
    ('corpus-audit-history-controls-20261119T041051Z', 'transitions', 25, '7941b0ff21b746c7194799b8b0a7712232ef8592a8c934ffc89fb9bebd1b73ea'),
    ('corpus-audit-history-controls-20261119T041927Z', 'statistics', 12, 'eb4ee01e1107767ea837dc8b5b67d47b3a070c2b2816d96173554bd327b608de'),
]:
    gate_dir = WORK / directory
    receipt = json.loads((gate_dir / 'receipt.json').read_bytes())
    gate = next(row for row in receipt['commands'] if row['name'] == name)
    assert gate['exit_code'] == 0 and gate['source_unchanged']
    assert gate['source_before'] == gate['source_after']
    assert gate['source_before']['source'] == {'head': HEAD, 'patch_sha256': PATCH}
    assert gate['source_before']['fixtures'] == {'head': FIXTURE, 'patch_sha256': sha(b'')}
    assert f'{count} passed; 0 failed' in '\n'.join(gate['result_lines'])
    assert sha(Path(gate['log']).read_bytes()) == gate['log_sha256'] == log_sha
    whole = (gate_dir / (name + '-before-source.patch')).read_bytes()
    assert sha(whole) == PATCH
    tested = blocks(whole)
    selected = b''.join(tested[path] for path in FILES)
    assert git('diff', '--binary', '--full-index', 'HEAD', '--', *FILES) == selected
    checks.append({'gate': name, 'passed': count, 'log_sha256': log_sha})
reports = []
for name, digest, frames, fields in [
    ('cold', '8956e17e385e691850dfdec6091e9cf0c1c4e91b1a1e7c5be30885b270576925', 1586, 21546),
    ('vtubers', '1fd18c9577abf07cec724d51a06d78445c69a297897eb35983407cdce0944015', 1774, 21448),
    ('modulo', 'd44b4369efff35c69a6ff880c3fe01e590cc061919aaf0b0767a5d4c5c6f5703', 1557, 18082),
]:
    data = (WORK / 'corpus-audit-native-controls-20261119T041242Z' / (name + '-report.json')).read_bytes()
    assert sha(data) == digest
    report = json.loads(data)
    assert report['archive_accepted'] and report['diagnostic_replay_checks_passed'] and report['production_gameplay_checks_passed']
    assert report['native_frames'] == report['replayed_frames'] == frames
    assert report['compared_stage_fields'] == fields and not report['mismatches'] and not report['errors']
    assert not report['whole_song_parity_proven']
    reports.append({'case': name, 'sha256': digest, 'frames': frames, 'combined_stage_fields': fields})
record = {'base_head': HEAD, 'tested_full_patch_sha256': PATCH, 'fixture_revision': FIXTURE,
          'selected_patch_sha256': sha(selected), 'files': FILES, 'unit_gates': checks,
          'native_reports': reports, 'whole_song_parity_proven': False}
path = WORK / 'stage-history-commit-staging.json'
assert not path.exists()
git('add', '--', *FILES)
assert git('diff', '--cached', '--binary', '--full-index') == selected
git('diff', '--cached', '--check')
print(git('diff', '--cached', '--stat').decode(), end='')
print(git('commit', '-m', 'fix(song-lua): commit independent stage history at screen completion',
          '-m', 'Copy retained stage and player statistics at the owned Out or Failed completion, before the final child update and timer feed. Resolve the current private statistics owner after initial screen setup, retain hidden reload transition children, and compare saved exit counters directly. Preserve missing-history failures and explicit remaining coverage.').decode(), end='')
record['commit'] = git('rev-parse', 'HEAD').decode().strip()
path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
