"""Retain source authority and scope without rewriting any native fixture."""
from pathlib import Path
import hashlib
import json
import subprocess

TASK = Path(__file__).resolve().parent
PRODUCT = TASK.parents[1]
HARNESS = PRODUCT.parent / "itgmania-harness"
NATIVE = HARNESS / "vendor/itgmania"
OUT = TASK / "played-stage-history-evidence"
OUT.mkdir(exist_ok=True)
RANGES = {
    "src/StatsManager.cpp": [(529, 567)],
    "src/ScreenGameplay.cpp": [(2884, 2895), (3184, 3195)],
    "src/Transition.cpp": [(15, 42)],
    "src/LuaManager.h": [(264, 273)],
}
result = {
    "native_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=NATIVE, text=True).strip(),
    "harness_capture_commit": "9eb6619c0eaf9c3aceabf7348efbb06a7fd37273",
    "harness_capture_source_proof_sha256": "a01d65ab3cbf5a78f24903ca47805a9af28928c4a574ac880fd04bbf0da84ed8",
    "files": [],
    "scope": [
        "Copy actual current stage at synchronous Out/Failed SM_DoNextScreen completion before the final gameplay timer update.",
        "Newest completed stage is index 1; invalid ranges return zero Lua results; actual committed count starts at zero.",
        "Retain independent player/scalar/tap/life/score/step-array state through later current feeds, host resets, script setters and repeated commits.",
        "Observe current stage at screen-end and played stage at gameplay-exit; do not derive replay inputs from expected counters.",
    ],
    "pending": [
        "Public STATSMAN:Reset remains its existing no-op; accumulated/final-evaluation statistics and full awards/score finalization remain separate gaps.",
        "A detached current GetLifeRecord function explicitly invoked with a played receiver still uses the callable's captured current history State: local f=current_player.GetLifeRecord; f(played_player, last_second, samples). Standard played_player:GetLifeRecord uses its independent copied State.",
    ],
}
for name, ranges in RANGES.items():
    data = (NATIVE / name).read_bytes()
    lines = data.decode("utf-8").splitlines()
    result["files"].append({
        "path": str(NATIVE / name), "sha256": hashlib.sha256(data).hexdigest(),
        "regions": [{"first_line": first, "last_line": last, "text": "\n".join(lines[first-1:last])} for first, last in ranges],
    })
trace = TASK / "random-boundary-evidence/de0ce4430a303dfb-c0001/native.json"
if trace.exists():
    result["modulo_native_sha256"] = hashlib.sha256(trace.read_bytes()).hexdigest()
result["modulo_retained_observations"] = {
    "final_update_sequence": 1557,
    "screen_end_current": {"gameplay_seconds": 94.49759674072266, "steps_seconds": 87.23177337646484},
    "gameplay_exit_played": {"gameplay_seconds": 94.45843505859375, "steps_seconds": 87.19261169433594},
    "last_independent_timer_delta_seconds": 0.039163000881671906,
    "note": "These are retained diagnostic observations only, never replay inputs or corrections.",
}
destination = OUT / "authority.json"
destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"path": str(destination), "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(), "native_commit": result["native_commit"]}))
