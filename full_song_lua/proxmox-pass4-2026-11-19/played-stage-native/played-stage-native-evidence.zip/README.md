# Played-stage, reload, sampler and font evidence

This archive retains original failed and passing observations with their own exact source identities. It contains no regenerated native expectation or repaired capture. The external manifest gives SHA256 and size for every ZIP member and each large native input archive; input archives are retained separately and are not duplicated here.

## Final tested state

The final native controls used product HEAD `23c79b2fb64f2467f0b2afe3e7b3aa1eecf90aa5`, full-index working patch `693e51d4a7d5ebb8afd0cd11e108ea68e2c6fba3a080908e587b365825a808b6`, and clean fixture revision `0a49b80d8dd1cbc59d86ac764e739537fcc1a79b`. Each before/after source identity is retained in its original receipt. Root subsequently committed the reviewed history/reload subset as `4224b3b2eb5dbc0efd15618bf86266bb651af56c`; the selected-patch proof and commit helper are included. Committed patches from published baseline `2da5562bb050d155a90498fd075279a0249ae479` are supplied for every tested HEAD, separately from its retained working patch.

| Control | Final result |
| --- | --- |
| Complete transitions target | 25 passed, including natural Out and Failed and pre-child-update commitment |
| Complete statistics target | 12 passed, including independent history, current mutations, host reset, repeated commits and GC |
| Cold combined native replay | 1,586 frames, 157 samples, 21,546 combined stage fields, zero mismatches/errors |
| Vtubers combined native replay | 1,774 frames, 142 samples, 21,448 combined stage fields, zero mismatches/errors |
| MODULO combined native replay | 1,557 frames, 116 samples, 18,082 combined stage fields, zero mismatches/errors |
| Genshin chart 3 combined native replay | 1,757 frames, 119 samples, 19,552 combined stage fields, zero mismatches/errors |
| Earlier full playback sampler gate, 035841 | 233 passed, 3 existing ignored tests; its separate source identity is retained |

All four final native reports have archive_accepted=true, production and diagnostic execution, and whole_song_parity_proven=false. Their complete pending-coverage lists remain unchanged. Counts above are combined between the two paths, not additional independent native samples.

## Retained negative evidence and cause

Natural first-screen completion originally finished the real Out actor (state 2, child tween time 0, role Out) but left published GetStagesPlayed at zero. Screen construction installs its completion callback before the initial late statistics installation. Capturing the earlier commit function retained an unpublished history owner. The fix resolves statistics_commit from the retained private catalog at the actual synchronous transition completion point. It adds no observer-triggered commit and never substitutes current counters for played statistics.

The original Cold and Vtubers full replay failures are retained. MODULO independently distinguishes current counters from the already committed copy on its final update; no expected delta was subtracted or imported. Reload tests preserve native hidden child tweens and the native animation states of loaded transition sprites.

Earlier sampler negative controls, the 32-case sampler matrix, full playback gate and native authority are retained. The immutable sampler authority predates the final Cold pass and still says its native replay was pending; the final Cold report in this archive supersedes that historical status. Its masked-sampler and pixel-coverage limits still apply.

The full BitmapText target at the final tested state passed 9/11, including the new File fallback regression. Two existing snapshot differences remain explicitly failed here: cached physical path spelling and the earlier normalized generic zoom representation. Subsequent cache spelling repair and source-derived snapshot work are outside this tested identity and are not claimed as validated by this archive. Genshin's affected native archive passed at the stated identity.

## Scope and provenance

Native source pin: `663525dcb86eb570d0ef6a2e209678436660ae26`. Capture harness pin: `9eb6619c0eaf9c3aceabf7348efbb06a7fd37273`. Source proof SHA256: `a01d65ab3cbf5a78f24903ca47805a9af28928c4a574ac880fd04bbf0da84ed8`. Native source bytes and source-derived authority are retained. The earlier reload authority's phrase "returns nil" describes assignment behavior; pinned StatsManager and the later played-stage authority establish that an invalid index returns zero Lua results.

Public STATSMAN:Reset, aggregate/final-evaluation history, complete score/award finalization, saved getter functions invoked with another stage's receiver, missing captured operations/subscriber identities, glyph geometry, sampled pixels and a full application build remain outside the demonstrated coverage. Standard played-player getters retain copied state independently of later current feeds and setters.

The native replay recipes are retained under their original receipt hashes; the older recipe was reconstructed only by reversing the later Genshin case additions and is byte-identical to its original SHA256. The unit coordinator is a post-run convenience; each unit receipt's exact command and source patches are authoritative. All original logs, receipts and reports remain byte-for-byte unchanged.
