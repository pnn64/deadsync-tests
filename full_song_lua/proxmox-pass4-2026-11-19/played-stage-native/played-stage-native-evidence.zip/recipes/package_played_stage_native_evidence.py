"""Package immutable retained controls; never change source, fixtures, or captures."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
BASE = "2da5562bb050d155a90498fd075279a0249ae479"
STAMP = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
OUT = TASK / ("played-stage-native-evidence-" + STAMP)
OUT.mkdir()
GENERATED = OUT / "generated"
GENERATED.mkdir()
members = {}


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def add(path, archive_path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    assert archive_path not in members and not archive_path.startswith("/")
    assert ".." not in Path(archive_path).parts
    members[archive_path] = {
        "archive_path": archive_path, "source_path": str(path.resolve()),
        "bytes": path.stat().st_size, "sha256": digest(path),
    }


def generated(name, data, archive_path):
    path = GENERATED / name
    path.write_bytes(data)
    add(path, archive_path)
    return path


def add_tree(relative, archive_root):
    directory = TASK / relative
    assert directory.is_dir(), str(directory)
    for path in sorted(directory.rglob("*")):
        if path.is_file():
            add(path, archive_root + "/" + path.relative_to(directory).as_posix())


unit_runs = [
    ("corpus-audit-history-controls-20261119T033312Z", "sampler-first-failure"),
    ("corpus-audit-history-controls-20261119T034114Z", "sampler-matrix-and-prior-failures"),
    ("corpus-audit-history-controls-20261119T035841Z", "sampler-full-playback-pass"),
    ("corpus-audit-history-controls-20261119T040234Z", "natural-owner-first-failure"),
    ("corpus-audit-history-controls-20261119T040648Z", "natural-owner-tween-proof"),
    ("corpus-audit-history-controls-20261119T041051Z", "final-transitions-and-font-controls"),
    ("corpus-audit-history-controls-20261119T041927Z", "final-statistics-and-genshin"),
]
native_runs = [
    ("corpus-audit-native-controls-20261119T031048Z", "before-sampler-and-played-stage-fix"),
    ("corpus-audit-native-controls-20261119T034556Z", "first-screen-cold-failure"),
    ("corpus-audit-native-controls-20261119T035614Z", "first-screen-vtubers-failure"),
    ("corpus-audit-native-controls-20261119T041242Z", "final-cold-vtubers-modulo"),
    ("corpus-audit-native-controls-20261119T041942Z", "final-genshin"),
]
identities = set()
summaries = []
external_inputs = {}
recipe_digests = set()
for relative, label in unit_runs:
    add_tree(relative, "gates/" + label)
    receipt = load(TASK / relative / "receipt.json")
    for command in receipt["commands"]:
        assert command["source_unchanged"]
        before = command["source_before"]
        assert before == command["source_after"]
        for when in ("before", "after"):
            for owner in ("source", "fixtures"):
                patch = TASK / relative / (command["name"] + "-" + when + "-" + owner + ".patch")
                assert digest(patch) == before[owner]["patch_sha256"]
        log = TASK / relative / (command["name"] + ".log")
        assert digest(log) == command["log_sha256"]
        identities.add(before["source"]["head"])
        summaries.append({
            "kind": "unit", "run": label, "gate": command["name"],
            "exit_code": command["exit_code"], "result_lines": command["result_lines"],
            "source_identity": before,
            "receipt_member": "gates/" + label + "/receipt.json",
        })
for relative, label in native_runs:
    add_tree(relative, "native/" + label)
    receipt = load(TASK / relative / "receipt.json")
    recipe_digests.add(receipt["recipe"]["sha256"])
    for case in receipt["cases"]:
        assert case["source_unchanged"] and case["source_before"] == case["source_after"]
        patch = TASK / relative / (case["case"] + "-source.patch")
        assert digest(patch) == case["source_before"]["patch_sha256"]
        if "report_sha256" in case:
            assert digest(TASK / relative / (case["case"] + "-report.json")) == case["report_sha256"]
        identities.add(case["source_before"]["head"])
        summaries.append({
            "kind": "native", "run": label, "case": case["case"],
            "exit_code": case["exit_code"], "source_identity": case["source_before"],
            "summary": case.get("summary"), "production_summary": case.get("production_summary"),
            "report_sha256": case.get("report_sha256"),
            "receipt_member": "native/" + label + "/receipt.json",
        })
        for reference in case["reference_inputs"]:
            path = Path(reference["path"])
            if str(path) in external_inputs:
                assert external_inputs[str(path)] == reference
                continue
            assert path.stat().st_size == reference["bytes"] and digest(path) == reference["sha256"]
            external_inputs[str(path)] = reference

# Retain both exact native replay recipes, including the older file before the
# later Genshin case was added. Its original receipt hash must match exactly.
recipe = (TASK / "corpus_audit_native_controls.py").read_bytes()
newline = b"\r\n" if b"\r\n" in recipe else b"\n"
case_block = '\n'.join([
    '    ("genshin", "full_song_lua", [',
    '        "--archive", str(TASK / "genshin-evidence/cdf8da51e4175dfecba1f8c075f34b83bebe6de9cae04a593949aa0e4299f0c1.tar.zst"),',
    '        "--report",',
    '    ]),',
    '',
]).encode().replace(b"\n", newline)
old_mapping = b'                   "cold": "5aed0bb71a0e2899c23cbad591d6700c52570ad6bf47a7e6bc5c7a49385589a3"}'
new_mapping = old_mapping[:-1] + b"," + newline + b'                   "genshin": "cdf8da51e4175dfecba1f8c075f34b83bebe6de9cae04a593949aa0e4299f0c1"}'
assert recipe.count(case_block) == 1 and recipe.count(new_mapping) == 1
older_recipe = recipe.replace(case_block, b"").replace(new_mapping, old_mapping)
recipes = {hashlib.sha256(data).hexdigest(): data for data in (recipe, older_recipe)}
assert recipe_digests <= recipes.keys(), recipe_digests - recipes.keys()
for key in sorted(recipe_digests):
    generated("native-recipe-" + key + ".py", recipes[key], "recipes/native-" + key + ".py")
add(TASK / "run_corpus_audit_history_checks.py", "recipes/post-run-unit-coordinator.py")
add(Path(__file__), "recipes/package_played_stage_native_evidence.py")

for relative, name in [
    ("played-stage-history-evidence/authority.json", "played-stage-authority.json"),
    ("modulo-transition-evidence/authority.json", "reload-and-native-counter-authority.json"),
    ("sampler-native-authority.json", "sampler-native-authority.json"),
    ("record_played_stage_authority.py", "record_played_stage_authority.py"),
    ("retain_sampler_authority.py", "retain_sampler_authority.py"),
    ("stage-history-commit-staging.json", "stage-history-commit-staging.json"),
    ("commit_stage_history_fix.py", "commit_stage_history_fix.py"),
]:
    add(TASK / relative, "authority/" + name)
assert digest(TASK / "played-stage-history-evidence/authority.json") == "9fced5d21663ab849c5b57493ec5453d6f9500efea57e3d640baaed8f23b93b8"
assert digest(TASK / "sampler-native-authority.json") == "643ca572eb293ee027715284a203892f92b889695592451ed2741e6d7b1eb75e"
stage_authority = load(TASK / "played-stage-history-evidence/authority.json")
native_root = Path("C:/GitHub/itgmania-harness/vendor/itgmania")
source_paths = {}
for row in stage_authority["files"]:
    path = Path(row["path"])
    assert digest(path) == row["sha256"]
    source_paths[str(path.resolve())] = (path, "authority/native/" + path.relative_to(native_root).as_posix())
for row in load(TASK / "sampler-native-authority.json")["authority"]:
    path = native_root / row["path"]
    assert digest(path) == row["sha256"]
    source_paths[str(path.resolve())] = (path, "authority/native/" + row["path"])
for path, member in source_paths.values():
    add(path, member)
theme = Path("C:/GitHub/itgmania-harness/vendor/simply-love/BGAnimations/ScreenGameplay in/default.lua")
assert digest(theme) == "7ef0a8b27f088636af616a3c59cd6e66989a4c924147acad19caf2e371c6feca"
add(theme, "authority/theme/ScreenGameplay-in-default.lua")

commit_receipt = load(TASK / "stage-history-commit-staging.json")
assert commit_receipt["commit"] == "4224b3b2eb5dbc0efd15618bf86266bb651af56c"
assert commit_receipt["tested_full_patch_sha256"] == "693e51d4a7d5ebb8afd0cd11e108ea68e2c6fba3a080908e587b365825a808b6"
for head in sorted(identities | {commit_receipt["commit"]}):
    patch = subprocess.check_output(["git", "diff", "--binary", "--full-index", BASE, head], cwd=ROOT)
    generated(head + ".patch", patch, "provenance/committed-" + BASE[:10] + "-to-" + head + ".patch")
    metadata = subprocess.check_output(["git", "show", "--no-patch", "--format=fuller", head], cwd=ROOT)
    generated(head + ".txt", metadata, "provenance/commit-" + head + ".txt")
path = "crates/deadsync-song-lua/src/gameplay_screen.rs"
source = subprocess.check_output(["git", "show", commit_receipt["base_head"] + ":" + path], cwd=ROOT)
generated("gameplay_screen.rs", source, "authority/product/gameplay_screen.rs")

readme = """# Played-stage, reload, sampler and font evidence

This archive retains original failed and passing observations with their own exact source identities. It contains no regenerated native expectation or repaired capture. The external manifest gives SHA256 and size for every ZIP member and each large native input archive; input archives are retained separately and are not duplicated here.

## Final tested state

The final native controls used product HEAD `23c79b2fb64f2467f0b2afe3e7b3aa1eecf90aa5`, full-index working patch `693e51d4a7d5ebb8afd0cd11e108ea68e2c6fba3a080908e587b365825a808b6`, and clean fixture revision `0a49b80d8dd1cbc59d86ac764e739537fcc1a79b`. Each before/after source identity is retained in its original receipt. Root subsequently committed the reviewed history/reload subset as `4224b3b2eb5dbc0efd15618bf86266bb651af56c`; the selected-patch proof and commit helper are included. Committed patches from published baseline `2da5562bb050d155a90498fd075279a0249ae479` are supplied for every tested HEAD, separately from its retained working patch.

| Control | Final result |
| --- | --- |
| Complete transitions target | 25 passed, including natural Out and Failed and pre-child-update commitment |
| Complete statistics target | 12 passed, including independent history, current mutations, host reset, repeated commits and GC |
| Cold combined native replay | 1,586 frames, 157 samples, 21,546 combined stage fields, zero mismatches/errors |
| Vtubers combined native replay | 1,774 frames, 142 samples, 21,448 combined stage fields, zero mismatches/errors |
| MODULO combined native replay | 1,557 frames, 116 samples, 18,082 combined stage fields, zero mismatches/errors |
| Genshin chart 3 combined native replay | 1,757 frames, 119 samples, 19,552 combined stage fields, zero mismatches/errors |
| Earlier full playback sampler gate, 035841 | 233 passed, 3 existing ignored tests; its separate source identity is retained |

All four final native reports have archive_accepted=true, production and diagnostic execution, and whole_song_parity_proven=false. Their complete pending-coverage lists remain unchanged. Counts above are combined between the two paths, not additional independent native samples.

## Retained negative evidence and cause

Natural first-screen completion originally finished the real Out actor (state 2, child tween time 0, role Out) but left published GetStagesPlayed at zero. Screen construction installs its completion callback before the initial late statistics installation. Capturing the earlier commit function retained an unpublished history owner. The fix resolves statistics_commit from the retained private catalog at the actual synchronous transition completion point. It adds no observer-triggered commit and never substitutes current counters for played statistics.

The original Cold and Vtubers full replay failures are retained. MODULO independently distinguishes current counters from the already committed copy on its final update; no expected delta was subtracted or imported. Reload tests preserve native hidden child tweens and the native animation states of loaded transition sprites.

Earlier sampler negative controls, the 32-case sampler matrix, full playback gate and native authority are retained. The immutable sampler authority predates the final Cold pass and still says its native replay was pending; the final Cold report in this archive supersedes that historical status. Its masked-sampler and pixel-coverage limits still apply.

The full BitmapText target at the final tested state passed 9/11, including the new File fallback regression. Two existing snapshot differences remain explicitly failed here: cached physical path spelling and the earlier normalized generic zoom representation. Subsequent cache spelling repair and source-derived snapshot work are outside this tested identity and are not claimed as validated by this archive. Genshin's affected native archive passed at the stated identity.

## Scope and provenance

Native source pin: `663525dcb86eb570d0ef6a2e209678436660ae26`. Capture harness pin: `9eb6619c0eaf9c3aceabf7348efbb06a7fd37273`. Source proof SHA256: `a01d65ab3cbf5a78f24903ca47805a9af28928c4a574ac880fd04bbf0da84ed8`. Native source bytes and source-derived authority are retained. The earlier reload authority's phrase "returns nil" describes assignment behavior; pinned StatsManager and the later played-stage authority establish that an invalid index returns zero Lua results.

Public STATSMAN:Reset, aggregate/final-evaluation history, complete score/award finalization, saved getter functions invoked with another stage's receiver, missing captured operations/subscriber identities, glyph geometry, sampled pixels and a full application build remain outside the demonstrated coverage. Standard played-player getters retain copied state independently of later current feeds and setters.

The native replay recipes are retained under their original receipt hashes; the older recipe was reconstructed only by reversing the later Genshin case additions and is byte-identical to its original SHA256. The unit coordinator is a post-run convenience; each unit receipt's exact command and source patches are authoritative. All original logs, receipts and reports remain byte-for-byte unchanged.
"""
generated("README.md", readme.encode(), "README.md")
summary = {
    "format_version": 1, "created_at": STAMP, "baseline": BASE,
    "source_identities": sorted(identities), "history_commit": commit_receipt,
    "runs": summaries, "external_inputs": list(external_inputs.values()),
    "coverage": "Retained semantic/draw-state controls only; all original pending coverage preserved.",
    "native_expectations_changed": False, "large_native_archives_duplicated": False,
}
generated("summary.json", (json.dumps(summary, indent=2) + "\n").encode(), "summary.json")
assert sum(row["bytes"] for row in members.values()) < 2 * 1024**3
archive = OUT / "evidence.zip"
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as bundle:
    for name, row in sorted(members.items()):
        bundle.write(row["source_path"], name)
with zipfile.ZipFile(archive) as bundle:
    assert set(bundle.namelist()) == set(members)
    for row in members.values():
        with bundle.open(row["archive_path"]) as stream:
            assert hashlib.file_digest(stream, "sha256").hexdigest() == row["sha256"], row["archive_path"]
archive_sha = digest(archive)
final = OUT / (archive_sha + ".zip")
archive.rename(final)
manifest = {
    "format_version": 1, "created_at": STAMP,
    "archive": {"path": str(final), "filename": final.name, "bytes": final.stat().st_size, "sha256": archive_sha},
    "member_count": len(members), "uncompressed_bytes": sum(row["bytes"] for row in members.values()),
    "members": [members[name] for name in sorted(members)],
    "external_inputs": list(external_inputs.values()),
    "verified_every_zip_member": True, "verified_every_external_input": True,
    "history_commit": commit_receipt["commit"], "tested_source_identities": sorted(identities),
    "native_expectations_changed": False,
}
manifest_path = OUT / (archive_sha + ".manifest.json")
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"archive": manifest["archive"], "manifest": str(manifest_path),
                  "manifest_sha256": digest(manifest_path), "members": len(members),
                  "uncompressed_bytes": manifest["uncompressed_bytes"],
                  "external_inputs": len(external_inputs), "all_hashes_verified": True}))
