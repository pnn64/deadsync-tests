"""Retain exact local candidate identities and native replay output; no capture edits."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--case", action="append", dest="selected_cases")
parser.add_argument("--life-control-dir", type=Path)
parser.add_argument("--life-control-sha256")
args = parser.parse_args()
STAMP = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
OUT = TASK / ("corpus-audit-native-controls-" + STAMP)
OUT.mkdir()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def input_identity(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def identity():
    patch = subprocess.check_output(["git", "diff", "--binary", "--full-index", "HEAD"], cwd=ROOT)
    return {
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "patch_sha256": sha(patch),
        "status": subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=ROOT, text=True).splitlines(),
    }, patch


cases = [
    ("clock", "live_song_lua", [
        str(TASK / "clock-control-verified/gameplay-clock-control-native.json"),
        str(TASK / "clock-control-verified/fixture/control.sm"),
    ]),
    ("life", "live_song_lua", [
        str(TASK / "life-event-score-evidence/validated/native.json"),
        str(TASK / "life-event-score-evidence/validated/fixture/control.ssc"),
    ]),
    ("life-diagnostic", "live_song_lua", [
        str(TASK / "life-event-score-evidence/validated/native.json"),
        str(TASK / "life-event-score-evidence/validated/fixture/control.ssc"),
    ]),
    ("vtubers", "full_song_lua", [
        "--archive", str(TASK / "corpus-audit-vtubers-artifact/531707cc01f3c02926333aff5e969e9c8ac856c03a1831040911c551414bf41e.tar.zst"),
        "--report",
    ]),
    ("chewingood", "full_song_lua", [
        "--archive", str(TASK / "chewingood-capture-artifacts/52b214a6e800e0a8c0189f2464999c873436163927be1ff084aba5b814e8c383.tar.zst"),
        "--report",
    ]),
    ("666", "full_song_lua", [
        "--archive", str(TASK / "666-parity-artifacts/be1243894931904648a39fa076ef8ca4f7057a9adf08075bce88b9d36ad8135c.tar.zst"),
        "--report",
    ]),
    ("say-something", "full_song_lua", [
        "--archive", str(TASK / "say-something-parity-artifacts/fa2be83a839d90e55a503ab2c57981e0f16f508c97c650a6d002e7e4260a3df0.tar.zst"),
        "--report",
    ]),
    ("modulo", "full_song_lua", [
        "--archive", str(TASK / "random-boundary-evidence/de0ce4430a303dfb-c0001/6e2f321c3b82b7e3ee3be443a3cf511ac87d99699ef040a871715ad05397fdf8.tar.zst"),
        "--report",
    ]),
    ("vanity", "full_song_lua", [
        "--archive", str(TASK / "random-boundary-evidence/05dffb361eb038d7-c0001/a7ca47099a85a03638e417f43f4be0f1d686ffea2c350b1cd26448a8d2b69c76.tar.zst"),
        "--report",
    ]),
    ("cold", "full_song_lua", [
        "--archive", str(TASK / "cold-parity-artifacts/5aed0bb71a0e2899c23cbad591d6700c52570ad6bf47a7e6bc5c7a49385589a3.tar.zst"),
        "--report",
    ]),
]
receipt = {"created_at": STAMP, "recipe": input_identity(Path(__file__)),
           "purpose": "Retained independent native inputs replayed against the local candidate", "cases": []}
expected_native = {"clock": "30dd265b8cb63026d2f9efb8bb3a00b994c9795b01c410bba6b248ccca3ae734",
                   "life": "e5c52b727279d45ccdaebea518f72eadcb40a92c4689b49fecf75f4cca5cefbf",
                   "vtubers": "531707cc01f3c02926333aff5e969e9c8ac856c03a1831040911c551414bf41e",
                   "chewingood": "52b214a6e800e0a8c0189f2464999c873436163927be1ff084aba5b814e8c383",
                   "666": "be1243894931904648a39fa076ef8ca4f7057a9adf08075bce88b9d36ad8135c",
                   "say-something": "fa2be83a839d90e55a503ab2c57981e0f16f508c97c650a6d002e7e4260a3df0",
                   "modulo": "6e2f321c3b82b7e3ee3be443a3cf511ac87d99699ef040a871715ad05397fdf8",
                   "vanity": "a7ca47099a85a03638e417f43f4be0f1d686ffea2c350b1cd26448a8d2b69c76",
                   "cold": "5aed0bb71a0e2899c23cbad591d6700c52570ad6bf47a7e6bc5c7a49385589a3"}
if args.life_control_dir is not None:
    assert args.life_control_sha256 and len(args.life_control_sha256) == 64, "New native control requires its independent SHA256 receipt"
    for name in ("life-glx", "life-glx-diagnostic"):
        cases.append((name, "live_song_lua", [str(args.life_control_dir / "native.json"),
                                             str(args.life_control_dir / "fixture/control.ssc")]))
    expected_native["life-glx"] = args.life_control_sha256
if args.selected_cases:
    requested = set(args.selected_cases)
    assert requested <= {name for name, _, _ in cases}, "Unknown native control case"
    by_name = {case[0]: case for case in cases}
    cases = [by_name[name] for name in dict.fromkeys(args.selected_cases)]
for name, target, arguments in cases:
    reference = Path(arguments[1] if target == "full_song_lua" else arguments[0])
    reference_inputs = [input_identity(reference)]
    diagnostic = name.endswith("-diagnostic")
    assert reference_inputs[0]["sha256"] == expected_native[name.removesuffix("-diagnostic")], "Retained native input bytes changed"
    if target == "live_song_lua":
        reference_inputs.extend(input_identity(path) for path in sorted(Path(arguments[1]).parent.iterdir()) if path.is_file())
    report = OUT / (name + "-report.json")
    command = ["cargo", "test", "--test", target, "--locked", "-j", "4", "--", *arguments, str(report)]
    if not diagnostic:
        command.append("--production")
    before, patch = identity()
    (OUT / (name + "-source.patch")).write_bytes(patch)
    print(json.dumps({"case": name, "starting": True, "patch_sha256": before["patch_sha256"]}), flush=True)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT / (name + ".log")).open("wb") as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    after, _ = identity()
    item = {"case": name, "command": command, "started_at": started, "exit_code": result.returncode,
            "reference_inputs": reference_inputs,
            "source_before": before, "source_after": after, "source_unchanged": before == after,
            "log": str(OUT / (name + ".log")), "report": str(report)}
    if report.exists():
        raw = report.read_bytes()
        data = json.loads(raw)
        item["report_sha256"] = sha(raw)
        item["summary"] = {key: data.get(key) for key in (
            "archive_accepted", "execution_path", "production_preparation_exercised", "production_gameplay_checks_passed",
            "whole_song_parity_proven", "native_frames", "replayed_frames", "checked_stage_samples", "compared_stage_fields",
            "drawable_coverage_exercised", "native_capture_bounded", "capture_completed_gameplay", "broadcast_params_compared",
            "pending_coverage", "errors", "mismatches") if key in data}
        for key in ("mismatches", "errors"):
            if isinstance(item["summary"].get(key), list):
                item["summary"][key + "_count"] = len(item["summary"][key])
                item["summary"][key] = item["summary"][key][:8]
        if isinstance(data.get("production_replay"), dict):
            production = data["production_replay"]
            item["production_summary"] = {key: production.get(key) for key in (
                "production_gameplay_checks_passed", "production_preparation_exercised", "native_frames", "replayed_frames",
                "checked_stage_samples", "compared_stage_fields", "drawable_coverage_exercised", "native_capture_bounded", "pending_coverage") if key in production}
            item["production_summary"].update({key + "_count": len(production.get(key, [])) for key in ("errors", "mismatches")})
        if target == "full_song_lua":
            item["scope"] = "Combined diagnostic and production archive acceptance, preserving report pending coverage"
            item["checks_passed"] = result.returncode == 0 and data.get("archive_accepted") is True and item["source_unchanged"]
        elif not diagnostic:
            item["scope"] = "Native control gameplay and captured-draw checks only; no full-gameplay archive or pixel acceptance claim"
            item["checks_passed"] = (item["source_unchanged"] and result.returncode in (0, 2)
                and data.get("execution_path") == "production-live-lua" and data.get("production_preparation_exercised") is True
                and data.get("native_frames", 0) > 0 and data.get("replayed_frames") == data["native_frames"]
                and data.get("checked_stage_samples", 0) > 0 and data.get("compared_stage_fields", 0) > 0
                and data.get("errors") == [] and data.get("mismatches") == []
                and data.get("interactive", {}).get("draw_mismatches") == 0)
        else:
            item["scope"] = "Bounded diagnostic command/query and source-broadcast semantics only; no archive or visual acceptance claim"
            item["checks_passed"] = (item["source_unchanged"] and result.returncode in (0, 2)
                and data.get("execution_path") == "diagnostic-live-lua"
                and data.get("native_frames", 0) > 0 and data.get("replayed_frames") == data["native_frames"]
                and data.get("checked_stage_samples", 0) > 0 and data.get("compared_stage_fields", 0) > 0
                and data.get("errors") == [] and data.get("mismatches") == []
                and data.get("command_queries", {}).get("compared") is True
                and data.get("broadcast_params_compared") is True
                and len(data.get("native_broadcasts", [])) > 0
                and len(data.get("lua_broadcasts", [])) == len(data["native_broadcasts"]))
    else:
        item["checks_passed"] = False
    receipt["cases"].append(item)
    (OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in item.items() if key not in ("command", "source_before", "source_after")}), flush=True)
print(json.dumps({"output_directory": str(OUT)}), flush=True)
raise SystemExit(0 if all(case.get("checks_passed") for case in receipt["cases"]) else 1)
