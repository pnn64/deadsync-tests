"""Capture source identities and gates for independent played-stage statistics."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
STAMP = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
OUT = TASK / ("corpus-audit-history-controls-" + STAMP)
OUT.mkdir()


def identity(name):
    result = {}
    for suffix, cwd in (("source", ROOT), ("fixtures", ROOT / "tests/fixtures")):
        data = subprocess.check_output(["git", "diff", "--binary", "--full-index", "HEAD"], cwd=cwd)
        (OUT / (name + "-" + suffix + ".patch")).write_bytes(data)
        result[suffix] = {
            "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=cwd, text=True).strip(),
            "patch_sha256": hashlib.sha256(data).hexdigest(),
        }
    return result


base = ["cargo", "test", "--locked", "-j", "4", "-p", "deadsync-song-lua", "--features", "test-support"]
serial = ["--", "--test-threads=1", "--nocapture"]
commands = [
    ("diff-check", ["git", "diff", "--check"]),
    ("statistics", base + ["--test", "statistics"] + serial),
    ("transitions", base + ["--test", "transitions"] + serial),
    ("bitmap-text", base + ["--test", "bitmap_text"] + serial),
    ("live-gameplay", base + ["--test", "live_gameplay"] + serial),
    ("sampler", base + ["--test", "playback", "playback::tests::song_lua_sprite_glow_draws_once_with_native_blend_and_sampler", "--", "--exact", "--nocapture"]),
    ("playback", base + ["--test", "playback"] + serial),
    ("native-archives", [sys.executable, "-X", "utf8", str(TASK / "corpus_audit_native_controls.py"), "--case", "cold", "--case", "vtubers", "--case", "modulo"]),
    ("native-genshin", [sys.executable, "-X", "utf8", str(TASK / "corpus_audit_native_controls.py"), "--case", "genshin"]),
]
if sys.argv[1:]:
    requested = set(sys.argv[1:])
    known = {name for name, _ in commands}
    if not requested <= known:
        raise SystemExit('Unknown gate: ' + ', '.join(sorted(requested - known)))
    commands = [(name, command) for name, command in commands if name in requested]
receipt = {"created_at": STAMP, "commands": [], "scope": "Committed-stage, reload and native sampler gates; preserved native inputs."}
for name, command in commands:
    before = identity(name + "-before")
    print(json.dumps({"case": name, "starting": True, "source": before}), flush=True)
    log_path = OUT / (name + ".log")
    with log_path.open("wb") as log:
        completed = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    after = identity(name + "-after")
    contents = log_path.read_text(encoding="utf-8", errors="replace")
    item = {
        "name": name, "command": command, "exit_code": completed.returncode,
        "source_before": before, "source_after": after, "source_unchanged": before == after,
        "log": str(log_path), "log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
        "result_lines": [line for line in contents.splitlines() if line.startswith("test result:")],
        "tail": contents.splitlines()[-14:],
    }
    receipt["commands"].append(item)
    (OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in item.items() if key not in ("command", "source_before", "source_after")}), flush=True)
print(json.dumps({"output_directory": str(OUT)}), flush=True)
sys.exit(0 if all(row["exit_code"] == 0 and row["source_unchanged"] for row in receipt["commands"]) else 1)
